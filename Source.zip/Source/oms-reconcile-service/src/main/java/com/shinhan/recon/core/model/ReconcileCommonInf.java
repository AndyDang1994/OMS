package com.shinhan.recon.core.model;

public class ReconcileCommonInf {

	private Long id;
	private String remarkNote;
	private String type;
	public ReconcileCommonInf() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ReconcileCommonInf(Long id, String remarkNote, String type) {
		super();
		this.id = id;
		this.remarkNote = remarkNote;
		this.type = type;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getRemarkNote() {
		return remarkNote;
	}
	public void setRemarkNote(String remarkNote) {
		this.remarkNote = remarkNote;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
	
}
