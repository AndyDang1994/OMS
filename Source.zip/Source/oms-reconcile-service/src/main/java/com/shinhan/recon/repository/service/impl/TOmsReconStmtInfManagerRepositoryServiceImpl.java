/**
 * 
 */
package com.shinhan.recon.repository.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.BankDailyReportInf;
import com.shinhan.recon.core.model.BankFileReconResult;
import com.shinhan.recon.core.model.BankStatemenTrxInfo;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.dao.TOmsReconStmtInfDAO;
import com.shinhan.recon.repository.entity.TMetadata;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;
import com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("tomsReconStmtInfManagerRepositoryService")
public class TOmsReconStmtInfManagerRepositoryServiceImpl extends AbstractServiceClass
		implements TOmsReconStmtInfManagerRepositoryService {

	private TOmsReconStmtInfDAO objectDao;

	@Autowired
	public TOmsReconStmtInfManagerRepositoryServiceImpl(TOmsReconStmtInfDAO objectDao) {
		this.objectDao = objectDao;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#
	 * getListTrxByDate(java.util.Map)
	 */
	@Override
	public List<TOmsReconStmtInf> getListTrxByDate(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconStmtInf> list = new ArrayList<>();
		String startDt = inputParams.get(APIConstant._START_DATE_KEY).toString();
		String endDt = inputParams.get(APIConstant._END_DATE_KEY).toString();
		String status = inputParams.get(APIConstant._STATUS_KEY).toString();
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String sql = oracleOMSNamedQueries.get("getOmsDataByDate");
		
		Query query = entityManager.createNativeQuery(sql,TOmsReconStmtInf.class);
		query.setParameter(APIConstant._START_DATE_KEY,DateUtils.converToDate(startDt));
		query.setParameter(APIConstant._END_DATE_KEY,  DateUtils.converToDate(endDt));
		query.setParameter(APIConstant._STATUS_KEY,status);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		
		list = query.getResultList();
		return list;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#
	 * create(java.util.Map)
	 */
	@Override
	public boolean create(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconStmtInf item = (TOmsReconStmtInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#
	 * createAll(java.util.Map)
	 */
	@Override
	public boolean createAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconStmtInf> items = (List<TOmsReconStmtInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#
	 * getOne(java.util.Map)
	 */
	@Override
	public TOmsReconStmtInf getOne(Map<String, Object> inputParams) throws BaseException {
		String omsId = inputParams.get(APIConstant.OMSID).toString();
		if (StringUtils.isBlank(omsId)) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_003"));
		}
		try {
			TOmsReconStmtInf item = objectDao.findById(Long.valueOf(omsId)).get();
			return item;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + omsId + "");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#
	 * update(java.util.Map)
	 */
	@Override
	public boolean update(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconStmtInf item = (TOmsReconStmtInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#updateAll(java.util.Map)
	 */
	@Override
	public boolean updateAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconStmtInf> items = (List<TOmsReconStmtInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#countTotalBankStatementTrxByDate(java.util.Map)
	 */
	@Override
	public BigDecimal countTotalBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT count( distinct lms.ID) "
					+ "FROM OMS_RECON_LMS_INF lms, OMS_RECON_STMT_INF bank "
					+ "WHERE bank.BANK_CODE = lms.BANK_CODE and lms.STATUS = bank.STATUS and lms.REF_ID = bank.REF_ID "
					+ "and bank.VALUE_DT BETWEEN :fromDt and :endDt "
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS =:statusCode "
					+ "and lms.TRANSACTION_TYPE = :transactionType "
					+ "and (:ref is NULL or lms.REF_NO =:ref) "
					+ "and (:loanNo is NULL or lms.LOAN_NO =:loanNo) "
					+ "and (:payMode is NULL or lms.PAYMODE =:payMode) "
					+ "and (:cif is NULL or lms.CIF =:cif) ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			
			query.setParameter("statusCode", APIConstant._BANK_STATEMENT_MATCH_STATUS);
			
			query.setParameter("ref", inputParams.get(APIConstant.REF_KEY).toString());
			query.setParameter("loanNo", inputParams.get(APIConstant.LOAN_NO_KEY).toString());
			long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
					? 0
					: Long.parseLong(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
			query.setParameter(APIConstant.UPLOAD_TRXTYPE_KEY, trxType);
			query.setParameter("payMode", inputParams.get(APIConstant.PAY_MODE_KEY).toString());
			query.setParameter("cif", inputParams.get(APIConstant.CIF_KEY).toString());
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	@Override
	public BankDailyReportInf getStatisticInf(Map<String, Object> inputParams) throws BaseException {
		try {
			String ref = inputParams.get(APIConstant.REF_KEY).toString();
//			String sql = "with tmp as ( "
//					+ "select to_date(:fromDt,'DD/MM/YYYY') + level -1 as trx_dt "
//					+ "from dual  "
//					+ "connect by level <=to_date(:endDt,'DD/MM/YYYY') - to_date(:fromDt,'DD/MM/YYYY') "
//					+ "), "
//					+ "tmp_status as( "
//					+ oracleOMSNamedQueries.get("maketabletemptatus")
//					+ ") "
//					+ "select * from ("
//					+ "select * from ( "
//					+ "select tmp_bank.VALUE as BANK_CODE,tmp_status.label as status,TO_CHAR(tmp.trx_dt,'DD/MM/YYYY') as trx_dt, count(a.trx_dt) as cnt "
//					+ "from oms_recon_stmt_inf a, tmp , tmp_status,OMS_METADATA tmp_bank "
//					+ "where a.trx_dt(+) = tmp.trx_dt "
//					+ "and a.STATUS(+) =tmp_status.STATUS "
//					+ "AND tmp_bank.LOOKUPCODE = 'BANK_CODE' "
//					+ "and a.bank_code(+) = tmp_bank.LOOKUPCODEID "
//					+ "group by tmp_bank.VALUE,tmp_status.status, tmp.trx_dt) "
//					+ "pivot ( sum(cnt) for trx_dt in ( " +ref + ") ) "
//					+ ") order by BANK_CODE";
			String[] dates = ref.split(",");
			if(inputParams.containsKey(APIConstant.UPLOAD_TRXTYPE_KEY)) {
				inputParams.remove(APIConstant.UPLOAD_TRXTYPE_KEY);
			}
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
			List<TOmsStmtFileMas> filemas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getListUploadByBankCode(inputParams); 
			List<TMetadata> metas = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant._LOOKUP_CODE_BANK_VALUE_);
//			Query query = entityManager.createNativeQuery(sql);
//			
//			query.setParameter("fromDt", inputParams.get(APIConstant._START_DATE_KEY).toString());
//			query.setParameter("endDt", inputParams.get(APIConstant._END_DATE_KEY).toString());
			BankDailyReportInf bankDailyReportInf = new BankDailyReportInf();
			List<Object[]> rs = new ArrayList<>();
			for (TMetadata objects : metas) {
				
				Object[] matchedList = new Object[dates.length + 3];
				matchedList[0] = objects.getValue();
				matchedList[1] = "Match data  Bank statement vs LMS";
				Object[] pendingList = new Object[dates.length + 3];
				pendingList[0] = objects.getValue();
				pendingList[1] = "Unmatch data  Bank statement vs LMS";
				Object[] revertList = new Object[dates.length + 3];
				revertList[0] = objects.getValue();
				revertList[1] = "Revert cheque";
				Object[] refundList = new Object[dates.length + 3];
				refundList[0] = objects.getValue();
				refundList[1] = "Refund/Cancel cheque";
				
				for( int idx = 0 ; idx < dates.length; idx++ ) {
					if(filemas.size() < 1 ) {
						matchedList[2 + idx] =0;
						pendingList[2+ idx] = 0;
						revertList[2 + idx] = 0;
						refundList[2 + idx] = 0;
					}
					for (TOmsStmtFileMas file : filemas) {
						if( file.getBankCode().equals(objects.getLookupCodeId()) && 
								DateUtils.formatToString(file.getUploadDt(), DateUtils.DATEFORMAT).equals(dates[idx].replaceAll("'", "")) ) {
							BankFileReconResult bankfile = DTOConverter.getBankFileReconResult(file);
							matchedList[2 + idx] =(matchedList[2 + idx] !=null ? (int)matchedList[2 + idx]: 0) + bankfile.getMatchedCnt();
							pendingList[2+ idx] = (pendingList[2+ idx] != null ? (int)pendingList[2+ idx] : 0) + bankfile.getPendingCnt();
							revertList[2 + idx] = (revertList[2 + idx] != null ? (int)revertList[2 + idx] : 0 ) +  bankfile.getRevertCnt();
							refundList[2 + idx] = (refundList[2 + idx] != null ? (int)refundList[2 + idx] : 0 ) + bankfile.getRefundCnt();
							
						}
					}
				}
				rs.add(matchedList);
				rs.add(pendingList);
				rs.add(revertList);
				rs.add(refundList);
				
			}
			bankDailyReportInf.setData(rs);
			return bankDailyReportInf;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002"));
		}
	}
	@Override
	public BankDailyReportInf getDailyCollStmtInf(Map<String, Object> inputParams) throws BaseException {
		try {
			String ref = inputParams.get(APIConstant.REF_KEY).toString();
//			String sql = "with tmp as ( "
//					+ "select to_date(:fromDt,'DD/MM/YYYY') + level -1 as trx_dt "
//					+ "from dual  "
//					+ "connect by level <=to_date(:endDt,'DD/MM/YYYY') - to_date(:fromDt,'DD/MM/YYYY') "
//					+ ") "
//					+ "select * from ( "
//					+ "select tmp_bank.VALUE as BANK_CODE,"
//					+ oracleOMSNamedQueries.get("getsumcollstmt") + ",TO_CHAR(tmp.trx_dt,'DD/MM/YYYY') as trx_dt "
//					+ "from oms_recon_stmt_inf a, tmp,OMS_METADATA tmp_bank "
//					+ "where a.trx_dt(+) = tmp.trx_dt "
//					+ "AND tmp_bank.LOOKUPCODE = 'BANK_CODE' "
//					+ "and a.status not in ('7','11') "
//					+ "and a.bank_code(+) = tmp_bank.LOOKUPCODEID "
//					+ "group by tmp_bank.VALUE, tmp.trx_dt) "
//					+ "pivot ( sum(amt) for trx_dt in ( " +ref + ") ) ";
			String sql = "with tmp as ( "
					+ "select to_date(:fromDt,'DD/MM/YYYY') + level -1 as trx_dt "
					+ "from dual  "
					+ "connect by level <=to_date(:endDt,'DD/MM/YYYY') - to_date(:fromDt,'DD/MM/YYYY') "
					+ ") "
					+ "select * from ( "
					+ "select tmp_bank.VALUE as BANK_CODE,"
					+ oracleOMSNamedQueries.get("getsumcollstmt") + ",TO_CHAR(f.upload_dt,'DD/MM/YYYY') as trx_dt "
					+ "from oms_recon_stmt_inf a, tmp,OMS_METADATA tmp_bank, oms_stmt_file_mas f "
					+ "where f.upload_dt(+) = tmp.trx_dt "
					+ "AND tmp_bank.LOOKUPCODE = 'BANK_CODE' "
					+ "and a.status not in ('7') "
					+ "and f.bank_code(+) = tmp_bank.LOOKUPCODEID "
					+ "and a.bank_code(+) = tmp_bank.LOOKUPCODEID "
					+ "and f.id = a.ref_id_file_mas(+) "
					+ "group by tmp_bank.VALUE, f.upload_dt) "
					+ "pivot ( sum(amt) for trx_dt in ( " +ref + ") ) ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", inputParams.get(APIConstant._START_DATE_KEY).toString());
			query.setParameter("endDt", inputParams.get(APIConstant._END_DATE_KEY).toString());
			BankDailyReportInf bankDailyReportInf = new BankDailyReportInf();
			bankDailyReportInf.setData(query.getResultList());
			return bankDailyReportInf;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002"));
		}
	}
	@Override
	public BankDailyReportInf getStatisticDisbInf(Map<String, Object> inputParams) throws BaseException {
		try {
			String ref = inputParams.get(APIConstant.REF_KEY).toString();
			String[] dates = ref.split(",");
			if(inputParams.containsKey(APIConstant.UPLOAD_TRXTYPE_KEY)) {
				inputParams.remove(APIConstant.UPLOAD_TRXTYPE_KEY);
			}
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
			List<TOmsStmtFileMas> filemas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getListUploadByBankCode(inputParams); 
			List<TMetadata> metas = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant._LOOKUP_CODE_BANK_DISB_VALUE_);
//			Query query = entityManager.createNativeQuery(sql);
//			
//			query.setParameter("fromDt", inputParams.get(APIConstant._START_DATE_KEY).toString());
//			query.setParameter("endDt", inputParams.get(APIConstant._END_DATE_KEY).toString());
			BankDailyReportInf bankDailyReportInf = new BankDailyReportInf();
			List<Object[]> rs = new ArrayList<>();
			for (TMetadata objects : metas) {
				
				Object[] matchedList = new Object[dates.length + 3];
				matchedList[0] = objects.getValue();
				matchedList[1] = "Disbursement";
				Object[] pendingList = new Object[dates.length + 3];
				pendingList[0] = objects.getValue();
				pendingList[1] = "Pending disbursement/excess money";
				Object[] revertList = new Object[dates.length + 3];
				revertList[0] = objects.getValue();
				revertList[1] = "Reverted";
				Object[] refundList = new Object[dates.length + 3];
				refundList[0] = objects.getValue();
				refundList[1] = "Refund";
				Object[] reDisbList = new Object[dates.length + 3];
				reDisbList[0] = objects.getValue();
				reDisbList[1] = "Re-disbursement";
				
				for( int idx = 0 ; idx < dates.length; idx++ ) {
					if(filemas.size() < 1 ) {
						matchedList[2 + idx] =0;
						pendingList[2+ idx] = 0;
						revertList[2 + idx] = 0;
						refundList[2 + idx] = 0;
						reDisbList[2 + idx] = 0;
					}
					for (TOmsStmtFileMas file : filemas) {
						if( file.getBankCode().equals(objects.getLookupCodeId()) && 
								DateUtils.formatToString(file.getUploadDt(), DateUtils.DATEFORMAT).equals(dates[idx].replaceAll("'", "")) ) {
							BankFileReconResult bankfile = DTOConverter.getBankFileReconResult(file);
							matchedList[2 + idx] =(matchedList[2 + idx] !=null ? (int)matchedList[2 + idx]: 0) + bankfile.getMatchedCnt();
							pendingList[2+ idx] = (pendingList[2+ idx] != null ? (int)pendingList[2+ idx] : 0) + bankfile.getPendingCnt();
							revertList[2 + idx] = (revertList[2 + idx] != null ? (int)revertList[2 + idx] : 0 ) +  bankfile.getRevertCnt();
							refundList[2 + idx] = (refundList[2 + idx] != null ? (int)refundList[2 + idx] : 0 ) + bankfile.getRefundCnt();
							reDisbList[2 + idx] = (reDisbList[2 + idx] != null ? (int)reDisbList[2 + idx] : 0 ) + bankfile.getRedisbCnt();
							
						}else {
							matchedList[2 + idx] =0;
							pendingList[2+ idx] = 0;
							revertList[2 + idx] = 0;
							refundList[2 + idx] = 0;
							reDisbList[2 + idx] = 0;
						}
					}
				}
				
				rs.add(matchedList);
				rs.add(refundList);
				rs.add(reDisbList);
				rs.add(pendingList);
				rs.add(revertList);
			}
			bankDailyReportInf.setData(rs);
			return bankDailyReportInf;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002"));
		}
	}
	@Override
	public BankDailyReportInf getSummaryStatisticInf(Map<String, Object> inputParams) throws BaseException {
		try {
//			String sql = "select b.value as bank_name, sum(case when a.trx_dt = to_date(:trxDt,'DD/MM/YYYY') -1 and a.status <>'11' then 1 else 0 end ) as cnt, "
//					+ "sum(case when a.trx_dt = to_date(:trxDt,'DD/MM/YYYY') -1 and a.status <>'11' then a.cr_amt else 0 end ) as recon_amt, "
//					+ "sum( case when a.status = 11 and a.trx_dt = to_date(:trxDt,'DD/MM/YYYY') then a.cr_amt else 0 end ) as bank_amt, '' as bal, '' as fee_amt, '' as note  "
//					+ "from oms_recon_stmt_inf a, oms_metadata b "
//					+ "where a.bank_code(+) = b.lookupcodeid "
//					+ "and b.lookupcode = 'BANK_CODE' "
//					+ "and a.status not in ('7','5') " // exclude deleted, finance, and finance for daily report status
//					+ "and 'N' = (select c.is_bank_yn from oms_bank_common c where c.bank_acc_num = b.lookupcodeid and rownum =1  ) "
//					+ "and a.trx_dt(+) between  to_date(:trxDt,'DD/MM/YYYY') -1 and to_date(:trxDt,'DD/MM/YYYY') "
//					+ "group by b.value "
//					+ "union "
//					+ "select 'Dong A' as bank_name ,sum(case when a.trx_dt = to_date(:trxDt,'DD/MM/YYYY') -1 and a.status <>'11' then 1 else 0 end ) as cnt, "
//					+ "sum(case when a.trx_dt = to_date(:trxDt,'DD/MM/YYYY') -1 and a.status <>'11' then a.cr_amt else 0 end ) as recon_amt, "
//					+ "sum( case when a.status = 11 and a.trx_dt = to_date(:trxDt,'DD/MM/YYYY') then a.cr_amt else 0 end ) as bank_amt, '' as bal, '' as fee_amt, '' as note "
//					+ "from oms_recon_stmt_inf a "
//					+ "where a.status not in ('7','5') "
//					+ "and a.trx_dt(+) between  to_date(:trxDt,'DD/MM/YYYY') -1 and to_date(:trxDt,'DD/MM/YYYY') "
//					+ "and a.bank_Code = '0301707061' "
//					+ "group by a.bank_Code  ";
			String sql = "select b.value as bank_name, sum(case when f.upload_dt = to_date(:trxDt,'DD/MM/YYYY') -1 and a.status not in ('11','6') and f.id = a.ref_id_file_mas then 1 else 0 end ) as cnt, "
					+ "sum(case when f.upload_dt = to_date(:trxDt,'DD/MM/YYYY') -1 and a.status not in ('11','6') and f.id = a.ref_id_file_mas then a.cr_amt else 0 end ) as recon_amt, "
					+ "sum( case when a.status in ('11','6') and f.upload_dt = to_date(:trxDt,'DD/MM/YYYY')and f.id = a.ref_id_file_mas then a.cr_amt else 0 end ) as bank_amt, '' as bal, '' as fee_amt, '' as note  "
					+ "from oms_recon_stmt_inf a, oms_metadata b, oms_stmt_file_mas f "
					+ "where a.bank_code(+) = b.lookupcodeid "
					+ "and f.bank_code(+) = b.lookupcodeid "
					+ "and b.lookupcode = 'BANK_CODE' "
					+ "and f.id = a.ref_id_file_mas(+) "
					+ "and a.status(+) not in ('7','5') " // exclude deleted, finance, and finance for daily report status
					+ "and 'N' = (select c.is_bank_yn from oms_bank_common c where c.bank_acc_num = b.lookupcodeid and rownum =1  ) "
					+ "and f.upload_dt(+) between  to_date(:trxDt,'DD/MM/YYYY') -1 and to_date(:trxDt,'DD/MM/YYYY') "
					+ "group by b.value "
					+ "union "
					+ "select 'Dong A' as bank_name ,sum(case when f.upload_dt = to_date(:trxDt,'DD/MM/YYYY') -1 and a.status not in ('11','6') and f.id = a.ref_id_file_mas then 1 else 0 end ) as cnt, "
					+ "sum(case when f.upload_dt = to_date(:trxDt,'DD/MM/YYYY') -1 and a.status not in ('11','6') and f.id = a.ref_id_file_mas then a.cr_amt else 0 end ) as recon_amt, "
					+ "sum( case when a.status in ('11','6') and f.upload_dt = to_date(:trxDt,'DD/MM/YYYY')and f.id = a.ref_id_file_mas then a.cr_amt else 0 end ) as bank_amt, '' as bal, '' as fee_amt, '' as note "
					+ "from oms_recon_stmt_inf a, oms_metadata b, oms_stmt_file_mas f "
					+ "where a.status(+) not in ('7','5') "
					+ "and a.bank_code(+) = b.lookupcodeid "
					+ "and f.bank_code(+) = b.lookupcodeid "
					+ "and b.lookupcode = 'BANK_CODE' "
					+ "and b.lookupcodeid  = '0301707061' "
					+ "and f.upload_dt(+) between  to_date(:trxDt,'DD/MM/YYYY') -1 and to_date(:trxDt,'DD/MM/YYYY') "
					+ "group by b.value  ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("trxDt", inputParams.get(APIConstant.TRX_DATE_KEY).toString());
			BankDailyReportInf bankDailyReportInf = new BankDailyReportInf();
			bankDailyReportInf.setData(query.getResultList());
			return bankDailyReportInf;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#getListBankStatementTrxByDate(java.util.Map)
	 */
	@Override
	public List<BankStatementLmsTrxInfo> getListBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT new com.shinhan.recon.core.model.BankStatementLmsTrxInfo("
					+ "bank.id as id, bank.refNo as refNo, bank.trxDt as trxDt, bank.bankCode as bankCode, "
					+ "bank.drAmt as drAmt, bank.crAmt as crAmt, bank.loanNo as loanNo, "
					+ "bank.statusCode as statusCode, bank.subStatusCode as subStatusCode, bank.remark as remark, bank.remarkNote as remarkNote, "
					+ "lms.id as idLMS, lms.refNo as refNoLMS, lms.bankCode as bankCodeLMS, lms.trxDt as trxDtLMS, "
					+ "lms.valueDt as valueDtLMS, lms.cif as cifLMS, lms.paymode as paymodeLMS, "
					+ "lms.drAmt as drAmtLMS, lms.crAmt as crAmtLMS, lms.loanNo as loanNoLMS, "
					+ "lms.statusCode as statusCodeLMS, lms.subStatusCode as subStatusCodeLMS, lms.remark as remarkLMS, lms.remarkNote as remarkNoteLMS"
					+ ") "
					+ "FROM TOmsReconLmsInf lms, TOmsReconStmtInf bank "
					+ "WHERE bank.bankCode = lms.bankCode and lms.statusCode = bank.statusCode "
					+ "and lms.refID = bank.refID "
					+ "and bank.valueDt BETWEEN :fromDt and :endDt "
					+ "and lms.bankCode =:bankCode and lms.statusCode =:statusCode "
					+ "and (:ref is NULL or lms.refNo =:ref) "
					+ "and (:loanNo is NULL or lms.loanNo =:loanNo) "
					+ "and (:payMode is NULL or lms.paymode =:payMode) "
					+ "and (:cif is NULL or lms.cif =:cif) ";
			
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			Query query = entityManager.createQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant._BANK_STATEMENT_MATCH_STATUS));
			
			query.setParameter("ref", inputParams.get(APIConstant.REF_KEY).toString());
			query.setParameter("loanNo", inputParams.get(APIConstant.LOAN_NO_KEY).toString());
			query.setParameter("payMode", inputParams.get(APIConstant.PAY_MODE_KEY).toString());
			query.setParameter("cif", inputParams.get(APIConstant.CIF_KEY).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			List<BankStatementLmsTrxInfo> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#countTotalUnmatchBankStatementTrxByDate(java.util.Map)
	 */
	@Override
	public BigDecimal countTotalUnmatchBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT count( distinct bank.ID) "
					+ "FROM OMS_RECON_STMT_INF bank "
					+ "WHERE "
					+ "bank.VALUE_DT BETWEEN :fromDt and :endDt "
					+ "and bank.BANK_CODE =:bankCode "
					+ "and bank.STATUS not in (1) "
					+ "and bank.REF_ID is NULL "
					+ "and DECODE(:statusCode,0,bank.STATUS,:statusCode) = bank.STATUS "
					+ "and (:ref is NULL or bank.REF_NO =:ref) "
					+ "and (:loanNo is NULL or bank.LOAN_NO =:loanNo) ";
			int statusCode = StringUtils.isBlank(inputParams.get(APIConstant._STATUS_KEY).toString())
					? 0
					: Integer.parseInt(inputParams.get(APIConstant._STATUS_KEY).toString());
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", statusCode);
			
			query.setParameter("ref", inputParams.get(APIConstant.REF_KEY).toString());
			query.setParameter("loanNo", inputParams.get(APIConstant.LOAN_NO_KEY).toString());
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	@Override
	public List<BankStatemenTrxInfo> getUnmatchListBankStatementTrxByDate(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT new com.shinhan.recon.core.model.BankStatemenTrxInfo("
					+ "bank.id as id, bank.refNo as refNo, bank.trxDt as trxDt, bank.bankCode as bankCode, "
					+ "bank.drAmt as drAmt, bank.crAmt as crAmt, bank.loanNo as loanNo, "
					+ "bank.statusCode as statusCode, bank.subStatusCode as subStatusCode, bank.remark as remark, bank.remarkNote as remarkNote"
					+ ") "
					+ "FROM TOmsReconStmtInf bank "
					+ "where bank.valueDt BETWEEN :fromDt and :endDt "
					+ "and ( bank.bankCode = :bankCode or :bankCode is null ) "
					+ "and DECODE(:statusCode,0,bank.statusCode,:statusCode) = bank.statusCode "
					+ "and bank.statusCode not in (1) "
					+ "and bank.refID is NULL "
					+ "and (:ref is NULL or bank.refNo =:ref) "
					+ "and (:loanNo is NULL or bank.loanNo =:loanNo) ";
			
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			long statusCode = StringUtils.isBlank(inputParams.get(APIConstant._STATUS_KEY).toString())
							? 0
							: Long.parseLong(inputParams.get(APIConstant._STATUS_KEY).toString());
			
			Query query = entityManager.createQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode",statusCode);
			
			query.setParameter("ref", inputParams.get(APIConstant.REF_KEY).toString());
			query.setParameter("loanNo", inputParams.get(APIConstant.LOAN_NO_KEY).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			List<BankStatemenTrxInfo> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	@Override
	public List<BankStatemenTrxInfo> getListBankStatementTrxByDateAndStatus(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT new com.shinhan.recon.core.model.BankStatemenTrxInfo("
					+ "bank.id as id, bank.refNo as refNo, bank.trxDt as trxDt, bank.bankCode as bankCode, "
					+ "bank.drAmt as drAmt, bank.crAmt as crAmt, bank.loanNo as loanNo, "
					+ "bank.statusCode as statusCode, bank.subStatusCode as subStatusCode, bank.remark as remark, bank.remarkNote as remarkNote"
					+ ") "
					+ "FROM TOmsReconStmtInf bank "
					+ "where bank.valueDt BETWEEN :fromDt and :endDt "
					+ "and bank.bankCode =:bankCode "
					+ "and bank.statusCode = :statusCode "
					+ "and bank.refID is NULL "
					+ "and (:ref is NULL or bank.refNo =:ref) "
					+ "and (:loanNo is NULL or bank.loanNo =:loanNo) ";
			
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
					? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
					? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			long status = inputParams.get(APIConstant._STATUS_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._STATUS_KEY).toString())
					? Long.parseLong(env.getProperty(APIConstant._STATUS_KEY))
							: Long.parseLong(inputParams.get(APIConstant._STATUS_KEY).toString());
			
			Query query = entityManager.createQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode",status);
			
			query.setParameter("ref", inputParams.get(APIConstant.REF_KEY).toString());
			query.setParameter("loanNo", inputParams.get(APIConstant.LOAN_NO_KEY).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			List<BankStatemenTrxInfo> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	@Override
	public List<TOmsReconStmtInf> getStatementByRef(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconStmtInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getStatementByRef");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String refNo = inputParams.get(APIConstant._REF_NO_KEY).toString();
		String crAmtString = inputParams.get(APIConstant._CR_AMT_KEY).toString();
		BigDecimal crAmt = new BigDecimal( StringUtils.isBlank(crAmtString) ? "0" :crAmtString );
		Query query = entityManager.createNativeQuery(sql,TOmsReconStmtInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant._REF_NO_KEY,refNo);
		query.setParameter(APIConstant._CR_AMT_KEY,crAmt);
		list = query.getResultList();
		return list;
	}
	@Override
	public List<TOmsReconStmtInf> getStatementByRevertRef(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconStmtInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getStatementByRevertRef");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String refNo = inputParams.get(APIConstant._REF_NO_KEY).toString();
		String crAmtString = inputParams.get(APIConstant._CR_AMT_KEY).toString();
		BigDecimal crAmt = new BigDecimal( StringUtils.isBlank(crAmtString) ? "0" :crAmtString );
		Query query = entityManager.createNativeQuery(sql,TOmsReconStmtInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant._REF_NO_KEY,refNo);
		query.setParameter(APIConstant._CR_AMT_KEY,crAmt);
		list = query.getResultList();
		return list;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#getMatchListBankStatementTrxByDateAndBankCode(java.util.Map)
	 */
	@Override
	public List<Object[]> getMatchListBankStatementTrxByDateAndBankCode(Map<String, Object> inputParams)
			throws BaseException {
		try {
			List<Object[]> result = new ArrayList<>();
			String sql = "SELECT "
					+ "bank.TRX_DT as trxDt, bank.REF_NO as refNo, bank.REMARK as remark, "
					+ "bank.DR_AMT as drAmt, bank.CR_AMT as crAmt, bank.LOAN_NO as loanNo, "
					+ "lms.TRX_DT as trxDtLMS, lms.REF_NO as refNoLMS, lms.LOAN_NO as loanNoLMS, "
					+ "lms.CIF as cif, lms.PAYMODE as paymode, "
					+ "lms.DR_AMT as drAmtLMS, lms.CR_AMT as crAmtLMS, bank.REMARK_NOTE as remarkLMS "
					+ "FROM OMS_RECON_LMS_INF lms, OMS_RECON_STMT_INF bank "
					+ "WHERE bank.BANK_CODE = lms.BANK_CODE and lms.STATUS = bank.STATUS "
					+ "and lms.REF_ID = bank.REF_ID "
					+ "and bank.VALUE_DT BETWEEN :fromDt and :endDt "
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS =:statusCode "
					+ "ORDER BY bank.REF_NO ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant._BANK_STATEMENT_MATCH_STATUS));
			result =  query.getResultList();
			
			for ( int i = 0; i < result.size(); i ++ ) {
				for(int j = i + 1; j < result.size(); j++) {
					if(result.get(i)[1].equals(result.get(j)[1]) && result.get(i)[4].equals(result.get(j)[4])) {
						for(int idx = 0; idx< 6; idx++) {
							result.get(j)[idx] = " ";
						}
					}else {
						break;
					}
				}
			}
			return result;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	@Override
	public List<Object[]> getCaseHandleListBankStatementTrxByDateAndBankCode(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT "
					+ "bank.TRX_DT as trxDt, bank.REF_NO as refNo, bank.REMARK as remark, "
					+ "bank.DR_AMT as drAmt, bank.CR_AMT as crAmt, bank.LOAN_NO as loanNo, "
					+ "lms.TRX_DT as trxDtLMS, lms.REF_NO as refNoLMS, lms.LOAN_NO as loanNoLMS, "
					+ "lms.CIF as cif, lms.PAYMODE as paymode, "
					+ "lms.DR_AMT as drAmtLMS, lms.CR_AMT as crAmtLMS, '' as remarkLMS "
					+ "FROM OMS_RECON_LMS_INF lms, OMS_RECON_STMT_INF bank "
					+ "WHERE bank.VALUE_DT = bank.TRX_DT and bank.BANK_CODE = lms.BANK_CODE and lms.STATUS = bank.STATUS "
					+ "and lms.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and lms.REF_ID = bank.REF_ID "
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS =:statusCode ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant.LMS_CASE_HANDLED_TRX));
			
			return query.getResultList();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	@Override
	public List<Object[]> getOtherListBankStatementTrxByDateAndBankCode(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT "
					+ "bank.TRX_DT as trxDt, bank.REF_NO as refNo, bank.REMARK as remark, "
					+ "bank.DR_AMT as drAmt, bank.CR_AMT as crAmt, bank.LOAN_NO as loanNo, "
					+ "lms.TRX_DT as trxDtLMS, lms.REF_NO as refNoLMS, lms.LOAN_NO as loanNoLMS, "
					+ "lms.CIF as cif, lms.PAYMODE as paymode, "
					+ "lms.DR_AMT as drAmtLMS, lms.CR_AMT as crAmtLMS, '' as remarkLMS "
					+ "FROM OMS_RECON_LMS_INF lms, OMS_RECON_STMT_INF bank "
					+ "WHERE lms.TRX_DT = bank.TRX_DT and bank.BANK_CODE = lms.BANK_CODE and lms.STATUS = bank.STATUS "
					+ "and lms.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and lms.REF_ID = bank.REF_ID "
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS =:statusCode "
					+ "ORDER BY bank.REF_NO";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant._BANK_STATEMENT_OTHER_CASE_STATUS));
			
			return query.getResultList();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#sumDrAndCrMatchListBankStatementTrxByDateAndBankCode(java.util.Map)
	 */
	@Override
	public BankStatementLmsTrxInfo sumDrAndCrMatchListBankStatementTrxByDateAndBankCode(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT MAX(drAmt) as drAmt, MAX(crAmt) as crAmt, MAX(drAmtLMS) as drAmtLMS, MAX(crAmtLMS) as crAmtLMS from ( "
					+ "SELECT "
					+ "SUM(bank.DR_AMT) as drAmt, SUM(bank.CR_AMT) as crAmt, "
					+ "0 as drAmtLMS, 0 as crAmtLMS "
					+ "FROM OMS_RECON_STMT_INF bank "
					+ "WHERE bank.VALUE_DT BETWEEN :fromDt and :endDt "
					+ "and bank.BANK_CODE =:bankCode and bank.STATUS =:statusCode "
					+ "union all "
					+ "SELECT "
					+ "0 as drAmt, 0 as crAmt, "
					+ "SUM(lms.DR_AMT) as drAmtLMS, SUM(lms.CR_AMT) as crAmtLMS "
					+ "FROM OMS_RECON_LMS_INF lms "
					+ "WHERE lms.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and lms.TRANSACTION_TYPE = :transactionType "
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS =:statusCode "
					+ ")";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant._BANK_STATEMENT_MATCH_STATUS));
			query.setParameter("transactionType", Long.valueOf(APIConstant.LMS_TRX_TYPE_REPAYMENT));
			
			List<Object[]> lst = query.getResultList();
			
			for(Object[] item : lst){
				if(item[0] == null) {
					return new BankStatementLmsTrxInfo(APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
				}
				return new BankStatementLmsTrxInfo(new BigDecimal(item[0] + ""), new BigDecimal(item[1] + "")
						, new BigDecimal(item[2] + ""), new BigDecimal(item[3] + ""));
			}
			return new BankStatementLmsTrxInfo();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#getUnMatchListTrxByDateAndBankCodeAndStatus(java.util.Map)
	 */
	@Override
	public List<Object[]> getUnMatchListTrxByDateAndBankCodeAndStatus(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT "
					+ "bank.TRX_DT as trxDt, bank.REF_NO as refNo, bank.REMARK as remark, "
					+ "bank.DR_AMT as drAmt, bank.CR_AMT as crAmt, bank.LOAN_NO as loanNo, "
					+ "'' as trxDtLMS, '' as refNoLMS, '' as loanNoLMS, "
					+ "'' as cif, '' as paymode, "
					+ "'' as drAmtLMS, '' as crAmtLMS, bank.REMARK_NOTE as remarkLMS "
					+ "FROM OMS_RECON_STMT_INF bank "
					+ "WHERE bank.VALUE_DT BETWEEN :fromDt and :endDt "
					+ "and bank.BANK_CODE =:bankCode and bank.STATUS = :statusCode "
					+ "ORDER BY bank.TRX_DT";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			
			query.setParameter("statusCode", Long.valueOf(inputParams.get(APIConstant._STATUS_KEY).toString()));
			
			return query.getResultList();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#sumDrAndCrUnMatchListBankStatementTrxByDateAndBankCode(java.util.Map)
	 */
	@Override
	public BankStatementLmsTrxInfo sumDrAndCrUnMatchListBankStatementTrxByDateAndBankCode(
			Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT "
					+ "SUM(bank.DR_AMT) as drAmt, SUM(bank.CR_AMT) as crAmt "
					+ "FROM OMS_RECON_STMT_INF bank "
					+ "WHERE "
					+ "bank.VALUE_DT BETWEEN :fromDt and :endDt "
					+ "and bank.STATUS not in ('7')"
					+ "and bank.BANK_CODE =:bankCode and bank.STATUS <> :statusCode ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant._BANK_STATEMENT_MATCH_STATUS));
			
			List<Object[]> lst = query.getResultList();
			
			for(Object[] item : lst){
				if(item[0] == null) {
					return new BankStatementLmsTrxInfo(APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
				}
				return new BankStatementLmsTrxInfo(new BigDecimal(item[0] + ""), new BigDecimal(item[1] + ""), APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
			}
			return new BankStatementLmsTrxInfo();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	@Override
	public List<TOmsReconStmtInf> getListTrxByBankcodeAndDate(Map<String, Object> inputParams) throws BaseException {
		List< TOmsReconStmtInf> rs = new ArrayList<>();
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String trxDt = inputParams.get(APIConstant.TRX_DATE_KEY).toString();
		String sql = oracleOMSNamedQueries.get("getOmsDataByBankCodeAndDate");
		Query query = entityManager.createNativeQuery(sql, TOmsReconStmtInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY, bankCode);
		query.setParameter(APIConstant.TRX_DATE_KEY, DateUtils.convertDate(trxDt, DateUtils.DATEFORMAT));
		rs = query.getResultList();
		return rs;
	}
	@Override
	public List<TOmsReconStmtInf> getListTrxByBankcodeAndFileId(Map<String, Object> inputParams) throws BaseException {
		List< TOmsReconStmtInf> rs = new ArrayList<>();
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String fileId = inputParams.get(APIConstant.FILE_ID).toString();
		String sql = oracleOMSNamedQueries.get("getOmsDataByBankCodeAndFileId");
		Query query = entityManager.createNativeQuery(sql, TOmsReconStmtInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY, bankCode);
		query.setParameter(APIConstant.FILE_ID, fileId);
		rs = query.getResultList();
		return rs;
	}

	@Override
	public List<TOmsReconStmtInf> getListTrxByStatus(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconStmtInf> rs = new ArrayList<>();
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String bankStatus = inputParams.get(APIConstant.UPLOAD_BANKSTATUS_KEY).toString();
		String sql = oracleOMSNamedQueries.get("getOMSDataByBankCode");
		Query query = entityManager.createNativeQuery(sql, TOmsReconStmtInf.class);
		query.setParameter(APIConstant.UPLOAD_BANKCODE_KEY, bankCode);
		query.setParameter(APIConstant.UPLOAD_BANKSTATUS_KEY, bankStatus);
		rs = query.getResultList();
		return rs;
	}

	@Override
	public List<Object[]> getPendingListBankStatementTrxForReport(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT "
					+ "bank.BANK_CODE as bankCode, bank.TRX_DT as trxDt, bank.REF_NO as refNo, bank.REMARK as remark, "
					+ "bank.DR_AMT as drAmt, bank.CR_AMT as crAmt, bank.LOAN_NO as loanNo, bank.REMARK_NOTE as remarkNote "
					+ "FROM  OMS_RECON_STMT_INF bank "
					+ "WHERE bank.VALUE_DT BETWEEN :fromDt and :endDt "
					+ "and bank.BANK_CODE =:bankCode  and bank.STATUS =:statusCode ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant._BANK_STATEMENT_PENDING_STATUS));
			List<Object[]> rs = new ArrayList<>(); 
			rs = query.getResultList();
			if(rs.isEmpty()) {
				Object[] objs = {inputParams.get(APIConstant._BANK_CODE_KEY).toString(), "","","No Data Found"};
				rs.add(objs);
			}
			return rs;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	
}
