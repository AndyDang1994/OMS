package com.shinhan.recon.core.util;

import java.io.File;
import java.io.IOException;

import com.sun.xfile.XFile;
import com.sun.xfile.XFileInputStream;
import com.sun.xfile.XFileOutputStream;

public class NFsUtils {

	
    public static void main(String[] args) {
        //uploadFileToNfs();
        //downLoadFileFromNfs();
    	//downloadViaNFS("\\\\svfcfs01\\OMS_UAT$", "", "", "\\omsrecon","C:/Dung Pham/Project/OMS/Imp/tmp");
    	uploadViaNFS("\\\\svfcfs01\\OMS_UAT$", "", "", "\\bkuprecon", "C:/Dung Pham/Project/OMS/Imp/tmp", "VCB898 04.05.2021.xls");
    }

    public static void downloadViaNFS(final String ip,final String user,final String password,final String dir, String destPath)
	{
    	System.out.println("Test dowload!");
		try {	 
			
			String url = ip+"\\"+dir;             
            		XFile xf = new XFile(url);
     		if (xf.exists())
     		{
     			System.out.println("URL is OK!");
     		}else
     		{
     			System.out.println("URL is bad!");
     			return;
     		}
     		 
     		String [] fileList = xf.list();
     		XFile temp = null;
     		long startTime = System.currentTimeMillis();
     		int filesz = 0;
            for(String file:fileList)
            {
            	temp = new XFile(url+"/"+file);
            	XFileInputStream  in  = new XFileInputStream(temp);
            	File tmp  = new File(destPath + "/" + file); 					// to make temporary directory
                XFileOutputStream out = new XFileOutputStream(destPath + "/" + file);
 
                int c;        
                byte[] buf = new byte[8196];           
                
                		
 
                while ((c = in.read(buf)) > 0) {                
                     filesz += c;                
                     out.write(buf, 0, c);                     
                }            
 
                System.out.println(file +" is downloaded!");       
                in.close();            
                out.close();        
                if (temp.canWrite())
                {
                	temp.delete();
                	System.out.println(file + " is deleted!");
                }else
                {
                	System.out.println(file + " can not be delted!");
                }
            }
                long endTime = System.currentTimeMillis();
                long timeDiff = endTime - startTime;
                int rate = (int) ((filesz /1000) / (timeDiff / 1000.0));
                System.out.println(filesz + " bytes copied @ " + rate + "Kb/sec");
           
            }catch (IOException e) {	    
            	System.out.println(e);        
            }
		
	}
    public static void uploadViaNFS(final String ip,final String user,final String password,final String dir, String resPath,String resFileName)
    {
    	System.out.println("start uploaded!");
    	try {	 
    		
    		String url = ip+"\\"+dir;             
    		
    		XFile temp = null;
    		long startTime = System.currentTimeMillis();
    		int filesz = 0;
    		temp = new XFile(resPath + "/" + resFileName);
			XFileInputStream  in  = new XFileInputStream(temp);					// to make temporary directory
			XFileOutputStream out = new XFileOutputStream(url + "/" +  resFileName);
			
			int c;        
			byte[] buf = new byte[8196];           
			
			
			
			while ((c = in.read(buf)) > 0) {                
				filesz += c;                
				out.write(buf, 0, c);                     
			}            
			
			System.out.println(resFileName +" is uploaded!");       
			in.close();            
			out.close();        
			if (temp.canWrite())
			{
				temp.delete();
				System.out.println(resFileName + " is deleted!");
			}else
			{
				System.out.println(resFileName + " can not be delted!");
			}
    		long endTime = System.currentTimeMillis();
    		long timeDiff = endTime - startTime;
    		int rate = (int) ((filesz /1000) / (timeDiff / 1000.0));
    		System.out.println(filesz + " bytes copied @ " + rate + "Kb/sec");
    		
    	}catch (IOException e) {	    
    		System.out.println(e);        
    	}
    	
    }
}
