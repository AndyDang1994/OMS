/**
 * 
 */
package com.shinhan.recon.service;

import java.io.File;
import java.util.List;
import java.util.Map;

import com.shinhan.recon.core.model.statement.BankStatementCommonTemplate;
import com.shinhan.recon.repository.entity.TBankCommon;

/**
 * @author shds04
 *
 */
public interface ReconcileParser {
	
	public List<BankStatementCommonTemplate> getBankStatement(File file, TBankCommon bankVal, Object bankTemplate, Map<String, String> glBaMap) throws Exception;
	
}
