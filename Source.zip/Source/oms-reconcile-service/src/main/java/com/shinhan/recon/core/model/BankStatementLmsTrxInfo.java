/**
 * 
 */
package com.shinhan.recon.core.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

/**
 * @author shds01
 *
 */
public class BankStatementLmsTrxInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1095014736940613761L;

	/** Bank-statement **/
	private BankStatemenTrxInfo bankStatemenTrxInfo;

	/** lms **/
	private LmsTrxInfo lmsTrxInfo;

	private String errorMessage;

	/**
	 * 
	 */
	public BankStatementLmsTrxInfo() {
		super();
	}

	/**
	 * @param bankStatemenTrxInfo
	 * @param lmsTrxInfo
	 */
	public BankStatementLmsTrxInfo(BankStatemenTrxInfo bankStatemenTrxInfo, LmsTrxInfo lmsTrxInfo) {
		super();
		this.bankStatemenTrxInfo = bankStatemenTrxInfo;
		this.lmsTrxInfo = lmsTrxInfo;
	}

	public BankStatementLmsTrxInfo(long id, String refNo, Date trxDt, String bankCode, BigDecimal drAmt,
			BigDecimal crAmt, String loanNo, Long statusCode, Long subStatusCode, String remark, String remarkNote,
			long idLMS, String refNoLMS, String bankCodeLMS, Date trxDtLMS, Date valueDtLMS, String cifLMS, String paymodeLMS,
			BigDecimal drAmtLMS, BigDecimal crAmtLMS, String loanNoLMS, 
			Long statusCodeLMS, Long subStatusCodeLMS, String remarkLMS, String remarkNoteLMS) {
		super();
		this.bankStatemenTrxInfo = (StringUtils.isBlank(refNo) ? new BankStatemenTrxInfo()
				: new BankStatemenTrxInfo(id, refNo, trxDt, bankCode, drAmt, crAmt, loanNo, statusCode, subStatusCode, remark, remarkNote));
		this.lmsTrxInfo = (StringUtils.isBlank(refNoLMS) ? new LmsTrxInfo()
				: new LmsTrxInfo(idLMS, refNoLMS, bankCodeLMS, trxDtLMS, valueDtLMS, cifLMS, paymodeLMS, drAmtLMS, crAmtLMS, loanNoLMS,
						statusCodeLMS, subStatusCodeLMS, remarkLMS, remarkNoteLMS));
	}
	
	public BankStatementLmsTrxInfo(BigDecimal drAmt, BigDecimal crAmt, BigDecimal drAmtLMS, BigDecimal crAmtLMS) {
		super();
		this.bankStatemenTrxInfo = (new BankStatemenTrxInfo(drAmt, crAmt));
		this.lmsTrxInfo = (new LmsTrxInfo(drAmtLMS, crAmtLMS));
	}

	/**
	 * @return the bankStatemenTrxInfo
	 */
	public BankStatemenTrxInfo getBankStatemenTrxInfo() {
		return bankStatemenTrxInfo;
	}

	/**
	 * @param bankStatemenTrxInfo the bankStatemenTrxInfo to set
	 */
	public void setBankStatemenTrxInfo(BankStatemenTrxInfo bankStatemenTrxInfo) {
		this.bankStatemenTrxInfo = bankStatemenTrxInfo;
	}

	/**
	 * @return the lmsTrxInfo
	 */
	public LmsTrxInfo getLmsTrxInfo() {
		return lmsTrxInfo;
	}

	/**
	 * @param lmsTrxInfo the lmsTrxInfo to set
	 */
	public void setLmsTrxInfo(LmsTrxInfo lmsTrxInfo) {
		this.lmsTrxInfo = lmsTrxInfo;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
