/**
 * 
 */
package com.shinhan.recon.disburs.service;

import java.io.File;
import java.util.List;

import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsReconDisburInf;

/**
 * @author shds04
 *
 */
public interface ReconcileDisbursalProcessCitibankService {
	public void processReconcileBankDisbursalCitibank(File file, List<TBankCommon> tBankCommons) throws Exception;

	public List<TOmsReconDisburInf> getCrShieldList(List<TOmsReconDisburInf> tOmsReconDisburInfs, String regex) throws Exception;
}
