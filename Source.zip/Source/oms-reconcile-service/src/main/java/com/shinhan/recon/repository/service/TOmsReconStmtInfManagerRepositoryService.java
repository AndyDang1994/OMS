/**
 * 
 */
package com.shinhan.recon.repository.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.model.BankDailyReportInf;
import com.shinhan.recon.core.model.BankStatemenTrxInfo;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;

/**
 * @author shds01
 *
 */
public interface TOmsReconStmtInfManagerRepositoryService {

	public List<TOmsReconStmtInf> getListTrxByDate(Map<String, Object> inputParams) throws BaseException;

	public BankDailyReportInf getStatisticInf(Map<String, Object> inputParams) throws BaseException;

	public List<TOmsReconStmtInf> getListTrxByStatus(Map<String, Object> inputParams) throws BaseException;

	public List<TOmsReconStmtInf> getListTrxByBankcodeAndDate(Map<String, Object> inputParams) throws BaseException;
	
	public List<TOmsReconStmtInf> getStatementByRef(Map<String, Object> inputParams) throws BaseException;

	public List<TOmsReconStmtInf> getStatementByRevertRef(Map<String, Object> inputParams) throws BaseException;
	
	public boolean create(Map<String, Object> inputParams) throws BaseException;
	
	public boolean createAll(Map<String, Object> inputParams) throws BaseException;
	
	public TOmsReconStmtInf getOne(Map<String, Object> inputParams) throws BaseException;
	
	public boolean update(Map<String, Object> inputParams) throws BaseException;
	
	public boolean updateAll(Map<String, Object> inputParams) throws BaseException;
	
	public BigDecimal countTotalBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException;

	public List<BankStatementLmsTrxInfo> getListBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException;
	
	public BigDecimal countTotalUnmatchBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException;
	
	public List<BankStatemenTrxInfo> getUnmatchListBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException;
	
	public List<Object[]> getMatchListBankStatementTrxByDateAndBankCode(Map<String, Object> inputParams) throws BaseException;

	public List<Object[]> getPendingListBankStatementTrxForReport(Map<String, Object> inputParams) throws BaseException;
	
	public BankStatementLmsTrxInfo sumDrAndCrMatchListBankStatementTrxByDateAndBankCode(Map<String, Object> inputParams) throws BaseException;
	
	public List<Object[]> getUnMatchListTrxByDateAndBankCodeAndStatus(Map<String, Object> inputParams) throws BaseException;
	
	public BankStatementLmsTrxInfo sumDrAndCrUnMatchListBankStatementTrxByDateAndBankCode(Map<String, Object> inputParams) throws BaseException;

	public List<Object[]> getCaseHandleListBankStatementTrxByDateAndBankCode(Map<String, Object> inputParams)
			throws BaseException;

	/**
	 * @param inputParams
	 * @return
	 * @throws BaseException
	 */
	public List<BankStatemenTrxInfo> getListBankStatementTrxByDateAndStatus(Map<String, Object> inputParams)
			throws BaseException;

	/**
	 * @param inputParams
	 * @return
	 * @throws BaseException
	 */
	public List<Object[]> getOtherListBankStatementTrxByDateAndBankCode(Map<String, Object> inputParams) throws BaseException;

	/**
	 * @param inputParams
	 * @return
	 * @throws BaseException
	 */
	public BankDailyReportInf getSummaryStatisticInf(Map<String, Object> inputParams) throws BaseException;

	public BankDailyReportInf getStatisticDisbInf(Map<String, Object> inputParams) throws BaseException;

	public List<TOmsReconStmtInf> getListTrxByBankcodeAndFileId(Map<String, Object> inputParams) throws BaseException;

	public BankDailyReportInf getDailyCollStmtInf(Map<String, Object> inputParams) throws BaseException;
}
