/**
 * 
 */
package com.shinhan.recon.report.model.bank;

import java.math.BigDecimal;

/**
 * @author shds04
 *
 */
public class DailyReportSummaryData {

	private String bankName;
	private long totalCount;
	private BigDecimal reconAmt;
	private BigDecimal bankAmt;
	private BigDecimal balcAmt;
	private BigDecimal feeAmt;
	private String remark;
	public DailyReportSummaryData() {
		super();
	}
	public DailyReportSummaryData(String bankName, long totalCount, BigDecimal reconAmt, BigDecimal bankAmt,
			BigDecimal balcAmt, BigDecimal feeAmt, String remark) {
		super();
		this.bankName = bankName;
		this.totalCount = totalCount;
		this.reconAmt = reconAmt;
		this.bankAmt = bankAmt;
		this.balcAmt = balcAmt;
		this.feeAmt = feeAmt;
		this.remark = remark;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public long getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}
	public BigDecimal getReconAmt() {
		return reconAmt;
	}
	public void setReconAmt(BigDecimal reconAmt) {
		this.reconAmt = reconAmt;
	}
	public BigDecimal getBankAmt() {
		return bankAmt;
	}
	public void setBankAmt(BigDecimal bankAmt) {
		this.bankAmt = bankAmt;
	}
	public BigDecimal getBalcAmt() {
		return balcAmt;
	}
	public void setBalcAmt(BigDecimal balcAmt) {
		this.balcAmt = balcAmt;
	}
	public BigDecimal getFeeAmt() {
		return feeAmt;
	}
	public void setFeeAmt(BigDecimal feeAmt) {
		this.feeAmt = feeAmt;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
}
