package com.shinhan.recon.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;
import com.shinhan.recon.service.ReconcileLogProcessService;

@Service("reconcileLogProcessService")
@Transactional(readOnly = false, propagation =  Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
public class ReconcileLogProcessServiceImpl extends AbstractReconcileBankStatement implements ReconcileLogProcessService {

	@Override
	public void logToFileMas(TOmsStmtFileMas tOmsStmtFileMas, String logInf) throws BaseException {
		tOmsStmtFileMas.setRemark(logInf);
		updateTOmsStmtFileMasToDB(tOmsStmtFileMas, APIConstant._OMS_RECONBATCH_);
	}

}
