/**
 * 
 */
package com.shinhan.recon.report.model.bank;

import java.util.ArrayList;
import java.util.List;

import com.shinhan.recon.report.model.DailyReportHeader;

/**
 * @author shds04
 *
 */
public class DailyReportData {
	private DailyReportHeader dailyReportHeader;
	private List<Object[]> opsData;
	private List<Object[]> reconSummaryData;
	private List<Object[]> disbursalDailyData;
	private List<Object[]> disbursalCollData;
	private List<Object[]> stmtCollData;
	public DailyReportData() {
		opsData = new ArrayList<>();
		reconSummaryData = new ArrayList<>();
		disbursalDailyData = new ArrayList<>();
		disbursalCollData = new ArrayList<>();
		stmtCollData = new ArrayList<>();
	}
	public DailyReportHeader getDailyReportHeader() {
		return dailyReportHeader;
	}
	public void setDailyReportHeader(DailyReportHeader dailyReportHeader) {
		this.dailyReportHeader = dailyReportHeader;
	}
	public List<Object[]> getOpsData() {
		return opsData;
	}
	public void setOpsData(List<Object[]> opsData) {
		this.opsData = opsData;
	}
	public List<Object[]> getReconSummaryData() {
		return reconSummaryData;
	}
	public void setReconSummaryData(List<Object[]> reconSummaryData) {
		this.reconSummaryData = reconSummaryData;
	}
	public List<Object[]> getDisbursalDailyData() {
		return disbursalDailyData;
	}
	public void setDisbursalDailyData(List<Object[]> disbursalDailyData) {
		this.disbursalDailyData = disbursalDailyData;
	}
	public List<Object[]> getDisbursalCollData() {
		return disbursalCollData;
	}
	public void setDisbursalCollData(List<Object[]> disbursalCollData) {
		this.disbursalCollData = disbursalCollData;
	}
	public List<Object[]> getStmtCollData() {
		return stmtCollData;
	}
	public void setStmtCollData(List<Object[]> stmtCollData) {
		this.stmtCollData = stmtCollData;
	}
	
}
