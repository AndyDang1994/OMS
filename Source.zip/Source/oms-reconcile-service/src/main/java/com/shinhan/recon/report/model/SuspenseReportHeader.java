package com.shinhan.recon.report.model;

import java.util.List;

public class SuspenseReportHeader {
	
	private String title; 
	private String endDt; 
	private String startDt;
	private List<String> headers;
	
	public SuspenseReportHeader() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SuspenseReportHeader(String title, String endDt, String startDt, List<String> headers) {
		super();
		this.title = title;
		this.endDt = endDt;
		this.startDt = startDt;
		this.headers = headers;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getEndDt() {
		return endDt;
	}
	public void setEndDt(String endDt) {
		this.endDt = endDt;
	}
	public String getStartDt() {
		return startDt;
	}
	public void setStartDt(String startDt) {
		this.startDt = startDt;
	}
	public List<String> getHeaders() {
		return headers;
	}
	public void setHeaders(List<String> headers) {
		this.headers = headers;
	}
	
	
	
}
