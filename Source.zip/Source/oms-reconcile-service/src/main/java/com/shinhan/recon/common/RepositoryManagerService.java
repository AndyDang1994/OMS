/**
 * 
 */
package com.shinhan.recon.common;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.repository.service.TOmsReconDisbursalInfManagerRepositoryService;
import com.shinhan.recon.repository.service.TOmsReconLmsInfManagerRepositoryService;
import com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService;
import com.shinhan.recon.repository.service.TOmsReconSuspInfManagerRepositoryService;
import com.shinhan.recon.repository.service.TOmsStmtFileMasManagerRepositoryService;
import com.shinhan.recon.repository.service.UtilityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("repositoryManagerService")
public class RepositoryManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private UtilityManagerRepositoryService utilityManagerRepositoryService;

	@Autowired
	private TOmsStmtFileMasManagerRepositoryService tomsStmtFileMasManagerRepositoryService;

	@Autowired
	private TOmsReconStmtInfManagerRepositoryService tomsReconStmtInfManagerRepositoryService;

	@Autowired
	private TOmsReconLmsInfManagerRepositoryService tomsReconLmsInfManagerRepositoryService;
	
	@Autowired
	private TOmsReconSuspInfManagerRepositoryService tOmsReconSuspInfManagerRepositoryService;

	@Autowired
	private TOmsReconDisbursalInfManagerRepositoryService tOmsReconDisbursalInfManagerRepositoryService;
	
	
	/**
	 * @return the utilityManagerRepositoryService
	 */
	public UtilityManagerRepositoryService getUtilityManagerRepositoryService() {
		return utilityManagerRepositoryService;
	}

	/**
	 * @param utilityManagerRepositoryService the utilityManagerRepositoryService to
	 *                                        set
	 */
	public void setUtilityManagerRepositoryService(
			@Qualifier("utilityManagerRepositoryService") UtilityManagerRepositoryService utilityManagerRepositoryService) {
		this.utilityManagerRepositoryService = utilityManagerRepositoryService;
	}

	/**
	 * @return the tomsStmtFileMasManagerRepositoryService
	 */
	public TOmsStmtFileMasManagerRepositoryService getTomsStmtFileMasManagerRepositoryService() {
		return tomsStmtFileMasManagerRepositoryService;
	}

	/**
	 * @param tomsStmtFileMasManagerRepositoryService the
	 *                                                tomsStmtFileMasManagerRepositoryService
	 *                                                to set
	 */
	public void setTomsStmtFileMasManagerRepositoryService(
			@Qualifier("tomsStmtFileMasManagerRepositoryService") TOmsStmtFileMasManagerRepositoryService tomsStmtFileMasManagerRepositoryService) {
		this.tomsStmtFileMasManagerRepositoryService = tomsStmtFileMasManagerRepositoryService;
	}

	/**
	 * @return the tomsReconStmtInfManagerRepositoryService
	 */
	public TOmsReconStmtInfManagerRepositoryService getTomsReconStmtInfManagerRepositoryService() {
		return tomsReconStmtInfManagerRepositoryService;
	}

	/**
	 * @param tomsReconStmtInfManagerRepositoryService the
	 *                                                 tomsReconStmtInfManagerRepositoryService
	 *                                                 to set
	 */
	public void setTomsReconStmtInfManagerRepositoryService(
			@Qualifier("tomsReconStmtInfManagerRepositoryService") TOmsReconStmtInfManagerRepositoryService tomsReconStmtInfManagerRepositoryService) {
		this.tomsReconStmtInfManagerRepositoryService = tomsReconStmtInfManagerRepositoryService;
	}

	/**
	 * @return the tomsReconLmsInfManagerRepositoryService
	 */
	public TOmsReconLmsInfManagerRepositoryService getTomsReconLmsInfManagerRepositoryService() {
		return tomsReconLmsInfManagerRepositoryService;
	}

	/**
	 * @param tomsReconLmsInfManagerRepositoryService the
	 *                                                tomsReconLmsInfManagerRepositoryService
	 *                                                to set
	 */
	public void setTomsReconLmsInfManagerRepositoryService(
			@Qualifier("tomsReconLmsInfManagerRepositoryService") TOmsReconLmsInfManagerRepositoryService tomsReconLmsInfManagerRepositoryService) {
		this.tomsReconLmsInfManagerRepositoryService = tomsReconLmsInfManagerRepositoryService;
	}

	public TOmsReconSuspInfManagerRepositoryService gettOmsReconSuspInfManagerRepositoryService() {
		return tOmsReconSuspInfManagerRepositoryService;
	}

	public void settOmsReconSuspInfManagerRepositoryService(
			@Qualifier("tOmsReconSuspInfManagerRepositoryService")	TOmsReconSuspInfManagerRepositoryService tOmsReconSuspInfManagerRepositoryService) {
		this.tOmsReconSuspInfManagerRepositoryService = tOmsReconSuspInfManagerRepositoryService;
	}

	public TOmsReconDisbursalInfManagerRepositoryService gettOmsReconDisbursalInfManagerRepositoryService() {
		return tOmsReconDisbursalInfManagerRepositoryService;
	}

	public void settOmsReconDisbursalInfManagerRepositoryService(
			@Qualifier("tOmsReconDisbursalInfManagerRepositoryService")	TOmsReconDisbursalInfManagerRepositoryService tOmsReconDisbursalInfManagerRepositoryService) {
		this.tOmsReconDisbursalInfManagerRepositoryService = tOmsReconDisbursalInfManagerRepositoryService;
	}

}
