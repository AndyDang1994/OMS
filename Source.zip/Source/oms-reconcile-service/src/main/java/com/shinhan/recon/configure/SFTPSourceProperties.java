/**
 * 
 */
package com.shinhan.recon.configure;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author shds01
 *
 */

@Component
@ConfigurationProperties(prefix = "sftp.client.oms")
public class SFTPSourceProperties {

	private String host;

	private Integer port;

	private String protocol;

	private String username;

	private String password;

	private String sftpRemoteDirectory;

	private String sftpRemoteBackupDir;

	/**
	 * @return the host
	 */
	public String getHost() {
		return host;
	}

	/**
	 * @param host the host to set
	 */
	public void setHost(String host) {
		this.host = host;
	}

	/**
	 * @return the port
	 */
	public Integer getPort() {
		return port;
	}

	/**
	 * @param port the port to set
	 */
	public void setPort(Integer port) {
		this.port = port;
	}

	/**
	 * @return the protocol
	 */
	public String getProtocol() {
		return protocol;
	}

	/**
	 * @param protocol the protocol to set
	 */
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the sftpRemoteDirectory
	 */
	public String getSftpRemoteDirectory() {
		return sftpRemoteDirectory;
	}

	/**
	 * @param sftpRemoteDirectory the sftpRemoteDirectory to set
	 */
	public void setSftpRemoteDirectory(String sftpRemoteDirectory) {
		this.sftpRemoteDirectory = sftpRemoteDirectory;
	}

	public String getSftpRemoteBackupDir() {
		return sftpRemoteBackupDir;
	}

	public void setSftpRemoteBackupDir(String sftpRemoteBackupDir) {
		this.sftpRemoteBackupDir = sftpRemoteBackupDir;
	}
	
}
