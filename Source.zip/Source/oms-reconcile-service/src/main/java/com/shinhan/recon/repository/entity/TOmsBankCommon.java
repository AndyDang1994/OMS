/**
 * 
 */
package com.shinhan.recon.repository.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author shds01
 *
 */
@Entity
@Table(name = "OMS_BANK_COMMON")
public class TOmsBankCommon implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	private String bankCode;
	private String bankName;
	private String bankNum;
	private String isBank;
	private String isRepayment;
	private int sheetIndex;
	private int fromRow;
	private int headerRow;
	private String templateColumnName;
	private int fileCnt;

	/**
	 * 
	 */
	public TOmsBankCommon() {
		super();
	}

	/**
	 * @param id
	 * @param bankCode
	 * @param bankName
	 * @param bankNum
	 * @param isBank
	 * @param isRepayment
	 * @param sheetIndex
	 * @param fromRow
	 * @param headerRow
	 * @param templateColumnName
	 * @param fileCnt
	 */
	public TOmsBankCommon(Long id, String bankCode, String bankName, String bankNum, String isBank, String isRepayment,
			int sheetIndex, int fromRow, int headerRow, String templateColumnName, int fileCnt) {
		super();
		this.id = id;
		this.bankCode = bankCode;
		this.bankName = bankName;
		this.bankNum = bankNum;
		this.isBank = isBank;
		this.isRepayment = isRepayment;
		this.sheetIndex = sheetIndex;
		this.fromRow = fromRow;
		this.headerRow = headerRow;
		this.templateColumnName = templateColumnName;
		this.fileCnt = fileCnt;
	}

	/**
	 * @return the id
	 */
	@Id
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the bankCode
	 */
	@Column(name = "BANK_CODE")
	public String getBankCode() {
		return bankCode;
	}

	/**
	 * @param bankCode the bankCode to set
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	/**
	 * @return the bankName
	 */
	@Column(name = "BANK_NAME")
	public String getBankName() {
		return bankName;
	}

	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * @return the bankNum
	 */
	@Column(name = "BANK_ACC_NUM")
	public String getBankNum() {
		return bankNum;
	}

	/**
	 * @param bankNum the bankNum to set
	 */
	public void setBankNum(String bankNum) {
		this.bankNum = bankNum;
	}

	/**
	 * @return the isBank
	 */
	@Column(name = "IS_BANK_YN")
	public String getIsBank() {
		return isBank;
	}

	/**
	 * @param isBank the isBank to set
	 */
	public void setIsBank(String isBank) {
		this.isBank = isBank;
	}

	/**
	 * @return the isRepayment
	 */
	@Column(name = "IS_REPAYMENT_YN")
	public String getIsRepayment() {
		return isRepayment;
	}

	/**
	 * @param isRepayment the isRepayment to set
	 */
	public void setIsRepayment(String isRepayment) {
		this.isRepayment = isRepayment;
	}

	/**
	 * @return the sheetIndex
	 */
	@Column(name = "SHEET_INDEX")
	public int getSheetIndex() {
		return sheetIndex;
	}

	/**
	 * @param sheetIndex the sheetIndex to set
	 */
	public void setSheetIndex(int sheetIndex) {
		this.sheetIndex = sheetIndex;
	}

	/**
	 * @return the fromRow
	 */
	@Column(name = "FROM_ROW")
	public int getFromRow() {
		return fromRow;
	}

	/**
	 * @param fromRow the fromRow to set
	 */
	public void setFromRow(int fromRow) {
		this.fromRow = fromRow;
	}

	/**
	 * @return the headerRow
	 */
	@Column(name = "HEADER_ROW")
	public int getHeaderRow() {
		return headerRow;
	}

	/**
	 * @param headerRow the headerRow to set
	 */
	public void setHeaderRow(int headerRow) {
		this.headerRow = headerRow;
	}

	/**
	 * @return the templateColumnName
	 */
	@Column(name = "TEMPLATE_COL_NAME")
	public String getTemplateColumnName() {
		return templateColumnName;
	}

	/**
	 * @param templateColumnName the templateColumnName to set
	 */
	public void setTemplateColumnName(String templateColumnName) {
		this.templateColumnName = templateColumnName;
	}

	/**
	 * @return the fileCnt
	 */
	@Column(name = "FILE_CNT")
	public int getFileCnt() {
		return fileCnt;
	}

	/**
	 * @param fileCnt the fileCnt to set
	 */
	public void setFileCnt(int fileCnt) {
		this.fileCnt = fileCnt;
	}
}
