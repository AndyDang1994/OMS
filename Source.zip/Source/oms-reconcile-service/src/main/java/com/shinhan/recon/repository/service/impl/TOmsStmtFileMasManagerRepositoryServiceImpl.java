/**
 * 
 */
package com.shinhan.recon.repository.service.impl;

import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.BankStatementFile;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.dao.TOmsStmtFileMasDAO;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;
import com.shinhan.recon.repository.service.TOmsStmtFileMasManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("tomsStmtFileMasManagerRepositoryService")
public class TOmsStmtFileMasManagerRepositoryServiceImpl extends AbstractServiceClass
		implements TOmsStmtFileMasManagerRepositoryService {

	private TOmsStmtFileMasDAO objectDao;

	@Autowired
	public TOmsStmtFileMasManagerRepositoryServiceImpl(TOmsStmtFileMasDAO objectDao) {
		this.objectDao = objectDao;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsStmtFileMasManagerRepositoryService#
	 * getListUploadByDate(java.util.Map)
	 */
	@Override
	public List<TOmsStmtFileMas> getListUploadByDate(Map<String, Object> inputParams) throws BaseException {
		String uploadDT = inputParams.get(APIConstant.UPLOAD_DATE_KEY).toString();
		String status = inputParams.get(APIConstant.UPLOAD_BANKSTATUS_KEY).toString();
		long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
				? 0
				: Integer.parseInt(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
		String sql = oracleOMSNamedQueries.get("getListUploadByDate");
		Query query = entityManager.createNativeQuery(sql, TOmsStmtFileMas.class);
		
		query.setParameter(APIConstant.UPLOAD_DATE_KEY, DateUtils.converToDate(uploadDT));
		query.setParameter(APIConstant.UPLOAD_BANKSTATUS_KEY, status);
		query.setParameter(APIConstant.UPLOAD_TRXTYPE_KEY, trxType);
		
		List<TOmsStmtFileMas> lStatementFiles = query.getResultList();
		return lStatementFiles;
	}
	@Override
	public List<TOmsStmtFileMas> getListUploadByDateAndStatus(Map<String, Object> inputParams) throws BaseException {
		String uploadDT = inputParams.get(APIConstant.UPLOAD_DATE_KEY).toString();
		String status = inputParams.get(APIConstant.UPLOAD_BANKSTATUS_KEY).toString();
		long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
				? 0
				: Integer.parseInt(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
		String sql = oracleOMSNamedQueries.get("getListUploadByDateAndStatus");
		Query query = entityManager.createNativeQuery(sql, TOmsStmtFileMas.class);
		
		query.setParameter(APIConstant.UPLOAD_DATE_KEY, DateUtils.converToDate(uploadDT));
		query.setParameter(APIConstant.UPLOAD_BANKSTATUS_KEY, status);
		query.setParameter(APIConstant.UPLOAD_TRXTYPE_KEY, trxType);
		
		List<TOmsStmtFileMas> lStatementFiles = query.getResultList();
		return lStatementFiles;
	}
	
	@Override
	public List<TOmsStmtFileMas> getListUploadByDateForRerty(Map<String, Object> inputParams) throws BaseException {
		String uploadDT = inputParams.get(APIConstant.UPLOAD_DATE_KEY).toString();
		String status = inputParams.get(APIConstant.UPLOAD_BANKSTATUS_KEY).toString();
		String sql = oracleOMSNamedQueries.get("getListUploadByDateForRerty");
		Query query = entityManager.createNativeQuery(sql, TOmsStmtFileMas.class);
		
		query.setParameter(APIConstant.UPLOAD_DATE_KEY, DateUtils.converToDate(uploadDT));
		query.setParameter(APIConstant.UPLOAD_BANKSTATUS_KEY, status);
		
		List<TOmsStmtFileMas> lStatementFiles = query.getResultList();
		return lStatementFiles;
	}

	@Override
	public List<TOmsStmtFileMas> getListUploadByDateAndBankCode(Map<String, Object> inputParams) throws BaseException {
		String uploadDT = inputParams.get(APIConstant.UPLOAD_DATE_KEY).toString();
		String bankCode = inputParams.get(APIConstant.UPLOAD_BANKCODE_KEY).toString();
		long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
				? 0
				: Integer.parseInt(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
		String sql = oracleOMSNamedQueries.get("getListUploadByDateAndBankCode");
		Query query = entityManager.createNativeQuery(sql, TOmsStmtFileMas.class);
		
		query.setParameter(APIConstant.UPLOAD_DATE_KEY, DateUtils.converToDate(uploadDT));
		query.setParameter(APIConstant.UPLOAD_BANKCODE_KEY, bankCode);
		query.setParameter(APIConstant.UPLOAD_TRXTYPE_KEY, trxType);
		List<TOmsStmtFileMas> lStatementFiles = query.getResultList();
		return lStatementFiles;
	}
	
	@Override
	public List<TOmsStmtFileMas> getListUploadByBankCode(Map<String, Object> inputParams) throws BaseException {
		String sql = "Select mas.* from OMS_STMT_FILE_MAS mas "
				+ "WHERE mas.UPLOAD_DT between :strDt and :endDt "
				+ "and mas.process_status = '10' "
				+ "and mas.file_type = :transactionType";
		Query query = entityManager.createNativeQuery(sql, TOmsStmtFileMas.class);
		long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
				? 0
				: Integer.parseInt(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
		query.setParameter("strDt", DateUtils.converToDate(inputParams.get(APIConstant._START_DATE_KEY).toString()));
		query.setParameter("endDt", DateUtils.converToDate(inputParams.get(APIConstant._END_DATE_KEY).toString()));
		query.setParameter(APIConstant.UPLOAD_TRXTYPE_KEY, trxType);
		List<TOmsStmtFileMas> lStatementFiles = query.getResultList();
		return lStatementFiles;
	}
	@Override
	public Long getMaxIDByDateAndBankCode(Map<String, Object> inputParams) throws BaseException {
		String uploadDT = inputParams.get(APIConstant.UPLOAD_DATE_KEY).toString();
		String bankCode = inputParams.get(APIConstant.UPLOAD_BANKCODE_KEY).toString();
		String sql = "Select max(mas.ID) from OMS_STMT_FILE_MAS mas "
				+ "WHERE mas.UPLOAD_DT = :uploadDT "
				+ "and mas.bank_code = :bankCode "
				+ "and mas.file_type = :transactionType";
		Query query = entityManager.createNativeQuery(sql);
		long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
				? 0
						: Integer.parseInt(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
		query.setParameter("uploadDT", DateUtils.converToDate(uploadDT));
		query.setParameter("bankCode", bankCode);
		query.setParameter(APIConstant.UPLOAD_TRXTYPE_KEY, trxType);
		Long rs = (Long) query.getSingleResult();
		return rs;
	}
	
	@Override
	public TOmsStmtFileMas getNewestFileMas(Map<String, Object> inputParams)throws BaseException{
		String bankCode = inputParams.get(APIConstant.UPLOAD_BANKCODE_KEY).toString();
		String sql = "Select mas.* from OMS_STMT_FILE_MAS mas "
				+ "WHERE bank_code = :bankCode "
				+ "and mas.file_type = :transactionType "
				+ "and mas.id = ( select max(a.id) from OMS_STMT_FILE_MAS a where a.bank_code = :bankCode and a.process_status = '10' and a.file_type = :transactionType )";
		long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
				? 0
						: Integer.parseInt(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
		Query query = entityManager.createNativeQuery(sql, TOmsStmtFileMas.class);
		query.setParameter("bankCode", bankCode);
		query.setParameter(APIConstant.UPLOAD_TRXTYPE_KEY, trxType);
		TOmsStmtFileMas rs = (TOmsStmtFileMas) query.getSingleResult();
		return rs;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsStmtFileMasManagerRepositoryService#
	 * create(java.util.Map)
	 */
	@Override
	public boolean create(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsStmtFileMas item = (TOmsStmtFileMas) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsStmtFileMasManagerRepositoryService#
	 * createAll(java.util.Map)
	 */
	@Override
	public boolean createAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsStmtFileMas> items = (List<TOmsStmtFileMas>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsStmtFileMasManagerRepositoryService#
	 * getOne(java.util.Map)
	 */
	@Override
	public TOmsStmtFileMas getOne(Map<String, Object> inputParams) throws BaseException {
		String omsId = inputParams.get(APIConstant.OMSID).toString();
		if (StringUtils.isBlank(omsId)) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_003"));
		}
		try {
			TOmsStmtFileMas item = objectDao.findById(Long.valueOf(omsId)).orElse(null);
			return item;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + omsId + "");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsStmtFileMasManagerRepositoryService#
	 * update(java.util.Map)
	 */
	@Override
	public boolean update(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsStmtFileMas item = (TOmsStmtFileMas) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	@Override
	public boolean updateAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsStmtFileMas> items = (List<TOmsStmtFileMas>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public List<BankStatementFile> getListStmtFileMasByDate(Map<String, Object> inputParams) throws BaseException {
		String uploadDT = inputParams.get(APIConstant.UPLOAD_DATE_KEY).toString();
		return objectDao.getListStmtFileMasByDate(DateUtils.converToDate(uploadDT));
	}

	@Override
	public List<TOmsStmtFileMas> getDeleteListUploadByBankcode(Map<String, Object> inputParams) throws BaseException {
		String uploadDT = inputParams.get(APIConstant.UPLOAD_DATE_KEY).toString();
		String bankCode = inputParams.get(APIConstant.UPLOAD_BANKCODE_KEY).toString();
		long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
				? 0
				: Integer.parseInt(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
		String sql = oracleOMSNamedQueries.get("getDeleteListUploadByBankcode");
		Query query = entityManager.createNativeQuery(sql, TOmsStmtFileMas.class);
		
		query.setParameter(APIConstant.UPLOAD_DATE_KEY, DateUtils.converToDate(uploadDT));
		query.setParameter(APIConstant.UPLOAD_BANKCODE_KEY, bankCode);
		query.setParameter(APIConstant.UPLOAD_TRXTYPE_KEY, trxType);
		List<TOmsStmtFileMas> lStatementFiles = query.getResultList();
		return lStatementFiles;
	}
}
