/**
 * 
 */
package com.shinhan.recon.disburs.service;

import java.io.File;
import java.util.List;

import com.shinhan.recon.repository.entity.TBankCommon;

/**
 * @author shds04
 *
 */
public interface ReconcileDisbursalProcessVietcombankService {
	
	public void processReconcileBankDisbursalVietcombank(File file, List<TBankCommon> tBankCommons) throws Exception;

}
