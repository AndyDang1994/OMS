/**
 * 
 */
package com.shinhan.recon.report.model.bank;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;

/**
 * @author shds01
 *
 */
public class RepaymentForBankMatchingDataReport {

	//private List<Object[]> matchingLst;
	private BankStatementLmsTrxInfo sumRecord;

	/**
	 * 
	 */
	public RepaymentForBankMatchingDataReport() {
		super();
		//this.matchingLst = new ArrayList<>();
		this.sumRecord = new BankStatementLmsTrxInfo(APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
	}

	/**
	 * @param matchingLst
	 * @param sumRecord
	 */
	public RepaymentForBankMatchingDataReport(
			BankStatementLmsTrxInfo sumRecord) {
		super();
		//this.matchingLst = matchingLst;
		this.sumRecord = sumRecord;
	}

	/**
	 * @return the sumRecord
	 */
	public BankStatementLmsTrxInfo getSumRecord() {
		return sumRecord;
	}

	/**
	 * @param sumRecord the sumRecord to set
	 */
	public void setSumRecord(BankStatementLmsTrxInfo sumRecord) {
		this.sumRecord = sumRecord;
	}

}
