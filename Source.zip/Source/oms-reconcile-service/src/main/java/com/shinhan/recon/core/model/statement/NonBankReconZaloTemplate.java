/**
 * 
 */
package com.shinhan.recon.core.model.statement;

/**
 * @author shds04
 *
 */
public class NonBankReconZaloTemplate {

	private String Stt;
	private String trxDt;
	private String ref;
	private String refExt;
	private String remitter;
	private String loanNo;
	private String description;
	private String userName;
	private String appName;
	private String chanName;
	private String sourceName;
	private String platform;
	private String trxType;
	private String trxStatus;
	
	private String cardNo;
	private String apprvCode;
	private String bankCode;
	private String bnkTraceNo;
	private String discName;
	private String respInf;
	private String bankStatus;
	private String credit;
	public NonBankReconZaloTemplate() {
		super();
	}
	public NonBankReconZaloTemplate(String stt, String trxDt, String ref, String refExt, String remitter,
			String loanNo, String userName, String appName, String chanName, String sourceName, String platform,
			String trxType, String trxStatus, String description, String cardNo, String apprvCode, String bankCode,
			String respInf, String bankStatus, String credit) {
		super();
		Stt = stt;
		this.trxDt = trxDt;
		this.ref = ref;
		this.refExt = refExt;
		this.remitter = remitter;
		this.loanNo = loanNo;
		this.userName = userName;
		this.appName = appName;
		this.chanName = chanName;
		this.sourceName = sourceName;
		this.platform = platform;
		this.trxType = trxType;
		this.trxStatus = trxStatus;
		this.description = description;
		this.cardNo = cardNo;
		this.apprvCode = apprvCode;
		this.bankCode = bankCode;
		this.respInf = respInf;
		this.bankStatus = bankStatus;
		this.credit = credit;
	}
	public String getStt() {
		return Stt;
	}
	public void setStt(String stt) {
		Stt = stt;
	}
	public String getTrxDt() {
		return trxDt;
	}
	public void setTrxDt(String trxDt) {
		this.trxDt = trxDt;
	}
	public String getRef() {
		return ref;
	}
	public void setRef(String ref) {
		this.ref = ref;
	}
	public String getRefExt() {
		return refExt;
	}
	public void setRefExt(String refExt) {
		this.refExt = refExt;
	}
	public String getRemitter() {
		return remitter;
	}
	public void setRemitter(String remitter) {
		this.remitter = remitter;
	}
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getChanName() {
		return chanName;
	}
	public void setChanName(String chanName) {
		this.chanName = chanName;
	}
	public String getSourceName() {
		return sourceName;
	}
	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}
	public String getPlatform() {
		return platform;
	}
	public void setPlatform(String platform) {
		this.platform = platform;
	}
	public String getTrxType() {
		return trxType;
	}
	public void setTrxType(String trxType) {
		this.trxType = trxType;
	}
	public String getTrxStatus() {
		return trxStatus;
	}
	public void setTrxStatus(String trxStatus) {
		this.trxStatus = trxStatus;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public String getApprvCode() {
		return apprvCode;
	}
	public void setApprvCode(String apprvCode) {
		this.apprvCode = apprvCode;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getRespInf() {
		return respInf;
	}
	public void setRespInf(String respInf) {
		this.respInf = respInf;
	}
	public String getBankStatus() {
		return bankStatus;
	}
	public void setBankStatus(String bankStatus) {
		this.bankStatus = bankStatus;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	
}
