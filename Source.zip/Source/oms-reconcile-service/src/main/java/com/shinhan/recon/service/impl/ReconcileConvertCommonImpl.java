package com.shinhan.recon.service.impl;

import java.util.List;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.model.statement.BankStatementCommonTemplate;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.service.ReconcileConvert;

public class ReconcileConvertCommonImpl extends AbstractServiceClass implements ReconcileConvert<TOmsReconStmtInf> {

	@Override
	public List<TOmsReconStmtInf> convertStatement(List<BankStatementCommonTemplate> bankStatements,
			TBankCommon bankFileVal) {
		return DTOConverter
				.setCommonTemplateToOmsReconStmtInf(bankStatements, bankFileVal.getBankAccNuber(), 
						APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
								DateUtils.DATEFORMAT), APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT), 1);
	}

}
