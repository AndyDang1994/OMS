/**
 * 
 */
package com.shinhan.recon.core.model;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author shds01
 *
 */
public class BankStatementFile {

	private Date uploadDt;
	private String bankCode;
	private String bankName;
	private String fileName;
	private BigDecimal openBalance;
	private BigDecimal closeBalance;
	private Long processStatus;
	private Long fileStatus;
	private int totalCount;
	private int successCount;
	private int fileValidCount;
	private String remark;
	private String isBank;
	private String isRepayment;
	private int fileCnt;

	/**
	 * 
	 */
	public BankStatementFile() {
		super();
	}

	/**
	 * @param uploadDt
	 * @param bankCode
	 * @param openBalance
	 * @param closeBalance
	 */
	public BankStatementFile(Date uploadDt, String bankCode, BigDecimal openBalance, BigDecimal closeBalance) {
		super();
		this.uploadDt = uploadDt;
		this.bankCode = bankCode;
		this.openBalance = openBalance;
		this.closeBalance = closeBalance;
	}

	/**
	 * @param uploadDt
	 * @param bankCode
	 * @param bankName
	 * @param fileName
	 * @param openBalance
	 * @param closeBalance
	 * @param processStatus
	 * @param fileStatus
	 * @param totalCount
	 * @param successCount
	 * @param fileValidCount
	 * @param remark
	 * @param isBank
	 * @param isRepayment
	 * @param fileCnt
	 */
	public BankStatementFile(Date uploadDt, String bankCode, String bankName, String fileName, BigDecimal openBalance,
			BigDecimal closeBalance, Long processStatus, Long fileStatus, int totalCount, int successCount,
			int fileValidCount, String remark, String isBank, String isRepayment, String fileCnt) {
		super();
		this.uploadDt = uploadDt;
		this.bankCode = bankCode;
		this.bankName = bankName;
		this.fileName = fileName;
		this.openBalance = openBalance;
		this.closeBalance = closeBalance;
		this.processStatus = processStatus;
		this.fileStatus = fileStatus;
		this.totalCount = totalCount;
		this.successCount = successCount;
		this.fileValidCount = fileValidCount;
		this.remark = remark;
		this.isBank = isBank;
		this.isRepayment = isRepayment;
		
	}

	/**
	 * @return the uploadDt
	 */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getUploadDt() {
		return uploadDt;
	}

	/**
	 * @param uploadDt the uploadDt to set
	 */
	public void setUploadDt(Date uploadDt) {
		this.uploadDt = uploadDt;
	}

	/**
	 * @return the bankCode
	 */
	public String getBankCode() {
		return bankCode;
	}

	/**
	 * @param bankCode the bankCode to set
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}

	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the openBalance
	 */
	public BigDecimal getOpenBalance() {
		return openBalance;
	}

	/**
	 * @param openBalance the openBalance to set
	 */
	public void setOpenBalance(BigDecimal openBalance) {
		this.openBalance = openBalance;
	}

	/**
	 * @return the closeBalance
	 */
	public BigDecimal getCloseBalance() {
		return closeBalance;
	}

	/**
	 * @param closeBalance the closeBalance to set
	 */
	public void setCloseBalance(BigDecimal closeBalance) {
		this.closeBalance = closeBalance;
	}

	/**
	 * @return the processStatus
	 */
	public Long getProcessStatus() {
		return processStatus;
	}

	/**
	 * @param processStatus the processStatus to set
	 */
	public void setProcessStatus(Long processStatus) {
		this.processStatus = processStatus;
	}

	/**
	 * @return the fileStatus
	 */
	public Long getFileStatus() {
		return fileStatus;
	}

	/**
	 * @param fileStatus the fileStatus to set
	 */
	public void setFileStatus(Long fileStatus) {
		this.fileStatus = fileStatus;
	}

	/**
	 * @return the totalCount
	 */
	public int getTotalCount() {
		return totalCount;
	}

	/**
	 * @param totalCount the totalCount to set
	 */
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	/**
	 * @return the successCount
	 */
	public int getSuccessCount() {
		return successCount;
	}

	/**
	 * @param successCount the successCount to set
	 */
	public void setSuccessCount(int successCount) {
		this.successCount = successCount;
	}

	/**
	 * @return the fileValidCount
	 */
	public int getFileValidCount() {
		return fileValidCount;
	}

	/**
	 * @param fileValidCount the fileValidCount to set
	 */
	public void setFileValidCount(int fileValidCount) {
		this.fileValidCount = fileValidCount;
	}

	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @return the isBank
	 */
	public String getIsBank() {
		return isBank;
	}

	/**
	 * @param isBank the isBank to set
	 */
	public void setIsBank(String isBank) {
		this.isBank = isBank;
	}

	/**
	 * @return the isRepayment
	 */
	public String getIsRepayment() {
		return isRepayment;
	}

	/**
	 * @param isRepayment the isRepayment to set
	 */
	public void setIsRepayment(String isRepayment) {
		this.isRepayment = isRepayment;
	}

	/**
	 * @return the fileCnt
	 */
	public int getFileCnt() {
		return fileCnt;
	}

	/**
	 * @param fileCnt the fileCnt to set
	 */
	public void setFileCnt(int fileCnt) {
		this.fileCnt = fileCnt;
	}

}
