/**
 * 
 */
package com.shinhan.recon.report.model.nonbank;

/**
 * @author shds01
 *
 */
public class RepaymentForNonBankReport {

	private RepaymentForNonBankHeaderReport headerReport;
	private RepaymentForNonBankMatchingDataReport dataMatchingReport;
	private RepaymentForNonBankUnMatchingDataReport dataUnMatchingReport;
	private RepaymentForNonBankFooterReport footerReport;

	/**
	 * 
	 */
	public RepaymentForNonBankReport() {
		super();
	}

	/**
	 * @param headerReport
	 */
	public RepaymentForNonBankReport(RepaymentForNonBankHeaderReport headerReport) {
		super();
		this.headerReport = headerReport;
	}

	/**
	 * @return the headerReport
	 */
	public RepaymentForNonBankHeaderReport getHeaderReport() {
		return headerReport;
	}

	/**
	 * @param headerReport the headerReport to set
	 */
	public void setHeaderReport(RepaymentForNonBankHeaderReport headerReport) {
		this.headerReport = headerReport;
	}

	/**
	 * @return the dataMatchingReport
	 */
	public RepaymentForNonBankMatchingDataReport getDataMatchingReport() {
		return dataMatchingReport;
	}

	/**
	 * @param dataMatchingReport the dataMatchingReport to set
	 */
	public void setDataMatchingReport(RepaymentForNonBankMatchingDataReport dataMatchingReport) {
		this.dataMatchingReport = dataMatchingReport;
	}

	/**
	 * @return the dataUnMatchingReport
	 */
	public RepaymentForNonBankUnMatchingDataReport getDataUnMatchingReport() {
		return dataUnMatchingReport;
	}

	/**
	 * @param dataUnMatchingReport the dataUnMatchingReport to set
	 */
	public void setDataUnMatchingReport(RepaymentForNonBankUnMatchingDataReport dataUnMatchingReport) {
		this.dataUnMatchingReport = dataUnMatchingReport;
	}

	/**
	 * @return the footerReport
	 */
	public RepaymentForNonBankFooterReport getFooterReport() {
		return footerReport;
	}

	/**
	 * @param footerReport the footerReport to set
	 */
	public void setFooterReport(RepaymentForNonBankFooterReport footerReport) {
		this.footerReport = footerReport;
	}

}
