/**
 * 
 */
package com.shinhan.recon.core.model.statement;

/**
 * @author shds01
 *
 */
public class BankStatementACBTemplate {

	private String valueDt;
	private String trxDt;
	private String ref;
	private String description;
	private String debit;
	private String credit;
	private String amt;

	/**
	 * 
	 */
	public BankStatementACBTemplate() {
		super();
	}

	/**
	 * @return the effectiveDt
	 */
	public String getEffectiveDt() {
		return valueDt;
	}

	/**
	 * @param effectiveDt the effectiveDt to set
	 */
	public void setEffectiveDt(String effectiveDt) {
		this.valueDt = effectiveDt;
	}

	/**
	 * @return the trxDt
	 */
	public String getTrxDt() {
		return trxDt;
	}

	/**
	 * @param trxDt the trxDt to set
	 */
	public void setTrxDt(String trxDt) {
		this.trxDt = trxDt;
	}

	/**
	 * @return the ref
	 */
	public String getRef() {
		return ref;
	}

	/**
	 * @param ref the ref to set
	 */
	public void setRef(String ref) {
		this.ref = ref;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the credit
	 */
	public String getCredit() {
		return credit;
	}

	/**
	 * @param credit the credit to set
	 */
	public void setCredit(String credit) {
		this.credit = credit;
	}

	/**
	 * @return the debit
	 */
	public String getDebit() {
		return debit;
	}

	/**
	 * @param debit the debit to set
	 */
	public void setDebit(String debit) {
		this.debit = debit;
	}

	/**
	 * @return the amt
	 */
	public String getAmt() {
		return amt;
	}

	/**
	 * @param amt the amt to set
	 */
	public void setAmt(String amt) {
		this.amt = amt;
	}

}
