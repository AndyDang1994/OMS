/**
 * 
 */
package com.shinhan.recon.report.model.nonbank;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;

/**
 * @author shds01
 *
 */
public class RepaymentForNonBankMatchingDataReport {

	private BankStatementLmsTrxInfo sumRecord;

	/**
	 * 
	 */
	public RepaymentForNonBankMatchingDataReport() {
		super();
		this.sumRecord = new BankStatementLmsTrxInfo(APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
	}

	/**
	 * @param matchingLst
	 * @param sumRecord
	 */
	public RepaymentForNonBankMatchingDataReport(
			BankStatementLmsTrxInfo sumRecord) {
		super();
		this.sumRecord = sumRecord;
	}

	/**
	 * @return the sumRecord
	 */
	public BankStatementLmsTrxInfo getSumRecord() {
		return sumRecord;
	}

	/**
	 * @param sumRecord the sumRecord to set
	 */
	public void setSumRecord(BankStatementLmsTrxInfo sumRecord) {
		this.sumRecord = sumRecord;
	}

}
