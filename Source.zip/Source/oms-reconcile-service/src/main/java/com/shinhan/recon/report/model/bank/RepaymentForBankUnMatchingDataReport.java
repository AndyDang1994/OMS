/**
 * 
 */
package com.shinhan.recon.report.model.bank;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;

/**
 * @author shds01
 *
 */
public class RepaymentForBankUnMatchingDataReport {

	
	private BankStatementLmsTrxInfo sumRecord;

	/**
	 * 
	 */
	public RepaymentForBankUnMatchingDataReport() {
		super();
		
		this.sumRecord = new BankStatementLmsTrxInfo(APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
	}

	/**
	 * @return the sumRecord
	 */
	public BankStatementLmsTrxInfo getSumRecord() {
		return sumRecord;
	}

	/**
	 * @param sumRecord the sumRecord to set
	 */
	public void setSumRecord(BankStatementLmsTrxInfo sumRecord) {
		this.sumRecord = sumRecord;
	}

}
