package com.shinhan.recon.service.impl;

import java.util.List;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.model.statement.BankStatementCommonTemplate;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsReconDisburInf;
import com.shinhan.recon.service.ReconcileConvert;

public class ReconcileConvertDisbCommonImpl extends AbstractServiceClass implements ReconcileConvert<TOmsReconDisburInf> {

	@Override
	public List<TOmsReconDisburInf> convertStatement(List<BankStatementCommonTemplate> bankStatements,
			TBankCommon bankFileVal) {
		return DTOConverter
						.setCommonTemplateToOmsReconDisbursalInf(bankStatements, bankFileVal.getBankAccNuber(), 
								APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
										DateUtils.DATEFORMAT), APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT), 1) ;
	}

}
