/**
 * 
 */
package com.shinhan.recon.report.model.nonbank;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;

/**
 * @author shds01
 *
 */
public class RepaymentForNonBankUnMatchingDataReport {

	private BankStatementLmsTrxInfo sumRecord;

	/**
	 * 
	 */
	public RepaymentForNonBankUnMatchingDataReport() {
		super();
		this.sumRecord = new BankStatementLmsTrxInfo(APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
	}

	/**
	 * @return the sumRecord
	 */
	public BankStatementLmsTrxInfo getSumRecord() {
		return sumRecord;
	}

	/**
	 * @param sumRecord the sumRecord to set
	 */
	public void setSumRecord(BankStatementLmsTrxInfo sumRecord) {
		this.sumRecord = sumRecord;
	}

}
