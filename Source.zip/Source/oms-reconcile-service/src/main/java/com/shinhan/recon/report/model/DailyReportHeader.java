/**
 * 
 */
package com.shinhan.recon.report.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author shds04
 *
 */
public class DailyReportHeader {
	
	private List<String> opsReportHeader;

	private List<String> opsCollectionHeader;

	public DailyReportHeader() {
		super();
		opsCollectionHeader = new ArrayList<>();
		opsReportHeader = new ArrayList<>();
	}

	public List<String> getOpsReportHeader() {
		return opsReportHeader;
	}

	public void setOpsReportHeader(List<String> opsReportHeader) {
		this.opsReportHeader = opsReportHeader;
	}

	public List<String> getOpsCollectionHeader() {
		return opsCollectionHeader;
	}

	public void setOpsCollectionHeader(List<String> opsCollectionHeader) {
		this.opsCollectionHeader = opsCollectionHeader;
	}
	
}
