/**
 * 
 */
package com.shinhan.recon.core.constant;

import java.math.BigDecimal;

/**
 * @author shds01
 *
 */

public class APIConstant {

	/** Common Constant */
	public static final String ALL = "all";
	public static final String DOCUMENT = "document";
	public static final String DOCTYPE = "docType";
	
	public static final String DATA = "data";
	public static final String COUNT = "count";
	
	public static final String RESULT = "result";
	public static final String RESULT_MSG = "resultMSG";
	public static final String FLAG = "flag";

	public static final String _START_DATE_KEY = "_startDt";
	public static final String _REF_NO_KEY = "refNo";
	public static final String _CR_AMT_KEY = "crAmt";
	public static final String _DR_AMT_KEY = "drAmt";
	public static final String _END_DATE_KEY = "_endDt";
	public static final String _TYPE_KEY = "_type";
	public static final String _STATUS_KEY = "status";
	public static final String _START_KEY = "_start";
	public static final String _NUMBER_KEY = "_number";
	public static final String _TXT_SEARCH_KEY = "_txtSearch";
	public static final String _POTIENTIAL_BLANK = "blank";
	public static final String _SORT = "sort";
	public static final String _ORDER = "order";
		
	public static final String USERNAME_KEY = "userName";
	public static final String EXPIRY_DATE = "expiryDate";
	public static final String TRACKING_LOG_INSTANCE = "trackingLogInstance";

	public static final String FILE = "file";
	public static final String FILE_UPLOAD = "fileUpload";
	
	public static final String SUBMISSION_MODE_KEY = "SubmissionMode";
	public static final String SUBMISSION_LAS_KEY = "SubmissionLAS";
	
	public static final String SUPERGEN_KEY = "super_user";
	public static final String OMS_AUTHENTICATION_SERVICE_USERPERMISSION = "oms_authen_service_userPermission";
	public static final String SHINHAN_USERNAME_KEY = "shinhan.common.userName";
	public static final String SHINHAN_PASSWORD_KEY = "shinhan.common.password";
	
	/** Common Document Constant */
	// Sharing resource file url
	public static final String URL_DIR_FILERESOURCE_SHARING = "url_dir_fileResource_sharing";

	public static final String FILE_TYPE_IMAGE_JPG = ".jpg";
	public static final String FILE_TYPE_IMAGE_PNG = ".png";
	public static final String FILE_TYPE_PDF = ".pdf";
	public static final String FILE_TYPE_JASPER = ".jasper";
	public static final String FILE_TYPE_TXT = ".txt";
	
	public static final String FILE_TYPE_JSON = ".json";
	public static final String FILE_TYPE_XML = ".xml";
	public static final String FILE_TYPE_EXCEL_OLD = ".xls";
	public static final String FILE_TYPE_EXCEL_NEW = ".xlsx";
	
	/** UPLOAD Constant **/
	public static final String PATH_SCAN_BANK_STATEMENT_FTP_FOLDER= "PATH_SCAN_BANK_STATEMENT_FTP_FOLDER";
	public static final String PATH_SCAN_BANK_STATEMENT_PROCESS_FOLDER= "PATH_SCAN_BANK_STATEMENT_PROCESS_FOLDER";
	public static final String PATH_SCAN_BANK_STATEMENT_DONE_FOLDER= "PATH_SCAN_BANK_STATEMENT_DONE_FOLDER";
	public static final String PATH_SCAN_BANK_TEMP_FOLDER= "PATH_SCAN_BANK_TEMP_FOLDER";
	public static final String PATH_SCAN_DISBURSAL_STATEMENT_PROCESS_FOLDER= "PATH_SCAN_DISBURSAL_STATEMENT_PROCESS_FOLDER";
	public static final String PATH_SCAN_DISBURSAL_STATEMENT_DONE_FOLDER= "PATH_SCAN_DISBURSAL_STATEMENT_DONE_FOLDER";
	public static final String FOLDER_TEMPLATE_REPORT= "FOLDER_TEMPLATE_REPORT";
	public static final String FOLDER_EXPORT_REPORT= "FOLDER_EXPORT_REPORT";
	
	public static final String FILE_BANK_TEMPLATE_REPORT_IN= "Bank_Template.xlsx";
	public static final String FILE_BANK_TEMPLATE_REPORT_EXPORT= "Reconciliation";

	public static final String FILE_DAILY_REPORT_IN= "Repayment_DailyReport.xlsx";
	public static final String FILE_DAILY_REPORT_EXPORT= "DailyReport_Export_";

	public static final String FILE_DISBURSAL_REPORT_IN= "Disbursal_Template.xlsx";
	public static final String FILE_DISBURSAL_REPORT_EXPORT= "Reconciliation";

	public static final String FILE_PENDING_REPORT_IN= "Pending_Report_Template.xlsx";
	public static final String FILE_SUSPENSE_REPORT_IN= "Suspense_Report_Template.xlsx";
	public static final String FILE_PENDING_REPORT_EXPORT= "Pending Report";
	public static final String FILE_SUSPENSE_REPORT_EXPORT= "Suspense Report";
	
	public static final String FILE_NONBANK_TEMPLATE_REPORT_IN= "NonBank_template.xlsx";
	public static final String FILE_NONBANK_TEMPLATE_REPORT_EXPORT= "Reconciliation";
	
	
	public static final String BANK_STATEMENT_VIETCOMBANK= "VCB";
	public static final String BANK_STATEMENT_ACB= "ACB";
	public static final String BANK_STATEMENT_TECHCOMBANK_HSC= "TCBHSC";
	public static final String BANK_STATEMENT_TECHCOMBANK_SGD= "TCBSGD";
	public static final String BANK_STATEMENT_SACOMBANK= "SACOMBANK";
	public static final String BANK_STATEMENT_AGRIBANK= "ARGB";
	public static final String BANK_STATEMENT_OCB_AD= "SVFC_AD";
	public static final String BANK_STATEMENT_OCB_IB= "SVFC_IB";
	public static final String BANK_STATEMENT_OCB_OTC= "SVFC_OTC";
	public static final String BANK_STATEMENT_OCB_061= "SVFC_061";
	public static final String BANK_STATEMENT_VIETTINBANK_STMT= "VTB_STMT";
	public static final String BANK_STATEMENT_VIETTINBANK_RECON= "VTB_RECON";
	public static final String NON_BANK_STATEMENT_VIETTEL= "VIETTEL_STMT";
	public static final String NON_BANK_RECON_VIETTEL= "VIETTEL_RECON";
	public static final String NON_BANK_STATEMENT_VNPOST= "VNPOST_STMT";
	public static final String NON_BANK_RECON_VNPOST= "VNPOST_RECON";
	public static final String NON_BANK_STATEMENT_PAYOO= "PAYOO_STMT";
	public static final String NON_BANK_STATEMENT_ZALOPAY= "ZALO_STMT";
	public static final String NON_BANK_RECON_ZALOPAY= "ZALO_RECON";
	public static final String NON_BANK_RECON_PAYOO= "PAYOO_RECON";
	public static final String NON_BANK_STATEMENT_MOMO= "MOMO_STMT";
	public static final String NON_BANK_RECON_MOMO= "MOMO_RECON";
	public static final String NON_BANK_STATEMENT_AIRPAY= "AIRPAY_STMT";
	public static final String NON_BANK_RECON_AIRPAY= "AIRPAY_RECON";
	public static final String NON_BANK_STATEMENT_NAPAS= "NAPAS_STMT";
	public static final String NON_BANK_RECON_NAPAS= "NAPAS_RECON";
	public static final String BANK_COMMON_TEMPLATE= "COMMON_TEMPLATE";
	
	/** Disbursal **/
	public static final String BANK_DISBURSAL_VIETCOMBANK= "DISBURSAL_VCB";
	public static final String BANK_DISBURSAL_TECHCOMBANK= "DISBURSAL_TCB";
	public static final String BANK_DISBURSAL_CITI= "DISBURSAL_CITI";
	
	/** HTTP Description **/
	public static final String HTTP_REQUEST_BODY_STR = "HttpRequestBody";
	public static final String METHOD_NOT_ALLOWED = "Method is not allowed";
	public static final String UNSUPPORTED_MEDIA_TYPE = "Media type is unsupported";
	public static final String NOT_ACCEPTABLE = "Not Acceptable";

	public static final String GET_METHOD_STR = "GET";
	public static final String POST_METHOD_STR = "POST";
	public static final String PATCH_METHOD_STR = "PATCH";
	public static final String DELETE_METHOD_STR = "DELETE";
	public static final String OPTIONS_METHOD_STR = "OPTIONS";
	public static final String ANONYMOUS_USER = "Anonymous";

	public static final String TEXT_HTML_CHARSET_UTF8_CHARSET_TYPE = "text/html;charset=UTF-8";
	public static final String UTF_8_CHARSET_TYPE = "UTF-8";
	public static final String CONTENT_TYPE_REQUEST_HEADER = "Content-Type";

	public static final String CONTENT_TYPE_IMAGE_PNG = "image/png";
	public static final String CONTENT_TYPE_IMAGE_JPG = "image/jpeg";

	public static final String CONTENT_TYPE_JSON = "application/json";
	public static final String CONTENT_TYPE_XML = "application/xml";
	public static final String CONTEXT_FILTER_PATH = "shinhan/service/";
	
	public static final String REQUEST_URI_STR = "requestURI";

	/** Exception Constant **/
	public static final String SERVICE_RUNTIME_EXCEPTION_ERROR = "Some error is happened";
	public static final String THE_TOKEN_IS_INVALID_ERROR = "The Token is invalid";
	public static final String THE_TOKEN_IS_INCORRECT_FORMAT_ERROR = "The Token is incorrect format";
	public static final String THE_TOKEN_IS_BLANK_ERROR = "The Token is blank";
	public static final String THE_TOKEN_UNPERMISSION_ERROR = "The Token can not execute this operation";
	public static final String NO_RECORD_FOUND_KEY = "No record found";
	public static final String THE_TOKEN_IS_EXPIRED_ERROR = "The Token is expired";
	public static final String THE_DATA_INCORRECT_FORMAT_ERROR = "The Data is incorrect format";
	public static final String THE_LOAN_INCORRECT_RMK = "Incorrect LoanNo";
	public static final String THE_LOAN_BLANK_RMK = "LoanNo is blank";

	
	
	/** SECURE Constant **/
	public static final String SYSADMIN_STR = "SYSADMIN";
	public static final String ACCESS_TOKEN_KEY = "access-token";
	//public static final String ACCESS_TOKEN_KEY = "Authorization";
	
	public static final String PUBLIC_KEY = "public_key";
	public static final String AES_KEY = "AES_key";
	public static final String EXECUTION_TIME_KEY = "executionTime";
	public static final String TOKEN_EXPIRY_MINUTES = "Token_expiry_minutes";

	public static final String OMNI_AES_KEY = "OMNI_AES_key";
	/** Other Constant **/
	
	public static final String YES_KEY = "Y";
	public static final String GL_OPEN_BALANCE = "openBlc";
	public static final String GL_CLOSE_BALANCE = "closeBlc";
	public static final String NO_KEY = "N";
	public static final String NULL_KEY = "NULL";
	public static final String BLANK_VALUE = "";
	public static final String EMPTY_KEY = "EMPTY";
	public static final String SUCCESS_KEY = "SUCCESS";
	public static final String SUCCESS_RESPONSE_KEY = "200";
	public static final String ERROR_100_RESPONSE_KEY = "100";
	public static final String ERROR_KEY = "ERROR";
	public static final String COMMA = ",";
	public static final String OMSID = "ID";
	public static String _USERNAME_BATCHJOB = "BatchJob";
	
	public static final BigDecimal DEC_ZERO = new BigDecimal("0");
	/** Metadata Constant */
	public static final String _LOOKUP_CODE_KEY = "lookupCode";
	public static final String _LOOKUP_CODE_BANK_VALUE_ = "BANK_CODE";
	public static final String _LOOKUP_CODE_BANK_DISB_VALUE_ = "BANK_CODE_DISB";
	public static final String _LOOKUP_CODE_BANK_REPORT_VALUE_ = "BANK_REPORT_NM";
	public static final String _UPLOADED_FILE_KEY = "UPLOAD_FILE_STATUS";
	public static final String _BANK_STATEMENT_STATUS_KEY = "BANK_STATEMENT_TRX_STATUS";
	
	/** LMS Trx Status **/
	public static final long LMS_TRX_MATCHED = 1;
	public static final long LMS_MONEY_IN_TRANSIT = 9;
	public static final long LMS_EXCESS_MONEY_STATUS = 10;
	public static final long LMS_OTHER_CASE_STATUS = 8;
	public static final long LMS_REVERT = 11;
	public static final long LMS_UPLOAD_PENDING = 2;
	public static final long LMS_UPLOADED_PENDING = 3;
	public static final long LMS_CANCEL_TRX = 4;
	public static final long LMS_DUP_TRX = 15;
	public static final long LMS_DELETE_TRX = 7;
	public static final long LMS_CASE_HANDLED_TRX = 6;
	public static final long _LMS_LOAN_STATUS_ACTIVE = 1;
	public static final long _LMS_LOAN_STATUS_UNACTIVE = 2;
	
	/** Metadata Value Constant */
	public static final long _BANK_STATEMENT_MATCH_STATUS = 1;
	public static final long _BANK_STATEMENT_PENDING_STATUS = 2;
	public static final long _BANK_STATEMENT_FIN_DAILY_STATUS = 11;
	public static final long _BANK_STATEMENT_REVERT_STATUS = 3;
	public static final long _BANK_STATEMENT_REFUND_STATUS = 4;
	public static final long _BANK_STATEMENT_FINANCE_STATUS = 5;
	public static final long _BANK_STATEMENT_CASE_HANDLED_STATUS = 6;
	public static final long _BANK_STATEMENT_OTHER_CASE_STATUS = 8;
	public static final long _BANK_STATEMENT_DELETED_STATUS = 7;
	public static final long _UPLOAD_FILE_PENDING_STATUS = 16;
	public static final long _UPLOAD_FILE_NORMAL_STATUS = 10;
	public static final long _UPLOAD_FILE_DELETE_STATUS = 20;
	public static final long _UPLOAD_FILE_PENDING_DELETE_STATUS = 19;
	public static final long _RECONCILE_PROCESSING_STATUS = 11;
	public static final long _RECONCILE_DONE_STATUS = 10;
	public static final long _RECONCILE_ERROR_STATUS = 19;
	public static final long _SUSPENSE_PENDING_STATUS = 2;
	public static final long _SUSPENSE_DONE_STATUS = 1;
	public static final long _SUSPENSE_INCOME_STATUS = 4;
	public static final long _SUSPENSE_DELETE_STATUS = 3;
	public static final long _LOAN_CORRECT_SUBSTATUS = 1;
	public static final long _LOAN_INCORRECT_SUBSTATUS = 2;
	public static final long _LOAN_INPARSE_SUBSTATUS = 3;
	public static final long _BANK_DISBURSAL_STATUS_MATCHED = 1;
	public static final long _BANK_DISBURSAL_STATUS_PENDING = 2;
	public static final long _BANK_DISBURSAL_STATUS_REVERTED = 3;
	public static final long _BANK_DISBURSAL_STATUS_CRSHIELD = 9;
	public static final long _BANK_DISBURSAL_STATUS_FINANCE = 5;
	public static final long _BANK_DISBURSAL_STATUS_EXCESS  = 6;
	public static final long _BANK_DISBURSAL_STATUS_RE_DISB  = 8;
	public static final long _BANK_DISBURSAL_STATUS_DELETE  = 7;
	
	
	/** File Statement Mas Constant **/
	public static final String UPLOAD_DATE_KEY = "uploadDt";
	public static final String UPLOAD_BANKCODE_KEY = "bankCode";
	public static final String UPLOAD_BANKSTATUS_KEY = "status";
	public static final String UPLOAD_TRXTYPE_KEY = "transactionType";
	public static final String VALUE_DATE_KEY = "valueDt";
	public static final String TRX_DATE_KEY = "trxDt";
	public static final String FILE_NAME = "FILE_NAME";
	public static final String FILE_ID = "fileId";
	
	
	/** Bank Statement Transaction Constant **/
	public static final String REF_KEY = "ref";
	public static final String LOAN_NO_KEY = "loanNo";
	public static final String PAY_MODE_KEY = "payMode";
	public static final String CIF_KEY = "cif";
	public static final String _BANK_CODE_KEY = "bankCode";
	public static final String _BANK_NAME_KEY = "bankName";

	/** Common Constant */
	public static final String _BIZCODE_KEY = "biz_code";
	public static final String _BANK_STATEMENT_MATCHING = "MATCHING_LIST";
	public static final String _BANK_FILE_LIST = "FILE_LIST";
	public static final String _BANK_LMS_MATCHING = "LMS_MATCHING_LIST";
	public static final String _BANK_STATEMENT_REVERSAL = "REVERSAL_LIST";
	public static final String _BANK_STATEMENT_FINANCE = "FINANCE_LIST";
	public static final String _BANK_STATEMENT_FINANCE_PENDING = "FINANCE_PENDING_LIST";
	public static final  String _BANK_STATEMENT_UNMATCHING = "UN_MATCHING_LIST";
	public static final  String _BANK_LMS_UNMATCHING = "UN_MATCHING_LMS_LIST";
	public static final  String _BANK_SUSPEND_LIST = "SUSPEND_LIST";
	public static final  String _BANK_DISBURS_MATCHED = "BANK_DISBURS_MATCHED";
	public static final  String _BANK_DISBURS_FINANCE = "BANK_DISBURS_FINANCE";
	public static final  String _BANK_DISBURS_UNMATCH = "BANK_DISBURS_UNMATCH";
	public static final  String _BANK_DISBURS_REVERT = "BANK_DISBURS_REVERT";
	public static final  String _BANK_DISBURS_CRSHIELD = "BANK_DISBURS_CRSHIELD";
	public static final String _OMS_ADMINSTRATOR_ = "Admin";
	public static final String _OMS_FILESCANBATCH_ = "Scan_File_Batch_Job";
	public static final String _OMS_RECONBATCH_ = "Recon_Batch_Job";
	
	
	/** Bank Common **/
	public static final String _BANK_COMMON_BIZ_TEMPLATE_VALUE_ = "BANK_FILE_TEMPLATE";
	public static final String _BANK_COMMON_BIZ_DISBURSAL_TEMPLATE_VALUE_ = "BANK_FILE_DISBURSAL_TEMPLATE";
	public static final String _BANK_COMMON_BIZ_FILE_VALUE_ = "BANK_FILE_VAL";
	public static final String _BANK_COMMON_BIZ_VALUE_ = "BIZ_VALUE";
	
	/** Regex Contain **/
	public static final String _BANK_REGEX_FINANCE = "REGEX_FINANCE";
	public static final String _REGEX_CHECK_LOAN_SUSPENSE = "REGEX_CHECK_LOAN_SUSPENSE";
	public static final String _BANK_REGEX_REVERSAL = "REGEX_REVERSAL";
	public static final String _BANK_REGEX_FINANCE_VCB = "REGEX_REVERSAL_VCB";
	public static final String _REGEX_GET_REF_AGRIBANK = "REGEX_GET_REF_AGRIBANK";
	public static final String _REGEX_GET_REF_OCB061 = "REGEX_GET_REF_OCB061";
	public static final String _REGEX_EXCPT_OCB061 = "REGEX_EXCPT_OCB061";
	public static final String _REGEX_GET_LOAN_NO = "REGEX_GET_LOAN_NO";
	public static final String _REGEX_DISB_FINANCE_VCB = "REGEX_DISB_FINANCE_VCB";
	public static final String _REGEX_DISB_CRSHIELD_VCB = "REGEX_DISB_CRSHIELD_VCB";
	public static final String _REGEX_DISB_REVERT_VCB = "REGEX_DISB_REVERT_VCB";
	
	/** LMS Transaction Type **/
	public static final long LMS_TRX_TYPE_REPAYMENT = 1;
	public static final long LMS_TRX_TYPE_DISBURSAL = 3;
	
	
	/** Suspense Report Note **/
	public static final String _SUSPENSE_NOTE_UNDFT = "Unidentified receipts";
	public static final String _SUSPENSE_NOTE_LATE_UPLOAD = "Late upload of bank statement";
	public static final String _SUSPENSE_NOTE_OVERPAY = "Over-payment from customers";
	public static final String _SUSPENSE_NOTE_WRONG_ACC = "Wrong credit to SVFC’s accounts";
	
	/** Report file type **/
	public static final long _DAILY_SUMMARY = 1;
	public static final long _DAILY_OPS = 3;
	public static final long _DAILY_OPS_DISB = 2;
	public static final long _DAILY_COLLECTION_STMT = 5;
	public static final long _DAILY_COLLECTION_DISB = 4;
	
	/** Suspense Report Type **/
	public static final long _SUSPENSE_RPT = 1;
	public static final long _WRITEOFF_RPT = 2;
	
	/** input report type **/
	public static final String _STMT_ = "STMT";
	public static final String _LMS_ = "LMS";
	public static final String _DISB_ = "DISB";
	
	
	/** pending report sheet name **/
	public static final String _REPMT_SHEET_NM = "Pending_Repayment";
	public static final String _DISB_SHEET_NM = "Pending_Disbursal";
}
