/**
 * 
 */
package com.shinhan.recon.report.model;

import java.math.BigDecimal;

/**
 * @author shds01
 *
 */
public class RepaymentForHeaderReport {
	private String fromDt;
	private String toDt;
	private String bankAccount;
	private String bankName;
	private BigDecimal openBal;
	private BigDecimal closeBal;
	private BigDecimal glOpenBal;
	private BigDecimal glCloseBal;

	/**
	 * 
	 */
	public RepaymentForHeaderReport() {
		super();
	}

	/**
	 * @param fromDt
	 * @param toDt
	 * @param bankAccount
	 * @param bankName
	 * @param openBal
	 * @param closeBal
	 */
	public RepaymentForHeaderReport(String fromDt, String toDt, String bankAccount, String bankName, BigDecimal openBal,
			BigDecimal closeBal, BigDecimal glOpenBal, BigDecimal glCloseBal) {
		super();
		this.fromDt = fromDt;
		this.toDt = toDt;
		this.bankAccount = bankAccount;
		this.bankName = bankName;
		this.openBal = openBal;
		this.closeBal = closeBal;
		this.glCloseBal =glCloseBal;
		this.glOpenBal = glOpenBal;
	}

	/**
	 * @return the fromDt
	 */
	public String getFromDt() {
		return fromDt;
	}

	/**
	 * @param fromDt the fromDt to set
	 */
	public void setFromDt(String fromDt) {
		this.fromDt = fromDt;
	}

	/**
	 * @return the toDt
	 */
	public String getToDt() {
		return toDt;
	}

	/**
	 * @param toDt the toDt to set
	 */
	public void setToDt(String toDt) {
		this.toDt = toDt;
	}

	/**
	 * @return the bankAccount
	 */
	public String getBankAccount() {
		return bankAccount;
	}

	/**
	 * @param bankAccount the bankAccount to set
	 */
	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}

	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}

	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * @return the openBal
	 */
	public BigDecimal getOpenBal() {
		return openBal;
	}

	/**
	 * @param openBal the openBal to set
	 */
	public void setOpenBal(BigDecimal openBal) {
		this.openBal = openBal;
	}

	/**
	 * @return the closeBal
	 */
	public BigDecimal getCloseBal() {
		return closeBal;
	}

	/**
	 * @param closeBal the closeBal to set
	 */
	public void setCloseBal(BigDecimal closeBal) {
		this.closeBal = closeBal;
	}

	public BigDecimal getGlOpenBal() {
		return glOpenBal;
	}

	public void setGlOpenBal(BigDecimal glOpenBal) {
		this.glOpenBal = glOpenBal;
	}

	public BigDecimal getGlCloseBal() {
		return glCloseBal;
	}

	public void setGlCloseBal(BigDecimal glCloseBal) {
		this.glCloseBal = glCloseBal;
	}
	
}
