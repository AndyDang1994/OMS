/**
 * 
 */
package com.shinhan.recon.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;

/**
 * @author shds04
 *
 */
public interface TOmsReconSuspInfDAO extends JpaRepository<TOmsReconSuspenseInf, Long> {

}
