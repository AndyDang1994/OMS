/**
 * 
 */
package com.shinhan.recon.service;

import java.io.File;
import java.util.List;

import com.shinhan.recon.repository.entity.TBankCommon;

/**
 * @author shds04
 *
 */
public interface ReconcileBankStatementAgribankService {
	public void processReconcileBankStatementAgribank(File file, List<TBankCommon> tBankCommons) throws Exception;
}
