/**
 * 
 */
package com.shinhan.recon.common;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.model.BankStatemenTrxInfo;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.core.model.LmsTrxInfo;
import com.shinhan.recon.core.model.ReconcileCommonInf;
import com.shinhan.recon.core.model.SuspenseTrxInf;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.entity.TOmsReconDisburInf;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;

/**
 * @author shds01
 *
 */
@Service("validationManagerService")
public class ValidationManagerService extends AbstractRepositoryClass{

	public HashMap<String, Object> checkValidationUpdateToUnmatch(List<BankStatementLmsTrxInfo> lst, String userName) throws BaseException{
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		Map<String, Object> inputParams;
		ArrayList<TOmsReconStmtInf> smts = new ArrayList<>();
		ArrayList<TOmsStmtFileMas> fileList = new ArrayList<>();
		ArrayList<TOmsReconLmsInf> lmss = new ArrayList<>();
		ArrayList<TOmsReconSuspenseInf> susp = new ArrayList<>();
		for(BankStatementLmsTrxInfo item : lst) {
			
			BankStatemenTrxInfo bankStatemenTrxInfo = item.getBankStatemenTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, bankStatemenTrxInfo.getId());
			TOmsReconStmtInf stmt = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getOne(inputParams);
			inputParams.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
			TOmsStmtFileMas fileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getNewestFileMas(inputParams);
			fileList.add(DTOConverter.setAddInfModForFileMas(bankStatemenTrxInfo.getStatusCode(),stmt.getStatusCode(),fileMas));
			LmsTrxInfo lmsTrxInfo = item.getLmsTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, lmsTrxInfo.getId());
			TOmsReconLmsInf lms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
			Map<String, Object> stmtMap = new HashedMap<>();
			stmtMap.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, stmt.getRefNo());
			stmtMap.put(APIConstant._CR_AMT_KEY, stmt.getCrAmt());
			
			List<TOmsReconSuspenseInf> lmsInfs  = getRepositoryManagerService()
					.gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRef(stmtMap);
			for (TOmsReconSuspenseInf tOmsReconSuspenseInf : lmsInfs) {
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_PENDING_STATUS);
				if( bankStatemenTrxInfo.getStatusCode() == APIConstant.LMS_DELETE_TRX ) {
					tOmsReconSuspenseInf.setStatusCode(APIConstant.LMS_DELETE_TRX);
				}
				susp.add(tOmsReconSuspenseInf);
			}
			if(APIConstant.LMS_TRX_MATCHED == lms.getStatusCode() && APIConstant._BANK_STATEMENT_MATCH_STATUS == stmt.getStatusCode() 
					&& stmt.getRefID().equals(lms.getRefID())) {
				DTOConverter.setUtilityTOmsReconStmtInfForUnmatch(stmt, bankStatemenTrxInfo.getStatusCode(), userName, new Date(), bankStatemenTrxInfo.getRemarkNote());
				smts.add(stmt);
				DTOConverter.setUtilityTOmsReconLmsInfForUnmatch(lms, lmsTrxInfo.getStatusCode(), userName, new Date(),lmsTrxInfo.getRemarkNote());
				lmss.add(lms);
				continue;
			}else {
				rs.put(APIConstant.RESULT_MSG, "Input information is not valid ref_no :" + lms.getRefNo() + " status :" + bankStatemenTrxInfo.getStatusCode());
				rs.put(APIConstant.RESULT, false);
				return rs;
			}
			
		}
		rs.put(APIConstant._BANK_STATEMENT_MATCHING, smts);
		rs.put(APIConstant._BANK_FILE_LIST, fileList);
		rs.put(APIConstant._BANK_LMS_MATCHING, lmss);
		rs.put(APIConstant._BANK_SUSPEND_LIST, susp);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	public HashMap<String, Object> checkValidationUpdateSuspenseTrx(List<SuspenseTrxInf> lst, String userName, boolean isConfirm) throws BaseException{
		HashMap<String, Object> rs = new HashMap<String, Object>();
		List<TOmsReconSuspenseInf> rsLst = new ArrayList<>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		Map<String, Object> inputParams = new HashMap<String, Object>();
		for(SuspenseTrxInf item : lst) {
			
			inputParams.put(APIConstant.OMSID, item.getId());
			TOmsReconSuspenseInf stmt = getRepositoryManagerService().gettOmsReconSuspInfManagerRepositoryService().getOne(inputParams);
			if( isConfirm ) {
				DTOConverter.setUtilityTOmsReconSuspenseInfForConfirm(stmt, userName,  new Date(), item.getRemarkNote());
			}else {
				DTOConverter.setUtilityTOmsReconSuspenseInfForUpdate(stmt,item.getStatus(), userName,  new Date(), item.getRemarkNote());
			}
			rsLst.add(stmt);
			
		}
		rs.put(APIConstant._BANK_SUSPEND_LIST, rsLst);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	public HashMap<String, Object> checkValidationUpdateDisbToUnmatch(List<BankStatementLmsTrxInfo> lst, String userName) throws BaseException{
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		Map<String, Object> inputParams;
		ArrayList<TOmsReconDisburInf> smts = new ArrayList<>();
		ArrayList<TOmsReconLmsInf> lmss = new ArrayList<>();
		ArrayList<TOmsStmtFileMas> fileList = new ArrayList<>();
		
		for(BankStatementLmsTrxInfo item : lst) {
			
			BankStatemenTrxInfo bankStatemenTrxInfo = item.getBankStatemenTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, bankStatemenTrxInfo.getId());
			TOmsReconDisburInf stmt = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getOne(inputParams);
			inputParams.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
			TOmsStmtFileMas fileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getNewestFileMas(inputParams);
			fileList.add(DTOConverter.setAddInfModForFileMas(bankStatemenTrxInfo.getStatusCode(),stmt.getStatusCode(),fileMas));
			LmsTrxInfo lmsTrxInfo = item.getLmsTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, lmsTrxInfo.getId());
			TOmsReconLmsInf lms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
			
			if(APIConstant.LMS_TRX_MATCHED == lms.getStatusCode() && APIConstant._BANK_STATEMENT_MATCH_STATUS == stmt.getStatusCode() 
					&& stmt.getRefID().equals(lms.getRefID())) {
				DTOConverter.setUtilityTDisburForUnmatch(stmt, bankStatemenTrxInfo.getStatusCode(), userName, new Date(), bankStatemenTrxInfo.getRemarkNote());
				smts.add(stmt);
				DTOConverter.setUtilityTOmsReconLmsInfForUnmatch(lms, lmsTrxInfo.getStatusCode(), userName, new Date(),lmsTrxInfo.getRemarkNote());
				lmss.add(lms);
				continue;
			}else {
				rs.put(APIConstant.RESULT_MSG, "Input information is not valid ref_no :" + lms.getRefNo() + " status :" + bankStatemenTrxInfo.getStatusCode());
				rs.put(APIConstant.RESULT, false);
				return rs;
			}
		}
		rs.put(APIConstant._BANK_STATEMENT_MATCHING, smts);
		rs.put(APIConstant._BANK_FILE_LIST, fileList);
		rs.put(APIConstant._BANK_LMS_MATCHING, lmss);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	
	public HashMap<String, Object> checkValidationUpdateToMatch(List<BankStatementLmsTrxInfo> lst, String userName) throws BaseException{
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		BigDecimal lmsAmt = APIConstant.DEC_ZERO;
		BigDecimal stmtAmt = APIConstant.DEC_ZERO;
		Map<String, Object> inputParams;
		ArrayList<TOmsReconStmtInf> smts = new ArrayList<>();
		ArrayList<TOmsReconLmsInf> lmss = new ArrayList<>();
		ArrayList<TOmsStmtFileMas> fileList = new ArrayList<>();
		ArrayList<TOmsReconSuspenseInf> susp = new ArrayList<>();
		for(BankStatementLmsTrxInfo item : lst) {
			
			BankStatemenTrxInfo bankStatemenTrxInfo = item.getBankStatemenTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, bankStatemenTrxInfo.getId());
			TOmsReconStmtInf stmt = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getOne(inputParams);
			inputParams.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
			TOmsStmtFileMas fileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getNewestFileMas(inputParams);
			fileList.add(DTOConverter.setAddInfModForFileMas(bankStatemenTrxInfo.getStatusCode(),stmt.getStatusCode(),fileMas));
			stmtAmt = stmt.getCrAmt();
			LmsTrxInfo lmsTrxInfo = item.getLmsTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, lmsTrxInfo.getId());
			TOmsReconLmsInf lms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
			lmsAmt= lmsAmt.add(lms.getDrAmt());
			if(bankStatemenTrxInfo.getStatusCode() != lmsTrxInfo.getStatusCode() || 
			   bankStatemenTrxInfo.getStatusCode() != lmsTrxInfo.getStatusCode() || 
			   ( bankStatemenTrxInfo.getStatusCode() != APIConstant._BANK_STATEMENT_MATCH_STATUS  )){
				rs.put(APIConstant.RESULT, false);
				rs.put(APIConstant.RESULT_MSG, "Input information is not valid ref_no :" + lms.getRefNo() + " status :" + bankStatemenTrxInfo.getStatusCode());
				return rs;
			}
			Map<String, Object> stmtMap = new HashedMap<>();
			stmtMap.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, stmt.getRefNo());
			stmtMap.put(APIConstant._CR_AMT_KEY, stmt.getCrAmt());
			
			List<TOmsReconSuspenseInf> lmsInfs  = getRepositoryManagerService()
					.gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRef(stmtMap);
			for (TOmsReconSuspenseInf tOmsReconSuspenseInf : lmsInfs) {
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_DONE_STATUS);
				susp.add(tOmsReconSuspenseInf);
			}
			String refId = stmt.getRefNo() + stmt.getLoanNo() + DateUtils.getSystemDateStr(DateUtils.DATE_FORMAT);
			DTOConverter.setUtilityTOmsReconStmtInfForMatch(stmt,bankStatemenTrxInfo.getStatusCode(), refId, userName, new Date(),bankStatemenTrxInfo.getRemarkNote());
			smts.add(stmt);
			DTOConverter.setUtilityTOmsReconLmsInfForMatch(lms,bankStatemenTrxInfo.getStatusCode(), refId, userName, new Date(),lmsTrxInfo.getRemarkNote());
			lmss.add(lms);
		}
		if(lmsAmt.compareTo(stmtAmt) != 0) {
			rs.put(APIConstant.RESULT_MSG, "Input information is not valid, please check reconciliation amount ");
			rs.put(APIConstant.RESULT, false);
			return rs;
		}
		rs.put(APIConstant._BANK_STATEMENT_MATCHING, smts);
		rs.put(APIConstant._BANK_FILE_LIST, fileList);
		rs.put(APIConstant._BANK_LMS_MATCHING, lmss);
		rs.put(APIConstant._BANK_SUSPEND_LIST, susp);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	public HashMap<String, Object> checkValidationUpdateDisbToMatch(List<BankStatementLmsTrxInfo> lst, String userName) throws BaseException{
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		BigDecimal lmsAmt = APIConstant.DEC_ZERO;
		BigDecimal stmtAmt = APIConstant.DEC_ZERO;
		Map<String, Object> inputParams;
		ArrayList<TOmsReconDisburInf> smts = new ArrayList<>();
		ArrayList<TOmsReconLmsInf> lmss = new ArrayList<>();
		ArrayList<TOmsStmtFileMas> fileList = new ArrayList<>();
		for(BankStatementLmsTrxInfo item : lst) {
			
			BankStatemenTrxInfo bankStatemenTrxInfo = item.getBankStatemenTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, bankStatemenTrxInfo.getId());
			TOmsReconDisburInf stmt = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getOne(inputParams);
			inputParams.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
			TOmsStmtFileMas fileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getNewestFileMas(inputParams);
			fileList.add(DTOConverter.setAddInfModForFileMas(bankStatemenTrxInfo.getStatusCode(),stmt.getStatusCode(),fileMas));
			LmsTrxInfo lmsTrxInfo = item.getLmsTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, lmsTrxInfo.getId());
			TOmsReconLmsInf lms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
			stmtAmt.add(stmt.getDrAmt());
			lmsAmt = lms.getCrAmt();
			DTOConverter.setUtilityDisburForMatch(stmt, stmt.getRefNo(), userName, new Date(),bankStatemenTrxInfo.getRemarkNote());
			smts.add(stmt);
			DTOConverter.setUtilityTOmsReconLmsInfForMatch(lms, stmt.getRefNo(), userName, new Date(),lmsTrxInfo.getRemarkNote());
			lmss.add(lms);
		}
		if(lmsAmt.compareTo(stmtAmt) != 0) {
			rs.put(APIConstant.RESULT_MSG, "Input information is not valid, please check reconciliation amount ");
			rs.put(APIConstant.RESULT, false);
			return rs;
		}
		rs.put(APIConstant._BANK_STATEMENT_MATCHING, smts);
		rs.put(APIConstant._BANK_FILE_LIST, fileList);
		rs.put(APIConstant._BANK_LMS_MATCHING, lmss);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	
	public HashMap<String, Object> checkValidationUpdateStatusBankStatement(List<BankStatemenTrxInfo> lst, String userName) throws BaseException {
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		Map<String, Object> inputParams;
		ArrayList<TOmsReconStmtInf> smts = new ArrayList<>();
		ArrayList<TOmsReconSuspenseInf> susp = new ArrayList<>();
		ArrayList<TOmsStmtFileMas> fileList = new ArrayList<>();
		for(BankStatemenTrxInfo info : lst) {
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, info.getId());
			TOmsReconStmtInf stmt = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getOne(inputParams);
			
			inputParams.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
			TOmsStmtFileMas fileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getNewestFileMas(inputParams);
			fileList.add(DTOConverter.setAddInfModForFileMas(info.getStatusCode(),stmt.getStatusCode(),fileMas));
			
			if(APIConstant._BANK_STATEMENT_MATCH_STATUS == stmt.getStatusCode() || APIConstant._BANK_STATEMENT_MATCH_STATUS == info.getStatusCode() 
					|| StringUtils.isNotBlank(stmt.getRefID()) ) {
				rs.put(APIConstant.RESULT_MSG, "Input information is not valid, please check status["+ stmt.getStatusCode() + "]");
				rs.put(APIConstant.RESULT, false);
				return rs;
			}
			Map<String, Object> stmtMap = new HashedMap<>();
			stmtMap.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, stmt.getRefNo());
			stmtMap.put(APIConstant._CR_AMT_KEY, stmt.getCrAmt());
			List<TOmsReconSuspenseInf> lmsInfs  = getRepositoryManagerService()
					.gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRef(stmtMap);
			for (TOmsReconSuspenseInf tOmsReconSuspenseInf : lmsInfs) {
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_PENDING_STATUS);
				if( APIConstant.LMS_DELETE_TRX == info.getStatusCode()  ) {
					tOmsReconSuspenseInf.setStatusCode(APIConstant.LMS_DELETE_TRX);
				}
				susp.add(tOmsReconSuspenseInf);
			}
			DTOConverter.setUtilityTOmsReconStmtInfForChangingStatus(stmt, info, userName, new Date());
			smts.add(stmt);
		}
		rs.put(APIConstant._BANK_STATEMENT_UNMATCHING, smts);
		rs.put(APIConstant._BANK_FILE_LIST, fileList);
		rs.put(APIConstant._BANK_SUSPEND_LIST, susp);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	public HashMap<String, Object> checkValidationUpdateStatusDisb(List<BankStatemenTrxInfo> lst, String userName) throws BaseException {
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		Map<String, Object> inputParams;
		ArrayList<TOmsReconDisburInf> smts = new ArrayList<>();
		ArrayList<TOmsStmtFileMas> fileList = new ArrayList<>();
		for(BankStatemenTrxInfo info : lst) {
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, info.getId());
			TOmsReconDisburInf stmt = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getOne(inputParams);
			
			inputParams.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
			TOmsStmtFileMas fileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getNewestFileMas(inputParams);
			fileList.add(DTOConverter.setAddInfModForFileMas(info.getStatusCode(),stmt.getStatusCode(),fileMas));
			if(APIConstant._BANK_STATEMENT_MATCH_STATUS == stmt.getStatusCode() || APIConstant._BANK_STATEMENT_MATCH_STATUS == info.getStatusCode() 
					|| StringUtils.isNotBlank(stmt.getRefID()) ) {
				rs.put(APIConstant.RESULT_MSG, "Input information is not valid, please check status["+ stmt.getStatusCode() + "]");
				rs.put(APIConstant.RESULT, false);
				return rs;
			}
			
			DTOConverter.setUtilityDisbForChangingStatus(stmt, info, userName, new Date());
			smts.add(stmt);
		}
		rs.put(APIConstant._BANK_STATEMENT_UNMATCHING, smts);
		rs.put(APIConstant._BANK_FILE_LIST, fileList);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	
	public HashMap<String, Object> checkValidationUpdateStatusLMS(List<LmsTrxInfo> lst, String userName) throws BaseException {
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		Map<String, Object> inputParams;
		ArrayList<TOmsReconLmsInf> lmss = new ArrayList<>();
		for(LmsTrxInfo info : lst) {
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, info.getId());
			TOmsReconLmsInf lms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
			
			if(APIConstant.LMS_TRX_MATCHED == lms.getStatusCode() || APIConstant.LMS_TRX_MATCHED == info.getStatusCode() 
					|| StringUtils.isNotBlank(lms.getRefID()) ) {
				rs.put(APIConstant.RESULT_MSG, "Input information is not valid, please check status["+ lms.getStatusCode() + "]" + " ref_no["+ lms.getRefNo() + "]");
				rs.put(APIConstant.RESULT, false);
				return rs;
			}
			
			DTOConverter.setUtilityTOmsReconLmsInfForChangingStatus(lms, info, userName, new Date());
			lmss.add(lms);
		}
		rs.put(APIConstant._BANK_LMS_UNMATCHING, lmss);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	public HashMap<String, Object> checkUpdateRemark(List<ReconcileCommonInf> lst, String userName) throws BaseException {
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		Map<String, Object> inputParams;
		ArrayList<TOmsReconLmsInf> lmss = new ArrayList<>();
		ArrayList<TOmsReconStmtInf> stmts = new ArrayList<>();
		List<TOmsReconDisburInf> disbs = new ArrayList<>();
		for(ReconcileCommonInf info : lst) {
			switch (info.getType()) {
				case APIConstant._STMT_:
					inputParams = new HashMap<String, Object>();
					inputParams.put(APIConstant.OMSID, info.getId());
					TOmsReconStmtInf stmt = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getOne(inputParams);
					stmt.setRemarkNote(info.getRemarkNote());
					stmts.add(stmt);
					break;
				case APIConstant._LMS_:
					inputParams = new HashMap<String, Object>();
					inputParams.put(APIConstant.OMSID, info.getId());
					TOmsReconLmsInf lms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
					
					lms.setRemarkNote(info.getRemarkNote());
					lmss.add(lms);
					break;
				case APIConstant._DISB_:
					inputParams = new HashMap<String, Object>();
					inputParams.put(APIConstant.OMSID, info.getId());
					TOmsReconDisburInf disb = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getOne(inputParams);
					disb.setRemarkNote(info.getRemarkNote());
					disbs.add(disb);
					break;
			}
			
		}
		rs.put(APIConstant._BANK_LMS_MATCHING, lmss);
		rs.put(APIConstant._BANK_STATEMENT_MATCHING, stmts);
		rs.put(APIConstant._BANK_DISBURS_MATCHED, disbs);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
}
