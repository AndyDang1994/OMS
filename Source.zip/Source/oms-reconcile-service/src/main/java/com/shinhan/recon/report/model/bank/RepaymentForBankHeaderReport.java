/**
 * 
 */
package com.shinhan.recon.report.model.bank;

import com.shinhan.recon.report.model.RepaymentForHeaderReport;

/**
 * @author shds01
 *
 */
public class RepaymentForBankHeaderReport extends RepaymentForHeaderReport{

	
	/**
	 * 
	 */
	public RepaymentForBankHeaderReport() {
		super();
	}

	/**
	 * @param fromDt
	 * @param toDt
	 * @param bankAccount
	 * @param bankName
	 */
	public RepaymentForBankHeaderReport(String fromDt, String toDt, String bankAccount, String bankName) {
		super();
		this.setFromDt(fromDt);
		this.setToDt(fromDt);
		this.setBankAccount(bankAccount);
		this.setBankName(bankName);
	}

}
