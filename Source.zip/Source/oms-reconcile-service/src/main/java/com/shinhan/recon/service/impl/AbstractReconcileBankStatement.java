/**
 * 
 */
package com.shinhan.recon.service.impl;

import java.io.File;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.UnaryOperator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;

import com.google.gson.JsonArray;
import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.BankFileReconResult;
import com.shinhan.recon.core.model.BankTemplateInfo;
import com.shinhan.recon.core.model.statement.BankStatementCommonTemplate;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.CompareBankStatementProcess;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.core.util.ReadFromCSV;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;
import com.shinhan.recon.service.ReconcileConvert;
import com.shinhan.recon.service.ReconcileParser;

/**
 * @author shds04
 *
 */
public abstract class AbstractReconcileBankStatement extends AbstractServiceClass {
	
	protected void processLoadReconcileInfo(File file, TBankCommon bankFileVal,List<BankStatementCommonTemplate> bankStatements,List<TOmsStmtFileMas> tOmsStmtFileMasList,List<TOmsReconStmtInf> stmtMatchingList,List<TOmsReconStmtInf> stmtUnMatchingList,
			List<TOmsReconLmsInf> lmsMatchingList,List<TOmsReconLmsInf> lmsUnMatchingList,List<TOmsReconSuspenseInf> suspanseList,List<TOmsReconStmtInf> bankStatementsFinance,List<TOmsReconStmtInf> bankStatementsReversal,List<TOmsReconStmtInf> stmtDebitList)
			throws ServiceRuntimeException, BaseException {
		Map<String, Object> unMatchinglistMap = new HashMap<>();
		Map<String, Object> statementFileMasMap = new HashedMap<String, Object>();
		Map<String, Object> lmsParaMap = new HashMap<>();
		
		unMatchinglistMap.put(APIConstant._BANK_CODE_KEY, bankFileVal.getBankAccNuber());
		unMatchinglistMap.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_PENDING_STATUS);
		unMatchinglistMap.put(APIConstant._START_DATE_KEY, DateUtils.getFirstDayOfLastMonth(DateUtils.DATEFORMAT));
		unMatchinglistMap.put(APIConstant._END_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_BANKCODE_KEY, bankFileVal.getBankAccNuber());
		statementFileMasMap.put(APIConstant.UPLOAD_TRXTYPE_KEY,  APIConstant.LMS_TRX_TYPE_REPAYMENT);
		statementFileMasMap.put(APIConstant._STATUS_KEY,  APIConstant._UPLOAD_FILE_NORMAL_STATUS);
		lmsParaMap.put(APIConstant.UPLOAD_BANKCODE_KEY, bankFileVal.getBankAccNuber());
		lmsParaMap.put(APIConstant.UPLOAD_BANKSTATUS_KEY, APIConstant.LMS_UPLOAD_PENDING);
		lmsParaMap.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		List<TOmsReconStmtInf> reconStmtInfs = new ArrayList<>();
		reconStmtInfs = DTOConverter
					.setCommonTemplateToOmsReconStmtInf(bankStatements, bankFileVal.getBankAccNuber(), 
															APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
																	DateUtils.DATEFORMAT), APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT), 0) ;
		
		getLoanNoFromDescription(reconStmtInfs, oracleOMSNamedQueries.get(APIConstant._REGEX_GET_LOAN_NO).replaceAll("\\s+",""));
		List<TOmsReconStmtInf> unmatchPrevious =  getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService()
				.getListTrxByStatus(unMatchinglistMap);
		List<TOmsReconLmsInf>  lmsStatementList = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService()
				.getListLmsTrxByBankCode(lmsParaMap);
		
		reconStmtInfs.addAll( unmatchPrevious );
		
		tOmsStmtFileMasList.addAll(getRepositoryManagerService()
				.getTomsStmtFileMasManagerRepositoryService().getListUploadByDateAndStatus(statementFileMasMap)); 
		
		stmtDebitList.addAll(CompareBankStatementProcess.getFinanceList(reconStmtInfs));
		reconStmtInfs.removeAll(stmtDebitList);
		CompareBankStatementProcess.getMatchingList(reconStmtInfs, lmsStatementList,stmtMatchingList,lmsMatchingList);
		if(APIConstant.BANK_STATEMENT_VIETCOMBANK.equals(bankFileVal.getBankCode())) {
			String regexFinance =  oracleOMSNamedQueries.get(APIConstant._BANK_REGEX_FINANCE_VCB).toLowerCase().replaceAll("\\s+","");
			bankStatementsFinance.addAll(CompareBankStatementProcess.getMatchingListByPattern(stmtDebitList, regexFinance));
			String regexReversal =  oracleOMSNamedQueries.get(APIConstant._BANK_REGEX_REVERSAL).toLowerCase().replaceAll("\\s+","");
			bankStatementsReversal.addAll( CompareBankStatementProcess.getMatchingListByPattern(stmtDebitList, regexReversal));
		}else {
			String regexFinance =  oracleOMSNamedQueries.get(APIConstant._BANK_REGEX_FINANCE).toLowerCase().replaceAll("\\s+","");
			bankStatementsFinance.addAll(CompareBankStatementProcess.getMatchingListByPattern(stmtDebitList, regexFinance));
			String regexReversal =  oracleOMSNamedQueries.get(APIConstant._BANK_REGEX_REVERSAL).toLowerCase().replaceAll("\\s+","");
			bankStatementsReversal.addAll( CompareBankStatementProcess.getMatchingListByPattern(stmtDebitList, regexReversal));
		}
		
		
		stmtDebitList.removeAll(bankStatementsFinance);  
		stmtDebitList.removeAll(bankStatementsReversal);
		
		stmtUnMatchingList.addAll( CommonUtil.getDiffStmtList(reconStmtInfs, stmtMatchingList));
		lmsUnMatchingList.addAll(CommonUtil.getDiffStmtList(lmsStatementList, lmsMatchingList));
		suspanseList.addAll( DTOConverter.getSuspenseListFromStatement(stmtUnMatchingList));
		//suspanseList.addAll( DTOConverter.getSuspenseListFromLms(lmsUnMatchingList));
		
		TOmsStmtFileMas tOmsStmtFileMas = getFileMasByFileName(file.getName(), tOmsStmtFileMasList);
		if( StringUtils.isBlank(tOmsStmtFileMas.getBankCode())) {
			throw new ServiceRuntimeException("File_Mas is null " + env.getProperty("MSG_004"));
		}
		lmsMatchingList.stream().forEach(e->{  
//			if(DateUtils.isPreviousMonth(e.getRemarkNote()) && 
//				!DateUtils.isPreviousMonth(e.getTrxDt())) {
//				e.setStatusCode(APIConstant.LMS_UPLOADED_PENDING);
//			}else {
//				e.setStatusCode(APIConstant._BANK_STATEMENT_MATCH_STATUS);
//			}
			if(DateUtils.getFieldOfDate(e.getRemarkNote(),Calendar.MONTH) != DateUtils.getFieldOfDate(e.getTrxDt(),Calendar.MONTH)) {
				e.setStatusCode(APIConstant.LMS_UPLOADED_PENDING);
			}else {
				e.setStatusCode(APIConstant._BANK_STATEMENT_MATCH_STATUS);
			}
			
		});
		for (TOmsReconStmtInf e : stmtMatchingList) {
			TOmsReconLmsInf tmp = new TOmsReconLmsInf();
			for (TOmsReconLmsInf lms : lmsMatchingList) {
				if( lms.getRefID().equals(e.getRefID()) ) {
					tmp = lms;
					break;
				}
			}
//			if( !DateUtils.isPreviousMonth(e.getValueDt()) ||
//				( DateUtils.getFieldOfDate(e.getValueDt(),Calendar.MONTH) == DateUtils.getFieldOfDate(tmp.getTrxDt(),Calendar.MONTH) )	) {
//				
//				e.setStatusCode(APIConstant._BANK_STATEMENT_MATCH_STATUS);
//				
//			}else {
//				e.setStatusCode(APIConstant._BANK_STATEMENT_PENDING_STATUS);
//				
//			}
			if( DateUtils.getFieldOfDate(e.getValueDt(),Calendar.MONTH) == DateUtils.getFieldOfDate(tmp.getTrxDt(),Calendar.MONTH)	) {
				
				e.setStatusCode(APIConstant._BANK_STATEMENT_MATCH_STATUS);
				
			}else {
				e.setStatusCode(APIConstant._BANK_STATEMENT_PENDING_STATUS);
				
			}
			if(e.getRefIdFileMas() == null) {
				e.setRefIdFileMas(tOmsStmtFileMas.getId());
			}
			
		}
		
		bankStatementsFinance.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_FINANCE_STATUS);
			if(e.getRefIdFileMas() == null) {
				e.setRefIdFileMas(tOmsStmtFileMas.getId());
			}
			
		});
	
		stmtUnMatchingList.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_PENDING_STATUS);
			if(e.getRefIdFileMas() == null) {
				e.setRefIdFileMas(tOmsStmtFileMas.getId());
			}
			
		});
		lmsUnMatchingList.stream().forEach(e->{
			e.setStatusCode(APIConstant.LMS_UPLOAD_PENDING);
		});
		suspanseList.stream().forEach(e->{
			e.setStatusCode(APIConstant._SUSPENSE_PENDING_STATUS);
			e.setConfirmYn(APIConstant.NO_KEY);
			if(e.getRefIdFileMas() == null) {
				e.setRefIdFileMas(tOmsStmtFileMas.getId());
			}
			
		});
		stmtDebitList.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_FINANCE_STATUS);
			if(e.getRefIdFileMas() == null) {
				e.setRefIdFileMas(tOmsStmtFileMas.getId());
			}
			
		});
		
		bankStatementsReversal.stream().forEach(e->{
			if(e.getRefIdFileMas() == null) {
				e.setRefIdFileMas(tOmsStmtFileMas.getId());
			}
			
		});
	}
	protected void processLoadReconcileInfo(File file, TBankCommon bankFileVal,List<BankStatementCommonTemplate> bankStatements,List<TOmsStmtFileMas> tOmsStmtFileMasList,List<TOmsReconStmtInf> stmtMatchingList,List<TOmsReconStmtInf> stmtUnMatchingList,
			List<TOmsReconLmsInf> lmsMatchingList,List<TOmsReconLmsInf> lmsUnMatchingList,List<TOmsReconSuspenseInf> suspanseList,List<TOmsReconStmtInf> bankStatementsFinance,List<TOmsReconStmtInf> bankStatementsReversal,List<TOmsReconStmtInf> stmtDebitList, ReconcileConvert<TOmsReconStmtInf> reconcileConvert)
					throws ServiceRuntimeException, BaseException {
		Map<String, Object> unMatchinglistMap = new HashMap<>();
		Map<String, Object> statementFileMasMap = new HashedMap<String, Object>();
		Map<String, Object> lmsParaMap = new HashMap<>();
		
		unMatchinglistMap.put(APIConstant._BANK_CODE_KEY, bankFileVal.getBankAccNuber());
		unMatchinglistMap.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_PENDING_STATUS);
		unMatchinglistMap.put(APIConstant._START_DATE_KEY, DateUtils.getFirstDayOfLastMonth(DateUtils.DATEFORMAT));
		unMatchinglistMap.put(APIConstant._END_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_BANKCODE_KEY, bankFileVal.getBankAccNuber());
		statementFileMasMap.put(APIConstant.UPLOAD_TRXTYPE_KEY,  APIConstant.LMS_TRX_TYPE_REPAYMENT);
		statementFileMasMap.put(APIConstant._STATUS_KEY,  APIConstant._UPLOAD_FILE_NORMAL_STATUS);
		lmsParaMap.put(APIConstant.UPLOAD_BANKCODE_KEY, bankFileVal.getBankAccNuber());
		lmsParaMap.put(APIConstant.UPLOAD_BANKSTATUS_KEY, APIConstant.LMS_UPLOAD_PENDING);
		lmsParaMap.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		List<TOmsReconStmtInf> reconStmtInfs =  reconcileConvert.convertStatement(bankStatements, bankFileVal);
//		if(bankFileVal.getBankCode().equals(APIConstant.BANK_STATEMENT_OCB_061)) {
//			reconStmtInfs = DTOConverter
//					.setCommonTemplateToOmsReconStmtInfForCiti(bankStatements, bankFileVal.getBankAccNuber(), 
//							APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
//									DateUtils.DATEFORMAT), APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT), 1) ;
//		}else {
//			reconStmtInfs = DTOConverter
//					.setCommonTemplateToOmsReconStmtInf(bankStatements, bankFileVal.getBankAccNuber(), 
//							APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
//									DateUtils.DATEFORMAT), APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT), 1) ;
//		}
		
		
		getLoanNoFromDescription(reconStmtInfs, oracleOMSNamedQueries.get(APIConstant._REGEX_GET_LOAN_NO).replaceAll("\\s+",""));
		List<TOmsReconStmtInf> unmatchPrevious =  getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService()
				.getListTrxByStatus(unMatchinglistMap);
		List<TOmsReconLmsInf>  lmsStatementList = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService()
				.getListLmsTrxByBankCode(lmsParaMap);
		
		reconStmtInfs.addAll( unmatchPrevious );
		
		tOmsStmtFileMasList.addAll(getRepositoryManagerService()
				.getTomsStmtFileMasManagerRepositoryService().getListUploadByDateAndStatus(statementFileMasMap)); 
		
		stmtDebitList.addAll(CompareBankStatementProcess.getFinanceList(reconStmtInfs));
		reconStmtInfs.removeAll(stmtDebitList);
		CompareBankStatementProcess.getMatchingList(reconStmtInfs, lmsStatementList,stmtMatchingList,lmsMatchingList);
		if(APIConstant.BANK_STATEMENT_VIETCOMBANK.equals(bankFileVal.getBankCode())) {
			String regexFinance =  oracleOMSNamedQueries.get(APIConstant._BANK_REGEX_FINANCE_VCB).toLowerCase().replaceAll("\\s+","");
			bankStatementsFinance.addAll(CompareBankStatementProcess.getMatchingListByPattern(stmtDebitList, regexFinance));
			String regexReversal =  oracleOMSNamedQueries.get(APIConstant._BANK_REGEX_REVERSAL).toLowerCase().replaceAll("\\s+","");
			bankStatementsReversal.addAll( CompareBankStatementProcess.getMatchingListByPattern(stmtDebitList, regexReversal));
		}else {
			String regexFinance =  oracleOMSNamedQueries.get(APIConstant._BANK_REGEX_FINANCE).toLowerCase().replaceAll("\\s+","");
			bankStatementsFinance.addAll(CompareBankStatementProcess.getMatchingListByPattern(stmtDebitList, regexFinance));
			String regexReversal =  oracleOMSNamedQueries.get(APIConstant._BANK_REGEX_REVERSAL).toLowerCase().replaceAll("\\s+","");
			bankStatementsReversal.addAll( CompareBankStatementProcess.getMatchingListByPattern(stmtDebitList, regexReversal));
		}
		
		
		stmtDebitList.removeAll(bankStatementsFinance);  
		stmtDebitList.removeAll(bankStatementsReversal);
		
		stmtUnMatchingList.addAll( CommonUtil.getDiffStmtList(reconStmtInfs, stmtMatchingList));
		lmsUnMatchingList.addAll(CommonUtil.getDiffStmtList(lmsStatementList, lmsMatchingList));
		suspanseList.addAll( DTOConverter.getSuspenseListFromStatement(stmtUnMatchingList));
		//suspanseList.addAll( DTOConverter.getSuspenseListFromLms(lmsUnMatchingList));
		
		TOmsStmtFileMas tOmsStmtFileMas = getFileMasByFileName(file.getName(), tOmsStmtFileMasList);
		if( StringUtils.isBlank(tOmsStmtFileMas.getBankCode())) {
			throw new ServiceRuntimeException("File_Mas is null " + env.getProperty("MSG_004"));
		}
		lmsMatchingList.stream().forEach(e->{  
			if(DateUtils.isPreviousMonth(e.getRemarkNote()) && 
				!DateUtils.isPreviousMonth(e.getTrxDt())) {
				e.setStatusCode(APIConstant.LMS_UPLOADED_PENDING);
			}else {
				e.setStatusCode(APIConstant._BANK_STATEMENT_MATCH_STATUS);
			}
			
		});
		for (TOmsReconStmtInf e : stmtMatchingList) {
			TOmsReconLmsInf tmp = new TOmsReconLmsInf();
			for (TOmsReconLmsInf lms : lmsMatchingList) {
				if( lms.getRefID().equals(e.getRefID()) ) {
					tmp = lms;
					break;
				}
			}
			if( !DateUtils.isPreviousMonth(e.getValueDt()) ||
				( DateUtils.isPreviousMonth(e.getValueDt()) && DateUtils.isPreviousMonth(tmp.getTrxDt()) )	) {
				
				e.setStatusCode(APIConstant._BANK_STATEMENT_MATCH_STATUS);
				
			}else {
				e.setStatusCode(APIConstant._BANK_STATEMENT_PENDING_STATUS);
				
			}
			if(e.getRefIdFileMas() == null) {
				e.setRefIdFileMas(tOmsStmtFileMas.getId());
			}
			
		}
		
		bankStatementsFinance.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_FINANCE_STATUS);
			if(e.getRefIdFileMas() == null) {
				e.setRefIdFileMas(tOmsStmtFileMas.getId());
			}
		});
		
		stmtUnMatchingList.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_PENDING_STATUS);
			if(e.getRefIdFileMas() == null) {
				e.setRefIdFileMas(tOmsStmtFileMas.getId());
			}
		});
		lmsUnMatchingList.stream().forEach(e->{
			e.setStatusCode(APIConstant.LMS_UPLOAD_PENDING);
		});
		suspanseList.stream().forEach(e->{
			e.setStatusCode(APIConstant._SUSPENSE_PENDING_STATUS);
			e.setConfirmYn(APIConstant.NO_KEY);
			if(e.getRefIdFileMas() == null) {
				e.setRefIdFileMas(tOmsStmtFileMas.getId());
			}
		});
		stmtDebitList.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_FINANCE_STATUS);
			if(e.getRefIdFileMas() == null) {
				e.setRefIdFileMas(tOmsStmtFileMas.getId());
			}
		});
		
		bankStatementsReversal.stream().forEach(e->{
			if(e.getRefIdFileMas() == null) {
				e.setRefIdFileMas(tOmsStmtFileMas.getId());
			}
		});
	}
	
	protected void processReconcileDataBase(List<TOmsReconStmtInf> stmtMatchingList, List<TOmsReconStmtInf> stmtDebitList,
			List<TOmsReconStmtInf> stmtUnMatchingList, List<TOmsReconLmsInf> lmsMatchingList,
			List<TOmsReconLmsInf> lmsUnMatchingList, List<TOmsReconSuspenseInf> suspanseList,
			List<TOmsReconStmtInf> bankStatementsFinance, List<TOmsReconStmtInf> bankStatementsReversal,
			TOmsStmtFileMas tOmsStmtFileMas) throws Exception {
		HashMap<String, Object> rs = new HashMap<>();
		rs.put(APIConstant._BANK_STATEMENT_UNMATCHING, stmtUnMatchingList);
		rs.put(APIConstant._BANK_LMS_UNMATCHING, lmsUnMatchingList);
		rs.put(APIConstant._BANK_STATEMENT_MATCHING, stmtMatchingList);
		rs.put(APIConstant._BANK_STATEMENT_FINANCE, bankStatementsFinance);
		rs.put(APIConstant._BANK_STATEMENT_REVERSAL, bankStatementsReversal);
		rs.put(APIConstant._BANK_STATEMENT_FINANCE_PENDING, stmtDebitList);
		rs.put(APIConstant._BANK_LMS_MATCHING, lmsMatchingList);
		rs.put(APIConstant._BANK_SUSPEND_LIST, suspanseList);
		
		if( StringUtils.isBlank(tOmsStmtFileMas.getBankCode())) {
			throw new ServiceRuntimeException("File_Mas is null " + env.getProperty("MSG_004"));
		}
		
		logger.info("***** Start Insert Bank Statement *****");
		createListTOmsReconStmtInfToDB(rs, APIConstant._OMS_RECONBATCH_);
		logger.info("***** End Insert Bank Statement *****");
		logger.info("***** Start Update LMS *****");
		updateListTOmsReconLmsInfToDB(rs, APIConstant._OMS_RECONBATCH_);
		logger.info("***** End Update LMS *****");
		logger.info("***** Start Update Suspense table *****");
		createListTOmsReconSuspInfToDB(rs, APIConstant._OMS_RECONBATCH_);
		logger.info("***** End Update Suspense table *****");
		logger.info("***** Start Update File Mas *****");
		updateTOmsStmtFileMasToDB(tOmsStmtFileMas, APIConstant._OMS_RECONBATCH_);
		logger.info("***** End Update File Mas *****");
	}
	
	protected void processReconcileForReversal(List<TOmsReconStmtInf> reversalInfList, List<TOmsReconStmtInf> stmtList,
			List<TOmsReconLmsInf> lmsList) throws Exception {
		
		for (TOmsReconStmtInf reversalInf : reversalInfList) {
			Map<String, Object> stmtMap = new HashedMap<>();
			stmtMap.put(APIConstant._BANK_CODE_KEY, reversalInf.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, reversalInf.getRefNo());
			stmtMap.put(APIConstant._CR_AMT_KEY, reversalInf.getDrAmt());
			stmtMap.put(APIConstant._DR_AMT_KEY, reversalInf.getDrAmt());
			stmtMap.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
			
			List<TOmsReconStmtInf> stmtLInfs  = getRepositoryManagerService()
					.getTomsReconStmtInfManagerRepositoryService().getStatementByRevertRef(stmtMap);
			List<TOmsReconLmsInf> lmsInfs  = getRepositoryManagerService()
					.getTomsReconLmsInfManagerRepositoryService().getListLmsTrxMatchWithRevertRef(stmtMap);
			if( stmtLInfs.size() > 0 &&  lmsInfs.size() > 0) {
				for (TOmsReconStmtInf tOmsReconStmtInf : stmtLInfs) {
					if(DateUtils.isPreviousMonth(tOmsReconStmtInf.getTrxDt())) {
						tOmsReconStmtInf.setStatusCode(APIConstant._BANK_STATEMENT_REFUND_STATUS);
						reversalInf.setStatusCode(APIConstant._BANK_STATEMENT_REFUND_STATUS);
					}else {
						tOmsReconStmtInf.setStatusCode(APIConstant._BANK_STATEMENT_REVERT_STATUS);
						reversalInf.setStatusCode(APIConstant._BANK_STATEMENT_REVERT_STATUS);
					}
					stmtList.add(tOmsReconStmtInf);
				}
				for (TOmsReconLmsInf tOmsReconLmsInf : lmsInfs) {
					tOmsReconLmsInf.setStatusCode(APIConstant.LMS_CANCEL_TRX);
					lmsList.add(tOmsReconLmsInf);
				}
			}else {
				reversalInf.setStatusCode(APIConstant._BANK_STATEMENT_REVERT_STATUS);
			}
		}
	}
	protected void processReconcileForSuspense(List<TOmsReconStmtInf> reversalInfList,List<TOmsReconStmtInf> matchingList,List<TOmsReconStmtInf> unMatchingList, List<TOmsReconSuspenseInf> stmtList)
			throws ServiceRuntimeException, BaseException {
		for (TOmsReconStmtInf reversalInf : reversalInfList) {
			Map<String, Object> stmtMap = new HashedMap<>();
			stmtMap.put(APIConstant._BANK_CODE_KEY, reversalInf.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, reversalInf.getRefNo());
			stmtMap.put(APIConstant._CR_AMT_KEY, reversalInf.getDrAmt());
			stmtMap.put(APIConstant._DR_AMT_KEY, reversalInf.getDrAmt());
			
			List<TOmsReconSuspenseInf> lmsInfs  = getRepositoryManagerService()
					.gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRef(stmtMap);
			for (TOmsReconSuspenseInf tOmsReconSuspenseInf : lmsInfs) {
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_DONE_STATUS);
				stmtList.add(tOmsReconSuspenseInf);
			}
		}
		for (TOmsReconStmtInf matchings : matchingList) {
			Map<String, Object> stmtMap = new HashedMap<>();
			stmtMap.put(APIConstant._BANK_CODE_KEY, matchings.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, matchings.getRefNo());
			stmtMap.put(APIConstant._CR_AMT_KEY, matchings.getCrAmt());
			
			List<TOmsReconSuspenseInf> lmsInfs  = getRepositoryManagerService()
					.gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRef(stmtMap);
			for (TOmsReconSuspenseInf tOmsReconSuspenseInf : lmsInfs) {
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_DONE_STATUS);
				stmtList.add(tOmsReconSuspenseInf);
			}
		}
		for (TOmsReconSuspenseInf unMatching : stmtList) {
				if(!StringUtils.isBlank(unMatching.getRemark())) {
					Pattern pattern = Pattern.compile(APIConstant._REGEX_CHECK_LOAN_SUSPENSE);
					Matcher matcher = pattern.matcher(unMatching.getRemark());
					if(matcher.find()) {
						unMatching.setSuspenseType(APIConstant._SUSPENSE_NOTE_WRONG_ACC);
					}else {
						unMatching.setSuspenseType(APIConstant._SUSPENSE_NOTE_UNDFT);
					}
				}else {
					unMatching.setSuspenseType(APIConstant._SUSPENSE_NOTE_UNDFT);
				}
				
		}
		
	}

	protected List<BankStatementCommonTemplate> getBankStatement(File file, TBankCommon bankVal, Object bankTemplate, Map<String, String> glBaMap, ReconcileParser reconcileParser) throws Exception {
		List<BankStatementCommonTemplate> rs = reconcileParser.getBankStatement(file, bankVal, bankTemplate, glBaMap);
		List<BankStatementCommonTemplate> del = new ArrayList<>();
		for (BankStatementCommonTemplate bankStatementCommonTemplate : rs) {
			String crAmt = ( StringUtils.isBlank(bankStatementCommonTemplate.getCredit()) ||  bankStatementCommonTemplate.getCredit() == null ? "0" : bankStatementCommonTemplate.getCredit() );
			String drAmt = ( StringUtils.isBlank(bankStatementCommonTemplate.getDebit()) ||  bankStatementCommonTemplate.getDebit() == null ? "0" : bankStatementCommonTemplate.getDebit() );
			if( crAmt.equals("0") && drAmt.equals("0") ) {
				del.add(bankStatementCommonTemplate);
			}
		}
		rs.removeAll(del);
		return rs;
	}
	protected void processLoadReconcileInfoForNonBank(File file, TBankCommon bankFileVal,List<BankStatementCommonTemplate> bankStatements,List<TOmsStmtFileMas> tOmsStmtFileMasList,List<TOmsReconStmtInf> bankStatementsFinance,List<TOmsReconStmtInf> stmtDebitList)
			throws ServiceRuntimeException, BaseException {
		Map<String, Object> unMatchinglistMap = new HashMap<>();
		Map<String, Object> statementFileMasMap = new HashedMap<String, Object>();
		Map<String, Object> lmsParaMap = new HashMap<>();
		
		unMatchinglistMap.put(APIConstant._BANK_CODE_KEY, bankFileVal.getBankAccNuber());
		unMatchinglistMap.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_PENDING_STATUS);
		unMatchinglistMap.put(APIConstant._START_DATE_KEY, DateUtils.getFirstDayOfLastMonth(DateUtils.DATEFORMAT));
		unMatchinglistMap.put(APIConstant._END_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_BANKCODE_KEY, bankFileVal.getBankAccNuber());
		statementFileMasMap.put(APIConstant.UPLOAD_TRXTYPE_KEY,  APIConstant.LMS_TRX_TYPE_REPAYMENT);
		statementFileMasMap.put(APIConstant._STATUS_KEY,  APIConstant._UPLOAD_FILE_NORMAL_STATUS);
		lmsParaMap.put(APIConstant.UPLOAD_BANKCODE_KEY, bankFileVal.getBankAccNuber());
		lmsParaMap.put(APIConstant.UPLOAD_BANKSTATUS_KEY, APIConstant.LMS_UPLOAD_PENDING);
		
		List<TOmsReconStmtInf> reconStmtInfs = DTOConverter
				.setCommonTemplateToOmsReconStmtInf(bankStatements, bankFileVal.getBankAccNuber(), 
														APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
																DateUtils.DATEFORMAT), APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT), 1) ;
		getLoanNoFromDescription(reconStmtInfs, oracleOMSNamedQueries.get(APIConstant._REGEX_GET_LOAN_NO).replaceAll("\\s+",""));
		
		tOmsStmtFileMasList.addAll(getRepositoryManagerService()
				.getTomsStmtFileMasManagerRepositoryService().getListUploadByDateAndStatus(statementFileMasMap)); 
		bankStatementsFinance.addAll(CompareBankStatementProcess.getFinanceList(reconStmtInfs));
		stmtDebitList.addAll(reconStmtInfs);
		
		stmtDebitList.removeAll(bankStatementsFinance);
		
		TOmsStmtFileMas tOmsStmtFileMas = getFileMasByFileName(file.getName(), tOmsStmtFileMasList);
		
		bankStatementsFinance.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_FINANCE_STATUS);
			e.setRefIdFileMas(tOmsStmtFileMas.getId());
		});
		
		stmtDebitList.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_FIN_DAILY_STATUS);
			e.setRefIdFileMas(tOmsStmtFileMas.getId());
		});
	}
	protected void processLoadReconcileInfoForNonBank(File file, TBankCommon bankFileVal,List<BankStatementCommonTemplate> bankStatements,List<TOmsStmtFileMas> tOmsStmtFileMasList,List<TOmsReconStmtInf> bankStatementsFinance,List<TOmsReconStmtInf> stmtDebitList, ReconcileConvert<TOmsReconStmtInf> reconcileConvert)
			throws ServiceRuntimeException, BaseException {
		Map<String, Object> unMatchinglistMap = new HashMap<>();
		Map<String, Object> statementFileMasMap = new HashedMap<String, Object>();
		Map<String, Object> lmsParaMap = new HashMap<>();
		
		unMatchinglistMap.put(APIConstant._BANK_CODE_KEY, bankFileVal.getBankAccNuber());
		unMatchinglistMap.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_PENDING_STATUS);
		unMatchinglistMap.put(APIConstant._START_DATE_KEY, DateUtils.getFirstDayOfLastMonth(DateUtils.DATEFORMAT));
		unMatchinglistMap.put(APIConstant._END_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_BANKCODE_KEY, bankFileVal.getBankAccNuber());
		statementFileMasMap.put(APIConstant.UPLOAD_TRXTYPE_KEY,  APIConstant.LMS_TRX_TYPE_REPAYMENT);
		statementFileMasMap.put(APIConstant._STATUS_KEY,  APIConstant._UPLOAD_FILE_NORMAL_STATUS);
		lmsParaMap.put(APIConstant.UPLOAD_BANKCODE_KEY, bankFileVal.getBankAccNuber());
		lmsParaMap.put(APIConstant.UPLOAD_BANKSTATUS_KEY, APIConstant.LMS_UPLOAD_PENDING);
		
//		List<TOmsReconStmtInf> reconStmtInfs = DTOConverter
//				.setCommonTemplateToOmsReconStmtInf(bankStatements, bankFileVal.getBankAccNuber(), 
//						APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
//								DateUtils.DATEFORMAT), APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT), 1) ;
		List<TOmsReconStmtInf> reconStmtInfs = reconcileConvert.convertStatement(bankStatements, bankFileVal);
		getLoanNoFromDescription(reconStmtInfs, oracleOMSNamedQueries.get(APIConstant._REGEX_GET_LOAN_NO).replaceAll("\\s+",""));
		
		tOmsStmtFileMasList.addAll(getRepositoryManagerService()
				.getTomsStmtFileMasManagerRepositoryService().getListUploadByDateAndStatus(statementFileMasMap)); 
		bankStatementsFinance.addAll(CompareBankStatementProcess.getFinanceList(reconStmtInfs));
		stmtDebitList.addAll(reconStmtInfs);
		
		stmtDebitList.removeAll(bankStatementsFinance);
		
		TOmsStmtFileMas tOmsStmtFileMas = getFileMasByFileName(file.getName(), tOmsStmtFileMasList);
		
		bankStatementsFinance.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_FINANCE_STATUS);
			e.setRefIdFileMas(tOmsStmtFileMas.getId());
		});
		
		stmtDebitList.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_FIN_DAILY_STATUS);
			e.setRefIdFileMas(tOmsStmtFileMas.getId());
		});
	}
	
	protected List<BankStatementCommonTemplate> getBankStatementForCSV(File file, TBankCommon bankVal, Object bankTemplate) throws Exception {
		BankTemplateInfo templateInfo = DTOConverter.getBankTemplateInfo(bankVal);
		ReadFromCSV readFromCSV = new ReadFromCSV(file.getAbsolutePath());
		ArrayList<Map> lsArrMapObject = (ArrayList<Map>) readFromCSV.readDataFromCsv(templateInfo.getTemplateColName(),templateInfo.getFromRow());
		JsonArray jsonArrayDocument = (JsonArray) CommonUtil.toPojo(lsArrMapObject, JsonArray.class);
		List<String> excelColumn = Arrays.asList(templateInfo.getTemplateColName().split(","));
		Field[] bankStatementProperty = bankTemplate.getClass().getDeclaredFields();
		
		Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping = buildBankStatementMapping(excelColumn, bankStatementProperty);
		List<BankStatementCommonTemplate> bankStatements = super.mapListExcelDataToListBankStatement(jsonArrayDocument, bankStatementMapping, BankStatementCommonTemplate::new);
		for (BankStatementCommonTemplate bankStatementCommonTemplate : bankStatements) {
			if( !StringUtils.isBlank(bankStatementCommonTemplate.getLoanNo()) ) {
				bankStatementCommonTemplate.setLoanNo(bankStatementCommonTemplate.getLoanNo().replaceAll("\"", ""));
			}
		}
		List<BankStatementCommonTemplate> del = new ArrayList<>();
		for (BankStatementCommonTemplate bankStatementCommonTemplate : bankStatements) {
			if( StringUtils.isBlank(bankStatementCommonTemplate.getCredit()) && StringUtils.isBlank(bankStatementCommonTemplate.getDebit()) ) {
				del.add(bankStatementCommonTemplate);
			}
		}
		bankStatements.removeAll(del);
		return bankStatements;
	}
	
	protected void getLoanNoFromDescription(List<TOmsReconStmtInf> stmtInfs, String regex) {
		
		Pattern p = Pattern.compile(regex);
		
		for (TOmsReconStmtInf tOmsReconStmtInf : stmtInfs) {
			Matcher matcher = p.matcher(" " + tOmsReconStmtInf.getRemark() + " ");
			String regexString = "";
			
			if(matcher.find()) {
				regexString = matcher.group(1);
			}
			if( StringUtils.isBlank(tOmsReconStmtInf.getLoanNo())){
				tOmsReconStmtInf.setLoanNo(regexString.trim());
			}
		}
		
	}
	
	protected void processLoadFileMasInf(TOmsStmtFileMas tOmsStmtFileMas, int totalCnt, int successCnt,Map<String, String> glBalance, BankFileReconResult bankFileReconResult)throws ServiceRuntimeException {
		if(CommonUtil.isNumber(glBalance.get(APIConstant.GL_OPEN_BALANCE)) && CommonUtil.isNumber(glBalance.get(APIConstant.GL_CLOSE_BALANCE))) {
			tOmsStmtFileMas.setOpenBalance(new BigDecimal( StringUtils.isBlank(glBalance.get(APIConstant.GL_OPEN_BALANCE)) ? "0":glBalance.get(APIConstant.GL_OPEN_BALANCE)));
			tOmsStmtFileMas.setCloseBalance(new BigDecimal( StringUtils.isBlank(glBalance.get(APIConstant.GL_CLOSE_BALANCE)) ? "0":glBalance.get(APIConstant.GL_CLOSE_BALANCE)));
		}else {
			tOmsStmtFileMas.setOpenBalance(APIConstant.DEC_ZERO);
			tOmsStmtFileMas.setCloseBalance(APIConstant.DEC_ZERO);
		}
		tOmsStmtFileMas.setProcessStatus(APIConstant._RECONCILE_DONE_STATUS);
		tOmsStmtFileMas.setSuccessCount(successCnt);
		tOmsStmtFileMas.setTotalCount(totalCnt);
		tOmsStmtFileMas.setAddInf(CommonUtil.toJson(bankFileReconResult));
	}
	
	protected void moveFileToDirectory(File srcFile, File desFile) throws ServiceRuntimeException {
		String newFileName = "";
		newFileName = srcFile.getName() + "_" + DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss);
		CommonUtil.moveFileToDirectory(srcFile, desFile, newFileName);
	}
	
	protected BankFileReconResult loadAddInfForFileMas(List<TOmsReconStmtInf> stmtMatchingList,List<TOmsReconStmtInf> stmtUnMatchingList,
			List<TOmsReconStmtInf> bankStatementsFinance,List<TOmsReconStmtInf> bankStatementsReversal,List<TOmsReconStmtInf> stmtDebitList, TOmsStmtFileMas tOmsStmtFileMas,List<TOmsReconLmsInf> tOmsReconLmsInf) throws BaseException {
		
		
		int refuncCnt = 0;
		int revertCnt = 0; 
		int finDailyCnt = 0;
		int matched = 0;
		int unmatched = 0;
		int prevMatched = 0;
		int prevUnmatched = 0;
		int uploadedCnt = 0;
		for (TOmsReconStmtInf tOmsReconStmtInf : stmtDebitList) {
			if(tOmsReconStmtInf.getStatusCode() == APIConstant._BANK_STATEMENT_FIN_DAILY_STATUS) {
				finDailyCnt++;
			}
		}
		for (TOmsReconStmtInf tOmsReconStmtInf : bankStatementsReversal) {
			if(tOmsReconStmtInf.getStatusCode() == APIConstant._BANK_STATEMENT_REFUND_STATUS) {
				refuncCnt++;
			}
		}
		
		for (TOmsReconStmtInf tOmsReconStmtInf : stmtMatchingList) {
			if( tOmsReconStmtInf.getRefIdFileMas() == tOmsStmtFileMas.getId() ) {
				matched++;
			}else {
				prevMatched++;
			}
		}
		
		for (TOmsReconStmtInf tOmsReconStmtInf : stmtUnMatchingList) {
			if( tOmsReconStmtInf.getRefIdFileMas() == tOmsStmtFileMas.getId() ) {
				unmatched++;
			}else {
				prevUnmatched++;
			}
		}
		
		for (TOmsReconLmsInf lmsInf : tOmsReconLmsInf) {
			
			if(lmsInf.getStatusCode() == APIConstant.LMS_UPLOADED_PENDING) {
				uploadedCnt++;
			}
			
		}
		revertCnt = bankStatementsReversal.size() - refuncCnt;
		BankFileReconResult bankFileReconResult = new  BankFileReconResult(stmtMatchingList.size() + stmtUnMatchingList.size() + bankStatementsFinance.size() + stmtDebitList.size() + bankStatementsReversal.size() -prevMatched -prevUnmatched +uploadedCnt, 
				matched + uploadedCnt, unmatched, bankStatementsFinance.size() + stmtDebitList.size() -finDailyCnt, revertCnt, refuncCnt, 0, 0);
		return bankFileReconResult;
	}
}
