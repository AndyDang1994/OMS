package com.shinhan.recon.service;

import java.util.List;

import com.shinhan.recon.core.model.statement.BankStatementCommonTemplate;
import com.shinhan.recon.repository.entity.TBankCommon;

public interface  ReconcileConvert<T> {
	
	List<T> convertStatement(List<BankStatementCommonTemplate> bankStatements,TBankCommon bankFileVal);
	
}
