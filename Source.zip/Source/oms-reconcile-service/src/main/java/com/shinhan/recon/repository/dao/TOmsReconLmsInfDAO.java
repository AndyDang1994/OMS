/**
 * 
 */
package com.shinhan.recon.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.shinhan.recon.repository.entity.TOmsReconLmsInf;

/**
 * @author shds01
 *
 */
@Repository
public interface TOmsReconLmsInfDAO extends JpaRepository<TOmsReconLmsInf, Long> {

}
