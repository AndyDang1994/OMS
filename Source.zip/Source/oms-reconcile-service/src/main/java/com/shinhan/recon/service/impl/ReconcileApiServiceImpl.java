/**
 * 
 */
package com.shinhan.recon.service.impl;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.recon.common.AbstractBasicCommonClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.recon.core.model.BankDailyReportInf;
import com.shinhan.recon.core.model.BankStatemenTrxInfo;
import com.shinhan.recon.core.model.BankStatementFile;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.core.model.LmsTrxInfo;
import com.shinhan.recon.core.model.ReconcileCommonInf;
import com.shinhan.recon.core.model.ReconcileCommonStatementInfo;
import com.shinhan.recon.core.model.SuspenseTrxInf;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;
import com.shinhan.recon.service.ReconcileApiService;

/**
 * @author shds01
 *
 */
@Service("reconcileApiService")
//@Transactional(readOnly = false, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
public class ReconcileApiServiceImpl extends AbstractBasicCommonClass implements ReconcileApiService {

	
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public BankDailyReportInf getAllBankDailyReport(Map<String, Object> inputParams) throws Exception {
		Date trxDate = DateUtils.formatStringToDate(inputParams.get(APIConstant.TRX_DATE_KEY).toString(), DateUtils.DATEFORMAT);
		Date startDate = DateUtils.convertDate(DateUtils.formatToString(DateUtils.getFirstDayOfMonth(trxDate), DateUtils.DATEFORMAT), DateUtils.DATEFORMAT);
		Date endDate = DateUtils.convertDate(DateUtils.formatToString(DateUtils.getLastDayOfMonth(trxDate), DateUtils.DATEFORMAT), DateUtils.DATEFORMAT);
		int reportType = Integer.parseInt(inputParams.get(APIConstant._TYPE_KEY).toString());
		
		inputParams.put(APIConstant._START_DATE_KEY, DateUtils.formatToString(startDate, DateUtils.DATEFORMAT));
		inputParams.put(APIConstant._END_DATE_KEY, DateUtils.formatToString(endDate, DateUtils.DATEFORMAT));
		String str = "";
		List<String> dateList = DateUtils.getListStringDate(startDate, endDate);
		for (String string : dateList) {
			str += "'" + string + "'";
			if(!string.equals(inputParams.get(APIConstant._END_DATE_KEY).toString())) {
				str += ",";
			}
		}
		BankDailyReportInf list = new BankDailyReportInf();
		inputParams.put(APIConstant.REF_KEY,str );
		if(reportType == APIConstant._DAILY_SUMMARY) {
			list = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getSummaryStatisticInf(inputParams);
		}else if(reportType == APIConstant._DAILY_OPS) {
			list = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getStatisticInf(inputParams);
		}else if(reportType == APIConstant._DAILY_OPS_DISB) {
			list = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getStatisticDisbInf(inputParams);
		}else if(reportType == APIConstant._DAILY_COLLECTION_DISB) {
			list = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getDailyCollDisbInf(inputParams);
		}else if(reportType == APIConstant._DAILY_COLLECTION_STMT) {
			list = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getDailyCollStmtInf(inputParams);
		}
		
		return list;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getListStmtFileMasByDate(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public List<BankStatementFile> getListStmtFileMasByDate(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getListStmtFileMasByDate(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#createStmtFileMas(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public TOmsStmtFileMas createStmtFileMas(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		TOmsStmtFileMas mas = (TOmsStmtFileMas) CommonUtil.toPojo(document, TOmsStmtFileMas.class);
		
		//Check validation and set Utility
		DTOConverter.setUtilityTOmsStmtFileMas(mas, userName, new Date(), userName, new Date());
		
		return createTOmsStmtFileMasToDB(mas, userName);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getOneStmtFileMas(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public TOmsStmtFileMas getOneStmtFileMas(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getOne(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#updateStmtFileMas(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public TOmsStmtFileMas updateStmtFileMas(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		TOmsStmtFileMas mas = (TOmsStmtFileMas) CommonUtil.toPojo(document, TOmsStmtFileMas.class);
		
		//Check validation and set Utility
		DTOConverter.setUtilityTOmsStmtFileMas(mas, userName, new Date(), userName, new Date());
		return updateTOmsStmtFileMasToDB(mas, userName);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getListTOmsReconLmsInfByDate(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public List<TOmsReconLmsInf> getListTOmsReconLmsInfByDate(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getListLmsTrxByDate(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#createTOmsReconLmsInf(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public TOmsReconLmsInf createTOmsReconLmsInf(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		TOmsReconLmsInf inf = (TOmsReconLmsInf) CommonUtil.toPojo(document, TOmsReconLmsInf.class);
		
		//Check validation and set Utility
		DTOConverter.setUtilityTOmsReconLmsInf(inf, userName, new Date(), userName, new Date());
		
		return createTOmsReconLmsInfToDB(inf, userName);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getOneTOmsReconLmsInf(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public TOmsReconLmsInf getOneTOmsReconLmsInf(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#updateTOmsReconLmsInf(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public TOmsReconLmsInf updateTOmsReconLmsInf(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		TOmsReconLmsInf inf = (TOmsReconLmsInf) CommonUtil.toPojo(document, TOmsReconLmsInf.class);
		
		//Check validation and set Utility
		DTOConverter.setUtilityTOmsReconLmsInf(inf, userName, new Date(), userName, new Date());
		return updateTOmsReconLmsInfToDB(inf, userName);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getListTOmsReconStmtInfByDate(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public List<TOmsReconStmtInf> getListTOmsReconStmtInfByDate(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getListTrxByDate(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#createTOmsReconStmtInf(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public TOmsReconStmtInf createTOmsReconStmtInf(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		TOmsReconStmtInf inf = (TOmsReconStmtInf) CommonUtil.toPojo(document, TOmsReconStmtInf.class);
		
		//Check validation and set Utility
		DTOConverter.setUtilityTOmsReconStmtInf(inf, userName, new Date(), userName, new Date());
		
		return createTOmsReconStmtInfToDB(inf, userName);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getOneTOmsReconStmtInf(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public TOmsReconStmtInf getOneTOmsReconStmtInf(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getOne(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#updateTOmsReconStmtInf(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public TOmsReconStmtInf updateTOmsReconStmtInf(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		TOmsReconStmtInf inf = (TOmsReconStmtInf) CommonUtil.toPojo(document, TOmsReconStmtInf.class);
		
		//Check validation and set Utility
		DTOConverter.setUtilityTOmsReconStmtInf(inf, userName, new Date(), userName, new Date());
		return updateTOmsReconStmtInfToDB(inf, userName);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#countTotalBankStatementTrxByDate(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public BigDecimal countTotalBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		if (bankCommon == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		if(APIConstant.YES_KEY.equalsIgnoreCase(bankCommon.getIsRepaymentYn())) {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		}else {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		return getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().countTotalBankStatementTrxByDate(inputParams);
	}
	
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public BigDecimal countTotalDisbursTrxByDate(Map<String, Object> inputParams) throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		if (bankCommon == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		if(APIConstant.NO_KEY.equalsIgnoreCase(bankCommon.getIsRepaymentYn())) {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
		}else {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		return getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().countTotalDisbursalTrxByDate(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getListBankStatementTrxByDate(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public List<BankStatementLmsTrxInfo> getListBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		if (bankCommon == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		if(APIConstant.YES_KEY.equalsIgnoreCase(bankCommon.getIsRepaymentYn())) {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		}else {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		return getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getListBankStatementTrxByDate(inputParams);
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#updateListBankStatementTrxByDate(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public List<BankStatementLmsTrxInfo> updateListBankStatementTrxByDate(Map<String, Object> inputParams)
			throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		boolean _isUnmatch = (boolean) inputParams.get(APIConstant.FLAG);
		HashMap<String, Object> rs = new HashMap<String, Object>();
		List<BankStatementLmsTrxInfo> lst = CommonUtil.toListPojo(document, BankStatementLmsTrxInfo.class);
		//Check validation
		
		if(_isUnmatch) {
			//For Unmatch
			rs = getValidationManagerService().checkValidationUpdateToUnmatch(lst, userName);
		}else {
			//For Match
			rs = getValidationManagerService().checkValidationUpdateToMatch(lst, userName);
		}
		boolean flag = (boolean) rs.get(APIConstant.RESULT);
		
		if(!flag) {
			throw new ServiceInvalidAgurmentException(rs.get(APIConstant.RESULT_MSG).toString());
		}
		updateToReconcileTrx(rs);
		
		return lst;
	}
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public boolean updateRemarkReconcileTrx(Map<String, Object> inputParams)
			throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		HashMap<String, Object> rs = new HashMap<String, Object>();
		List<ReconcileCommonInf> lst = CommonUtil.toListPojo(document, ReconcileCommonInf.class);
		//Check validation
		rs = getValidationManagerService().checkUpdateRemark(lst, userName);
		
		updateRemark(rs);
		
		return true;
	}
	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#countTotalUnMatchLMSTrxByDate(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public BigDecimal countTotalUnMatchLMSTrxByDate(Map<String, Object> inputParams) throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		if (bankCommon == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		if(APIConstant.YES_KEY.equalsIgnoreCase(bankCommon.getIsRepaymentYn())) {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		}else {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
		}
		return getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().countTotalUnMatchLMSTrxByDate(inputParams);
	}
	
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public List<LmsTrxInfo> getUnmatchListLMSTrxByDate(Map<String, Object> inputParams) throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		if (bankCommon == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		if(APIConstant.YES_KEY.equalsIgnoreCase(bankCommon.getIsRepaymentYn())) {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		}else {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
		}
		return getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getUnmatchListLMSTrxByDate(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#setStatusUnmatchListLMS(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public List<LmsTrxInfo> setStatusUnmatchListLMS(Map<String, Object> inputParams) throws BaseException {

		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		List<LmsTrxInfo> lst = CommonUtil.toListPojo(document, LmsTrxInfo.class);
		//Check validation
		HashMap<String, Object> rs = getValidationManagerService().checkValidationUpdateStatusLMS(lst, userName);
		boolean flag = (boolean) rs.get(APIConstant.RESULT);
		if(!flag) {
			throw new ServiceInvalidAgurmentException(rs.get(APIConstant.RESULT_MSG).toString());
		}
		updateStatusUnmatchListLMS(rs);
		
		return lst;
	
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#countTotalUnMatchBankStatementTrxByDate(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public BigDecimal countTotalUnMatchBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		if (bankCommon == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		if(APIConstant.YES_KEY.equalsIgnoreCase(bankCommon.getIsRepaymentYn())) {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		}else {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		return getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().countTotalUnmatchBankStatementTrxByDate(inputParams);
	}
	
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public BigDecimal countTotalUnMatchDisbByDate(Map<String, Object> inputParams) throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		if (bankCommon == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		if(APIConstant.NO_KEY.equalsIgnoreCase(bankCommon.getIsRepaymentYn())) {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
		}else {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		return getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().countTotalUnmatchDisbByDate(inputParams);
	}
	
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public List<BankStatemenTrxInfo> getUnmatchListBankStatementTrxByDate(Map<String, Object> inputParams)
			throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		if (bankCommon == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		if(APIConstant.YES_KEY.equalsIgnoreCase(bankCommon.getIsRepaymentYn())) {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		}else {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		return getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getUnmatchListBankStatementTrxByDate(inputParams);
	}
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public List<BankStatemenTrxInfo> getUnmatchListDisbByDate(Map<String, Object> inputParams)
			throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		if (bankCommon == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		if(APIConstant.NO_KEY.equalsIgnoreCase(bankCommon.getIsRepaymentYn())) {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
		}else {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		return getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getUnmatchListDisbByDate(inputParams);
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#setStatusUnmatchListBankStatement(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public List<BankStatemenTrxInfo> setStatusUnmatchListBankStatement(Map<String, Object> inputParams)
			throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<BankStatemenTrxInfo> lst = CommonUtil.toListPojo(document, BankStatemenTrxInfo.class);
		//Check validation
		HashMap<String, Object> rs = getValidationManagerService().checkValidationUpdateStatusBankStatement(lst, userName);
		boolean flag = (boolean) rs.get(APIConstant.RESULT);
		if(!flag) {
			throw new ServiceInvalidAgurmentException(rs.get(APIConstant.RESULT_MSG).toString());
		}
		updateStatusUnmatchListBankStatement(rs);
		
		return lst;
	}
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public List<BankStatemenTrxInfo> setStatusUnmatchListDisb(Map<String, Object> inputParams)
			throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<BankStatemenTrxInfo> lst = CommonUtil.toListPojo(document, BankStatemenTrxInfo.class);
		//Check validation
		HashMap<String, Object> rs = getValidationManagerService().checkValidationUpdateStatusDisb(lst, userName);
		boolean flag = (boolean) rs.get(APIConstant.RESULT);
		if(!flag) {
			throw new ServiceInvalidAgurmentException(rs.get(APIConstant.RESULT_MSG).toString());
		}
		updateStatusUnmatchListDisb(rs);
		
		return lst;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getBankStatementCommonInforByDate(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public ReconcileCommonStatementInfo getBankStatementCommonInforByDate(Map<String, Object> inputParams) throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		if (bankCommon == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		if(APIConstant.YES_KEY.equalsIgnoreCase(bankCommon.getIsRepaymentYn())) {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		}else {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
		}
		
		ReconcileCommonStatementInfo commonInfo = new ReconcileCommonStatementInfo();
		BankStatementLmsTrxInfo sumRecordBank = new BankStatementLmsTrxInfo();
		if(APIConstant.YES_KEY.equalsIgnoreCase(bankCommon.getIsRepaymentYn())) {
			/**Matching Data*/
			//Sum total balance trx which matching
			commonInfo.setTotalRecordMatching(getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().sumDrAndCrMatchListBankStatementTrxByDateAndBankCode(inputParams));
			
			/**UnMatching Data*/
			//Sum total balance trx which un-matching
			sumRecordBank = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().sumDrAndCrUnMatchListBankStatementTrxByDateAndBankCode(inputParams);
			
		}else {
			/**Matching Data*/
			//Sum total balance trx which matching
			commonInfo.setTotalRecordMatching(getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().sumDrAndCrMatchListDisbursalTrxByDateAndBankCode(inputParams));
			
			/**UnMatching Data*/
			//Sum total balance trx which un-matching
			sumRecordBank = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().sumDrAndCrUnMatchListDisbursalTrxByDateAndBankCode(inputParams);
			
		}
		
		//Sum the debit amount and credit amount of un-matching trx LMS
		BankStatementLmsTrxInfo sumRecordLMS = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().sumDrAndCrUnMatchListLMSTrxByDateAndBankCode(inputParams);
		
		commonInfo.setTotalRecordUnMatching(new BankStatementLmsTrxInfo(sumRecordBank.getBankStatemenTrxInfo().getDrAmt(), sumRecordBank.getBankStatemenTrxInfo().getCrAmt()
				, sumRecordLMS.getLmsTrxInfo().getDrAmt(), sumRecordLMS.getLmsTrxInfo().getCrAmt()));
		/**Grand Data*/
		commonInfo.setTotalRecordGrandData(DTOConverter.getGrandBalanceReconcileOfLMSAndBankStatement
				(commonInfo.getTotalRecordMatching().getLmsTrxInfo().getDrAmt(), commonInfo.getTotalRecordMatching().getLmsTrxInfo().getCrAmt(),
					commonInfo.getTotalRecordMatching().getBankStatemenTrxInfo().getDrAmt(), commonInfo.getTotalRecordMatching().getBankStatemenTrxInfo().getCrAmt(),
					sumRecordLMS.getLmsTrxInfo().getDrAmt(), sumRecordLMS.getLmsTrxInfo().getCrAmt(), 
					sumRecordBank.getBankStatemenTrxInfo().getDrAmt(), sumRecordBank.getBankStatemenTrxInfo().getCrAmt()));
		
		/**Header Data*/
		BankStatementFile headerData = DTOConverter.transferDataTBankCommonToBankStatementFile(bankCommon);
		BigDecimal openBal = getRepositoryManagerService().getUtilityManagerRepositoryService().getOpenBalanceOfBankCodeByDate(inputParams);
		BigDecimal closeBal = openBal.add(
				commonInfo.getTotalRecordGrandData().getBankStatemenTrxInfo().getDrAmt()
					.subtract(commonInfo.getTotalRecordGrandData().getBankStatemenTrxInfo().getCrAmt()));
		
		headerData.setOpenBalance(openBal);
		headerData.setCloseBalance(closeBal);
		commonInfo.setHeaderData(headerData);
		
		return commonInfo;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#exportReconcileReport(java.util.Map)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public File exportReconcileReport(Map<String, Object> inputParams) throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		if (bankCommon == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		} else {
			inputParams.put(APIConstant._BANK_NAME_KEY, bankCommon.getBankName());
		}
		
		if(APIConstant.YES_KEY.equalsIgnoreCase(bankCommon.getIsRepaymentYn())) {
			// For Re-payment report reconcile
			if(APIConstant.YES_KEY.equalsIgnoreCase(bankCommon.getIsBankYn())) {
				return getProcessManagerService().getReconcileExportReportService().exportReconcileRepaymentReportForBank(inputParams);
			}
			return getProcessManagerService().getReconcileExportReportService().exportReconcileRepaymentReportForNonBank(inputParams);
		} else {
			// For Disbursal report reconcile
			return getProcessManagerService().getReconcileExportReportService().exportReconcileDisbursalReport(inputParams);
		}
	}
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public File exportDailyReport(Map<String, Object> inputParams) throws Exception {
		
		Date trxDate = DateUtils.formatStringToDate(inputParams.get(APIConstant.TRX_DATE_KEY).toString(), DateUtils.DATEFORMAT);
		inputParams.put(APIConstant._START_DATE_KEY, DateUtils.formatToString(DateUtils.getFirstDayOfMonth(trxDate), DateUtils.DATEFORMAT));
		inputParams.put(APIConstant._END_DATE_KEY, DateUtils.formatToString(DateUtils.getLastDayOfMonth(trxDate), DateUtils.DATEFORMAT));
		return getProcessManagerService().getReconcileExportReportService().exportDailyReport(inputParams);

	}
	
	@Override
	public File exportSuspenseReport(Map<String, Object> inputParams) throws Exception {
	
		return getProcessManagerService().getReconcileExportReportService().exportSuspenseReport(inputParams);
		
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public boolean retryReconcileByBankcode(Map<String, Object> inputParams) throws BaseException {
		String userName =  inputParams.get(APIConstant.USERNAME_KEY).toString();
		String bankCode = inputParams.get(APIConstant.UPLOAD_BANKCODE_KEY).toString();
		inputParams.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		if (bankCommon == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		
		if(APIConstant.YES_KEY.equalsIgnoreCase(bankCommon.getIsRepaymentYn())) {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		}else {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
		}
		List<TOmsStmtFileMas> fileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getListUploadByDateAndBankCode(inputParams);
		
		for (TOmsStmtFileMas tOmsStmtFileMas : fileMas) {
			tOmsStmtFileMas.setFileStatus(APIConstant._UPLOAD_FILE_PENDING_DELETE_STATUS);
			tOmsStmtFileMas.setUploadUser(userName);
		}
		return updateTOmsStmtFileListToDB(fileMas, userName);
	}

	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public List<BankStatementLmsTrxInfo> getMatchingDisburTrxByDate(Map<String, Object> inputParams)
			throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		if (bankCommon == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		if(APIConstant.NO_KEY.equalsIgnoreCase(bankCommon.getIsRepaymentYn())) {
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
		}else {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		return getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getListMatchingTrxByDate(inputParams);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public List<BankStatementLmsTrxInfo> updateListDisburByDate(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		boolean _isUnmatch = (boolean) inputParams.get(APIConstant.FLAG);
		HashMap<String, Object> rs = new HashMap<String, Object>();
		List<BankStatementLmsTrxInfo> lst = CommonUtil.toListPojo(document, BankStatementLmsTrxInfo.class);
		//Check validation
		
		if(_isUnmatch) {
			//For Unmatch
			rs = getValidationManagerService().checkValidationUpdateDisbToUnmatch(lst, userName);
		}else {
			//For Match
			rs = getValidationManagerService().checkValidationUpdateDisbToMatch(lst, userName);
		}
		boolean flag = (boolean) rs.get(APIConstant.RESULT);
		
		if(!flag) {
			throw new ServiceInvalidAgurmentException(rs.get(APIConstant.RESULT_MSG).toString());
		}
		updateToDisbTrx(rs);
		
		return lst;
	}

	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public List<SuspenseTrxInf> getListSuspenseInf(Map<String, Object> inputParams) throws BaseException {
		List<SuspenseTrxInf> rs = new ArrayList<>();
		List<SuspenseTrxInf> lst = getRepositoryManagerService().gettOmsReconSuspInfManagerRepositoryService().getSuspenseList(inputParams);
		
		for (SuspenseTrxInf suspenseTrxInf : lst) {
			if(Long.parseLong(inputParams.get(APIConstant._TYPE_KEY).toString()) == APIConstant._WRITEOFF_RPT && suspenseTrxInf.getAgeing() > 365) {
				rs.add(suspenseTrxInf);
			}else if(Long.parseLong(inputParams.get(APIConstant._TYPE_KEY).toString()) == APIConstant._SUSPENSE_RPT && suspenseTrxInf.getAgeing() <= 365) {
				rs.add(suspenseTrxInf);
			}
		}
		return rs;
	}
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public BigDecimal countTotalSuspenseTrxByDate(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().gettOmsReconSuspInfManagerRepositoryService().countTotalSuspenseTrxByDate(inputParams);
	}
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public List<SuspenseTrxInf> updateListSuspenseTrxByDate(Map<String, Object> inputParams)
			throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		boolean _isConfirm = (boolean) inputParams.get(APIConstant.FLAG);
		HashMap<String, Object> rs = new HashMap<String, Object>();
		List<SuspenseTrxInf> lst = CommonUtil.toListPojo(document, SuspenseTrxInf.class);
		//Check validation
		
		rs = getValidationManagerService().checkValidationUpdateSuspenseTrx(lst, userName,_isConfirm);
		
		boolean flag = (boolean) rs.get(APIConstant.RESULT);
		
		if(!flag) {
			throw new ServiceInvalidAgurmentException(rs.get(APIConstant.RESULT_MSG).toString());
		}
		updateToSuspenseTrx(rs);
		
		return lst;
	}

	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public File exportPendingReport(Map<String, Object> inputParams) throws BaseException {
		
		return getProcessManagerService().getReconcileExportReportService().exportPendingReport(inputParams);
	}
}
