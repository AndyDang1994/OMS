/**
 * 
 */
package com.shinhan.auth.repository.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.auth.core.exception.ServiceRuntimeException;
import com.shinhan.auth.repository.entity.TDataModel;
import com.shinhan.auth.repository.entity.TMetadata;

/**
 * @author shds01
 *
 */
public interface UtilityManagerRepositoryService {

	public List<TMetadata> getAllMetadata(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<TMetadata> getAllMetadataByAdmin(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<TMetadata> getMetadataByLookupCode(String lookupCode) throws ServiceRuntimeException;
	
	public TMetadata getMetadataById(Long id) throws ServiceRuntimeException;
	
	public TMetadata getMetadataByLookupCodeAndId(String lookupCode, String lookupId) throws ServiceRuntimeException;
	
	public BigDecimal countMetadataByLookupCodeAndId(String lookupCode, String lookupId) throws ServiceRuntimeException;
	
	public boolean createMetadata(TMetadata metadata) throws ServiceRuntimeException;
	
	public boolean updateMetadata(TMetadata metadata) throws ServiceRuntimeException;
	
	public boolean deleteMetadata(TMetadata metadata) throws ServiceRuntimeException;
	
	public TDataModel getDataModelByDocType(String docType) throws ServiceRuntimeException;
	
	public boolean createDataModel(TDataModel model) throws ServiceRuntimeException;
	
	public boolean updateDataModel(TDataModel model) throws ServiceRuntimeException;
}
