/**
 * 
 */
package com.shinhan.auth.core.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.shinhan.auth.core.constant.APIConstant;
import com.shinhan.auth.core.exception.ServiceRuntimeException;
import com.shinhan.auth.core.model.UserFeatureInfo;
import com.shinhan.auth.core.model.UserInfo;
import com.shinhan.auth.core.model.UserRoleInfo;
import com.shinhan.auth.repository.entity.AuthUser;
import com.shinhan.auth.repository.entity.TDataModel;
import com.shinhan.auth.repository.entity.TMetadata;

/**
 * @author shds01
 *
 */
public class DTOConverter {

	public static List<?> convertSettoList(Set<?> sets) throws ServiceRuntimeException {
		List<?> list = new ArrayList<>(sets);
		return list;
	}
	
	public static UserRoleInfo setUtilityUserRoleInfoForProfile(TMetadata metadata) throws ServiceRuntimeException{
		return new UserRoleInfo(metadata.getLookupCodeId(), metadata.getValue(), metadata.getIsShow());
	}
	
	public static UserRoleInfo setUtilityUserRoleInfoForCreation(TMetadata metadata) throws ServiceRuntimeException{
		return new UserRoleInfo(metadata.getLookupCodeId(), metadata.getValue());
	}
	
	public static UserFeatureInfo setUtilityUserFeatureInfoForCreation(TMetadata metadata) throws ServiceRuntimeException{
		return new UserFeatureInfo(metadata.getLookupCodeId(), metadata.getValue());
	}
	
	public static TDataModel setUtilityTDataModelForCreationRole(TMetadata metadata, List<TMetadata> features) throws ServiceRuntimeException{
		TDataModel model = new TDataModel();
		model.setDocumentType(metadata.getLookupCodeId());
		/** Start Set Datamodel for document type*/
		//Feature info
		List<UserFeatureInfo> lstFeatureInfo = new ArrayList<UserFeatureInfo>();
		for(TMetadata feature : features){
			lstFeatureInfo.add(setUtilityUserFeatureInfoForCreation(feature));
		}
		//Role info
		UserRoleInfo userInfo = new UserRoleInfo(metadata.getLookupCodeId(), metadata.getValue(), lstFeatureInfo);
		/** End Set Datamodel for document type*/
		model.setDataModel(CommonUtil.toJsonValueAsString(userInfo));
		
		return model;
	}
	
	public static TDataModel setUtilityTDataModelForUpdateRole(TDataModel model, TMetadata metadata, List<UserFeatureInfo> features) throws ServiceRuntimeException{
		if(model == null) {
			model = new TDataModel();
		}
		model.setDocumentType(metadata.getLookupCodeId());
		/** Start Set Datamodel for document type*/
		UserRoleInfo userInfo = new UserRoleInfo(metadata.getLookupCodeId(), metadata.getValue(), features);
		/** End Set Datamodel for document type*/
		model.setDataModel(CommonUtil.toJsonValueAsString(userInfo));
		
		return model;
	}
	
	public static void setUtilityTDataModelForCreationFeatureForRole(TDataModel model, UserFeatureInfo feature) throws ServiceRuntimeException{
		UserRoleInfo userInfo = (UserRoleInfo) CommonUtil.toPojo(model.getDataModel(), UserRoleInfo.class);
		userInfo.getFeatures().add(feature);
		model.setDataModel(CommonUtil.toJsonValueAsString(userInfo));
	}
	
	public static void setUtilityTMetadataForRole(TMetadata metadata){
		metadata.setServiceName(APIConstant.SERVICENAME_ADMIN);
		metadata.setLookupCode(APIConstant.LOOKUP_CODE_OMS_USER_ROLE);
		metadata.setLanguage(APIConstant.LANGUAGE_VN);
		metadata.setIsShow(APIConstant.YES_KEY);
	}
	
	public static void setUtilityTMetadataForFeature(TMetadata metadata){
		metadata.setServiceName(APIConstant.SERVICENAME_ADMIN);
		metadata.setLookupCode(APIConstant.LOOKUP_CODE_OMS_USER_FEATURE);
		metadata.setLanguage(APIConstant.LANGUAGE_VN);
		metadata.setIsShow(APIConstant.YES_KEY);
	}

	public static AuthUser populateForCreateNewAuthUser(UserInfo userInfo)throws ServiceRuntimeException {
		AuthUser auth = new AuthUser();
		
		auth.setUsername(userInfo.getUserName());
		auth.setPassword(CommonUtil.encrytePassword(userInfo.getPassword()));
		auth.setFullname(userInfo.getFullname());
		auth.setStatus(APIConstant.USER_STATUS_ACTIVE);
		
		List<UserRoleInfo> roles = CommonUtil.toListPojo(CommonUtil.toJson(userInfo.getRoles()), UserRoleInfo.class);
		for(UserRoleInfo role : roles) {
			role.setFeatures(new ArrayList<>());
		}
			
		auth.setConfiguration(userInfo.getRoles() != null ? CommonUtil.toJsonValueAsString(roles) : CommonUtil.toJson(new ArrayList<UserRoleInfo>()));
		
		return auth;
	}
	
	public static void populateForActiveAuthUser(AuthUser auth)throws ServiceRuntimeException {
		auth.setStatus(APIConstant.USER_STATUS_ACTIVE);
	}
	
	public static void populateForDeactiveAuthUser(AuthUser auth)throws ServiceRuntimeException {
		auth.setStatus(APIConstant.USER_STATUS_DEACTIVE);
	}
	
	public static void populateForUpdatePasswordAuthUser(AuthUser auth, UserInfo userInfo)throws ServiceRuntimeException {
		auth.setPassword(CommonUtil.encrytePassword(userInfo.getPassword()));
	}
	
	public static void populateForUpdateRoleAuthUser(AuthUser auth, UserInfo userInfo)throws ServiceRuntimeException {
		List<UserRoleInfo> roles = CommonUtil.toListPojo(CommonUtil.toJson(userInfo.getRoles()), UserRoleInfo.class);
		for(UserRoleInfo role : roles) {
			role.setFeatures(new ArrayList<>());
		}
			
		auth.setConfiguration(userInfo.getRoles() != null ? CommonUtil.toJsonValueAsString(roles) : CommonUtil.toJson(new ArrayList<UserRoleInfo>()));
	}
}

