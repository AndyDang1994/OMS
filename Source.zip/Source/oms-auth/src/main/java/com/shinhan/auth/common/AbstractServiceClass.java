/**
 * 
 */
package com.shinhan.auth.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
/**
 * @author shds01
 *
 */
public abstract class AbstractServiceClass extends AbstractRepositoryClass {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	public Environment env;

	@Autowired
	private ProcessManagerService processManagerService;

	@Autowired
	private AsyncManagerService asyncManagerService;

	@Autowired
	private ValidationManagerService validationManagerService;

	/**
	 * @return the processManagerService
	 */
	public ProcessManagerService getProcessManagerService() {
		return processManagerService;
	}

	/**
	 * @param processManagerService the processManagerService to set
	 */
	public void setProcessManagerService(
			@Qualifier("processManagerService") ProcessManagerService processManagerService) {
		this.processManagerService = processManagerService;
	}

	/**
	 * @return the asyncManagerService
	 */
	public AsyncManagerService getAsyncManagerService() {
		return asyncManagerService;
	}

	/**
	 * @param asyncManagerService the asyncManagerService to set
	 */
	public void setAsyncManagerService(@Qualifier("asyncManagerService") AsyncManagerService asyncManagerService) {
		this.asyncManagerService = asyncManagerService;
	}

	/**
	 * @return the validationManagerService
	 */
	public ValidationManagerService getValidationManagerService() {
		return validationManagerService;
	}

	/**
	 * @param validationManagerService the validationManagerService to set
	 */
	public void setValidationManagerService(@Qualifier("validationManagerService") ValidationManagerService validationManagerService) {
		this.validationManagerService = validationManagerService;
	}

}
