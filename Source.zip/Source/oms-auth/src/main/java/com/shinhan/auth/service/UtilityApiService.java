/**
 * 
 */
package com.shinhan.auth.service;

import java.util.List;
import java.util.Map;

import com.shinhan.auth.core.exception.BaseException;
import com.shinhan.auth.repository.entity.TMetadata;

/**
 * @author shds01
 *
 */
public interface UtilityApiService {
	
	public List<TMetadata> getAllMetadata(Map<String, Object> inputParams) throws BaseException;
	
	public List<TMetadata> getMetadataByLookupCode(String lookupCode) throws BaseException;
	
	public TMetadata createMetadata(Map<String, Object> inputParams) throws BaseException;
	
	public TMetadata updateMetadata(Map<String, Object> inputParams) throws BaseException;
	
	public TMetadata deleteMetadata(Map<String, Object> inputParams) throws BaseException;
}
