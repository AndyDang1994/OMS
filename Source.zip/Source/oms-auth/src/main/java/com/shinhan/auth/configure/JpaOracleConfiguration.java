package com.shinhan.auth.configure;

import java.util.Properties;

import javax.naming.NamingException;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariDataSource;

/**
 * @author shds01
 *
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "com.shinhan.auth.repository.dao",
		entityManagerFactoryRef = "oracleEntityManagerFactory",
		transactionManagerRef = "oracleTransactionManager")

@PropertySource("classpath:application.properties")
public class JpaOracleConfiguration {

	@Autowired
	private Environment environment;

	@Value("${datasource.oracle.oms.maxPoolSize}")
	private int maxPoolSize;
	
	@Value("${datasource.oracle.oms.minIdlePoolSize}")
	private int minIdleSize;
	
	@Value("${datasource.oracle.oms.connection-timeout}")
	private int connectionTimeout;
	

	@Bean(name = "oracleDataSourceProperties")
	@Primary
	@ConfigurationProperties(prefix = "datasource.oracle.oms")
	public DataSourceProperties oracleDataSourceProperties(){
		return new DataSourceProperties();
	}

	/*
	 * Configure HikariCP pooled DataSource.
	 */
	@Bean(name = "oracleDataSource")
	@Primary 
	public DataSource oracleDataSource() {
		DataSourceProperties dataSourceProperties = oracleDataSourceProperties();
			HikariDataSource dataSource = (HikariDataSource) DataSourceBuilder
					.create(dataSourceProperties.getClassLoader())
					.driverClassName(dataSourceProperties.getDriverClassName())
					.url(dataSourceProperties.getUrl())
					.username(dataSourceProperties.getUsername())
					.password(dataSourceProperties.getPassword())
					.type(HikariDataSource.class)
					.build();
			dataSource.setMaximumPoolSize(maxPoolSize);
			dataSource.setMinimumIdle(minIdleSize);
			dataSource.setConnectionTimeout(connectionTimeout);
			return dataSource;
	}

	/*
	 * Entity Manager Factory setup.
	 */
	@Bean(name = "oracleEntityManagerFactory")
	@Primary
	public LocalContainerEntityManagerFactoryBean oracleEntityManagerFactory() throws NamingException {
		HibernateJpaVendorAdapter hibernateJpaVendorAdapter = new HibernateJpaVendorAdapter();
		LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();
		factoryBean.setDataSource(oracleDataSource());
		factoryBean.setPackagesToScan(new String[] { "com.shinhan.auth.repository.entity" });
		factoryBean.setJpaVendorAdapter(hibernateJpaVendorAdapter);
		factoryBean.setJpaProperties(jpaProperties());
		factoryBean.setPersistenceUnitName("entityManagerOMS");
		return factoryBean;
	}

	/*
	 * Here you can specify any provider specific properties.
	 */
	private Properties jpaProperties() {
		Properties properties = new Properties();
		properties.put("hibernate.dialect", environment.getRequiredProperty("datasource.oracle.oms.hibernate.dialect"));
		properties.put("hibernate.hbm2ddl.auto", environment.getRequiredProperty("datasource.oracle.oms.hibernate.hbm2ddl.method"));
		properties.put("hibernate.show_sql", environment.getRequiredProperty("datasource.oracle.oms.hibernate.show_sql"));
		properties.put("hibernate.format_sql", environment.getRequiredProperty("datasource.oracle.oms.hibernate.format_sql"));
		if(StringUtils.isNotEmpty(environment.getRequiredProperty("datasource.oracle.oms.defaultSchema"))){
			properties.put("hibernate.default_schema", environment.getRequiredProperty("datasource.oracle.oms.defaultSchema"));
		}
		return properties;
	}

	@Bean(name = "oracleTransactionManager")
	@Autowired
	@Primary
	public PlatformTransactionManager oracleTransactionManager(@Qualifier("oracleEntityManagerFactory") EntityManagerFactory emf) {
		JpaTransactionManager txManager = new JpaTransactionManager();
		txManager.setEntityManagerFactory(emf);
		return txManager;
	}

}
