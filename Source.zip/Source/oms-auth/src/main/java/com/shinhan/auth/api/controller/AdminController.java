/**
 * 
 */
package com.shinhan.auth.api.controller;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.shinhan.auth.core.constant.APIConstant;
import com.shinhan.auth.core.exception.BaseException;
import com.shinhan.auth.core.model.UserInfo;


/**
 * @author shds01
 *
 */
@RestController
public class AdminController extends BaseController{
	
	@RequestMapping(value = "shinhan/service/configuration/userProfile", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	public ResponseEntity<Object> getUserProfileByUserName(@RequestParam(required = true, defaultValue = "") String userName, Locale locale) throws BaseException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.USERNAME_TXT, userName);
		
		UserInfo user = getProcessManagerService().getAuthApiService().getUserProfileByUserName(inputParams);
		return triggerSuccessOutPut(user, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/userProfile", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> createUserProfile(@RequestBody String document, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		UserInfo user = getProcessManagerService().getAuthApiService().createUserProfile(inputParams);
		return triggerSuccessOutPut(user, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/userProfile/active", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> activeUserProfile(@RequestBody String document, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		UserInfo user = getProcessManagerService().getAuthApiService().activeUserProfile(inputParams);
		return triggerSuccessOutPut(user, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/userProfile/deactive", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> deactiveUserProfile(@RequestBody String document, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		UserInfo user = getProcessManagerService().getAuthApiService().deactiveUserProfile(inputParams);
		return triggerSuccessOutPut(user, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/userProfile/password", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> updateUserProfilePassword(@RequestBody String document, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		UserInfo user = getProcessManagerService().getAuthApiService().updateUserProfilePassword(inputParams);
		return triggerSuccessOutPut(user, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/userProfile/role", produces = "application/json;charset=utf-8", method = RequestMethod.PATCH)
	@ResponseBody
	public ResponseEntity<Object> updateUserProfileRole(@RequestBody String document, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		UserInfo user = getProcessManagerService().getAuthApiService().updateUserProfileRole(inputParams);
		return triggerSuccessOutPut(user, JsonObject.class, null);
	}
}
