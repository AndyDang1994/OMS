/**
 * 
 */
package com.shinhan.autodebit.service;

import java.io.File;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.autodebit.core.exception.BaseException;
import com.shinhan.autodebit.core.exception.ServiceRuntimeException;
import com.shinhan.autodebit.core.model.AutoDebitRegisBankResultTrxInfo;
import com.shinhan.autodebit.core.model.AutoDebitRegisTrxInfo;
import com.shinhan.autodebit.core.model.AutoDebitTrxInfo;


/**
 * @author shds01
 *
 */
public interface ADApiService {

	public List<AutoDebitTrxInfo> getListUnRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countTotalUnRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public File exportUnRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<AutoDebitTrxInfo> getListRegisterAutoDebitTrx(Map<String, Object> inputParams) throws BaseException;
	
	public BigDecimal countTotalRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public File exportRegisterAutoDebitTrx(Map<String, Object> inputParams) throws BaseException;
	
	public List<AutoDebitTrxInfo> getListRegisterAutoDebitTrxBySMS(Map<String, Object> inputParams) throws BaseException;
	
	public BigDecimal countTotalRegisterAutoDebitTrxBySMS(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public File exportRegisterAutoDebitTrxBySMS(Map<String, Object> inputParams) throws BaseException;
	
	public List<AutoDebitRegisTrxInfo> importAutoDebitTrx(Map<String, Object> inputParams) throws BaseException;
	
	public List<AutoDebitTrxInfo> updateToBankResultSuccess(Map<String, Object> inputParams) throws BaseException;
	
	public List<AutoDebitRegisBankResultTrxInfo> updateToBankResultSuccessByUpload(Map<String, Object> inputParams) throws BaseException;
	
	public List<AutoDebitTrxInfo> importHardCopyTransaction(Map<String, Object> inputParams) throws BaseException;
	
	public File exportAutoDebitByBank(Map<String, Object> inputParams) throws BaseException;
	
	public List<AutoDebitRegisBankResultTrxInfo> importAutoDebitBankResultTrx(Map<String, Object> inputParams) throws BaseException;
	
	public List<AutoDebitTrxInfo> updateFailReasonADTransaction(Map<String, Object> inputParams) throws BaseException;
	
	public List<AutoDebitTrxInfo> sendSmsForUnRegisADTrx(Map<String, Object> inputParams) throws BaseException;
	
	public List<AutoDebitTrxInfo> sendSmsForRegisADTrx(Map<String, Object> inputParams) throws BaseException;
	
	public File exportReportByTemplate(Map<String, Object> inputParams) throws BaseException;
}
