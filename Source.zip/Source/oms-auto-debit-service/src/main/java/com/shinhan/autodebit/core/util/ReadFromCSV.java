package com.shinhan.autodebit.core.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReadFromCSV {
	private String filePath;

	public ReadFromCSV(String filePath) {
		this.filePath = filePath;
	}

	public List<Map> readDataFromCsv(String bankTemplateColumn) {
		List<String> excelColumn = Arrays.asList(bankTemplateColumn.split(","));
		ArrayList<Map> mapArray = new ArrayList<Map>();
		try {
			String line = "";
			String splitBy = ",";
			Map<String, Object> rowMap = null;
			BufferedReader br = new BufferedReader(new FileReader(this.filePath));
			while ((line = br.readLine()) != null) // returns a Boolean value
			{
				rowMap = new HashMap<String, Object>(excelColumn.size());
				String[] result = line.split(splitBy); // use comma as separator
				for (int i = 0; i < result.length; i++) {
					rowMap.put(excelColumn.get(i), result[i].trim());
				}
				mapArray.add(rowMap);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mapArray;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
}
