/**
 * 
 */
package com.shinhan.autodebit.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsInf;

/**
 * @author shds01
 *
 */
@Repository
public interface TOmsAutoDebitLmsInfDAO extends JpaRepository<TOmsAutoDebitLmsInf, String> {

	@Query("SELECT item FROM TOmsAutoDebitLmsInf item WHERE LOWER(item.loanNo) = LOWER(:loanNo)")
	public TOmsAutoDebitLmsInf getItemByLoanNo(@Param("loanNo") String loanNo);
	
	@Query("SELECT item FROM TOmsAutoDebitLmsInf item WHERE LOWER(item.loanNo) = LOWER(:loanNo) and LOWER(item.statusCode) = LOWER(:statusCode)")
	public TOmsAutoDebitLmsInf getOneByLoanNoAndStatusCode(@Param("loanNo") String loanNo, @Param("statusCode") String statusCode);
}
