/**
 * 
 */
package com.shinhan.autodebit.report;

import java.io.File;
import java.util.List;
import java.util.Map;

import com.shinhan.autodebit.core.exception.BaseException;
import com.shinhan.autodebit.core.exception.ServiceRuntimeException;


/**
 * @author shds01
 *
 */
public interface ADExportReportService {

	public File exportADReportForBankByTemplate (Map<String, Object> inputParams) throws BaseException;
	
	public File exportUnRegisterAutoDebitTrx (List<Object[]> data) throws ServiceRuntimeException;
	
	public File exportRegisterAutoDebitTrx (List<Object[]> data, String statusCode) throws BaseException;
	
	public File exportReportByTemplate (Map<String, Object> inputParams) throws BaseException;
}
