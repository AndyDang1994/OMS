/**
 * 
 */
package com.shinhan.autodebit.repository.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.autodebit.common.AbstractServiceClass;
import com.shinhan.autodebit.core.constant.APIConstant;
import com.shinhan.autodebit.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.autodebit.core.exception.ServiceRuntimeException;
import com.shinhan.autodebit.core.model.AutoDebitTrxInfo;
import com.shinhan.autodebit.core.util.CommonUtil;
import com.shinhan.autodebit.core.util.DateUtils;
import com.shinhan.autodebit.repository.dao.TOmsAutoDebitLmsInfDAO;
import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsInf;
import com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("adInfManagerRepositoryService")
public class ADInfManagerRepositoryServiceImpl extends AbstractServiceClass
		implements ADInfManagerRepositoryService {

	private TOmsAutoDebitLmsInfDAO objectDao;

	@Autowired
	public ADInfManagerRepositoryServiceImpl(TOmsAutoDebitLmsInfDAO objectDao) {
		this.objectDao = objectDao;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#getOne(java.lang.String)
	 */
	@Override
	public TOmsAutoDebitLmsInf getOne(String loanNo) throws ServiceRuntimeException {
		if (StringUtils.isBlank(loanNo)) {
			return null;
		}
		try {
			TOmsAutoDebitLmsInf item = objectDao.findById(loanNo).get();
			return item;
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + loanNo + "");
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#getOneByLoanNo(java.lang.String)
	 */
	@Override
	public TOmsAutoDebitLmsInf getOneByLoanNo(String loanNo) throws ServiceRuntimeException {
		if (StringUtils.isBlank(loanNo)) {
			return null;
		}
		try {
			TOmsAutoDebitLmsInf item = objectDao.getItemByLoanNo(loanNo);
			return item;
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + loanNo + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#getOneByLoanNoAndStatusCode(java.lang.String, java.lang.String)
	 */
	@Override
	public TOmsAutoDebitLmsInf getOneByLoanNoAndStatusCode(String loanNo, String statusCode)
			throws ServiceRuntimeException {
		if (StringUtils.isBlank(loanNo) || StringUtils.isBlank(statusCode)) {
			return null;
		}
		try {
			TOmsAutoDebitLmsInf item = objectDao.getOneByLoanNoAndStatusCode(loanNo, statusCode);
			return item;
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + loanNo + "");
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#getListRegisterAutoDebitTrx(java.util.Map)
	 */
	@Override
	public List<AutoDebitTrxInfo> getListRegisterAutoDebitTrx(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		try {
			String statusCode = inputParams.get(APIConstant._STATUS_AD_MAP).toString();
			
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			String condition = "";
			String orderBy = "";
			String groupBy = "";
			String sql = "SELECT new com.shinhan.autodebit.core.model.AutoDebitTrxInfo("
					+ "mas.loanNo as loanNo, mas.customerName as customerName, mas.authorizeDt as authorizeDt, mas.firstDt as firstDt, "
					+ "mas.branch as branch, mas.roUser as roUser, mas.bankName as bankName, "
					+ "mas.adType as adType, mas.autosalDay as autosalDay, mas.doc36 as doc36, "
					
					+ "inf.sendDt as sendDt, inf.signedLocation as signedLocation, inf.sendUser as sendUser, inf.receiveDt as receiveDt, "
					+ "inf.receiveUser as receiveUser, inf.drDt as drDt, inf.sendBankDt as sendBankDt, "
					+ "inf.smsDueDt as smsDueDt, inf.bankResultDt as bankResultDt, inf.registrationResult as registrationResult, "
					
					+ "(SELECT tm.value from TMetadata tm "
					+ "where tm.lookupCode = '"+APIConstant.LOOKUP_CODE_AD_IMPORT_BANK_RESULT_FAIL+"' and tm.lookupCodeId = inf.reason) as reason, "
					
					+ " inf.smsADDt as smsADDt, inf.statusCode as statusCode, inf.smsDueDtStatus as smsDueDtStatus, inf.smsADDtStatus as smsADDtStatus "
					+ ") "
					+ "from TOmsAutoDebitLmsInf inf, TOmsAutoDebitLmsMas mas "
					+ "where inf.loanNo = mas.loanNo and inf.statusCode = :statusCode "
					+ "and mas.loanStatus = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loanACH = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					
					+ "and (:loanNo is NULL or mas.loanNo =:loanNo) "
					+ "and (:branch is NULL or mas.branch =:branch) "
					+ "and (:roUser is NULL or mas.roUser =:roUser) "
					+ "and (:bankName is NULL or mas.bankName =:bankName) "
					+ "and (:adType is NULL or mas.adType =:adType) "
					+ "and (:fromDt is NULL or :endDt is NULL or mas.authorizeDt between :fromDt and :endDt) "
					;
			
			switch (statusCode) {
				case APIConstant.AUTO_DEBIT_STATUS_MAPPING_BN_SEND_HARD_COPY:
					condition = "and (:signedLocation is NULL or inf.signedLocation =:signedLocation) " 
								+ "and (:sendUser is NULL or inf.sendUser =:sendUser) "
								+ "and inf.sendDt between :startSendDt and :endSendDt "
								;
					orderBy = "order by inf.sendDt asc, inf.sendDtIndex asc, inf.signedLocation desc , inf.sendUser desc, loanNo asc ";
					break;
				case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DR_RECEIVED_HARD_COPY:
					condition = "and (:receiveUser is NULL or inf.receiveUser =:receiveUser) " 
								+ "and to_char(inf.receiveDt, 'DD/MM/YYYY') between :startReceiveDt and :endReceiveDt "
								;
					orderBy = "order by inf.receiveDt asc, inf.receiveUser desc, inf.receiveDtIndex asc, loanNo asc";
					break;
				case APIConstant.AUTO_DEBIT_STATUS_MAPPING_WAITING_BANK_REGISTRATION:
					condition = "and inf.sendBankDt between :startSendBankDt and :endSendBankDt "
							;
					orderBy = "order by inf.sendBankDt asc, mas.bankName asc, inf.receiveDt asc, inf.sendDt asc, loanNo asc";
					break;
				case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION:
					condition = "and inf.bankResultDt between :startBankResultDt and :endBankResultDt "
								+ "and inf.registrationResult = '"+APIConstant.AD_IMPORT_BANK_RESULT_FAIL+"' "
							;
					orderBy = "order by inf.bankResultDt asc, loanNo asc";
					break;
				default :
					orderBy = "order by mas.authorizeDt asc, loanNo asc";
					
					break;
			}
			sql = sql + condition + groupBy + orderBy;
			Query query = entityManager.createQuery(sql);
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("branch", inputParams.get(APIConstant._BRANCH).toString());
			query.setParameter("roUser", inputParams.get(APIConstant._RO_USER).toString());
			query.setParameter("bankName", inputParams.get(APIConstant._BANK).toString());
			query.setParameter("adType", inputParams.get(APIConstant._AD_TYPE).toString());
			query.setParameter("fromDt"
					, inputParams.get(APIConstant._START_DATE_KEY) != null && StringUtils.isNotBlank(inputParams.get(APIConstant._START_DATE_KEY).toString())
					? DateUtils.converToDate(inputParams.get(APIConstant._START_DATE_KEY).toString()) 
					: null);
			query.setParameter("endDt"
					, inputParams.get(APIConstant._END_DATE_KEY) != null && StringUtils.isNotBlank(inputParams.get(APIConstant._END_DATE_KEY).toString())
					? DateUtils.converToDate(inputParams.get(APIConstant._END_DATE_KEY).toString()) 
					: null);
			query.setParameter("statusCode", statusCode);
			
			switch (statusCode) {
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_BN_SEND_HARD_COPY:
				query.setParameter("startSendDt", DateUtils.convertDate(inputParams.get(APIConstant._START_SEND_DT).toString(), DateUtils.DATEFORMAT));
				query.setParameter("endSendDt", DateUtils.convertDate(inputParams.get(APIConstant._END_SEND_DT).toString(), DateUtils.DATEFORMAT));
				query.setParameter("signedLocation", inputParams.get(APIConstant._SIGNEDLOCATION).toString());
				query.setParameter("sendUser", inputParams.get(APIConstant._SENDUSER).toString());
				break;
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DR_RECEIVED_HARD_COPY:
				query.setParameter("startReceiveDt", inputParams.get(APIConstant._START_RECEIVE_DT).toString());
				query.setParameter("endReceiveDt", inputParams.get(APIConstant._END_RECEIVE_DT).toString());
				query.setParameter("receiveUser", inputParams.get(APIConstant._RECEIVE_USER).toString());
				break;
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_WAITING_BANK_REGISTRATION:
				query.setParameter("startSendBankDt", DateUtils.convertDate(inputParams.get(APIConstant._START_SEND_BANK_DT).toString(), DateUtils.DATEFORMAT));
				query.setParameter("endSendBankDt", DateUtils.convertDate(inputParams.get(APIConstant._END_SEND_BANK_DT).toString(), DateUtils.DATEFORMAT));
				break;
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION:
				query.setParameter("startBankResultDt", DateUtils.convertDate(inputParams.get(APIConstant._START_BANK_RESULT_DT).toString(), DateUtils.DATEFORMAT));
				query.setParameter("endBankResultDt", DateUtils.convertDate(inputParams.get(APIConstant._END_BANK_RESULT_DT).toString(), DateUtils.DATEFORMAT));
				break;
			default :
				break;
			}
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			List<AutoDebitTrxInfo> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#countRegisterAutoDebitTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			String statusCode = inputParams.get(APIConstant._STATUS_AD_MAP).toString();
			String condition = "";
			String sql = "select count(inf.loan_no) from oms_ad_lms_inf inf, oms_ad_lms_mas mas "
					+ "where inf.loan_no = mas.loan_no and inf.status_code = :statusCode "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					
					+ "and (:loanNo is NULL or mas.loan_no =:loanNo) "
					+ "and (:branch is NULL or mas.branch =:branch) "
					+ "and (:roUser is NULL or mas.ro_user =:roUser) "
					+ "and (:bankName is NULL or mas.bank_name =:bankName) "
					+ "and (:adType is NULL or mas.ad_type =:adType) "
					+ "and (:fromDt is NULL or :endDt is NULL or mas.authorized_dt between :fromDt and :endDt) "
					;
			
			switch (statusCode) {
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_BN_SEND_HARD_COPY:
				condition = "and (:signedLocation is NULL or inf.signed_location =:signedLocation) " 
							+ "and (:sendUser is NULL or inf.send_user =:sendUser) "
							+ "and inf.send_dt between :startSendDt and :endSendDt "
							;
				break;
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DR_RECEIVED_HARD_COPY:
				condition = "and (:receiveUser is NULL or inf.received_user =:receiveUser) " 
							+ "and to_char(inf.received_dt, 'DD/MM/YYYY') between :startReceiveDt and :endReceiveDt "
							;
				break;
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_WAITING_BANK_REGISTRATION:
				condition = "and inf.send_bank_dt between :startSendBankDt and :endSendBankDt "
							;
				break;
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION:
				condition = "and inf.bank_result_dt between :startBankResultDt and :endBankResultDt "
							+ "and inf.registration_result = '"+APIConstant.AD_IMPORT_BANK_RESULT_FAIL+"' "
							;
				break;
			default :
				break;
			}
			sql = sql + condition;
				
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("branch", inputParams.get(APIConstant._BRANCH).toString());
			query.setParameter("roUser", inputParams.get(APIConstant._RO_USER).toString());
			query.setParameter("bankName", inputParams.get(APIConstant._BANK).toString());
			query.setParameter("adType", inputParams.get(APIConstant._AD_TYPE).toString());
			query.setParameter("fromDt"
					, inputParams.get(APIConstant._START_DATE_KEY) != null && StringUtils.isNotBlank(inputParams.get(APIConstant._START_DATE_KEY).toString())
					? DateUtils.converToDate(inputParams.get(APIConstant._START_DATE_KEY).toString()) 
					: "");
			query.setParameter("endDt"
					, inputParams.get(APIConstant._END_DATE_KEY) != null && StringUtils.isNotBlank(inputParams.get(APIConstant._END_DATE_KEY).toString())
					? DateUtils.converToDate(inputParams.get(APIConstant._END_DATE_KEY).toString()) 
					: "");
			query.setParameter("statusCode", statusCode);
			

			switch (statusCode) {
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_BN_SEND_HARD_COPY:
				query.setParameter("startSendDt", DateUtils.convertDate(inputParams.get(APIConstant._START_SEND_DT).toString(), DateUtils.DATEFORMAT));
				query.setParameter("endSendDt", DateUtils.convertDate(inputParams.get(APIConstant._END_SEND_DT).toString(), DateUtils.DATEFORMAT));
				query.setParameter("signedLocation", inputParams.get(APIConstant._SIGNEDLOCATION).toString());
				query.setParameter("sendUser", inputParams.get(APIConstant._SENDUSER).toString());
				break;
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DR_RECEIVED_HARD_COPY:
				query.setParameter("startReceiveDt", inputParams.get(APIConstant._START_RECEIVE_DT).toString());
				query.setParameter("endReceiveDt", inputParams.get(APIConstant._END_RECEIVE_DT).toString());
				query.setParameter("receiveUser", inputParams.get(APIConstant._RECEIVE_USER).toString());
				break;
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_WAITING_BANK_REGISTRATION:
				query.setParameter("startSendBankDt", DateUtils.convertDate(inputParams.get(APIConstant._START_SEND_BANK_DT).toString(), DateUtils.DATEFORMAT));
				query.setParameter("endSendBankDt", DateUtils.convertDate(inputParams.get(APIConstant._END_SEND_BANK_DT).toString(), DateUtils.DATEFORMAT));
				break;
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION:
				query.setParameter("startBankResultDt", DateUtils.convertDate(inputParams.get(APIConstant._START_BANK_RESULT_DT).toString(), DateUtils.DATEFORMAT));
				query.setParameter("endBankResultDt", DateUtils.convertDate(inputParams.get(APIConstant._END_BANK_RESULT_DT).toString(), DateUtils.DATEFORMAT));
				break;
			default :
				break;
			}
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#exportRegisterAutoDebitTrx(java.util.Map)
	 */
	@Override
	public List<Object[]> exportRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			String statusCode = inputParams.get(APIConstant._STATUS_AD_MAP).toString();
			
			String condition = "";
			String orderBy = "";
			String groupBy = "";
			String sqlSelectData = "";
			String sql = ""
					
					+ "from TOmsAutoDebitLmsInf inf, TOmsAutoDebitLmsMas mas "
					+ "where inf.loanNo = mas.loanNo and inf.statusCode = :statusCode "
					+ "and mas.loanStatus = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loanACH = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					
					+ "and (:loanNo is NULL or mas.loanNo =:loanNo) "
					+ "and (:branch is NULL or mas.branch =:branch) "
					+ "and (:roUser is NULL or mas.roUser =:roUser) "
					+ "and (:bankName is NULL or mas.bankName =:bankName) "
					+ "and (:adType is NULL or mas.adType =:adType) "
					+ "and (:fromDt is NULL or :endDt is NULL or mas.authorizeDt between :fromDt and :endDt) "
					;
			
			switch (statusCode) {
				case APIConstant.AUTO_DEBIT_STATUS_MAPPING_BN_SEND_HARD_COPY:
					sqlSelectData = "SELECT "
									+ "mas.loanNo as loanNo, mas.customerName as customerName, mas.authorizeDt as authorizeDt, mas.firstDt as firstDt, "
									+ "mas.branch as branch, mas.roUser as roUser, mas.bankName as bankName, "
									+ "mas.adType as adType, mas.autosalDay as autosalDay, "
									
									+ "inf.sendDt as sendDt, inf.signedLocation as signedLocation, inf.sendUser as sendUser ";
					condition = "and (:signedLocation is NULL or inf.signedLocation =:signedLocation) " 
								+ "and (:sendUser is NULL or inf.sendUser =:sendUser) "
								+ "and inf.sendDt between :startSendDt and :endSendDt "
								;
					orderBy = "order by inf.sendDt asc, inf.sendDtIndex asc, inf.signedLocation desc , inf.sendUser desc ";
					break;
				case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DR_RECEIVED_HARD_COPY:
					sqlSelectData = "SELECT "
							+ "mas.loanNo as loanNo, mas.customerName as customerName, mas.authorizeDt as authorizeDt, mas.firstDt as firstDt, "
							+ "mas.branch as branch, mas.roUser as roUser, mas.bankName as bankName, "
							+ "mas.adType as adType, mas.autosalDay as autosalDay, "
							
							+ "inf.sendDt as sendDt, inf.sendUser as sendUser, "
							+ "inf.receiveDt as receiveDt, inf.receiveUser as receiveUser "
							;
					condition = "and (:receiveUser is NULL or inf.receiveUser =:receiveUser) " 
								+ "and to_char(inf.receiveDt, 'DD/MM/YYYY') between :startReceiveDt and :endReceiveDt "
								;
					orderBy = "order by inf.receiveDt asc, inf.receiveUser desc, inf.receiveDtIndex asc";
					break;
				case APIConstant.AUTO_DEBIT_STATUS_MAPPING_WAITING_BANK_REGISTRATION:
					sqlSelectData = "SELECT "
							+ "mas.loanNo as loanNo, mas.customerName as customerName, mas.authorizeDt as authorizeDt, mas.firstDt as firstDt, "
							+ "mas.branch as branch, mas.roUser as roUser, mas.bankName as bankName, "
							+ "mas.adType as adType, mas.autosalDay as autosalDay, "
							
							+ "inf.sendDt as sendDt, "
							+ "inf.receiveDt as receiveDt, "
							+ "inf.sendBankDt as sendBankDt "
							;
					condition = "and inf.sendBankDt between :startSendBankDt and :endSendBankDt "
							;
					orderBy = "order by inf.sendBankDt asc";
					break;
				case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION:
					sqlSelectData = "SELECT "
							+ "mas.loanNo as loanNo, mas.customerName as customerName, mas.authorizeDt as authorizeDt, mas.firstDt as firstDt, "
							
							+ "inf.bankResultDt as bankResultDt, "
							+ "inf.registrationResult as registrationResult, "
							+ "(SELECT tm.value from TMetadata tm "
							+ "where tm.lookupCode = '"+APIConstant.LOOKUP_CODE_AD_IMPORT_BANK_RESULT_FAIL+"' and tm.lookupCodeId = inf.reason) as reason, "
							
							
							+ "inf.smsADDt as smsADDt "
							;
					condition = "and inf.bankResultDt between :startBankResultDt and :endBankResultDt "
							+ "and inf.registrationResult = '"+APIConstant.AD_IMPORT_BANK_RESULT_FAIL+"' "
						;
					orderBy = "order by inf.bankResultDt asc";
					break;
				
				default :
					orderBy = "order by mas.authorizeDt asc";
					
					break;
			}
			sql = sqlSelectData + sql + condition + groupBy + orderBy;
			Query query = entityManager.createQuery(sql);
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("branch", inputParams.get(APIConstant._BRANCH).toString());
			query.setParameter("roUser", inputParams.get(APIConstant._RO_USER).toString());
			query.setParameter("bankName", inputParams.get(APIConstant._BANK).toString());
			query.setParameter("adType", inputParams.get(APIConstant._AD_TYPE).toString());
			query.setParameter("fromDt"
					, inputParams.get(APIConstant._START_DATE_KEY) != null && StringUtils.isNotBlank(inputParams.get(APIConstant._START_DATE_KEY).toString())
					? DateUtils.converToDate(inputParams.get(APIConstant._START_DATE_KEY).toString()) 
					: null);
			query.setParameter("endDt"
					, inputParams.get(APIConstant._END_DATE_KEY) != null && StringUtils.isNotBlank(inputParams.get(APIConstant._END_DATE_KEY).toString())
					? DateUtils.converToDate(inputParams.get(APIConstant._END_DATE_KEY).toString()) 
					: null);
			query.setParameter("statusCode", statusCode);
			
			switch (statusCode) {
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_BN_SEND_HARD_COPY:
				query.setParameter("startSendDt", DateUtils.convertDate(inputParams.get(APIConstant._START_SEND_DT).toString(), DateUtils.DATEFORMAT));
				query.setParameter("endSendDt", DateUtils.convertDate(inputParams.get(APIConstant._END_SEND_DT).toString(), DateUtils.DATEFORMAT));
				query.setParameter("signedLocation", inputParams.get(APIConstant._SIGNEDLOCATION).toString());
				query.setParameter("sendUser", inputParams.get(APIConstant._SENDUSER).toString());
				break;
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DR_RECEIVED_HARD_COPY:
				query.setParameter("startReceiveDt", inputParams.get(APIConstant._START_RECEIVE_DT).toString());
				query.setParameter("endReceiveDt", inputParams.get(APIConstant._END_RECEIVE_DT).toString());
				query.setParameter("receiveUser", inputParams.get(APIConstant._RECEIVE_USER).toString());
				break;
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_WAITING_BANK_REGISTRATION:
				query.setParameter("startSendBankDt", DateUtils.convertDate(inputParams.get(APIConstant._START_SEND_BANK_DT).toString(), DateUtils.DATEFORMAT));
				query.setParameter("endSendBankDt", DateUtils.convertDate(inputParams.get(APIConstant._END_SEND_BANK_DT).toString(), DateUtils.DATEFORMAT));
				break;
			case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION:
				query.setParameter("startBankResultDt", DateUtils.convertDate(inputParams.get(APIConstant._START_BANK_RESULT_DT).toString(), DateUtils.DATEFORMAT));
				query.setParameter("endBankResultDt", DateUtils.convertDate(inputParams.get(APIConstant._END_BANK_RESULT_DT).toString(), DateUtils.DATEFORMAT));
				break;
			default :
				break;
			}
			
			List<Object[]> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#createAll(java.util.Map)
	 */
	@Override
	public boolean createAll(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			@SuppressWarnings("unchecked")
			List<TOmsAutoDebitLmsInf> items = (List<TOmsAutoDebitLmsInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#update(com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsInf)
	 */
	@Override
	public boolean update(TOmsAutoDebitLmsInf inf) throws ServiceRuntimeException {
		try {
			if (inf != null) {
				objectDao.save(inf);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#updateAll(java.util.Map)
	 */
	@Override
	public boolean updateAll(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			@SuppressWarnings("unchecked")
			List<TOmsAutoDebitLmsInf> items = (List<TOmsAutoDebitLmsInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#getListAutoDebitTrxForExport(java.lang.String)
	 */
	@Override
	public List<TOmsAutoDebitLmsInf> getListAutoDebitTrxForExport(String bankCode) throws ServiceRuntimeException {
		try {

			String sql = "SELECT new com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsInf("
					
					+ "mas.loanNo as loanNo, inf.sendDt as sendDt, inf.signedLocation as signedLocation, inf.sendUser as sendUser, inf.receiveDt as receiveDt, "
					+ "inf.receiveUser as receiveUser, inf.drDt as drDt, inf.sendBankDt as sendBankDt, "
					+ "inf.smsDueDt as smsDueDt, inf.bankResultDt as bankResultDt, inf.registrationResult as registrationResult, "
					+ "inf.reason as reason, inf.smsADDt as smsADDt, inf.statusCode as statusCode, "
					+ "inf.createdUser as createdUser, inf.createdDt as createdDt, inf.updatedUser as updatedUser, inf.updatedDt as updatedDt, "
					+ "inf.smsDueDtStatus as smsDueDtStatus, inf.smsADDtStatus as smsADDtStatus "
					
					+ ") "
					+ "from TOmsAutoDebitLmsInf inf, TOmsAutoDebitLmsMas mas "
					+ "where inf.loanNo = mas.loanNo and inf.statusCode = :statusCode "
					+ "and mas.loanStatus = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loanACH = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and mas.bankName =:bankName "
					+ "order by inf.receiveDt asc, inf.receiveUser desc, inf.receiveDtIndex asc"
					;
			Query query = entityManager.createQuery(sql);
			
			query.setParameter("bankName", bankCode);
			query.setParameter("statusCode", APIConstant.AUTO_DEBIT_STATUS_MAPPING_DR_RECEIVED_HARD_COPY);
			
			List<TOmsAutoDebitLmsInf> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002") );
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#getListRegisterAutoDebitTrxByPeriodDate(java.util.Map)
	 */
	@Override
	public List<AutoDebitTrxInfo> getListRegisterAutoDebitTrxByPeriodDate(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		try {
			String isSend = inputParams.get(APIConstant._IS_SEND).toString();
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			String sql = "SELECT new com.shinhan.autodebit.core.model.AutoDebitTrxInfo("
					+ "mas.loanNo as loanNo, mas.customerName as customerName, mas.authorizeDt as authorizeDt, mas.firstDt as firstDt, "
					+ "mas.branch as branch, mas.roUser as roUser, mas.bankName as bankName, "
					+ "mas.adType as adType, mas.autosalDay as autosalDay, mas.doc36 as doc36, "
					
					+ "inf.sendDt as sendDt, inf.signedLocation as signedLocation, inf.sendUser as sendUser, inf.receiveDt as receiveDt, "
					+ "inf.receiveUser as receiveUser, inf.drDt as drDt, inf.sendBankDt as sendBankDt, "
					+ "inf.smsDueDt as smsDueDt, inf.bankResultDt as bankResultDt, inf.registrationResult as registrationResult, "
					+ "inf.reason as reason, inf.smsADDt as smsADDt, inf.statusCode as statusCode, "
					+ "inf.smsDueDtStatus as smsDueDtStatus, inf.smsADDtStatus as smsADDtStatus "
					+ ") "
					+ "from TOmsAutoDebitLmsMas mas left join TOmsAutoDebitLmsInf inf on mas.loanNo = inf.loanNo "
					+ "where mas.firstDt = :firstDueDt and inf.statusCode <> :statusCode "
					+ "and mas.loanStatus = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loanACH = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					
					+ "and (:loanNo is NULL or mas.loanNo =:loanNo) "
					+ "and (:branch is NULL or mas.branch =:branch) "
					+ "and (:roUser is NULL or mas.roUser =:roUser) "
					+ "and (:bankName is NULL or mas.bankName =:bankName) ";
					if(APIConstant.YES_KEY.equalsIgnoreCase(isSend)) {
						sql = sql + "and inf.smsDueDt != NULL ";
					} else if(APIConstant.NO_KEY.equalsIgnoreCase(isSend)) {
						sql = sql + "and inf.smsDueDt = NULL ";
					}
					
			String orderBy = "order by firstDt asc, loanNo asc";
			Query query = entityManager.createQuery(sql + orderBy);
			
			query.setParameter("statusCode", APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION);
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("branch", inputParams.get(APIConstant._BRANCH).toString());
			query.setParameter("roUser", inputParams.get(APIConstant._RO_USER).toString());
			query.setParameter("bankName", inputParams.get(APIConstant._BANK).toString());
			query.setParameter("firstDueDt", inputParams.get(APIConstant.PERIOD_DT));
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			List<AutoDebitTrxInfo> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#countRegisterAutoDebitTrxByPeriodDate(java.util.Map)
	 */
	@Override
	public BigDecimal countRegisterAutoDebitTrxByPeriodDate(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		try {
			String isSend = inputParams.get(APIConstant._IS_SEND).toString();
			String sql = "select count(distinct mas.loan_no) "
					+ "from oms_ad_lms_mas mas left join oms_ad_lms_inf inf on mas.loan_no = inf.loan_no "
					+ "where mas.first_due_dt =:firstDueDt and inf.status_code <> :statusCode "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					
					+ "and (:loanNo is NULL or mas.loan_no =:loanNo) "
					+ "and (:branch is NULL or mas.branch =:branch) "
					+ "and (:roUser is NULL or mas.ro_user =:roUser) "
					+ "and (:bankName is NULL or mas.bank_name =:bankName) "
					;
			
			if(APIConstant.YES_KEY.equalsIgnoreCase(isSend)) {
				sql = sql + "and inf.sms_due_dt is not NULL ";
			} else if(APIConstant.NO_KEY.equalsIgnoreCase(isSend)) {
				sql = sql + "and inf.sms_due_dt is NULL ";
			}
			
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("statusCode", APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION);
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("branch", inputParams.get(APIConstant._BRANCH).toString());
			query.setParameter("roUser", inputParams.get(APIConstant._RO_USER).toString());
			query.setParameter("bankName", inputParams.get(APIConstant._BANK).toString());
			query.setParameter("firstDueDt", inputParams.get(APIConstant.PERIOD_DT));
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#exportRegisterAutoDebitTrxByPeriodDate(java.util.Map)
	 */
	@Override
	public List<Object[]> exportRegisterAutoDebitTrxByPeriodDate(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		try {
			String isSend = inputParams.get(APIConstant._IS_SEND).toString();
			String sql = "SELECT "
					+ "mas.loanNo as loanNo, mas.customerName as customerName, mas.authorizeDt as authorizeDt, mas.firstDt as firstDt, "
					+ "mas.branch as branch, mas.roUser as roUser, mas.bankName as bankName, "
					+ "mas.adType as adType, mas.autosalDay as autosalDay, "
					
					+ "inf.sendDt as sendDt, inf.receiveDt as receiveDt, "
					+ "inf.sendBankDt as sendBankDt, inf.smsDueDt as smsDueDt "

					+ "from TOmsAutoDebitLmsMas mas left join TOmsAutoDebitLmsInf inf on mas.loanNo = inf.loanNo "
					+ "where mas.firstDt = :firstDueDt and inf.statusCode <> :statusCode "
					+ "and mas.loanStatus = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loanACH = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					
					+ "and (:loanNo is NULL or mas.loanNo =:loanNo) "
					+ "and (:branch is NULL or mas.branch =:branch) "
					+ "and (:roUser is NULL or mas.roUser =:roUser) "
					+ "and (:bankName is NULL or mas.bankName =:bankName) ";
					if(APIConstant.YES_KEY.endsWith(isSend)) {
						sql = sql + "and inf.smsDueDt != NULL ";
					} else if(APIConstant.NO_KEY.endsWith(isSend)) {
						sql = sql + "and inf.smsDueDt = NULL ";
					}
			
			Query query = entityManager.createQuery(sql);
			
			query.setParameter("statusCode", APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION);
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("branch", inputParams.get(APIConstant._BRANCH).toString());
			query.setParameter("roUser", inputParams.get(APIConstant._RO_USER).toString());
			query.setParameter("bankName", inputParams.get(APIConstant._BANK).toString());
			query.setParameter("firstDueDt", inputParams.get(APIConstant.PERIOD_DT));
			
			List<Object[]> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#exportReportSummaryAutoDebitTrx(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Object[]> exportReportSummaryAutoDebitTrx(String startDt, String endDt) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		try {
			String condition = "";
			String orderBy = "";
			String groupBy = "";
			String sqlSelectData = "";
			String sql = ""
						+ "from TOmsAutoDebitLmsInf inf, TOmsAutoDebitLmsMas mas "
						+ "where inf.loanNo = mas.loanNo "
						+ "and mas.loanStatus = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loanACH = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
						;
					sqlSelectData = "SELECT "
							+ "mas.loanNo as loanNo, mas.customerName as customerName, mas.authorizeDt as authorizeDt, mas.firstDt as firstDt, "
							+ "mas.branch as branch, mas.roUser as roUser, mas.bankName as bankName, "
							+ "mas.adType as adType, mas.autosalDay as autosalDay, "
							
							+ "inf.sendDt as sendDt, inf.receiveDt as receiveDt, "
							+ "inf.sendBankDt as sendBankDt, inf.bankResultDt as bankResultDt, inf.registrationResult as registrationResult, "
							+ "(SELECT tm.value from TMetadata tm "
							+ "where tm.lookupCode = '"+APIConstant.LOOKUP_CODE_AD_IMPORT_BANK_RESULT_FAIL+"' and tm.lookupCodeId = inf.reason) as reason, "
							+ "inf.smsDueDt as smsDueDt, "
							+ "inf.smsADDt as smsADDt "
							;
					condition = "and mas.authorizeDt between :startDt and :endDt ";
					orderBy = "order by mas.authorizeDt asc";
					
			sql = sqlSelectData + sql + condition + groupBy + orderBy;
			Query query = entityManager.createQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
		
			List<Object[]> list = query.getResultList();
			if(CollectionUtils.isEmpty(list)) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
			}
			return list;
		}
		catch(ServiceInvalidAgurmentException ex) {
			ex.printStackTrace();
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." );
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#exportReportTATSummaryAutoDebitTrx(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Object[]> exportReportTATSummaryAutoDebitTrx(String startDt, String endDt)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		boolean isEmpty = false;
		List<Object[]> rs = new ArrayList<Object[]>();
		String sql;
		Query query;
		List<Object[]> list;
		try {
			
			/** Report for T1 - T */
			sql = "select count(a.cnt), sum(a.diff) FROM "
					+ "(SELECT count(sub.loan_no) as cnt, SUM(sub.dateDiff) as diff From ( "
					+ "SELECT mas.loan_no as loan_no, (inf.send_dt - mas.authorized_dt) as dateDiff "
					+ "from OMS_AD_LMS_INF inf, OMS_AD_LMS_MAS mas "
					+ "where inf.loan_no = mas.loan_no and inf.send_dt is not NULL "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and mas.authorized_dt between :startDt and :endDt ) "
					+ "sub group by sub.loan_no "
					+ ") a "
					+ ""
					;
			
			query = entityManager.createNativeQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			list = query.getResultList();
			if(CollectionUtils.isEmpty(list) || APIConstant.DEC_ZERO.compareTo(new BigDecimal(String.valueOf(list.get(0)[0]))) == 0) {
				Object[] dummy = {APIConstant.DEC_ZERO, APIConstant.DEC_ZERO};
				list.clear();
				list.add(dummy);
				isEmpty = true;
			}
			rs.add(list.get(0));
			
			/** Report for T2 - T */
			sql = "select count(a.cnt), sum(a.diff) FROM "
					+ "(SELECT count(sub.loan_no) as cnt, SUM(sub.dateDiff) as diff From ( "
					+ "SELECT mas.loan_no as loan_no, (to_date(to_char(inf.received_dt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') - mas.authorized_dt) as dateDiff "
					+ ""
					+ "from OMS_AD_LMS_INF inf, OMS_AD_LMS_MAS mas "
					+ "where inf.loan_no = mas.loan_no and inf.received_dt is not NULL "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and mas.authorized_dt between :startDt and :endDt ) "
					+ "sub group by sub.loan_no "
					+ ") a "
					+ ""
					;
			query = entityManager.createNativeQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			list = query.getResultList();
			if(CollectionUtils.isEmpty(list) || APIConstant.DEC_ZERO.compareTo(new BigDecimal(String.valueOf(list.get(0)[0]))) == 0) {
				Object[] dummy = {APIConstant.DEC_ZERO, APIConstant.DEC_ZERO};
				list.clear();
				list.add(dummy);
			} else {
				isEmpty = false;
			}
			rs.add(list.get(0));
			
			/** Report for T3 - T */
			sql = "SELECT count(a.cnt), sum(a.diff) FROM "
					+ "(SELECT count(sub.loan_no) as cnt, SUM(sub.dateDiff) as diff FROM ( "
					+ "SELECT mas.loan_no as loan_no, (inf.send_bank_dt - mas.authorized_dt) as dateDiff "
					+ "from OMS_AD_LMS_INF inf, OMS_AD_LMS_MAS mas "
					+ "where inf.loan_no = mas.loan_no and inf.send_bank_dt is not NULL "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and mas.authorized_dt between :startDt and :endDt ) "
					+ "sub group by sub.loan_no "
					+ ") a "
					+ ""
					;
			query = entityManager.createNativeQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			list = query.getResultList();
			if(CollectionUtils.isEmpty(list) || APIConstant.DEC_ZERO.compareTo(new BigDecimal(String.valueOf(list.get(0)[0]))) == 0) {
				Object[] dummy = {APIConstant.DEC_ZERO, APIConstant.DEC_ZERO};
				list.clear();
				list.add(dummy);
			} else {
				isEmpty = false;
			}
			rs.add(list.get(0));
			
			/** Report for T4 - T */
			sql = "SELECT count(a.cnt), sum(a.diff) FROM "
					+ "(SELECT count(sub.loan_no) as cnt, SUM(sub.dateDiff) as diff FROM ( "
					+ "SELECT mas.loan_no as loan_no, (inf.bank_result_dt - mas.authorized_dt) as dateDiff "
					+ "from OMS_AD_LMS_INF inf, OMS_AD_LMS_MAS mas "
					+ "where inf.loan_no = mas.loan_no and inf.bank_result_dt is not NULL "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and mas.authorized_dt between :startDt and :endDt ) "
					+ "sub group by sub.loan_no "
					+ ") a "
					+ ""
					;
			query = entityManager.createNativeQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			list = query.getResultList();
			if(CollectionUtils.isEmpty(list) || APIConstant.DEC_ZERO.compareTo(new BigDecimal(String.valueOf(list.get(0)[0]))) == 0) {
				Object[] dummy = {APIConstant.DEC_ZERO, APIConstant.DEC_ZERO};
				list.clear();
				list.add(dummy);
			} else {
				isEmpty = false;
			}
			rs.add(list.get(0));
			
			/** Report for T2 - T1 */
			sql = "SELECT count(a.cnt), sum(a.diff) FROM "
					+ "(SELECT count(sub.loan_no) as cnt, SUM(sub.dateDiff) as diff FROM ( "
					+ "SELECT mas.loan_no as loan_no, "
					+ "CASE WHEN inf.send_dt is NULL then 0 ELSE (to_date(to_char(inf.received_dt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') - inf.send_dt) END as dateDiff "
					
					+ "from OMS_AD_LMS_INF inf, OMS_AD_LMS_MAS mas "
					+ "where inf.loan_no = mas.loan_no and inf.received_dt is not NULL "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and mas.authorized_dt between :startDt and :endDt ) "
					+ "sub group by sub.loan_no "
					+ ") a "
					+ ""
					;
			query = entityManager.createNativeQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			list = query.getResultList();
			if(CollectionUtils.isEmpty(list) || APIConstant.DEC_ZERO.compareTo(new BigDecimal(String.valueOf(list.get(0)[0]))) == 0) {
				Object[] dummy = {APIConstant.DEC_ZERO, APIConstant.DEC_ZERO};
				list.clear();
				list.add(dummy);
			} else {
				isEmpty = false;
			}
			rs.add(list.get(0));
			
			/** Report for T3 - T2 */
			sql = "SELECT count(a.cnt), sum(a.diff) FROM "
					+ "(SELECT count(sub.loan_no) as cnt, SUM(sub.dateDiff) as diff FROM ( "
					+ "SELECT mas.loan_no as loan_no, "
					+ "CASE WHEN inf.received_dt is NULL then 0 ELSE (inf.send_bank_dt - to_date(to_char(inf.received_dt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"')) END as dateDiff "
					+ "from OMS_AD_LMS_INF inf, OMS_AD_LMS_MAS mas "
					+ "where inf.loan_no = mas.loan_no and inf.send_bank_dt is not NULL "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and mas.authorized_dt between :startDt and :endDt ) "
					+ "sub group by sub.loan_no "
					+ ") a "
					+ ""
					;
			query = entityManager.createNativeQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			list = query.getResultList();
			if(CollectionUtils.isEmpty(list) || APIConstant.DEC_ZERO.compareTo(new BigDecimal(String.valueOf(list.get(0)[0]))) == 0) {
				Object[] dummy = {APIConstant.DEC_ZERO, APIConstant.DEC_ZERO};
				list.clear();
				list.add(dummy);
			} else {
				isEmpty = false;
			}
			rs.add(list.get(0));
			
			/** Report for T4 - T3 */
			sql = "SELECT count(a.cnt), sum(a.diff) FROM "
					+ "(SELECT count(sub.loan_no) as cnt, SUM(sub.dateDiff) as diff FROM ( "
					+ "SELECT mas.loan_no as loan_no, "
					+ "CASE WHEN inf.send_bank_dt is NULL then 0 ELSE (inf.bank_result_dt - inf.send_bank_dt) END as dateDiff "
					+ "from OMS_AD_LMS_INF inf, OMS_AD_LMS_MAS mas "
					+ "where inf.loan_no = mas.loan_no and inf.bank_result_dt is not NULL "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and mas.authorized_dt between :startDt and :endDt ) "
					+ "sub group by sub.loan_no "
					+ ") a "
					+ ""
					;
			query = entityManager.createNativeQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			list = query.getResultList();
			if(CollectionUtils.isEmpty(list) || APIConstant.DEC_ZERO.compareTo(new BigDecimal(String.valueOf(list.get(0)[0]))) == 0) {
				Object[] dummy = {APIConstant.DEC_ZERO, APIConstant.DEC_ZERO};
				list.clear();
				list.add(dummy);
			} else {
				isEmpty = false;
			}
			rs.add(list.get(0));
			
			if(isEmpty) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
			}
			
			return rs;
		}
		catch(ServiceInvalidAgurmentException ex) {
			ex.printStackTrace();
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#exportReportBankResultAutoDebitTrx(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Object[]> exportReportBankResultAutoDebitTrx(String startDt, String endDt)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		List<Object[]> rs = new ArrayList<Object[]>();
		boolean isEmpty = false;
		String sql;
		Query query;
		List<Object[]> list;
		Object[] header;
		Object[] dummyForEmpty;
		Date current = DateUtils.converToDate(startDt);
		Date end = DateUtils.converToDate(endDt);
		String lstDt = "'"+DateUtils.formatToString(DateUtils.converToDate(startDt), DateUtils.ddMMMyy)+"'" + "";
		while (current.before(end)) {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(current);
			calendar.add(Calendar.DATE, 1);
			current = calendar.getTime();
			String dummyDt = DateUtils.formatToString(current, DateUtils.ddMMMyy);
			lstDt += ", " + "'"+dummyDt+"'";
		}
		try {
			header = StringUtils.split(StringUtils.remove(lstDt.replace("'", ""), APIConstant.SPACE_KEY), APIConstant.COMMA);
			rs.add(header);
			/** Report for Success */
			sql = "SELECT * "
					+ "FROM ( "
					+ "SELECT mas.authorized_dt, "
					+ "case when inf.status_code = '"+APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION+"' "
							+ "and inf.registration_result = '"+APIConstant.AD_IMPORT_BANK_RESULT_SUCCESS+"' then 1 else 0 END as cntSuccess "
					+ "from OMS_AD_LMS_INF inf, OMS_AD_LMS_MAS mas "
					+ "where inf.loan_no = mas.loan_no "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and mas.authorized_dt between :startDt and :endDt "
					+ "order by mas.authorized_dt"
					+ ")"
					+ "PIVOT (SUM(cntSuccess) FOR (authorized_dt) IN ("+lstDt+"))"
					+ ""
					;
			
			query = entityManager.createNativeQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			list = query.getResultList();
			
			if(CommonUtil.checkValueInListIsNullOrZero(list)) {
				dummyForEmpty = new Object[header.length];
				for(int i = 0; i < header.length; i ++) {
					dummyForEmpty[i] = 0;
				}
				list.clear();
				list.add(dummyForEmpty);
				isEmpty = true;
			}
			try {
				//For case have only one item
				if(APIConstant.DEC_ZERO.compareTo(new BigDecimal(list.get(0) + "")) != 0) {
					dummyForEmpty = new Object[header.length];
					dummyForEmpty[0] = list.get(0);
					list.clear();
					list.add(dummyForEmpty);
				}
			} catch(Exception e) {
				logger.info("Not One Item");
			}
			rs.add(list.get(0));
			
			/** Report for Un-Success */
			sql = "SELECT * "
					+ "FROM ( "
					+ "SELECT mas.authorized_dt, "
					+ "case when inf.status_code = '"+APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION+"' "
							+ "and inf.registration_result = '"+APIConstant.AD_IMPORT_BANK_RESULT_FAIL+"' then 1 else 0 END as cntSuccess "
					+ "from OMS_AD_LMS_INF inf, OMS_AD_LMS_MAS mas "
					+ "where inf.loan_no = mas.loan_no "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and mas.authorized_dt between :startDt and :endDt "
					+ "order by mas.authorized_dt"
					+ ")"
					+ "PIVOT (SUM(cntSuccess) FOR (authorized_dt) IN ("+lstDt+"))"
					+ ""
					;
			
			query = entityManager.createNativeQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			list = query.getResultList();
			if(CommonUtil.checkValueInListIsNullOrZero(list)) {
				dummyForEmpty = new Object[header.length];
				for(int i = 0; i < header.length; i ++) {
					dummyForEmpty[i] = 0;
				}
				list.clear();
				list.add(dummyForEmpty);
			} else {
				isEmpty = false;
			}
			
			try {
				//For case have only one item
				if(APIConstant.DEC_ZERO.compareTo(new BigDecimal(list.get(0) + "")) != 0) {
					dummyForEmpty = new Object[header.length];
					dummyForEmpty[0] = list.get(0);
					list.clear();
					list.add(dummyForEmpty);
				}
			} catch(Exception e) {
				logger.info("Not One Item");
			}
			
			rs.add(list.get(0));
			
			/** Report for without form */
			sql = "SELECT * "
					+ "FROM ( "
					+ "SELECT mas.authorized_dt, "
					//+ "case when mas.doc36 = '"+APIConstant.DOC36_NO_VALUE+"' then 1 else 0 END as cntDoc "
					+ "mas.loan_no "
					+ "from OMS_AD_LMS_MAS mas "
					+ "where mas.authorized_dt between :startDt and :endDt "
					+ "and NOT EXISTS (select loan_no from OMS_AD_LMS_INF inf where mas.loan_no = inf.loan_no) "
					+ "order by mas.authorized_dt"
					+ ")"
					//+ "PIVOT (SUM(cntDoc) FOR (authorized_dt) IN ("+lstDt+"))"
					+ "PIVOT (count(loan_no) FOR (authorized_dt) IN ("+lstDt+"))"
					+ ""
					;
			
			query = entityManager.createNativeQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			list = query.getResultList();
			if(CommonUtil.checkValueInListIsNullOrZero(list)) {
				dummyForEmpty = new Object[header.length];
				for(int i = 0; i < header.length; i ++) {
					dummyForEmpty[i] = 0;
				}
				list.clear();
				list.add(dummyForEmpty);
			} else {
				isEmpty = false;
			}
			
			try {
				//For case have only one item
				if(APIConstant.DEC_ZERO.compareTo(new BigDecimal(list.get(0) + "")) != 0) {
					dummyForEmpty = new Object[header.length];
					dummyForEmpty[0] = list.get(0);
					list.clear();
					list.add(dummyForEmpty);
				}
			} catch(Exception e) {
				logger.info("Not One Item");
			}
			rs.add(list.get(0));
			
			if(isEmpty) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
			}
			
			return rs;
		}
		catch(ServiceInvalidAgurmentException ex) {
			ex.printStackTrace();
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + "");
		}
	
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#exportReportBankResultFailAutoDebitTrx(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Object[]> exportReportBankResultFailAutoDebitTrx(String startDt, String endDt)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {

		List<Object[]> rs = new ArrayList<Object[]>();
		String sql;
		Query query;
		List<Object[]> list;
		Date current = DateUtils.converToDate(startDt);
		Date end = DateUtils.converToDate(endDt);
		String lstDt = "'"+DateUtils.formatToString(DateUtils.converToDate(startDt), DateUtils.ddMMMyy)+"'" + "";
		while (current.before(end)) {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(current);
			calendar.add(Calendar.DATE, 1);
			current = calendar.getTime();
			String dummyDt = DateUtils.formatToString(current, DateUtils.ddMMMyy);
			lstDt += ", " + "'"+dummyDt+"'";
		}
		try {
			rs.add(StringUtils.split(StringUtils.remove((APIConstant.REASON_VALUE + ", " + lstDt).replace("'", ""), APIConstant.SPACE_KEY), APIConstant.COMMA));
			/** Report for Fail */
			sql = "SELECT * FROM ( "
					+ "SELECT reason, authorized_dt, count(loan_no) as cnt FROM "
					+ "(SELECT tm.value as reason, mas.authorized_dt, inf.loan_no "
					+ "from oms_metadata tm left join OMS_AD_LMS_INF inf "
					+ "on tm.lookupCodeId = inf.reason "
					+ "and inf.status_code = '"+APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION+"' "
					+ "and inf.registration_result = '"+APIConstant.AD_IMPORT_BANK_RESULT_FAIL+"' "
					+ "left join OMS_AD_LMS_MAS mas "
					+ "on inf.loan_no = mas.loan_no "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and mas.authorized_dt between :startDt and :endDt "
					+ "where tm.lookupCode = '"+APIConstant.LOOKUP_CODE_AD_IMPORT_BANK_RESULT_FAIL+"' "
					+ "order by tm.orderby, mas.authorized_dt) "
					+ "group by reason, authorized_dt "
					+ "order by reason, authorized_dt "
					+") "
					+ "PIVOT (SUM(cnt) FOR authorized_dt IN ("+lstDt+"))"
					+ ""
					;
			
			query = entityManager.createNativeQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			list = query.getResultList();
			if(CollectionUtils.isEmpty(list)) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
			}
			rs.addAll(list);
			
			/** Report for Count Total Fail */
			sql = "SELECT * "
					+ "FROM ( "
					+ "SELECT mas.authorized_dt, inf.reason "
					
					+ "from OMS_AD_LMS_INF inf, OMS_AD_LMS_MAS mas "
					+ "where inf.loan_no = mas.loan_no "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and inf.status_code = '"+APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION+"' "
					+ "and inf.registration_result = '"+APIConstant.AD_IMPORT_BANK_RESULT_FAIL+"' "
					+ "and mas.authorized_dt between :startDt and :endDt "
					+ "order by mas.authorized_dt"
					+ ")"
					+ "PIVOT (COUNT(reason) FOR (authorized_dt) IN ("+lstDt+"))"
					+ ""
					;
			
			query = entityManager.createNativeQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			list = query.getResultList();
			if(CollectionUtils.isEmpty(list)) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
			}
			Object[] totals = list.get(0);
			Object[] totalNews = new Object[totals.length + 1];
			totalNews[0] = APIConstant.TOTAL_VALUE;
			for (int i = 1; i <= totals.length; i++) {
				totalNews[i] = totals[i-1];
			}
			rs.add(totalNews);
			
			return rs;
		}
		catch(ServiceInvalidAgurmentException ex) {
			ex.printStackTrace();
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#exportReportBankTransactionAutoDebitTrx(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Object[]> exportReportBankTransactionAutoDebitTrx(String startDt, String endDt)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		try {
			String condition = "";
			String orderBy = "";
			String groupBy = "";
			String sqlSelectData = "";
			String sql = ""
						+ "from OMS_AD_LMS_MAS mas left join OMS_AD_LMS_INF inf ON inf.loan_no = mas.loan_no "
						+ "where mas.authorized_dt is not NULL "
						+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
						;
					sqlSelectData = "SELECT sub.bank_name, count(sub.loan_no) as bankCnt, sum (sub.cntReceived) as bankRegisCnt "
							+ "FROM (SELECT mas.bank_name, mas.loan_no, "
							+ "inf.received_dt, inf.status_code, "
							+ "case when inf.received_dt is not NULL then 1 else 0 end as cntReceived "
							;
					condition = "and mas.authorized_dt between :startDt and :endDt) sub ";
					orderBy = "group by sub.bank_name order by sub.bank_name";
					
			sql = sqlSelectData + sql + condition + groupBy + orderBy;
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
		
			List<Object[]> list = query.getResultList();
			if(CollectionUtils.isEmpty(list)) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
			}
			return list;
		}
		catch(ServiceInvalidAgurmentException ex) {
			ex.printStackTrace();
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." );
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#exportReportTATBankAutoDebitTrx(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Object[]> exportReportTATBankAutoDebitTrx(String startDt, String endDt)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String sql;
		Query query;
		List<Object[]> list;
		try {
			sql = "SELECT sub.bank_name as bank_name, count(sub.loan_no) as cnt, SUM(sub.dateDiff) as diff FROM ( "
					+ "SELECT "
					+ "case when mas.bank_name is null or mas.bank_name = 'OTHER' or mas.bank_name = 'OTHERS' then 'OTHERS' else mas.bank_name end as bank_name, "
					+ "mas.loan_no as loan_no, (inf.bank_result_dt - mas.authorized_dt) as dateDiff "
					+ "from OMS_AD_LMS_INF inf, OMS_AD_LMS_MAS mas "
					+ "where inf.loan_no = mas.loan_no and inf.bank_result_dt is not NULL "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and mas.authorized_dt between :startDt and :endDt "
					+ "order by mas.bank_name "
					+ ") "
					+ "sub group by sub.bank_name"
					;
			query = entityManager.createNativeQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			list = query.getResultList();
			if(CollectionUtils.isEmpty(list)) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
			}
			return list;
		}
		catch(ServiceInvalidAgurmentException ex) {
			ex.printStackTrace();
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." );
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#exportReportTATBankTransactionAutoDebitTrx(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Object[]> exportReportTATBankTransactionAutoDebitTrx(String startDt, String endDt)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String sql;
		Query query;
		List<Object[]> list;
		try {
			sql = "SELECT sub.bank_name, count(sub.loan_no) as bankCnt, sum (sub.cntSuccess) as cntSuccess, sum (sub.cntFail) as cntFail FROM ( "
					+ "SELECT "
					+ "case when mas.bank_name is null or mas.bank_name = 'OTHER' or mas.bank_name = 'OTHERS' then 'OTHERS' else mas.bank_name end as bank_name, "
		
					+ "mas.loan_no, inf.status_code, inf.registration_result, "
					+ "case when inf.status_code = '"+APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION+"' "
							+ "and inf.registration_result = '"+APIConstant.AD_IMPORT_BANK_RESULT_SUCCESS+"' then 1 else 0 end as cntSuccess, "
							
					+ "case when "
					+ "(inf.status_code = '"+APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION+"' "
					+ "and inf.registration_result = '"+APIConstant.AD_IMPORT_BANK_RESULT_FAIL+"') "
					//+ "or (inf.status_code = '"+APIConstant.AUTO_DEBIT_STATUS_MAPPING_WAITING_BANK_REGISTRATION+"' ) "
					+ "then 1 else 0 end as cntFail "
					
					+ "from OMS_AD_LMS_MAS mas left join OMS_AD_LMS_INF inf ON inf.loan_no = mas.loan_no "
					+ "where mas.authorized_dt is not NULL "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and mas.authorized_dt between :startDt and :endDt "
					+ "order by mas.bank_name) "
					+ "sub group by sub.bank_name order by sub.bank_name"
					+ ""
					;
			query = entityManager.createNativeQuery(sql);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			list = query.getResultList();
			if(CollectionUtils.isEmpty(list)) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
			}
			return list;
		}
		catch(ServiceInvalidAgurmentException ex) {
			ex.printStackTrace();
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." );
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#getListAutoDebitTrxForSendSMSFirstDueDt()
	 */
	@Override
	public List<TOmsAutoDebitLmsInf> getListAutoDebitTrxForSendSMSFirstDueDt() throws ServiceRuntimeException {
		try {
			String sql = "SELECT inf.* "
					+ "from oms_ad_lms_inf inf, oms_ad_lms_mas mas "
					+ "where inf.loan_no = mas.loan_no "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and inf.sms_due_dt_status = '"+APIConstant.AD_SEND_SMS_STATUS_PROCESSING+"' "
					
					;
			Query query = entityManager.createNativeQuery(sql, TOmsAutoDebitLmsInf.class);
			
			List<TOmsAutoDebitLmsInf> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002") );
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService#getListAutoDebitTrxForSendSMSFailBank()
	 */
	@Override
	public List<TOmsAutoDebitLmsInf> getListAutoDebitTrxForSendSMSFailBank() throws ServiceRuntimeException {
		try {
			String sql = "SELECT inf.* "
					+ "from oms_ad_lms_inf inf, oms_ad_lms_mas mas "
					+ "where inf.loan_no = mas.loan_no "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					
					+ "and inf.status_code = '"+APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION+"' "
					+ "and inf.registration_result = '"+APIConstant.AD_IMPORT_BANK_RESULT_FAIL+"' "
					
					+ "and inf.sms_ad_dt_status = '"+APIConstant.AD_SEND_SMS_STATUS_PROCESSING+"' "
					
					;
			Query query = entityManager.createNativeQuery(sql, TOmsAutoDebitLmsInf.class);
			
			List<TOmsAutoDebitLmsInf> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002") );
		}
	}

}
