/**
 * 
 */
package com.shinhan.autodebit.common;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.shinhan.autodebit.core.exception.BaseException;
import com.shinhan.autodebit.core.util.DateUtils;

/**
 * @author shds01
 *
 */
@Service("asyncManagerService")
public class AsyncManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Async()
	public void testAsync() throws BaseException {
		logger.info("Start Async : " + new Date());
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			throw new IllegalStateException(e);
		}
		logger.info("End Async : " + new Date());
	}
	
	@Async("taskExecutorOMS")
	public void writeResponseInLog(String json){
		logger.info("Start writeResponseInLog Async Task at : " + DateUtils.getSystemDateStr(DateUtils.ddMMyyyy_HH_mm_ss));
		ObjectMapper objectMapper = new ObjectMapper();
		try{
			JsonNode jsonNode = objectMapper.readValue(json, JsonNode.class);
			logger.info("Response : " + jsonNode.toString());
		}catch(Exception e){
			logger.info("Response : " + json);
		}
		logger.info("End writeResponseInLog Async Task at : " +DateUtils.getSystemDateStr(DateUtils.ddMMyyyy_HH_mm_ss));
	}
}
