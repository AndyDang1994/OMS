/**
 * 
 */
package com.shinhan.autodebit.repository.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author shds01
 *
 */
@Entity
@Table(name = "OMS_CS_TRACKING")
public class TOmsCSTracking implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	private String loanNo;
	private String trackingNo;
	private String trackingType;

	/**
	 * 
	 */
	public TOmsCSTracking() {
		super();
	}

	/**
	 * @param id
	 * @param loanNo
	 * @param trackingNo
	 * @param trackingType
	 */
	public TOmsCSTracking(Long id, String loanNo, String trackingNo, String trackingType) {
		super();
		this.id = id;
		this.loanNo = loanNo;
		this.trackingNo = trackingNo;
		this.trackingType = trackingType;
	}

	/**
	 * @return the id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "OMS_CS_TRACKING_SEQ_GEN")
	@SequenceGenerator(name = "OMS_CS_TRACKING_SEQ_GEN", sequenceName = "OMS_CS_TRACKING_SEQ", allocationSize = 1)
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the loanNo
	 */
	@Column(name = "LOAN_NO")
	public String getLoanNo() {
		return loanNo;
	}

	/**
	 * @param loanNo the loanNo to set
	 */
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	/**
	 * @return the trackingNo
	 */
	@Column(name = "TRACKING_ID")
	public String getTrackingNo() {
		return trackingNo;
	}

	/**
	 * @param trackingNo the trackingNo to set
	 */
	public void setTrackingNo(String trackingNo) {
		this.trackingNo = trackingNo;
	}

	/**
	 * @return the trackingType
	 */
	@Column(name = "TRACKING_TYPE")
	public String getTrackingType() {
		return trackingType;
	}

	/**
	 * @param trackingType the trackingType to set
	 */
	public void setTrackingType(String trackingType) {
		this.trackingType = trackingType;
	}

}
