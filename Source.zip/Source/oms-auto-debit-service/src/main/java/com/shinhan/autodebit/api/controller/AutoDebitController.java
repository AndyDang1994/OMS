/**
 * 
 */
package com.shinhan.autodebit.api.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.shinhan.autodebit.core.constant.APIConstant;
import com.shinhan.autodebit.core.exception.BaseException;
import com.shinhan.autodebit.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.autodebit.core.model.AutoDebitRegisBankResultTrxInfo;
import com.shinhan.autodebit.core.model.AutoDebitRegisTrxInfo;
import com.shinhan.autodebit.core.model.AutoDebitTrxInfo;
import com.shinhan.autodebit.core.util.DateUtils;


/**
 * @author shds01
 *
 */
@RestController
public class AutoDebitController extends BaseController{
	
	@RequestMapping(value = "shinhan/service/autodebit/unregistrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public String getUnRegisterTrxAutoList(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			
			@RequestParam(required = false, defaultValue = "" ) String _startDt,
			@RequestParam(required = false, defaultValue = "" ) String _endDt,
			
			@RequestParam(required = false, defaultValue = "" ) String _loanNo,
			@RequestParam(required = false, defaultValue = "" ) String _branch,
			@RequestParam(required = false, defaultValue = "" ) String _roUser,
			@RequestParam(required = false, defaultValue = "" ) String _bank,
			@RequestParam(required = false, defaultValue = "" ) String _adType,
			@RequestParam(required = false, defaultValue = "" ) String _doc36,
			@RequestParam(required = false, defaultValue = "" ) String _firstDueDt,
			
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		
		inputParams.put(APIConstant._LOAN_NO, _loanNo);
		inputParams.put(APIConstant._BRANCH, _branch);
		inputParams.put(APIConstant._RO_USER, _roUser);
		inputParams.put(APIConstant._BANK, _bank);
		
		inputParams.put(APIConstant._AD_TYPE, _adType);
		inputParams.put(APIConstant._DOC36, _doc36);
		
		inputParams.put(APIConstant._FIRST_DUEDT, _firstDueDt);
		
		List<AutoDebitTrxInfo> lst = getProcessManagerService().getAdApiService().getListUnRegisterAutoDebitTrx(inputParams);
		BigDecimal countTotal = getProcessManagerService().getAdApiService().countTotalUnRegisterAutoDebitTrx(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
		
	}
	
	@RequestMapping(value = "shinhan/service/autodebit/unregistrx/export", produces = {"application/pdf"}, method = RequestMethod.POST)
	public ResponseEntity<Object> exportUnRegisterTrxAutoListToExcel(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			
			@RequestParam(required = true) String _startDt,
			@RequestParam(required = true) String _endDt,
			
			@RequestParam(required = false, defaultValue = "" ) String _loanNo,
			@RequestParam(required = false, defaultValue = "" ) String _branch,
			@RequestParam(required = false, defaultValue = "" ) String _roUser,
			@RequestParam(required = false, defaultValue = "" ) String _bank,
			@RequestParam(required = false, defaultValue = "" ) String _adType,
			@RequestParam(required = false, defaultValue = "" ) String _doc36,
			@RequestParam(required = false, defaultValue = "" ) String _firstDueDt,
			
			@RequestBody String document,
			Locale locale) throws BaseException, FileNotFoundException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		
		inputParams.put(APIConstant._LOAN_NO, _loanNo);
		inputParams.put(APIConstant._BRANCH, _branch);
		inputParams.put(APIConstant._RO_USER, _roUser);
		inputParams.put(APIConstant._BANK, _bank);
		
		inputParams.put(APIConstant._AD_TYPE, _adType);
		inputParams.put(APIConstant._DOC36, _doc36);
		
		inputParams.put(APIConstant._FIRST_DUEDT, _firstDueDt);
		
		File item = getProcessManagerService().getAdApiService().exportUnRegisterAutoDebitTrx(inputParams);
		
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_004"));
		}
		
		return triggerSuccessResponseFile(item);
		
	}

	@RequestMapping(value = "shinhan/service/autodebit/registrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public String getRegisterTrxAutoList(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			
			@RequestParam(required = false, defaultValue = "" ) String _startDt,
			@RequestParam(required = false, defaultValue = "" ) String _endDt,
			
			@RequestParam(required = false, defaultValue = "" ) String _loanNo,
			@RequestParam(required = false, defaultValue = "" ) String _branch,
			@RequestParam(required = false, defaultValue = "" ) String _roUser,
			@RequestParam(required = false, defaultValue = "" ) String _bank,
			@RequestParam(required = false, defaultValue = "" ) String _adType,
			
			@RequestParam(required = true, defaultValue = "" ) String _statusMap,
			
			@RequestParam(required = false, defaultValue = "" ) String _startSendDt,
			@RequestParam(required = false, defaultValue = "" ) String _endSendDt,
			@RequestParam(required = false, defaultValue = "" ) String _signedLocation,
			@RequestParam(required = false, defaultValue = "" ) String _sendUser,
			
			@RequestParam(required = false, defaultValue = "" ) String _receiveUser,
			@RequestParam(required = false, defaultValue = "" ) String _startReceiveDt,
			@RequestParam(required = false, defaultValue = "" ) String _endReceiveDt,
			
			@RequestParam(required = false, defaultValue = "" ) String _startSendBankDt,
			@RequestParam(required = false, defaultValue = "" ) String _endSendBankDt,
			
			@RequestParam(required = false, defaultValue = "" ) String _startBankResultDt,
			@RequestParam(required = false, defaultValue = "" ) String _endBankResultDt,
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant._START_DATE_KEY, _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, _endDt);
		
		inputParams.put(APIConstant._LOAN_NO, _loanNo);
		inputParams.put(APIConstant._BRANCH, _branch);
		inputParams.put(APIConstant._RO_USER, _roUser);
		inputParams.put(APIConstant._BANK, _bank);
		inputParams.put(APIConstant._AD_TYPE, _adType);
		
		inputParams.put(APIConstant._STATUS_AD_MAP, _statusMap);
		
		inputParams.put(APIConstant._START_SEND_DT, _startSendDt);
		inputParams.put(APIConstant._END_SEND_DT, _endSendDt);
		inputParams.put(APIConstant._SIGNEDLOCATION, _signedLocation);
		inputParams.put(APIConstant._SENDUSER, _sendUser);
		
		inputParams.put(APIConstant._RECEIVE_USER, _receiveUser);
		inputParams.put(APIConstant._START_RECEIVE_DT, _startReceiveDt);
		inputParams.put(APIConstant._END_RECEIVE_DT, _endReceiveDt);
		
		inputParams.put(APIConstant._START_SEND_BANK_DT, _startSendBankDt);
		inputParams.put(APIConstant._END_SEND_BANK_DT, _endSendBankDt);
		
		inputParams.put(APIConstant._START_BANK_RESULT_DT, _startBankResultDt);
		inputParams.put(APIConstant._END_BANK_RESULT_DT, _endBankResultDt);
		
		List<AutoDebitTrxInfo> lst = getProcessManagerService().getAdApiService().getListRegisterAutoDebitTrx(inputParams);
		BigDecimal countTotal = getProcessManagerService().getAdApiService().countTotalRegisterAutoDebitTrx(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
		
	}
	
	@RequestMapping(value = "shinhan/service/autodebit/registrx/export", produces = {"application/pdf"}, method = RequestMethod.POST)
	public ResponseEntity<Object> exportRegisterTrxAutoList(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			
			@RequestParam(required = false, defaultValue = "" ) String _startDt,
			@RequestParam(required = false, defaultValue = "" ) String _endDt,
			
			@RequestParam(required = false, defaultValue = "" ) String _loanNo,
			@RequestParam(required = false, defaultValue = "" ) String _branch,
			@RequestParam(required = false, defaultValue = "" ) String _roUser,
			@RequestParam(required = false, defaultValue = "" ) String _bank,
			@RequestParam(required = false, defaultValue = "" ) String _adType,
			
			@RequestParam(required = true, defaultValue = "" ) String _statusMap,
			
			@RequestParam(required = false, defaultValue = "" ) String _startSendDt,
			@RequestParam(required = false, defaultValue = "" ) String _endSendDt,
			@RequestParam(required = false, defaultValue = "" ) String _signedLocation,
			@RequestParam(required = false, defaultValue = "" ) String _sendUser,
			
			@RequestParam(required = false, defaultValue = "" ) String _receiveUser,
			@RequestParam(required = false, defaultValue = "" ) String _startReceiveDt,
			@RequestParam(required = false, defaultValue = "" ) String _endReceiveDt,
			
			@RequestParam(required = false, defaultValue = "" ) String _startSendBankDt,
			@RequestParam(required = false, defaultValue = "" ) String _endSendBankDt,
			
			@RequestParam(required = false, defaultValue = "" ) String _startBankResultDt,
			@RequestParam(required = false, defaultValue = "" ) String _endBankResultDt,
			Locale locale) throws BaseException, FileNotFoundException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant._START_DATE_KEY, _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, _endDt);
		
		inputParams.put(APIConstant._LOAN_NO, _loanNo);
		inputParams.put(APIConstant._BRANCH, _branch);
		inputParams.put(APIConstant._RO_USER, _roUser);
		inputParams.put(APIConstant._BANK, _bank);
		inputParams.put(APIConstant._AD_TYPE, _adType);
		
		inputParams.put(APIConstant._STATUS_AD_MAP, _statusMap);
		
		inputParams.put(APIConstant._START_SEND_DT, _startSendDt);
		inputParams.put(APIConstant._END_SEND_DT, _endSendDt);
		inputParams.put(APIConstant._SIGNEDLOCATION, _signedLocation);
		inputParams.put(APIConstant._SENDUSER, _sendUser);
		
		inputParams.put(APIConstant._RECEIVE_USER, _receiveUser);
		inputParams.put(APIConstant._START_RECEIVE_DT, _startReceiveDt);
		inputParams.put(APIConstant._END_RECEIVE_DT, _endReceiveDt);
		
		inputParams.put(APIConstant._START_SEND_BANK_DT, _startSendBankDt);
		inputParams.put(APIConstant._END_SEND_BANK_DT, _endSendBankDt);
		
		inputParams.put(APIConstant._START_BANK_RESULT_DT, _startBankResultDt);
		inputParams.put(APIConstant._END_BANK_RESULT_DT, _endBankResultDt);
		
		File item = getProcessManagerService().getAdApiService().exportRegisterAutoDebitTrx(inputParams);
		
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_004"));
		}
		return triggerSuccessResponseFile(item);
	}
	
	@RequestMapping(value = "shinhan/service/autodebit/registrx/sms", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public String getRegisterTrxAutoListBySendSms(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			
			@RequestParam(required = false, defaultValue = "" ) String _loanNo,
			@RequestParam(required = false, defaultValue = "" ) String _branch,
			@RequestParam(required = false, defaultValue = "" ) String _roUser,
			@RequestParam(required = false, defaultValue = "" ) String _bank,
			
			@RequestParam(required = true) String _firstDueDt,
			@RequestParam(required = false, defaultValue = "" ) String _isSend,
			
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant._LOAN_NO, _loanNo);
		inputParams.put(APIConstant._BRANCH, _branch);
		inputParams.put(APIConstant._RO_USER, _roUser);
		inputParams.put(APIConstant._BANK, _bank);
		
		inputParams.put(APIConstant._FIRST_DUEDT, _firstDueDt);
		inputParams.put(APIConstant._IS_SEND, StringUtils.isBlank(_isSend) ? APIConstant.ALL : _isSend);
		
		List<AutoDebitTrxInfo> lst = getProcessManagerService().getAdApiService().getListRegisterAutoDebitTrxBySMS(inputParams);
		BigDecimal countTotal = getProcessManagerService().getAdApiService().countTotalRegisterAutoDebitTrxBySMS(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
		
	}
	
	@RequestMapping(value = "shinhan/service/autodebit/registrx/sms/export", produces = {"application/pdf"}, method = RequestMethod.POST)
	public ResponseEntity<Object> exportRegisterTrxAutoList(
			@RequestParam(required = false, defaultValue = "" ) String _loanNo,
			@RequestParam(required = false, defaultValue = "" ) String _branch,
			@RequestParam(required = false, defaultValue = "" ) String _roUser,
			@RequestParam(required = false, defaultValue = "" ) String _bank,
			
			@RequestParam(required = true) String _firstDueDt,
			@RequestParam(required = false, defaultValue = "" ) String _isSend,
			
			Locale locale) throws BaseException, FileNotFoundException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		inputParams.put(APIConstant._LOAN_NO, _loanNo);
		inputParams.put(APIConstant._BRANCH, _branch);
		inputParams.put(APIConstant._RO_USER, _roUser);
		inputParams.put(APIConstant._BANK, _bank);
		
		inputParams.put(APIConstant._FIRST_DUEDT, _firstDueDt);
		inputParams.put(APIConstant._IS_SEND, StringUtils.isBlank(_isSend) ? APIConstant.ALL : _isSend);
		
		File item = getProcessManagerService().getAdApiService().exportRegisterAutoDebitTrxBySMS(inputParams);
		
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_004"));
		}
		return triggerSuccessResponseFile(item);
	}
	
	/** Step 1 to Step 2 */
	@RequestMapping(value = "shinhan/service/autodebit/importregistrx", produces = MediaType.MULTIPART_FORM_DATA_VALUE, method = RequestMethod.POST)
	public String regisAutodebitTransaction(@RequestParam(required = false, name = APIConstant.FILE_UPLOAD) MultipartFile fileUpload, Locale locale) throws BaseException{
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.FILE_UPLOAD, fileUpload);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		List<AutoDebitRegisTrxInfo> lst = getProcessManagerService().getAdApiService().importAutoDebitTrx(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	
	/** Step 1 to Step 5 */
	@RequestMapping(value = "shinhan/service/autodebit/updatebankresult", produces = MediaType.MULTIPART_FORM_DATA_VALUE, method = RequestMethod.POST)
	public String updateToBankResultSuccess(@RequestParam(required = false, name = APIConstant.FILE_UPLOAD) MultipartFile fileUpload, Locale locale) throws BaseException{
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.FILE_UPLOAD, fileUpload);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		List<AutoDebitRegisBankResultTrxInfo> lst = getProcessManagerService().getAdApiService().updateToBankResultSuccessByUpload(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	
	@RequestMapping(value = "shinhan/service/autodebit/updatebankresult", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.PATCH)
	public String updateToBankResultSuccess(@RequestBody String document, Locale locale) throws BaseException{
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		List<AutoDebitTrxInfo> lst = getProcessManagerService().getAdApiService().updateToBankResultSuccess(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	
	/** Step 2 to Step 3 */
	@RequestMapping(value = "shinhan/service/autodebit/importhardcopy", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.POST)
	public String importHardCopyTransaction(@RequestBody String document, Locale locale) throws BaseException{
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		List<AutoDebitTrxInfo> lst = getProcessManagerService().getAdApiService().importHardCopyTransaction(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	
	/** Step 3 to Step 4 
	 * @throws FileNotFoundException */
	@RequestMapping(value = "shinhan/service/autodebit/exportbankdata", produces = {"application/pdf"}, method = RequestMethod.POST)
	public ResponseEntity<Object> exportAutoDebitByBank(@RequestBody String document, @RequestParam(required = false, defaultValue = "") String _bank, Locale locale) throws BaseException, FileNotFoundException{
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant._BANK, _bank);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		File item = getProcessManagerService().getAdApiService().exportAutoDebitByBank(inputParams);
		
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_004"));
		}
		
		return triggerSuccessResponseFile(item);
	}
	
	/** Step 4 to Step 5 */
	@RequestMapping(value = "shinhan/service/autodebit/importbankresult", produces = MediaType.MULTIPART_FORM_DATA_VALUE, method = RequestMethod.POST)
	public String importBankResultTransaction(@RequestParam(required = false, name = APIConstant.FILE_UPLOAD) MultipartFile fileUpload, Locale locale) throws BaseException{
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.FILE_UPLOAD, fileUpload);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		List<AutoDebitRegisBankResultTrxInfo> lst = getProcessManagerService().getAdApiService().importAutoDebitBankResultTrx(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	
	/** Step 5 */
	@RequestMapping(value = "shinhan/service/autodebit/updatefailreason", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.PATCH)
	public String updateFailReasonADTransaction(@RequestBody String document, Locale locale) throws BaseException{
		
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		List<AutoDebitTrxInfo> lst = getProcessManagerService().getAdApiService().updateFailReasonADTransaction(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	
	/** Sending SMS */
	@RequestMapping(value = "shinhan/service/autodebit/unregistrx/sendsms", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.POST)
	public String sendSmsForUnRegisADTrx(@RequestBody String document, Locale locale) throws BaseException{
		
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		List<AutoDebitTrxInfo> lst = getProcessManagerService().getAdApiService().sendSmsForUnRegisADTrx(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	
	@RequestMapping(value = "shinhan/service/autodebit/registrx/sendsms", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.POST)
	public String sendSmsForRegisADTrx(@RequestBody String document, @RequestParam(required = true, defaultValue = "" ) String _statusMap, Locale locale) throws BaseException{
		
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant._STATUS_AD_MAP, _statusMap);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		List<AutoDebitTrxInfo> lst = getProcessManagerService().getAdApiService().sendSmsForRegisADTrx(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	
	/** Exporting Report*/
	@RequestMapping(value = "shinhan/service/autodebit/exportreport", produces = {"application/pdf"}, method = RequestMethod.POST)
	public ResponseEntity<Object> exportReportByTemplate(@RequestBody String document,
			@RequestParam(required = false, defaultValue = "" ) String _templateName,
			@RequestParam(required = false, defaultValue = "" ) String _startDt,
			@RequestParam(required = false, defaultValue = "" ) String _endDt,
			
			Locale locale) throws BaseException, FileNotFoundException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._TEMPLATE_NAME, _templateName);
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		
		File item = getProcessManagerService().getAdApiService().exportReportByTemplate(inputParams);
		
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_004"));
		}
		return triggerSuccessResponseFile(item);
	}
}
