/**
 * 
 */
package com.shinhan.autodebit.core.model;

/**
 * @author shds01
 *
 */
public class CommunicationSystemSendSMSTemplateData {

	private String agreement_no;
	private String first_duedate;

	/**
	 * 
	 */
	public CommunicationSystemSendSMSTemplateData() {
		super();
	}

	/**
	 * @param agreement_no
	 */
	public CommunicationSystemSendSMSTemplateData(String agreement_no) {
		super();
		this.agreement_no = agreement_no;
	}

	/**
	 * @param agreement_no
	 * @param first_duedate
	 */
	public CommunicationSystemSendSMSTemplateData(String agreement_no, String first_duedate) {
		super();
		this.agreement_no = agreement_no;
		this.first_duedate = first_duedate;
	}

	/**
	 * @return the agreement_no
	 */
	public String getAgreement_no() {
		return agreement_no;
	}

	/**
	 * @param agreement_no the agreement_no to set
	 */
	public void setAgreement_no(String agreement_no) {
		this.agreement_no = agreement_no;
	}

	/**
	 * @return the first_duedate
	 */
	public String getFirst_duedate() {
		return first_duedate;
	}

	/**
	 * @param first_duedate the first_duedate to set
	 */
	public void setFirst_duedate(String first_duedate) {
		this.first_duedate = first_duedate;
	}

}
