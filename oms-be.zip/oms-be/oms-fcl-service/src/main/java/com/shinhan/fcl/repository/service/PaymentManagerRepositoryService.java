/**
 * 
 */
package com.shinhan.fcl.repository.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.repository.entity.TOmsFCLPaymentInf;

/**
 * @author shds01
 *
 */
public interface PaymentManagerRepositoryService {
	
	public List<EarlyTerminationTrx> getListPaymentAvailable(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countPaymentAvailableTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public TOmsFCLPaymentInf getTrxByLoanNo(String loanNo) throws ServiceRuntimeException;
	
	public boolean createAll(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<Object[]> exportReportPaymentTrx(String startDt, String endDt) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
}
