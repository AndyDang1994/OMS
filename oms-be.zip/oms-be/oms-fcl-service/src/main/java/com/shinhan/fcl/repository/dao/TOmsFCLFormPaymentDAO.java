/**
 * 
 */
package com.shinhan.fcl.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.shinhan.fcl.repository.entity.TOmsFCLFormPaymentInf;

/**
 * @author shds01
 *
 */
@Repository
public interface TOmsFCLFormPaymentDAO extends JpaRepository<TOmsFCLFormPaymentInf, String> {

	@Query("SELECT item FROM TOmsFCLFormPaymentInf item WHERE LOWER(item.loan_no) = LOWER(:loanNo)")
	public TOmsFCLFormPaymentInf getItemByLoanNo(@Param("loanNo") String loanNo);
}
