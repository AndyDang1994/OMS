/**
 * 
 */
package com.shinhan.fcl.repository.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.repository.entity.TOmsFCLFollowEMIInf;

/**
 * @author shds01
 *
 */
public interface FollowUpManagerRepositoryService {
	
	public List<EarlyTerminationTrx> getListFollowUpEMI(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countFollowUpEMITrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public TOmsFCLFollowEMIInf getFollowUpEMITrxById(long id) throws ServiceRuntimeException;
	
	public boolean createAll(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<Object[]> exportReportFollowupEMITrx(String startDt, String endDt) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
}
