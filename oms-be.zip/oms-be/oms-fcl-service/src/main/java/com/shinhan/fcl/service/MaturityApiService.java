/**
 * 
 */
package com.shinhan.fcl.service;

import java.io.File;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;

/**
 * @author shds01
 *
 */
public interface MaturityApiService {
	
	public List<EarlyTerminationTrx> getListMaturityWaiveOff(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countMaturityWaiveOffTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<EarlyTerminationTrx> executeWaiveMaturityWaiveOff(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public File exportReportForMaturityWaiveOff(Map<String, Object> inputParams) throws BaseException;
	
	public List<EarlyTerminationTrx> getListMaturityBookInc(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countMaturityBookIncTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<EarlyTerminationTrx> getListMaturityBookIncDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countMaturityBookIncDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<EarlyTerminationTrx> executeDoneMaturityBookInc(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<EarlyTerminationTrx> getListMaturityRefund(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countMaturityRefundTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<EarlyTerminationTrx> getListMaturityRefundDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countMaturityRefundDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<EarlyTerminationTrx> executeDoneMaturityRefund(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public File exportReportForMaturityRefund(Map<String, Object> inputParams) throws BaseException;
}
