/**
 * 
 */
package com.shinhan.fcl.repository.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.fcl.common.AbstractServiceClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.util.DateUtils;
import com.shinhan.fcl.repository.dao.TOmsFCLTBDAO;
import com.shinhan.fcl.repository.dao.TOmsFCLTBMasDAO;
import com.shinhan.fcl.repository.entity.TOmsFCLTBInf;
import com.shinhan.fcl.repository.entity.TOmsFCLTBMas;
import com.shinhan.fcl.repository.service.TBManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("tbManagerRepositoryService")
public class TBManagerRepositoryServiceImpl extends AbstractServiceClass
		implements TBManagerRepositoryService {

	@Autowired
	private TOmsFCLTBDAO objectTBInfDao;
	
	@Autowired
	private TOmsFCLTBMasDAO objectTBMasDao;

	
	public TBManagerRepositoryServiceImpl(TOmsFCLTBDAO objectTBInfDao, TOmsFCLTBMasDAO objectTBMasDao) {
		this.objectTBInfDao = objectTBInfDao;
		this.objectTBMasDao = objectTBMasDao;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormManagerRepositoryService#getListTB(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListTB(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		try {
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			String sql = "SELECT new com.shinhan.fcl.core.model.EarlyTerminationTrx("
					
					+ "inf.loan_no, mas.cif, mas.customer_name, "
					+ "mas.principal_bal, mas.total_to_pay, mas.total_payment_received, "
					+ "mas.interest_amount, mas.last_change_amount, mas.overdue_fee, "
					+ "mas.total_waiveoff_amount, mas.term_status, mas.last_due_date, mas.waive_off_status, "
					+ "inf.effective_dt as effective_dt, inf.status_code as statusCode, inf.remarks "
					
					+ ") "
					+ "from TOmsFCLTBInf inf left join TOmsFCLTBMas mas on inf.loan_no = mas.loan_no "
					+ "where to_date(to_char(inf.createdDt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') between :fromDt and :endDt "
					+ "and (mas.loan_status is NULL or mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"') "
					+ "and (:loanNo is NULL or inf.loan_no = :loanNo) "
					+ "and (:loanNo is NULL or inf.loan_no = :loanNo) "
					+ "and (:cifNo is NULL or mas.cif is NULL or mas.cif = :cifNo) "
					
					+ "and EXISTS (select t.loan_no from TOmsFCLTBInf t where inf.loan_no = t.loan_no "
									+ "and (t.status_code is NULL or t.status_code != '"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE+"') ) "
					+ "and NOT EXISTS ("
						+ "select inf.loan_no "
						+ "from TOmsFCLTBInf sub where sub.status_code = '"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_REMOVE_VALUE+"' and sub.effective_dt is not null and inf.loan_no = sub.loan_no "
						+ "and to_date(:current_date,'"+DateUtils.DATEFORMAT+"') - to_date(to_char(sub.effective_dt, '"+DateUtils.DATEFORMAT+"'), '"+DateUtils.DATEFORMAT+"') < 32 "
					+ ")"
					
					;
			
			String orderBy = " order by inf.createdDt, mas.term_status, mas.principal_bal, inf.loan_no ";
			
			Query query = entityManager.createQuery(sql + orderBy);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			
			query.setParameter("current_date", DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			@SuppressWarnings("unchecked")
			List<EarlyTerminationTrx> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormManagerRepositoryService#countTBTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countTBTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			String sql = "select count(inf.loan_no) "
						+ "from oms_fcl_tb_inf inf left join oms_fcl_tb_mas mas on inf.loan_no = mas.loan_no "
						+ "where to_date(to_char(inf.regis_inf_dt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') between :fromDt and :endDt "
						+ "and (mas.loan_status is NULL or mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"') "
						+ "and (:loanNo is NULL or inf.loan_no = :loanNo) "
						+ "and (:cifNo is NULL or mas.cif is NULL or mas.cif = :cifNo) "
						
						+ "and EXISTS (select t1.loan_no from oms_fcl_tb_inf t1 where t1.loan_no = inf.loan_no "
										+ "and (t1.status_code is NULL or t1.status_code != '"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE+"')) "
						+ "and NOT EXISTS ("
							+ "select inf.loan_no "
							+ "from oms_fcl_tb_inf sub where sub.status_code = '"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_REMOVE_VALUE+"' and sub.effective_dt is not null and inf.loan_no = sub.loan_no "
							+ "and to_date(:current_date,'"+DateUtils.DATEFORMAT+"') - to_date(to_char(sub.effective_dt, '"+DateUtils.DATEFORMAT+"'), '"+DateUtils.DATEFORMAT+"') < 32 "
						+ ")"
						;
			
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			
			query.setParameter("current_date", DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.TBManagerRepositoryService#getListTBDoneTrx(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListTBDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			String sql = "SELECT new com.shinhan.fcl.core.model.EarlyTerminationTrx("
					
					+ "inf.loan_no, mas.cif, mas.customer_name, "
					+ "mas.principal_bal, mas.total_to_pay, mas.total_payment_received, "
					+ "mas.interest_amount, mas.last_change_amount, mas.overdue_fee, "
					+ "mas.total_waiveoff_amount, mas.term_status, mas.last_due_date, mas.waive_off_status, "
					+ "inf.effective_dt as effective_dt, inf.status_code as statusCode, inf.remarks, inf.updatedUser "
					
					+ ") "
					+ "from TOmsFCLTBInf inf, TOmsFCLTBMas mas "
					+ "where mas.loan_no = inf.loan_no "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' "
					+ "and to_date(to_char(inf.effective_dt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') between :fromDt and :endDt "
					+ "and inf.status_code = '"+ APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE +"' "
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:cifNo is NULL or mas.cif = :cifNo) "
					;
			
			String orderBy = " order by inf.effective_dt, mas.term_status, mas.principal_bal, inf.loan_no ";
			
			Query query = entityManager.createQuery(sql + orderBy);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			@SuppressWarnings("unchecked")
			List<EarlyTerminationTrx> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.TBManagerRepositoryService#countTBDoneTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countTBDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			String sql = "select count(*) from oms_fcl_tb_inf inf, oms_fcl_tb_mas mas "
					
					+ "where mas.loan_no = inf.loan_no "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' "
					+ "and to_date(to_char(inf.effective_dt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') between :fromDt and :endDt "
					+ "and inf.status_code = '"+ APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE +"' "
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:cifNo is NULL or mas.cif = :cifNo) "
					;
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.TBManagerRepositoryService#getTrxByLoanNo(java.lang.String)
	 */
	@Override
	public TOmsFCLTBInf getTrxByLoanNo(String loanNo) throws ServiceRuntimeException {
		if (StringUtils.isBlank(loanNo)) {
			return null;
		}
		try {
			return objectTBInfDao.getItemByLoanNo(loanNo);
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + loanNo + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.TBManagerRepositoryService#createAll(java.util.Map)
	 */
	@Override
	public boolean createAll(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			@SuppressWarnings("unchecked")
			List<TOmsFCLTBInf> items = (List<TOmsFCLTBInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectTBInfDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.TBManagerRepositoryService#deleteAll(java.util.List)
	 */
	@Override
	public boolean deleteAll(List<TOmsFCLTBInf> items) throws ServiceRuntimeException {
		try {
			if (CollectionUtils.isNotEmpty(items)) {
				objectTBInfDao.deleteAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}


	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.TBManagerRepositoryService#createAllMas(java.util.List)
	 */
	@Override
	public boolean createAllMas(List<TOmsFCLTBMas> items) throws ServiceRuntimeException {
		try {
			if (CollectionUtils.isNotEmpty(items)) {
				objectTBMasDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.TBManagerRepositoryService#exportReportTBTrx(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Object[]> exportReportTBTrx(String startDt, String endDt)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		try {
			String sql = "SELECT "
					+ "rownum, sub.* from ("
					+ "SELECT "
					+ "to_char(inf.regis_inf_dt, '"+DateUtils.DATEFORMAT+"'), inf.loan_no, "
					+ "mas.customer_name, mas.term_status, mas.waive_off_status, "
					
					+ "to_char(mas.last_due_date, '"+DateUtils.DATEFORMAT+"'), "
					+ "to_char(mas.effective_dt, '"+DateUtils.DATEFORMAT+"'), "
					+ "inf.lchg_inf_user, inf.remarks "
					
					+ "from oms_fcl_tb_inf inf, oms_fcl_tb_mas mas "
					+ "where inf.loan_no = mas.loan_no "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_CLOSE+"' "
					+ "and to_date(to_char(inf.effective_dt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') between :startDt and :endDt "
					+ "and inf.status_code = '"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE+"'"
					;
			
			String orderBy = " order by inf.regis_inf_dt asc, inf.loan_no asc) sub";
			
			Query query = entityManager.createNativeQuery(sql + orderBy);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			List<Object[]> list = query.getResultList();
			if(CollectionUtils.isEmpty(list)) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
			}
			return list;
		} catch (ServiceInvalidAgurmentException ex) {
			throw new ServiceInvalidAgurmentException(ex.getMessage());
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.migrate.repository.service.TBManagerRepositoryService#getListTBTrxScanning()
	 */
	@Override
	public List<TOmsFCLTBInf> getListTBTrxScanning() throws ServiceRuntimeException {
		try {
			String sql ="SELECT item FROM TOmsFCLTBInf item "
					+ "WHERE LOWER(item.status_code) = LOWER('"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_INITIAL_VALUE+"') "
						+ "order by item.effective_dt asc, item.loan_no asc";
			
			Query query = entityManager.createQuery(sql, TOmsFCLTBInf.class);
			query.setMaxResults(Integer.valueOf(env.getProperty(APIConstant.LIMIT_NUMBER_TRX_JOB)));
			
			return query.getResultList();
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			return null;
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.TBManagerRepositoryService#getListTBTrxScanningNotFound()
	 */
	@Override
	public List<TOmsFCLTBInf> getListTBTrxScanningNotFound() throws ServiceRuntimeException {
		try {
			String sql ="SELECT item FROM TOmsFCLTBInf item "
					+ "WHERE LOWER(item.status_code) = LOWER('"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_NOT_FOUND_VALUE+"') "
							+ "and to_date(to_char(item.effective_dt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') < to_date(:current_date,'"+DateUtils.DATEFORMAT+"') "
						+ "order by item.effective_dt asc, item.loan_no asc";
			
			Query query = entityManager.createQuery(sql, TOmsFCLTBInf.class);
			
			query.setParameter("current_date", DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
			query.setMaxResults(Integer.valueOf(env.getProperty(APIConstant.LIMIT_NUMBER_TRX_JOB)));
			
			return query.getResultList();
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.TBManagerRepositoryService#getListTBTrxScanningNotFoundForRemove()
	 */
	@Override
	public List<TOmsFCLTBInf> getListTBTrxScanningNotFoundForRemove() throws ServiceRuntimeException {
		try {
			String sql ="SELECT item FROM TOmsFCLTBInf item "
					+ "WHERE LOWER(item.status_code) = LOWER('"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_NOT_FOUND_VALUE+"') "
							+ "and to_date(to_char(item.effective_dt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') <= to_date(:current_date,'"+DateUtils.DATEFORMAT+"') "
						+ "order by item.effective_dt asc, item.loan_no asc";
			
			Query query = entityManager.createQuery(sql, TOmsFCLTBInf.class);
			
			query.setParameter("current_date", DateUtils.formatDate(DateUtils.getBefore7DayDate(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT));
			query.setMaxResults(Integer.valueOf(env.getProperty(APIConstant.LIMIT_NUMBER_TRX_JOB)));
			
			return query.getResultList();
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			return null;
		}
	
	}

}
