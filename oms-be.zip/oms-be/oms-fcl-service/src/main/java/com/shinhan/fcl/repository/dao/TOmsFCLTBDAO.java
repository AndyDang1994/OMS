/**
 * 
 */
package com.shinhan.fcl.repository.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.repository.entity.TOmsFCLTBInf;

/**
 * @author shds01
 *
 */
@Repository
public interface TOmsFCLTBDAO extends JpaRepository<TOmsFCLTBInf, String> {

	@Query("SELECT item FROM TOmsFCLTBInf item WHERE LOWER(item.loan_no) = LOWER(:loanNo)")
	public TOmsFCLTBInf getItemByLoanNo(@Param("loanNo") String loanNo);
	
	@Query("SELECT item FROM TOmsFCLTBInf item WHERE LOWER(item.status_code) = LOWER('"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_INITIAL_VALUE+"') order by item.createdUser, item.loan_no")
	public List<TOmsFCLTBInf> getItemToScanning();
}
