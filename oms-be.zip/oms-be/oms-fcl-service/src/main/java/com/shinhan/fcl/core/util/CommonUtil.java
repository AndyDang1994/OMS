/**
 * 
 */
package com.shinhan.fcl.core.util;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.Normalizer;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;
import org.xmlpull.mxp1.MXParser;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.exception.UnauthorizedException;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.io.copy.HierarchicalStreamCopier;
import com.thoughtworks.xstream.io.json.JettisonMappedXmlDriver;
import com.thoughtworks.xstream.io.xml.XppReader;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SignatureException;

/**
 * @author shds01
 *
 */
public class CommonUtil {
	public static final String INPUT = "input";
	public static final String INVALID_INPUT = "input-invalid";
	public static final String INPUT2 = "input2";
	public static final String INVALID_INPUT2 = "input2-invalid";
	public static final String RESULTS = "results";
	public static final String VALID = "valid";

	protected static final Logger logger = LoggerFactory.getLogger(CommonUtil.class);
	public static Gson gson = new GsonBuilder().serializeNulls().setDateFormat("dd/MM/yyyy").setPrettyPrinting().create();
	public static ObjectMapper objectMapper = new ObjectMapper();
	private static Map<String, String> countWaiveOffMap = new HashMap<>();
	
	
	@Autowired
	private transient static Environment env;
	
	private static RestTemplate restTemplate;

	public static void main(String[] args) {
		//resetCountWaiveOffMap();
		generateCountWaiveOffMap("000");
		String password = "123456";
		String encrytedPassword = encrytePassword(password);

		System.out.println("Encryted Password: " + encrytedPassword);
		BigDecimal b = new BigDecimal("20.23131231");
		writeDecimal(b.doubleValue(), 0);
	}

	public static void resetCountWaiveOffMap(){
		countWaiveOffMap = new HashMap<>();
		countWaiveOffMap.put(DateUtils.getSystemDateStr(DateUtils.ddMMyyyy), "0");
	}
	
	public static String generateCountWaiveOffMap(String format){
		String number = "";
		String key = DateUtils.getSystemDateStr(DateUtils.ddMMyyyy);
		if(countWaiveOffMap == null || countWaiveOffMap.containsKey(key) == false) {
			countWaiveOffMap.put(key, "0");
			return "001";
		}
		try {
			String index = countWaiveOffMap.get(key);
			int i = Integer.valueOf(index);
			i++;
			if(i > 100) {
				i = 1;
			}
			index = String.valueOf(i);
			
			number = format.substring(0, format.length() - index.length()) + index;
			countWaiveOffMap = new HashMap<>();
			countWaiveOffMap.put(key, String.valueOf(i));
			return number;
		}
		catch(Exception ex) {
			ex.printStackTrace();
			countWaiveOffMap = new HashMap<>();
			countWaiveOffMap.put(key, "0");
			return "001";
		}
	}
	
	public static String encrytePassword(String password) {
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		return encoder.encode(password);
	}
	
	public static boolean decrytePassword(String password, String encrytedPassword) {
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		return encoder.matches(password, encrytedPassword);
	}
	
	public static String base64UrlDecode(String input) {
		String result = null;
		byte[] decodedBytes = Base64.getDecoder().decode(input);
		result = new String(decodedBytes);
		return result;
	}

	public static Map<String, Object> putParamInMap(Map<String, Object> inputParams, String key, Object value) {
		if (inputParams.containsKey(key)) {
			inputParams.remove(key);
		}
		inputParams.put(key, value);
		return inputParams;
	}

	public static List<String> importParamIntoList(String param) {
		List<String> paramList = null;
		if (StringUtils.isNotEmpty(param)) {
			paramList = new ArrayList<>();
			if (param.contains(",")) {
				String[] arr = param.split(",");
				if (arr.length > 0) {
					for (String string : arr) {
						if (StringUtils.isNotEmpty(string)) {
							paramList.add(string);
						}
					}
				}
			} else {
				paramList.add(param);
			}
		}
		return paramList;
	}
	
	public static String toJsonValueAsString(final Object object) throws ServiceRuntimeException {
		try {
			return objectMapper.writeValueAsString(object);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_004"), e.getCause());
		}
	}

	public static String toJson(final Object object) throws ServiceRuntimeException {
		try {
			return gson.toJson(object);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_004"), e.getCause());
		}
	}

	public static Object toPojo(final String jsonString, final Class<?> clazz) throws ServiceRuntimeException {
		try {
			return gson.fromJson(jsonString, clazz);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_004"), e.getCause());
		}
	}
	
	public static <T> T jsonToPojo(final String jsonString, final Class<T> clazz) throws ServiceRuntimeException {
		try {
			return gson.fromJson(jsonString, clazz);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_004"), e.getCause());
		}
	}

	public static <T> List<T> toListPojo(final String jsonArray, final Class<T> clazz) throws ServiceRuntimeException {
		try {
			return gson.fromJson(jsonArray, TypeToken.getParameterized(List.class, clazz).getType());
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_004"), e.getCause());
		}
	}
	
	public static <T> List<T> toListPojo(final Object objectArray, final Class<T> clazz) throws ServiceRuntimeException {
		try {
			return gson.fromJson(toJson(objectArray), TypeToken.getParameterized(List.class, clazz).getType());
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_004"), e.getCause());
		}
	}

	/**
	 * Should use #clonePojo()(Meaningful and easier to understand) instead of this
	 * one
	 * 
	 * @param json
	 * @param clazz
	 * @return Object
	 * @throws ServiceRuntimeException
	 */
	public static Object toPojo(final Object json, final Class<?> clazz) throws ServiceRuntimeException {
		try {
			return gson.fromJson(toJson(json), clazz);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_004"), e.getCause());
		}
	}

	/**
	 * This util use json to do a deep clone of an object With other object
	 * different than entity(prevent hibernate automatic persist that instante?) or
	 * just want an shallow clone should implement interface Cloneable instead of
	 * using this one
	 * 
	 * @param objectToClone
	 * @return the cloned object
	 * @throws ServiceRuntimeException
	 */
	@SuppressWarnings("unchecked")
	public static <T> T clonePojo(final T objectToClone) throws ServiceRuntimeException {
		try {
			return (T) gson.fromJson(toJson(objectToClone), objectToClone.getClass());
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_004"), e.getCause());
		}
	}

	public static String readFile(String url){
		try {
			Path path = Paths.get(url);
			BufferedReader reader = Files.newBufferedReader(path);
			String line = reader.readLine();
			
			return line;
		}
		catch(Exception ex) {
			return null;
		}
		
	}
	
	public static boolean saveFile(InputStream inputStream, String fileName, String filePath)
			throws ServiceRuntimeException {
		boolean isFile = false;
		OutputStream outputStream = null;
		try {
			File files = new File(filePath);
			if (!files.exists()) {
				if (!files.mkdirs())
					;
			}
			String fileNameToCreate = (filePath + fileName);
			File fileSave = new File(fileNameToCreate);
			outputStream = new FileOutputStream(fileSave);
			int read = 0;
			byte[] bytes = new byte[1024];

			while ((read = inputStream.read(bytes)) != -1) {
				outputStream.write(bytes, 0, read);
			}

			isFile = true;
			outputStream.close();
			logger.info("Save file : " + isFile + " " + fileNameToCreate);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_004"), e.getCause());
		}
		return isFile;
	}
	
	public static boolean convertBase64ToFile(String raw, String fileName, String filePath)
			throws ServiceRuntimeException {
		boolean isFile = false;
		try {
			File files = new File(filePath);
			if (!files.exists()) {
				if (!files.mkdirs())
					;
			}
			String fileNameToCreate = (filePath + fileName);
			File fileSave = new File(fileNameToCreate);
			
			byte[] decodedBytes = Base64.getDecoder().decode(raw);
			FileUtils.writeByteArrayToFile(fileSave, decodedBytes);
			isFile = true;
			logger.info("Save file : " + isFile + " " + fileNameToCreate);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_004"), e.getCause());
		}
		return isFile;
	}
	
	public static String forPercentages(double value, Locale locale) {
		NumberFormat nf = NumberFormat.getPercentInstance(locale);
		nf.setMinimumFractionDigits(2);
		return nf.format(value);
	}

	public static String formatNumberfromView(String input) {
		return input.replaceAll("\\,", "").replaceAll("\\.", "");
	}

	/**
	 * Format a double to the given pattern and the symbols
	 * 
	 * @param number
	 * @param str
	 * @return the number formatted
	 */
	public static String formatDecimal(double number, String str) {
		Locale local = new Locale("vi", "VN");
		DecimalFormat df = new DecimalFormat(str, new DecimalFormatSymbols(local));
		return df.format(number);
	}

	public static String writeDecimal(double number, int frac) {
		if (number == 0.00)
			return "-";
		switch (frac) {
		case 0:
			return formatDecimal(number, "#,###");
		case 1:
			return formatDecimal(number, "#,##0.0");
		case 2:
			return formatDecimal(number, "#,###.#");
		case 3:
			return formatDecimal(number, "#,##0.000");
		case 5:
			return formatDecimal(number, "#,##0.00000");
		case 7:
			return formatDecimal(number, "#,###.0");
		case 8:
			return formatDecimal(number, "#,000");
		case 9:
			return formatDecimal(number, "#,##0.00");
		default:
			return formatDecimal(number, "#,###");
		}
	}

	public static String writeDecimalFor0(double number, int frac) {
		if (number == 0.00)
			return "0";
		switch (frac) {
		case 0:
			return formatDecimal(number, "#,###");
		case 1:
			return formatDecimal(number, "#,##0.0");
		case 2:
			return formatDecimal(number, "#,###.#");
		case 3:
			return formatDecimal(number, "#,##0.000");
		case 5:
			return formatDecimal(number, "#,##0.00000");
		case 7:
			return formatDecimal(number, "#,###.0");
		case 8:
			return formatDecimal(number, "#,000");
		case 9:
			return formatDecimal(number, "#,##0.00");
		default:
			return formatDecimal(number, "#,###");
		}
	}

	public static BigDecimal round(BigDecimal val, int scale) {
		BigDecimal ret = new BigDecimal(0);
		ret = val.setScale(scale, BigDecimal.ROUND_HALF_UP);
		return ret;
	}

	public static BigDecimal roundUP(BigDecimal val, int scale) {
		BigDecimal ret = new BigDecimal(0);
		ret = val.setScale(scale, BigDecimal.ROUND_UP);
		return ret;
	}

	public static String escapeString(String text) {
		if (StringUtils.isBlank(text)) {
			return "";
		}
		text = text.replaceAll("'", "");
		text = text.replaceAll("-", "");
		text = text.replaceAll("\"", "");
		return text;
	}

	public static String getCryptUser(Environment env, String userName) {
		try {
			JsonObject json = new JsonObject();
			json.addProperty(APIConstant.USERNAME_KEY, userName);
			json.addProperty(APIConstant.EXPIRY_DATE, APIConstant.YES_KEY);
			json.addProperty(APIConstant.ACCESS_TIME, System.currentTimeMillis());
			
			String compactJws = Jwts.builder().setPayload(gson.toJson(json))
					.signWith(SignatureAlgorithm.HS256, env.getProperty(APIConstant.PUBLIC_KEY).trim()).compact();
			logger.info("compactJws : " + compactJws);
			return compactJws;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	public static String checkSecureTheToken(Environment env, String access_token)
			throws UnauthorizedException, ServiceRuntimeException {

		logger.info(APIConstant.ACCESS_TOKEN_KEY + " : " + access_token);

		if (StringUtils.isBlank(access_token)) {
			throw new UnauthorizedException(APIConstant.THE_TOKEN_IS_BLANK_ERROR);
		}
		// Check the token is valid or not.
		String keyStr = env.getProperty(APIConstant.PUBLIC_KEY).trim();
		String bodyPayload = "";
		try {
			// OK, we can trust this JWT
			Jws<Claims> jwsClaims = Jwts.parser().setSigningKey(keyStr).parseClaimsJws(access_token);
			if (jwsClaims == null) {
				throw new UnauthorizedException(APIConstant.THE_TOKEN_IS_INVALID_ERROR);
			}
			String[] listStr = StringUtils.split(access_token, ".");
			bodyPayload = CommonUtil.base64UrlDecode(listStr[1]);
			String signature = listStr[2];
			String compactJws = Jwts.builder().setPayload(bodyPayload).signWith(SignatureAlgorithm.HS256, keyStr)
					.compact();
			if (!StringUtils.contains(compactJws, signature)) {
				throw new UnauthorizedException(APIConstant.THE_TOKEN_IS_INVALID_ERROR);
			}
		} catch (SignatureException e) {
			// don't trust the JWT!
			logger.info(e.getMessage());
			throw new UnauthorizedException(APIConstant.THE_TOKEN_IS_INVALID_ERROR);
		} catch (Exception e) {
			logger.info(e.getMessage());
			throw new UnauthorizedException(APIConstant.THE_TOKEN_IS_INCORRECT_FORMAT_ERROR);
		}
		logger.info("bodyPayload : " + bodyPayload);
		if (StringUtils.isBlank(bodyPayload)) {
			throw new UnauthorizedException(APIConstant.THE_TOKEN_IS_INCORRECT_FORMAT_ERROR);
		}

		return bodyPayload;
	}

	public static void copyFile(File input, File output) throws IOException {
		FileUtils.copyFile(input, output);
		logger.info("Copy file " + input.getName() + " from " + input.getPath());
		logger.info("To file " + output.getName() + " from " + output.getPath());
	}
	
	public static void cleanFileInFolder(String filePath) throws IOException {
		try {
			File file = new File(filePath);
			if (file.exists()) {
				if(file.isDirectory()) {
					FileUtils.cleanDirectory(file);
					logger.info("Clean Folder : " + file + " Is Done");
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}

	public static String toUpperCase(String input) {
		return StringUtils.isNotBlank(input) ? input.toUpperCase() : "";
	}

	public static String toLowerCase(String input) {
		return StringUtils.isNotBlank(input) ? input.toLowerCase() : "";
	}

	public static String getKeyBarcode(String userName) {
		String now = DateUtils.simpleDateFormat.format(new Date());
		/** String keyXML = now+last 3 characters of userName; **/
		StringBuilder sb = new StringBuilder();
		String keyBar = sb.append(now).append(userName.substring(userName.length() - 3, userName.length())).toString();
		return keyBar;
	}

	public static <T> T trimAllStringProperty(T object) throws ServiceRuntimeException {
		if (object == null)
			return null;
		for (Field field : object.getClass().getDeclaredFields()) {
			try {
				field.setAccessible(true);
				Object value = field.get(object);
				if (value instanceof String) {
					field.set(object, ((String) value).trim());
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new ServiceRuntimeException(env.getProperty("MSG_004"), e.getCause());
			}
		}
		return object;
	}

	public static String getLogMessenge(Exception e) {
		String error = null;
		try {
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			error = sw.toString();
		} catch (Exception e2) {
			e2.printStackTrace();
			return e.getMessage();
		}
		return error;
	}

	/**
	 * This function help set a value into a field of an object Support multiple
	 * level on an Object (separate by an ".") Important note: - if a field is a
	 * List if will add value inside that List if the type is match - it also check
	 * the super class, mean if the class extend another class it is automatically
	 * cared - swallow exception so best practice is check the boolean response
	 * 
	 * @param object
	 * @param fieldName
	 * @param fieldValue
	 * @return boolean
	 */
	public static <T, V> Boolean setPropertyIntoObject(T object, V fieldValue, String fieldName) {
		return setPropertyIntoObjectHandler(object, fieldValue, fieldName.split("\\."));
	}

	private static <T, V> Boolean setPropertyIntoObjectHandler(T object, V fieldValue, String... fieldName) {
		if (object == null || fieldValue == null || ArrayUtils.isEmpty(fieldName)) {
			return false;
		}
		if (fieldName.length == 1) {
			return setPropertyIntoObjectHandler(object, fieldValue, fieldName[0]);
		} else {
			try {
				Field field = getField(object, fieldName[0]);
				if (field == null)
					return false;
				Object subObject = Optional.ofNullable(field.get(object))
						.orElse(Class.forName(field.getType().getName()).newInstance());
				boolean isSucess = setPropertyIntoObjectHandler(subObject, fieldValue,
						Arrays.copyOfRange(fieldName, 1, fieldName.length));
				if (isSucess) {
					field.set(object, subObject);
				}
				return isSucess;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private static <T, V> Boolean setPropertyIntoObjectHandler(T object, V fieldValue, String fieldName) {
		if (object == null || fieldValue == null || StringUtils.isBlank(fieldName)) {
			return false;
		}
		try {
			Field field = getField(object, fieldName);
			if (field == null)
				return false;

			if (field.getType().equals(fieldValue.getClass())) {
				field.set(object, fieldValue);
				return true;
			}
			boolean islistWithSameType = field.getType().equals(List.class)
					&& ((Class) ((ParameterizedType) field.getGenericType()).getActualTypeArguments()[0])
							.equals(fieldValue.getClass());
			if (islistWithSameType) {
				List<V> currentValue = Optional.ofNullable((List<V>) field.get(object)).orElse(new ArrayList<>());
				currentValue.add(fieldValue);
				field.set(object, currentValue);
				return true;
			}
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@SuppressWarnings("rawtypes")
	private static <T> Field getField(T object, String fieldName) {
		Class clazz = object.getClass();
		while (clazz != null) {
			try {
				Field field = clazz.getDeclaredField(fieldName);
				field.setAccessible(true);
				return field;
			} catch (NoSuchFieldException e) {
				clazz = clazz.getSuperclass();
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		String message = String.format("Property: \"%s\" not available on %s", fieldName, object.getClass().getName());
		logger.error(message);
		return null;
	}

	@SuppressWarnings("unchecked")
	@SafeVarargs
	public static <T> List<T> joinList(final List<? extends T>... lists) {
		if (lists.length == 1) {
			return (List<T>) Optional.ofNullable(lists[0]).orElse(new ArrayList<>());
		}
		final ArrayList<T> result = new ArrayList<>();
		result.addAll(Optional.ofNullable(lists[0]).orElse(new ArrayList<>()));
		result.addAll(joinList(Arrays.copyOfRange(lists, 1, lists.length)));
		return result;
	}

	/**
	 * This function return only "." and alphanumeric character inside String input
	 * 
	 * @param input
	 * @return
	 */
	public static String removeSpecialCharacter(final String input) {
		return input.replaceAll("[^a-zA-Z0-9.]+", "");
	}

	public static String stripAccents(final CharSequence input) {
		return Normalizer.normalize(input, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
	}

	public static String rename(String stName) {
		if (stName != null) {
			stName = stName.trim();
			for (int i = 0; i < stName.length(); ++i) {
				char c = stName.charAt(i);
				int j = (int) c;
				switch (j) {
				case 224:
				case 225:
				case 7843:
				case 227:
				case 7841:
				case 259:
				case 7857:
				case 7855:
				case 7859:
				case 7861:
				case 7863:
				case 226:
				case 7847:
				case 7845:
				case 7849:
				case 7851:
				case 7853:
				case 97: {
					stName = stName.replace(stName.charAt(i), 'a');
				}
					break;
				case 65:
				case 192:
				case 193:
				case 7842:
				case 195:
				case 7840:
				case 258:
				case 7856:
				case 7854:
				case 7858:
				case 7860:
				case 7862:
				case 194:
				case 7846:
				case 7844:
				case 7848:
				case 7850:
				case 7852: {
					stName = stName.replace(stName.charAt(i), 'A');
				}
					break;
				case 98: {
					stName = stName.replace(stName.charAt(i), 'b');
				}
					break;
				case 66: {
					stName = stName.replace(stName.charAt(i), 'B');
				}
					break;
				case 99: {
					stName = stName.replace(stName.charAt(i), 'c');
				}
					break;
				case 67: {
					stName = stName.replace(stName.charAt(i), 'C');
				}
					break;
				case 273:
				case 100: {
					stName = stName.replace(stName.charAt(i), 'd');
				}
					break;
				case 272:
				case 68: {
					stName = stName.replace(stName.charAt(i), 'D');
				}
					break;
				case 101:
				case 232:
				case 233:
				case 7867:
				case 7869:
				case 7865:
				case 234:
				case 7873:
				case 7871:
				case 7875:
				case 7877:
				case 7879: {
					stName = stName.replace(stName.charAt(i), 'e');
				}
					break;
				case 69:
				case 200:
				case 201:
				case 7866:
				case 7868:
				case 7864:
				case 202:
				case 7872:
				case 7870:
				case 7874:
				case 7876:
				case 7878: {
					stName = stName.replace(stName.charAt(i), 'E');
				}
					break;
				case 102: {
					stName = stName.replace(stName.charAt(i), 'f');
				}
					break;
				case 70: {
					stName = stName.replace(stName.charAt(i), 'F');
				}
					break;
				case 103: {
					stName = stName.replace(stName.charAt(i), 'g');
				}
					break;
				case 71: {
					stName = stName.replace(stName.charAt(i), 'G');
				}
					break;
				case 104: {
					stName = stName.replace(stName.charAt(i), 'h');
				}
					break;
				case 72: {
					stName = stName.replace(stName.charAt(i), 'H');
				}
					break;
				case 105:
				case 236:
				case 237:
				case 7881:
				case 297:
				case 7883: {
					stName = stName.replace(stName.charAt(i), 'i');
				}
					break;
				case 73:
				case 204:
				case 205:
				case 7880:
				case 296:
				case 7882: {
					stName = stName.replace(stName.charAt(i), 'I');
				}
					break;
				case 106: {
					stName = stName.replace(stName.charAt(i), 'j');
				}
					break;
				case 74: {
					stName = stName.replace(stName.charAt(i), 'J');
				}
					break;
				case 107: {
					stName = stName.replace(stName.charAt(i), 'k');
				}
					break;
				case 75: {
					stName = stName.replace(stName.charAt(i), 'K');
				}
					break;
				case 108: {
					stName = stName.replace(stName.charAt(i), 'l');
				}
					break;
				case 76: {
					stName = stName.replace(stName.charAt(i), 'L');
				}
					break;
				case 109: {
					stName = stName.replace(stName.charAt(i), 'm');
				}
					break;
				case 77: {
					stName = stName.replace(stName.charAt(i), 'M');
				}
					break;
				case 110: {
					stName = stName.replace(stName.charAt(i), 'n');
				}
					break;
				case 78: {
					stName = stName.replace(stName.charAt(i), 'N');
				}
					break;
				case 111:
				case 242:
				case 243:
				case 7887:
				case 245:
				case 7885:
				case 244:
				case 7891:
				case 7889:
				case 7893:
				case 7895:
				case 7897:
				case 417:
				case 7901:
				case 7899:
				case 7903:
				case 7905:
				case 7907: {
					stName = stName.replace(stName.charAt(i), 'o');
				}
					break;
				case 79:
				case 210:
				case 211:
				case 7886:
				case 213:
				case 7884:
				case 212:
				case 7890:
				case 7888:
				case 7892:
				case 7894:
				case 7896:
				case 416:
				case 7900:
				case 7898:
				case 7902:
				case 7904:
				case 7906: {
					stName = stName.replace(stName.charAt(i), 'O');
				}
					break;
				case 117:
				case 249:
				case 250:
				case 7911:
				case 361:
				case 7909:
				case 432:
				case 7915:
				case 7913:
				case 7917:
				case 7919:
				case 7921: {
					stName = stName.replace(stName.charAt(i), 'u');
				}
					break;
				case 85:
				case 217:
				case 218:
				case 7910:
				case 360:
				case 7908:
				case 431:
				case 7914:
				case 7912:
				case 7916:
				case 7918:
				case 7920: {
					stName = stName.replace(stName.charAt(i), 'U');
				}
					break;
				case 118: {
					stName = stName.replace(stName.charAt(i), 'v');
				}
					break;
				case 86: {
					stName = stName.replace(stName.charAt(i), 'V');
				}
					break;
				case 119: {
					stName = stName.replace(stName.charAt(i), 'w');
				}
					break;
				case 87: {
					stName = stName.replace(stName.charAt(i), 'W');
				}
					break;
				case 120: {
					stName = stName.replace(stName.charAt(i), 'x');
				}
					break;
				case 88: {
					stName = stName.replace(stName.charAt(i), 'X');
				}
					break;
				case 121:
				case 7923:
				case 253:
				case 7927:
				case 7929:
				case 7925: {
					stName = stName.replace(stName.charAt(i), 'y');
				}
					break;
				case 89:
				case 7922:
				case 221:
				case 7926:
				case 7928:
				case 7924: {
					stName = stName.replace(stName.charAt(i), 'Y');
				}
					break;
				case 122: {
					stName = stName.replace(stName.charAt(i), 'z');
				}
					break;
				case 90: {
					stName = stName.replace(stName.charAt(i), 'Z');
				}
					break;
				default:
					break;
				}
			}

			stName = stName.replace('?', '_');
			stName = stName.replace('.', '_');
			stName = stName.replace('`', '_');
			stName = stName.replace(' ', '_');
			stName = stName.replace(',', '_');
			stName = stName.replace('/', '_');
			stName = stName.replace(':', '_');
			stName = stName.replace('^', '_');
			stName = stName.replace(';', '_');
			stName = stName.replace('\\', '_');
			stName = stName.replace('\'', '_');
		} else {
			stName = "";
		}
		return stName;
	}
	
	/**
	 * input null -> false input empty -> false input not match regex -> false Other
	 * -> true
	 * 
	 * @param regex
	 * @param input
	 * @return
	 */
	public static boolean isMatchWithRegex(final String regex, final String input) {
		if (StringUtils.isBlank(input))
			return false;
		return input.matches(regex);
	}

	public static boolean isNotMatchWithRegex(final String regex, final String input) {
		return !isMatchWithRegex(regex, input);
	}
	
	/** Invoke rest template 
	 * @throws ServiceRuntimeException */
	public static <T> T invokeRestTemplateService(String contextUrl, String httpMethodStr
			, String token, Object body, Class<T> responseType) throws ServiceRuntimeException{
		
		logger.info("***********Start invokeRestTemplateService Raw**********");
		HttpHeaders httpHeaders = new HttpHeaders();
		//Set user profile for HTTPHeader
		if(!StringUtils.isBlank(token)) {
			httpHeaders.set(APIConstant.ACCESS_TOKEN_KEY, token);
		}
		
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		
		T rs = null;
		
		HttpMethod httpMethod = HttpMethod.valueOf(httpMethodStr.toUpperCase());
		
		ResponseEntity<T> response = null;
		HttpStatus statusCode = null;
		long startTime = System.currentTimeMillis();
		logger.info("URL : " + contextUrl);
		logger.info("Token : " + token);
		logger.info("Method: " + httpMethodStr);
		logger.info("Header: " + httpHeaders.toString());
		logger.info("DataSet : " + CommonUtil.toJson(body));
		
		// successful (2xx)
		try{
			if(restTemplate == null){
				restTemplate = new RestTemplate(new HttpComponentsClientHttpRequestFactory());
			}
			
			if (APIConstant.GET_METHOD_STR.equals(httpMethodStr)) {
				response = restTemplate.exchange(contextUrl, httpMethod, new HttpEntity<Object>(null, httpHeaders), responseType);
			} else {
				response = restTemplate.exchange(contextUrl, HttpMethod.POST, new HttpEntity<Object>(body, httpHeaders), responseType);
			}
			rs = response.getBody();
			statusCode = response.getStatusCode();
		}
		// client error (4xx)
		catch(HttpClientErrorException e){
			statusCode = e.getStatusCode();
			logger.info("HTTP Status Code:" + statusCode);
			logger.info("Response Body:" + e.getResponseBodyAsString());
			rs = jsonToPojo(e.getResponseBodyAsString(), responseType);
		}
		// server error (5xx)
		catch(HttpServerErrorException e){
			statusCode = e.getStatusCode();
			logger.info("HTTP Status Code:" + statusCode);
			logger.info("Response Body:" + e.getResponseBodyAsString());
			rs = jsonToPojo(e.getResponseBodyAsString(), responseType);
		}
		finally {
			long endTime = System.currentTimeMillis();
			long time = endTime - startTime;
			logger.info("Response : " + rs);
			logger.info("Time Duration: " + time);
			logger.info("***********End invokeRestTemplateService Raw**********");
		}
		return rs;
	}
	
	public static BigDecimal parseStrToBigDecimal(String input){
		if (StringUtils.isBlank(input)) {
			return APIConstant.DEC_ZERO;
		}
		
		try {
			return new BigDecimal(input);
		} catch (Exception ex) {
			ex.printStackTrace();
			return APIConstant.DEC_ZERO;
		}
	}

	public static Document getSampleInputToCallWS(String url) throws ServiceRuntimeException{
		try{
			ClassPathResource cpr = new ClassPathResource(url);
			InputStream inputTemplate = cpr.getInputStream();
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			return builder.parse(inputTemplate);
		}
		catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
	public static Node getNodeByXpath(Node document, String xpath) {

		Node node = null;
		try {
			XPath xPathIntance = XPathFactory.newInstance().newXPath();
			node = (Node) xPathIntance.evaluate(xpath, document, XPathConstants.NODE);
		} catch (XPathExpressionException e) {
			logger.info(e.getMessage(), e);
		}
		return node;
	}
	
	public static Node getNodeByXpath(Document document, String xpath) {

		Node node = null;
		try {
			XPath xPathIntance = XPathFactory.newInstance().newXPath();
			node = (Node) xPathIntance.evaluate(xpath, document.getDocumentElement(), XPathConstants.NODE);
		} catch (XPathExpressionException e) {
			logger.error(e.getMessage(), e);
		}
		return node;
	}
	
	public static String convertXMLtoJSON(String docByXML) {
		String result = null;
		String docByXMLReplace = docByXML.replaceAll(">\\s+<", "><");
		HierarchicalStreamReader sourceReader = new XppReader(new StringReader(docByXMLReplace), new MXParser());

		StringWriter buffer = new StringWriter();
		JettisonMappedXmlDriver jettisonDriver = new JettisonMappedXmlDriver();
		HierarchicalStreamWriter destinationWriter = jettisonDriver.createWriter(buffer);

		HierarchicalStreamCopier copier = new HierarchicalStreamCopier();
		copier.copy(sourceReader, destinationWriter);

		result = buffer.toString();
		return result;
	}
	
	public static Document converterXMLtoDOM(String docByXML) throws ServiceRuntimeException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		try {
			builder = factory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			throw new ServiceRuntimeException(e);
		}
		try {
			return builder.parse(new ByteArrayInputStream(docByXML.getBytes(StandardCharsets.UTF_8)));
		} catch (SAXException | IOException e) {
			throw new ServiceRuntimeException(e);
		}
	}

	public static String converterDOMToXML(Document document) throws ServiceRuntimeException {
		try {
			StringWriter writer = new StringWriter();
			TransformerFactory tFactory = TransformerFactory.newInstance();
			StreamResult docXML = new StreamResult(writer);
			DOMSource source = new DOMSource(document);
			try {
				Transformer transformer = tFactory.newTransformer();
				transformer.transform(source, docXML);
			} catch (TransformerException e) {
			}
			String xml = writer.toString();
			writer.close();
			return xml;
		}catch(Exception e){
			throw new ServiceRuntimeException(env.getProperty("MSG_004"), e.getCause());
		}
	}
}
