/**
 * 
 */
package com.shinhan.fcl.service.impl;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.fcl.common.AbstractBasicCommonClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.model.WaiveOffDocumentTrx;
import com.shinhan.fcl.core.util.CommonUtil;
import com.shinhan.fcl.core.util.DTOConverter;
import com.shinhan.fcl.core.util.DateUtils;
import com.shinhan.fcl.repository.entity.TOmsFCLFormInf;
import com.shinhan.fcl.repository.entity.TOmsFCLFormPaymentInf;
import com.shinhan.fcl.repository.entity.TOmsFCLFormPaymentMas;
import com.shinhan.fcl.service.FormApiService;

/**
 * @author shds01
 *
 */

@Service("formApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class FormApiServiceImpl extends AbstractBasicCommonClass implements FormApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#getListFormAvailable(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListFormAvailable(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		return getRepositoryManagerService().getFormManagerRepositoryService().getListFormAvailable(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#countFormAvailableTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countFormAvailableTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getFormManagerRepositoryService().countFormAvailableTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#executeRemoveForm(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeRemoveForm(Map<String, Object> inputParams)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLFormInf> listUpd = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLFormInf inf = getValidationManagerService().checkValidationExecuteRemoveForm(trx);
			if(trx.getValid()){
				if(inf == null) {
					listUpd.add(DTOConverter.populateDataExecuteRemoveFormNew(trx.getLoan_no(), userName));
				} else {
					DTOConverter.populateDataExecuteRemoveForm(inf, userName);
					listUpd.add(inf);
				}
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().executeRemoveFormTrxToDB(listUpd);
		}
		
		return lst;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#executeUnRemoveForm(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeUnRemoveForm(Map<String, Object> inputParams)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLFormInf> listUpd = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLFormInf inf = getValidationManagerService().checkValidationExecuteRemoveForm(trx);
			if(trx.getValid() && inf != null){
				DTOConverter.populateDataExecuteUnRemoveForm(inf, userName);
				listUpd.add(inf);
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().executeUnRemoveFormTrxToDB(listUpd);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#executeETForm(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeETForm(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLFormInf> listReg = new ArrayList<>();
		ArrayList<TOmsFCLFormPaymentInf> listRegFormPayment = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLFormInf inf = getValidationManagerService().checkValidationExecuteETForm(trx);
			if(trx.getValid()){
				if(inf == null) {
					listReg.add(DTOConverter.populateDataExecuteETFormNew(trx.getLoan_no(), userName));
				} else {
					DTOConverter.populateDataExecuteETForm(inf, userName);
					listReg.add(inf);
				}
				
				listRegFormPayment.add(DTOConverter.populateDataExecuteETFormPayment(trx.getLoan_no(), userName));
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().executeETFormTrxToDB(listReg, listRegFormPayment);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#executeWaiveOff(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeWaiveOff(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLFormInf> listReg = new ArrayList<>();
		List<WaiveOffDocumentTrx> lstWaiveOff = new ArrayList<WaiveOffDocumentTrx>();
		boolean isWriteFile = false;
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLFormInf inf = getValidationManagerService().checkValidationExecuteWaiveForm(trx);
			if(trx.getValid()){
				if(inf == null) {
					listReg.add(DTOConverter.populateDataExecuteWaiveFormNew(trx.getLoan_no(), userName));
				} else {
					DTOConverter.populateDataExecuteWaiveForm(inf, userName);
					listReg.add(inf);
				}
				lstWaiveOff.add(DTOConverter.populateDataExecuteWaiveForWaiveOffDocumentTrx(trx));
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		//Process write csv file 
		String indexWaiveOff = CommonUtil.generateCountWaiveOffMap(env.getProperty(APIConstant.WAIVEOFF_INDEX_VALUE_FORMAT));
		String pathDir = env.getProperty(APIConstant.PATH_EXPORT_FCL);
		String nameFile = APIConstant.WAIVEOFF_DOCUMENT_TITLE + "-" + DateUtils.getSystemDateStr(DateUtils.ddMMyyyy) + "-" 
				+ indexWaiveOff + APIConstant.FILE_TYPE_CSV;
		
		isWriteFile = writeCSVFileToWaiveOff(lstWaiveOff, pathDir, nameFile);
		
		if(countTotal == count && isWriteFile){
			getRepositoryManagerService().executeWaiveFormTrxToDB(listReg);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#updateRemarkForm(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> updateRemarkForm(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLFormInf> listUpd = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLFormInf inf = getValidationManagerService().checkValidationUpdateRemarkForm(trx);
			if(trx.getValid()){
				if(inf == null) {
					listUpd.add(DTOConverter.populateDataUpdateRemarkFormNew(trx.getLoan_no(), userName, trx.getRemarks()));
				} else {
					DTOConverter.populateDataUpdateRemarkForm(inf, userName, trx.getRemarks());
					listUpd.add(inf);
				}
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().executeRemoveFormTrxToDB(listUpd);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#exportReportFormTrx(java.util.Map)
	 */
	@Override
	public File exportReportFormTrx(Map<String, Object> inputParams) throws BaseException {
		inputParams.put(APIConstant._TEMPLATE_NAME, APIConstant.EXPORT_FCL_REPORT_TEMPLATE_NAME_FORM_AVAIABLE);
		
		File fileExport = getProcessManagerService().getExportReportService().exportReportByTemplate(inputParams);
		if(fileExport == null || !fileExport.exists()) {
			return null;
		}
		return fileExport;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#exportETFormByLoan(java.util.Map)
	 */
	@Override
	public File exportETFormByLoan(Map<String, Object> inputParams) throws BaseException {
		String loanNo = inputParams.get(APIConstant._LOAN_NO).toString();
		
		TOmsFCLFormPaymentMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLFormPaymentMasTrxByLoanNo(loanNo);
		if(mas == null || (APIConstant.FCL_CATEGORY_FCL_NOT_MONEY.equalsIgnoreCase(mas.getFcl_category()) == false) ) {
			// TODO throw new ServiceRuntimeException(String.format(env.getProperty("MSG_007"), loanNo));
		}
		
		/** Start Call WS to searching */
		String refDocId = searchDocumentFormByLoanNo(loanNo);
		if(StringUtils.isBlank(refDocId)) {
			logger.info("***** No Document For Searching By Loan ***** " + loanNo);
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_019"), loanNo));
		}
		/** End Call WS to searching */
		
		/** Start Call WS to download file */
		File file = downloadDocumentFormByRefId(refDocId);
		if(file == null || file.exists() == false) {
			logger.info("***** No Document For Searching By Ref ***** " + refDocId);
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_019"), loanNo));
		}
		
		/** End Call WS to download file */
		return file;
	}

}
