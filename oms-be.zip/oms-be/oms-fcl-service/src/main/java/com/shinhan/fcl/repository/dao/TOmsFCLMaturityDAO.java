/**
 * 
 */
package com.shinhan.fcl.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.shinhan.fcl.repository.entity.TOmsFCLMaturityInf;

/**
 * @author shds01
 *
 */
@Repository
public interface TOmsFCLMaturityDAO extends JpaRepository<TOmsFCLMaturityInf, String> {

	@Query("SELECT item FROM TOmsFCLMaturityInf item WHERE LOWER(item.loan_no) = LOWER(:loanNo)")
	public TOmsFCLMaturityInf getItemByLoanNo(@Param("loanNo") String loanNo);
}
