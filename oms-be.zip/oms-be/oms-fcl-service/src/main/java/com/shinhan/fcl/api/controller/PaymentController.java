/**
 * 
 */
package com.shinhan.fcl.api.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.util.DateUtils;

/**
 * @author shds01
 *
 */
@RestController
public class PaymentController extends BaseController{
	
	/** Payment Available */
	@RequestMapping(value = "shinhan/service/payment", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	public String getListPaymentAvailable(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _cifNo,
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant._LOAN_NO, _loanNo);
		inputParams.put(APIConstant._CIF_NO, _cifNo);
		
		List<EarlyTerminationTrx> lst = getProcessManagerService().getPaymentApiService().getListPaymentAvailable(inputParams);
		BigDecimal countTotal = getProcessManagerService().getPaymentApiService().countPaymentAvailableTrx(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
	
	@RequestMapping(value = "shinhan/service/payment", produces = "application/json;charset=utf-8", method = RequestMethod.PATCH)
	public String updateListPaymentAvailable(@RequestBody String document,
			Locale locale) throws BaseException {
		
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		List<EarlyTerminationTrx> lst = getProcessManagerService().getPaymentApiService().updateRemarkPayment(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	
	@RequestMapping(value = "shinhan/service/payment/executeRemove", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	public String executeRemovePayment(@RequestBody String document,
			Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		List<EarlyTerminationTrx> lst = getProcessManagerService().getPaymentApiService().executeRemovePayment(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	
	@RequestMapping(value = "shinhan/service/payment/executeET", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	public String executeETPayment(@RequestBody String document,
			Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		List<EarlyTerminationTrx> lst = getProcessManagerService().getPaymentApiService().executeETPayment(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	
	@RequestMapping(value = "shinhan/service/payment/exportreport", produces = {"application/pdf"}, method = RequestMethod.POST)
	public ResponseEntity<Object> exportReportForPayment(@RequestBody String document,
			@RequestParam(required = false, defaultValue = "" ) String _startDt,
			@RequestParam(required = false, defaultValue = "" ) String _endDt,
			Locale locale) throws BaseException, FileNotFoundException {
		
		Map<String, Object> inputParams = new HashMap<>();
		
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		
		File item = getProcessManagerService().getPaymentApiService().exportReportForPayment(inputParams);
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_004"));
		}
		return triggerSuccessResponseFile(item);
	}
}
