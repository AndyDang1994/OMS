/**
 * 
 */
package com.shinhan.fcl.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.repository.entity.TOmsFCLFollowEMIInf;
import com.shinhan.fcl.repository.entity.TOmsFCLFormInf;
import com.shinhan.fcl.repository.entity.TOmsFCLFormPaymentInf;
import com.shinhan.fcl.repository.entity.TOmsFCLMaturityInf;
import com.shinhan.fcl.repository.entity.TOmsFCLPaymentInf;
import com.shinhan.fcl.repository.entity.TOmsFCLTBInf;
import com.shinhan.fcl.repository.entity.TOmsFCLTBMas;
import com.shinhan.fcl.repository.service.FollowUpManagerRepositoryService;
import com.shinhan.fcl.repository.service.FormManagerRepositoryService;
import com.shinhan.fcl.repository.service.FormPaymentManagerRepositoryService;
import com.shinhan.fcl.repository.service.MaturityManagerRepositoryService;
import com.shinhan.fcl.repository.service.PaymentManagerRepositoryService;
import com.shinhan.fcl.repository.service.TBManagerRepositoryService;
import com.shinhan.fcl.repository.service.UtilityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("repositoryManagerService")
public class RepositoryManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	public Environment env;

	@Autowired
	private UtilityManagerRepositoryService utilityManagerRepositoryService;

	@Autowired
	private FormManagerRepositoryService formManagerRepositoryService;

	@Autowired
	private PaymentManagerRepositoryService paymentManagerRepositoryService;

	@Autowired
	private FormPaymentManagerRepositoryService formPaymentManagerRepositoryService;

	@Autowired
	private MaturityManagerRepositoryService maturityManagerRepositoryService;

	@Autowired
	private FollowUpManagerRepositoryService followUpManagerRepositoryService;

	@Autowired
	private TBManagerRepositoryService tbManagerRepositoryService;
	/**
	 * @return the utilityManagerRepositoryService
	 */
	public UtilityManagerRepositoryService getUtilityManagerRepositoryService() {
		return utilityManagerRepositoryService;
	}

	/**
	 * @param utilityManagerRepositoryService the utilityManagerRepositoryService to
	 *                                        set
	 */
	public void setUtilityManagerRepositoryService(
			@Qualifier("utilityManagerRepositoryService") UtilityManagerRepositoryService utilityManagerRepositoryService) {
		this.utilityManagerRepositoryService = utilityManagerRepositoryService;
	}

	/**
	 * @return the formManagerRepositoryService
	 */
	public FormManagerRepositoryService getFormManagerRepositoryService() {
		return formManagerRepositoryService;
	}

	/**
	 * @param formManagerRepositoryService the formManagerRepositoryService to set
	 */
	public void setFormManagerRepositoryService(
			@Qualifier("formManagerRepositoryService") FormManagerRepositoryService formManagerRepositoryService) {
		this.formManagerRepositoryService = formManagerRepositoryService;
	}

	/**
	 * @return the paymentManagerRepositoryService
	 */
	public PaymentManagerRepositoryService getPaymentManagerRepositoryService() {
		return paymentManagerRepositoryService;
	}

	/**
	 * @param paymentManagerRepositoryService the paymentManagerRepositoryService to
	 *                                        set
	 */
	public void setPaymentManagerRepositoryService(
			@Qualifier("paymentManagerRepositoryService") PaymentManagerRepositoryService paymentManagerRepositoryService) {
		this.paymentManagerRepositoryService = paymentManagerRepositoryService;
	}

	/**
	 * @return the formPaymentManagerRepositoryService
	 */
	public FormPaymentManagerRepositoryService getFormPaymentManagerRepositoryService() {
		return formPaymentManagerRepositoryService;
	}

	/**
	 * @param formPaymentManagerRepositoryService the
	 *                                            formPaymentManagerRepositoryService
	 *                                            to set
	 */
	public void setFormPaymentManagerRepositoryService(
			@Qualifier("formPaymentManagerRepositoryService") FormPaymentManagerRepositoryService formPaymentManagerRepositoryService) {
		this.formPaymentManagerRepositoryService = formPaymentManagerRepositoryService;
	}

	/**
	 * @return the maturityManagerRepositoryService
	 */
	public MaturityManagerRepositoryService getMaturityManagerRepositoryService() {
		return maturityManagerRepositoryService;
	}

	/**
	 * @param maturityManagerRepositoryService the maturityManagerRepositoryService
	 *                                         to set
	 */
	public void setMaturityManagerRepositoryService(
			@Qualifier("maturityManagerRepositoryService") MaturityManagerRepositoryService maturityManagerRepositoryService) {
		this.maturityManagerRepositoryService = maturityManagerRepositoryService;
	}

	/**
	 * @return the followUpManagerRepositoryService
	 */
	public FollowUpManagerRepositoryService getFollowUpManagerRepositoryService() {
		return followUpManagerRepositoryService;
	}

	/**
	 * @param followUpManagerRepositoryService the followUpManagerRepositoryService
	 *                                         to set
	 */
	public void setFollowUpManagerRepositoryService(
			@Qualifier("followUpManagerRepositoryService") FollowUpManagerRepositoryService followUpManagerRepositoryService) {
		this.followUpManagerRepositoryService = followUpManagerRepositoryService;
	}
	
	/**
	 * @return the tbManagerRepositoryService
	 */
	public TBManagerRepositoryService getTbManagerRepositoryService() {
		return tbManagerRepositoryService;
	}

	/**
	 * @param tbManagerRepositoryService the tbManagerRepositoryService to set
	 */
	public void setTbManagerRepositoryService(
			@Qualifier("tbManagerRepositoryServices") TBManagerRepositoryService tbManagerRepositoryService) {
		this.tbManagerRepositoryService = tbManagerRepositoryService;
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void updateNoteFollowupEMITrxToDB(ArrayList<TOmsFCLFollowEMIInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getFollowUpManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeWaiveMaturityWaiveOffTrxToDB(ArrayList<TOmsFCLMaturityInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getMaturityManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeDoneMaturityBookIncTrxToDB(ArrayList<TOmsFCLMaturityInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getMaturityManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeDoneMaturityRefundTrxToDB(ArrayList<TOmsFCLMaturityInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getMaturityManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void updateTBTrxNotFoundInLMSToDB(List<TOmsFCLTBInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getTbManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void updateTBTrxFoundInLMSToDB(List<TOmsFCLTBInf> listInf, List<TOmsFCLTBMas> listMas) throws ServiceRuntimeException{
		
		getTbManagerRepositoryService().createAllMas(listMas);
		
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listInf);
		getTbManagerRepositoryService().createAll(inputs);
		
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void deleteTBTrxNotFoundInLMSToDB(List<TOmsFCLTBInf> listInf) throws ServiceRuntimeException{
		
		getTbManagerRepositoryService().deleteAll(listInf);
		
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void uploadTBTrxToDB(ArrayList<TOmsFCLTBInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getTbManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeDoneTBTrxToDB(ArrayList<TOmsFCLTBInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getTbManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeRemoveTBTrxToDB(ArrayList<TOmsFCLTBInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getTbManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeUnRemoveTBTrxToDB(ArrayList<TOmsFCLTBInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getTbManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeWaiveTBTrxToDB(ArrayList<TOmsFCLTBInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getTbManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeDummyTBTrxToDB(ArrayList<TOmsFCLTBInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getTbManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeRemovePaymentTrxToDB(ArrayList<TOmsFCLPaymentInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getPaymentManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeETPaymentTrxToDB(ArrayList<TOmsFCLPaymentInf> listReg, ArrayList<TOmsFCLFormPaymentInf> listRegFormPayment) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		
		//Insert into payment-inf
		inputs.put(APIConstant.DOCUMENT, listReg);
		getPaymentManagerRepositoryService().createAll(inputs);
		
		//Insert into form&payment for ET trx
		inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listRegFormPayment);
		getFormPaymentManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeUpdateRemarkPaymentTrxToDB(ArrayList<TOmsFCLPaymentInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getPaymentManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeRemoveFormTrxToDB(ArrayList<TOmsFCLFormInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getFormManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeUnRemoveFormTrxToDB(ArrayList<TOmsFCLFormInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getFormManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeETFormTrxToDB(ArrayList<TOmsFCLFormInf> listReg, ArrayList<TOmsFCLFormPaymentInf> listRegFormPayment) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		
		//Insert into form-inf
		inputs.put(APIConstant.DOCUMENT, listReg);
		getFormManagerRepositoryService().createAll(inputs);
		
		//Insert into form &p ayment for ET trx
		inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listRegFormPayment);
		getFormPaymentManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeWaiveFormTrxToDB(ArrayList<TOmsFCLFormInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getFormManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeDoneFormPaymentTrxToDB(ArrayList<TOmsFCLFormPaymentInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getFormPaymentManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeCheckedFormPaymentTrxToDB(ArrayList<TOmsFCLFormPaymentInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getFormPaymentManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeWaiveFormPaymentTrxToDB(ArrayList<TOmsFCLFormPaymentInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getFormPaymentManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeDummyFormPaymentTrxToDB(ArrayList<TOmsFCLFormPaymentInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getFormPaymentManagerRepositoryService().createAll(inputs);
	}
}
