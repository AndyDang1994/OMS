/**
 * 
 */
package com.shinhan.fcl.integration.soap.model;

/**
 * @author shds01
 *
 */
public class Element {
	private String CIF;
	private String LOAN_ID;
	private String CUST_NAME;
	private String PRINCIPAL;
	private String TOTAL_TO_PAY;
	private String TOTAL_PMT_RECEIVED;
	private String INT;
	private String LPP;
	private String ODF;
	private String TOTAL_WAIVE_OFF;
	private String TERM_STATUS;
	private String LAST_DUE_DATE;
	private String WAIVE_OFF;
	private String REPAYMENT_AMOUNT;
	private String PL_EARLY_SETTLE;

	/**
	 * 
	 */
	public Element() {
		super();
	}

	/**
	 * @return the cIF
	 */
	public String getCIF() {
		return CIF;
	}

	/**
	 * @param cIF the cIF to set
	 */
	public void setCIF(String cIF) {
		CIF = cIF;
	}

	/**
	 * @return the lOAN_ID
	 */
	public String getLOAN_ID() {
		return LOAN_ID;
	}

	/**
	 * @param lOAN_ID the lOAN_ID to set
	 */
	public void setLOAN_ID(String lOAN_ID) {
		LOAN_ID = lOAN_ID;
	}

	/**
	 * @return the cUST_NAME
	 */
	public String getCUST_NAME() {
		return CUST_NAME;
	}

	/**
	 * @param cUST_NAME the cUST_NAME to set
	 */
	public void setCUST_NAME(String cUST_NAME) {
		CUST_NAME = cUST_NAME;
	}

	/**
	 * @return the pRINCIPAL
	 */
	public String getPRINCIPAL() {
		return PRINCIPAL;
	}

	/**
	 * @param pRINCIPAL the pRINCIPAL to set
	 */
	public void setPRINCIPAL(String pRINCIPAL) {
		PRINCIPAL = pRINCIPAL;
	}

	/**
	 * @return the tOTAL_TO_PAY
	 */
	public String getTOTAL_TO_PAY() {
		return TOTAL_TO_PAY;
	}

	/**
	 * @param tOTAL_TO_PAY the tOTAL_TO_PAY to set
	 */
	public void setTOTAL_TO_PAY(String tOTAL_TO_PAY) {
		TOTAL_TO_PAY = tOTAL_TO_PAY;
	}

	/**
	 * @return the tOTAL_PMT_RECEIVED
	 */
	public String getTOTAL_PMT_RECEIVED() {
		return TOTAL_PMT_RECEIVED;
	}

	/**
	 * @param tOTAL_PMT_RECEIVED the tOTAL_PMT_RECEIVED to set
	 */
	public void setTOTAL_PMT_RECEIVED(String tOTAL_PMT_RECEIVED) {
		TOTAL_PMT_RECEIVED = tOTAL_PMT_RECEIVED;
	}

	/**
	 * @return the iNT
	 */
	public String getINT() {
		return INT;
	}

	/**
	 * @param iNT the iNT to set
	 */
	public void setINT(String iNT) {
		INT = iNT;
	}

	/**
	 * @return the lPP
	 */
	public String getLPP() {
		return LPP;
	}

	/**
	 * @param lPP the lPP to set
	 */
	public void setLPP(String lPP) {
		LPP = lPP;
	}

	/**
	 * @return the oDF
	 */
	public String getODF() {
		return ODF;
	}

	/**
	 * @param oDF the oDF to set
	 */
	public void setODF(String oDF) {
		ODF = oDF;
	}

	/**
	 * @return the tOTAL_WAIVE_OFF
	 */
	public String getTOTAL_WAIVE_OFF() {
		return TOTAL_WAIVE_OFF;
	}

	/**
	 * @param tOTAL_WAIVE_OFF the tOTAL_WAIVE_OFF to set
	 */
	public void setTOTAL_WAIVE_OFF(String tOTAL_WAIVE_OFF) {
		TOTAL_WAIVE_OFF = tOTAL_WAIVE_OFF;
	}

	/**
	 * @return the tERM_STATUS
	 */
	public String getTERM_STATUS() {
		return TERM_STATUS;
	}

	/**
	 * @param tERM_STATUS the tERM_STATUS to set
	 */
	public void setTERM_STATUS(String tERM_STATUS) {
		TERM_STATUS = tERM_STATUS;
	}

	/**
	 * @return the lAST_DUE_DATE
	 */
	public String getLAST_DUE_DATE() {
		return LAST_DUE_DATE;
	}

	/**
	 * @param lAST_DUE_DATE the lAST_DUE_DATE to set
	 */
	public void setLAST_DUE_DATE(String lAST_DUE_DATE) {
		LAST_DUE_DATE = lAST_DUE_DATE;
	}

	/**
	 * @return the wAIVE_OFF
	 */
	public String getWAIVE_OFF() {
		return WAIVE_OFF;
	}

	/**
	 * @param wAIVE_OFF the wAIVE_OFF to set
	 */
	public void setWAIVE_OFF(String wAIVE_OFF) {
		WAIVE_OFF = wAIVE_OFF;
	}

	/**
	 * @return the rEPAYMENT_AMOUNT
	 */
	public String getREPAYMENT_AMOUNT() {
		return REPAYMENT_AMOUNT;
	}

	/**
	 * @param rEPAYMENT_AMOUNT the rEPAYMENT_AMOUNT to set
	 */
	public void setREPAYMENT_AMOUNT(String rEPAYMENT_AMOUNT) {
		REPAYMENT_AMOUNT = rEPAYMENT_AMOUNT;
	}

	/**
	 * @return the pL_EARLY_SETTLE
	 */
	public String getPL_EARLY_SETTLE() {
		return PL_EARLY_SETTLE;
	}

	/**
	 * @param pL_EARLY_SETTLE the pL_EARLY_SETTLE to set
	 */
	public void setPL_EARLY_SETTLE(String pL_EARLY_SETTLE) {
		PL_EARLY_SETTLE = pL_EARLY_SETTLE;
	}

}
