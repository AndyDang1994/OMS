/**
 * 
 */
package com.shinhan.fcl.service.impl;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.fcl.common.AbstractBasicCommonClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.DummyDocumentTrx;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.model.WaiveOffDocumentTrx;
import com.shinhan.fcl.core.util.CommonUtil;
import com.shinhan.fcl.core.util.DTOConverter;
import com.shinhan.fcl.core.util.DateUtils;
import com.shinhan.fcl.repository.entity.TOmsFCLFormPaymentInf;
import com.shinhan.fcl.repository.entity.TOmsFCLFormPaymentMas;
import com.shinhan.fcl.service.FormPaymentApiService;

/**
 * @author shds01
 *
 */

@Service("formPaymentApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class FormPaymentApiServiceImpl extends AbstractBasicCommonClass implements FormPaymentApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#getListFormPaymentAvailable(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListFormPaymentAvailable(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		return getRepositoryManagerService().getFormPaymentManagerRepositoryService().getListFormPaymentAvailable(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#countFormPaymentAvailableTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countFormPaymentAvailableTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getFormPaymentManagerRepositoryService().countFormPaymentAvailableTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormPaymentApiService#getListFormPaymentAvailableDoneTrx(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListFormPaymentAvailableDoneTrx(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		return getRepositoryManagerService().getFormPaymentManagerRepositoryService().getListFormPaymentAvailableDoneTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormPaymentApiService#countFormPaymentAvailableDoneTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countFormPaymentAvailableDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getFormPaymentManagerRepositoryService().countFormPaymentAvailableDoneTrx(inputParams);
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormPaymentApiService#executeDone(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeDone(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLFormPaymentInf> listUpd = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLFormPaymentInf inf = getValidationManagerService().checkValidationExecuteDoneFormPayment(trx);
			if(trx.getValid()){
				if(inf == null) {
					inf = DTOConverter.initDataExecuteDoneFormPaymentNew(trx.getLoan_no(), userName);
				}
				DTOConverter.populateDataExecuteDoneFormPayment(inf, userName);
				listUpd.add(inf);
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().executeDoneFormPaymentTrxToDB(listUpd);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormPaymentApiService#executeChecked(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeChecked(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLFormPaymentInf> listUpd = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLFormPaymentInf inf = getValidationManagerService().checkValidationExecuteCheckedFormPayment(trx);
			if(trx.getValid() && inf != null){
				DTOConverter.populateDataExecuteCheckedFormPayment(inf, userName);
				listUpd.add(inf);
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().executeCheckedFormPaymentTrxToDB(listUpd);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormPaymentApiService#executeWaiveOff(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeWaiveOff(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLFormPaymentInf> listReg = new ArrayList<>();
		List<WaiveOffDocumentTrx> lstWaiveOff = new ArrayList<WaiveOffDocumentTrx>();
		boolean isWriteFile = false;
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLFormPaymentInf inf = getValidationManagerService().checkValidationExecuteWaiveFormPayment(trx);
			if(trx.getValid()){
				if(inf == null) {
					inf = DTOConverter.populateDataExecuteWaiveFormPaymentNew(trx.getLoan_no(), userName);
				}
				DTOConverter.populateDataExecuteWaiveFormPayment(inf, userName);
				listReg.add(inf);
				lstWaiveOff.add(DTOConverter.populateDataExecuteWaiveForWaiveOffDocumentTrx(trx));
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		//Process write csv file
		String indexWaiveOff = CommonUtil.generateCountWaiveOffMap(env.getProperty(APIConstant.WAIVEOFF_INDEX_VALUE_FORMAT));
		String pathDir = env.getProperty(APIConstant.PATH_EXPORT_FCL);
		String nameFile = APIConstant.WAIVEOFF_DOCUMENT_TITLE + "-" + DateUtils.getSystemDateStr(DateUtils.ddMMyyyy) + "-" 
				+ indexWaiveOff + APIConstant.FILE_TYPE_CSV;
		
		isWriteFile = writeCSVFileToWaiveOff(lstWaiveOff, pathDir, nameFile);
		
		if(countTotal == count && isWriteFile){
			getRepositoryManagerService().executeWaiveFormPaymentTrxToDB(listReg);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormPaymentApiService#executeDummy(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeDummy(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLFormPaymentInf> listReg = new ArrayList<>();
		List<DummyDocumentTrx> lstDummy = new ArrayList<DummyDocumentTrx>();
		boolean isWriteFile = false;
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLFormPaymentInf inf = getValidationManagerService().checkValidationExecuteDummyFormPayment(trx);
			boolean isWaive = false;
			if(trx.getValid()){
				if(inf == null) {
					inf = DTOConverter.populateDataExecuteDummyFormPaymentNew(trx.getLoan_no(), userName);
				} else if (APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_WAIVEOFF_VALUE.equalsIgnoreCase(inf.getStatus_code())){
					isWaive = true;
				}
				DTOConverter.populateDataExecuteDummyFormPayment(inf, userName);
				listReg.add(inf);
				lstDummy.add(DTOConverter.populateDataExecuteDummyForDummyDocumentTrx(trx, isWaive, userName));
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		//Process write csv file 
		String pathDir = env.getProperty(APIConstant.PATH_EXPORT_FCL);
		String nameFile = APIConstant.DUMMY_DOCUMENT_TITLE + "-" + DateUtils.getSystemDateStr(DateUtils.ddMMyyyyhhmmss) + APIConstant.FILE_TYPE_CSV;
		isWriteFile = writeCSVFileToDummy(lstDummy, pathDir, nameFile);
		
		if(countTotal == count && isWriteFile){
			getRepositoryManagerService().executeDummyFormPaymentTrxToDB(listReg);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormPaymentApiService#exportReportFormPaymentTrx(java.util.Map)
	 */
	@Override
	public File exportReportFormPaymentTrx(Map<String, Object> inputParams) throws BaseException {
inputParams.put(APIConstant._TEMPLATE_NAME, APIConstant.EXPORT_FCL_REPORT_TEMPLATE_NAME_FORM_PAYMENT_AVAIABLE);
		
		File fileExport = getProcessManagerService().getExportReportService().exportReportByTemplate(inputParams);
		if(fileExport == null || !fileExport.exists()) {
			return null;
		}
		return fileExport;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormPaymentApiService#exportETFormByLoan(java.util.Map)
	 */
	@Override
	public File exportETFormByLoan(Map<String, Object> inputParams) throws BaseException {
		String loanNo = inputParams.get(APIConstant._LOAN_NO).toString();
		
		TOmsFCLFormPaymentMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLFormPaymentMasTrxByLoanNo(loanNo);
		if(mas == null || (APIConstant.FCL_CATEGORY_FCL_NOT_MONEY.equalsIgnoreCase(mas.getFcl_category()) == false) ) {
			// TODO throw new ServiceRuntimeException(String.format(env.getProperty("MSG_007"), loanNo));
		}
		
		/** Start Call WS to searching */
		String refDocId = searchDocumentFormByLoanNo(loanNo);
		if(StringUtils.isBlank(refDocId)) {
			logger.info("***** No Document For Searching By Loan ***** " + loanNo);
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_019"), loanNo));
		}
		/** End Call WS to searching */
		
		/** Start Call WS to download file */
		File file = downloadDocumentFormByRefId(refDocId);
		if(file == null || file.exists() == false) {
			logger.info("***** No Document For Searching By Ref ***** " + refDocId);
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_019"), loanNo));
		}
		
		/** End Call WS to download file */
		return file;
	}


}
