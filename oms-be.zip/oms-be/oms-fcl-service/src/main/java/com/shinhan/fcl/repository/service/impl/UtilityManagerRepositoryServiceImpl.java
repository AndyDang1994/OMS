/**
 * 
 */
package com.shinhan.fcl.repository.service.impl;

import java.util.List;

import javax.persistence.Query;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.fcl.common.AbstractServiceClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.repository.dao.TMetadataDAO;
import com.shinhan.fcl.repository.dao.TOmsFCLFollowEMIMasDAO;
import com.shinhan.fcl.repository.dao.TOmsFCLFormPaymentMasDAO;
import com.shinhan.fcl.repository.dao.TOmsFCLMaturityMasDAO;
import com.shinhan.fcl.repository.dao.TOmsFCLTBMasDAO;
import com.shinhan.fcl.repository.entity.TMetadata;
import com.shinhan.fcl.repository.entity.TOmsFCLFollowEMIMas;
import com.shinhan.fcl.repository.entity.TOmsFCLFormPaymentMas;
import com.shinhan.fcl.repository.entity.TOmsFCLMaturityMas;
import com.shinhan.fcl.repository.entity.TOmsFCLTBMas;
import com.shinhan.fcl.repository.service.UtilityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("utilityManagerRepositoryService")
public class UtilityManagerRepositoryServiceImpl extends AbstractServiceClass
		implements UtilityManagerRepositoryService {

	@Autowired
	private TMetadataDAO objectMetaDao;
	
	@Autowired
	private TOmsFCLFollowEMIMasDAO objectFollowMasDao;
	
	@Autowired
	private TOmsFCLMaturityMasDAO objectMaturityMasDao;
	
	@Autowired
	private TOmsFCLTBMasDAO objectTBMasDao;
	
	@Autowired
	private TOmsFCLFormPaymentMasDAO objectFormPaymentMasDao;
	
	public UtilityManagerRepositoryServiceImpl(TMetadataDAO objectMetaDao, TOmsFCLFollowEMIMasDAO objectFollowMasDao
			, TOmsFCLMaturityMasDAO objectMaturityMasDao, TOmsFCLTBMasDAO objectTBMasDao, TOmsFCLFormPaymentMasDAO objectFormPaymentMasDao) {
		this.objectMetaDao = objectMetaDao;
		
		this.objectFollowMasDao = objectFollowMasDao;
		this.objectMaturityMasDao = objectMaturityMasDao;
		this.objectTBMasDao = objectTBMasDao;
		this.objectFormPaymentMasDao = objectFormPaymentMasDao;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.UtilityManagerRepositoryService#getMetadataById(java.lang.Long)
	 */
	@Override
	public TMetadata getMetadataById(Long id) throws ServiceRuntimeException {
		return objectMetaDao.findById(id).get(); 
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.fcl.repository.service.UtilityManagerRepositoryService#
	 * getMetadataByLookupCode(java.lang.String)
	 */
	@Override
	public List<TMetadata> getMetadataByLookupCode(String lookupCode) throws ServiceRuntimeException {
		String sql = oracleOMSNamedQueries.get("getMetadataByLookupCode");
		Query query = entityManager.createNativeQuery(sql, TMetadata.class);
		
		query.setParameter("SERVICENAME", APIConstant.SERVICENAME_FCL);
		query.setParameter("LOOKUPCODE", lookupCode);
		
		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();

		return list;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.UtilityManagerRepositoryService#getMetadataByLookupCodeAndId(java.lang.String, java.lang.String)
	 */
	@Override
	public TMetadata getMetadataByLookupCodeAndId(String lookupCode, String lookupId) throws ServiceRuntimeException {
		String sql = oracleOMSNamedQueries.get("getMetadataByLookupCodeAndId");

		Query query = entityManager.createNativeQuery(sql, TMetadata.class);
		query.setParameter("SERVICENAME", APIConstant.SERVICENAME_FCL);
		query.setParameter("LOOKUPCODE", lookupCode);
		query.setParameter("LOOKUPCODEID", lookupId);

		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();
		if(CollectionUtils.isEmpty(list)) {
			throw new ServiceRuntimeException(String.format(env.getProperty("MSG_007"), lookupId));
		}
		
		return (TMetadata) list.get(0);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.UtilityManagerRepositoryService#getFCLFollowMasTrxById(java.lang.String)
	 */
	@Override
	public TOmsFCLFollowEMIMas getFCLFollowMasTrxById(long id) throws ServiceRuntimeException {
		try {
			return objectFollowMasDao.findById(id).get();
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.UtilityManagerRepositoryService#getFCLMaturityMasTrxByLoanNo(java.lang.String)
	 */
	@Override
	public TOmsFCLMaturityMas getFCLMaturityMasTrxByLoanNo(String loanNo) throws ServiceRuntimeException {
		if (StringUtils.isBlank(loanNo)) {
			return null;
		}
		try {
			return objectMaturityMasDao.findById(loanNo).get();
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.UtilityManagerRepositoryService#getFCLTBMasTrxByLoanNo(java.lang.String)
	 */
	@Override
	public TOmsFCLTBMas getFCLTBMasTrxByLoanNo(String loanNo) throws ServiceRuntimeException {
		if (StringUtils.isBlank(loanNo)) {
			return null;
		}
		try {
			return objectTBMasDao.findById(loanNo).get();
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.UtilityManagerRepositoryService#getFCLFormPaymentMasTrxByLoanNo(java.lang.String)
	 */
	@Override
	public TOmsFCLFormPaymentMas getFCLFormPaymentMasTrxByLoanNo(String loanNo) throws ServiceRuntimeException {
		if (StringUtils.isBlank(loanNo)) {
			return null;
		}
		try {
			return objectFormPaymentMasDao.findById(loanNo).get();
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			return null;
		}
	}
	
}
