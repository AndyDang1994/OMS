/**
 * 
 */
package com.shinhan.fcl.report;

import java.io.File;
import java.util.Map;

import com.shinhan.fcl.core.exception.BaseException;


/**
 * @author shds01
 *
 */
public interface ExportReportService {
	
	public File exportReportByTemplate (Map<String, Object> inputParams) throws BaseException;
}
