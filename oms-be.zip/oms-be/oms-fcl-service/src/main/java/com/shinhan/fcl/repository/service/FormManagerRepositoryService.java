/**
 * 
 */
package com.shinhan.fcl.repository.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.repository.entity.TOmsFCLFormInf;

/**
 * @author shds01
 *
 */
public interface FormManagerRepositoryService {
	
	public List<EarlyTerminationTrx> getListFormAvailable(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countFormAvailableTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public TOmsFCLFormInf getTrxByLoanNo(String loanNo) throws ServiceRuntimeException;
	
	public boolean createAll(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<Object[]> exportReportFormAvaiableTrx(String startDt, String endDt) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
}
