/**
 * 
 */
package com.shinhan.fcl.integration.soap.model;

/**
 * @author shds01
 *
 */
public class ResponseData {

	private Message Message;

	/**
	 * 
	 */
	public ResponseData() {
		super();
	}

	/**
	 * @return the message
	 */
	public Message getMessage() {
		return Message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(Message message) {
		Message = message;
	}

}
