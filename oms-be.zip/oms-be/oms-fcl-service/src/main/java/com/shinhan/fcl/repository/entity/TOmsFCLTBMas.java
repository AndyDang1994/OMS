/**
 * 
 */
package com.shinhan.fcl.repository.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author shds01
 *
 */
@Entity
@Table(name = "OMS_FCL_TB_MAS")
public class TOmsFCLTBMas implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4844757815682197418L;

	private String loan_no;
	private String loan_status;
	private String cif;
	private String customer_name;
	private BigDecimal principal_bal;
	private BigDecimal total_to_pay;
	private BigDecimal total_payment_received;
	private BigDecimal interest_amount;
	private BigDecimal last_change_amount;
	private BigDecimal overdue_fee;
	private BigDecimal total_waiveoff_amount;
	private String term_status;
	private Date last_due_date;
	private String waive_off_status;
	private BigDecimal repayment_amount;
	private BigDecimal penalty_fees;
	
	private Date effective_dt;
	private String statusCode;

	private String createdUser;
	private Date createdDt;
	private String updatedUser;
	private Date updatedDt;

	/**
	 * 
	 */
	public TOmsFCLTBMas() {
		super();
	}

	/**
	 * @return the loan_no
	 */
	@Id
	@Column(name = "LOAN_NO")
	public String getLoan_no() {
		return loan_no;
	}

	/**
	 * @param loan_no the loan_no to set
	 */
	public void setLoan_no(String loan_no) {
		this.loan_no = loan_no;
	}

	/**
	 * @return the loan_status
	 */
	@Column(name = "LOAN_STATUS")
	public String getLoan_status() {
		return loan_status;
	}

	/**
	 * @param loan_status the loan_status to set
	 */
	public void setLoan_status(String loan_status) {
		this.loan_status = loan_status;
	}

	/**
	 * @return the cif
	 */
	@Column(name = "CIF")
	public String getCif() {
		return cif;
	}

	/**
	 * @param cif the cif to set
	 */
	public void setCif(String cif) {
		this.cif = cif;
	}

	/**
	 * @return the customer_name
	 */
	@Column(name = "CUSTOMER_NAME")
	public String getCustomer_name() {
		return customer_name;
	}

	/**
	 * @param customer_name the customer_name to set
	 */
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	/**
	 * @return the principal_bal
	 */
	@Column(name = "PRINCIPAL_BAL")
	public BigDecimal getPrincipal_bal() {
		return principal_bal;
	}

	/**
	 * @param principal_bal the principal_bal to set
	 */
	public void setPrincipal_bal(BigDecimal principal_bal) {
		this.principal_bal = principal_bal;
	}

	/**
	 * @return the total_to_pay
	 */
	@Column(name = "TOTAL_TO_PAY")
	public BigDecimal getTotal_to_pay() {
		return total_to_pay;
	}

	/**
	 * @param total_to_pay the total_to_pay to set
	 */
	public void setTotal_to_pay(BigDecimal total_to_pay) {
		this.total_to_pay = total_to_pay;
	}

	/**
	 * @return the total_payment_received
	 */
	@Column(name = "TOTAL_PAYMENT_RECEIVED")
	public BigDecimal getTotal_payment_received() {
		return total_payment_received;
	}

	/**
	 * @param total_payment_received the total_payment_received to set
	 */
	public void setTotal_payment_received(BigDecimal total_payment_received) {
		this.total_payment_received = total_payment_received;
	}

	/**
	 * @return the interest_amount
	 */
	@Column(name = "INTEREST_AMOUNT")
	public BigDecimal getInterest_amount() {
		return interest_amount;
	}

	/**
	 * @param interest_amount the interest_amount to set
	 */
	public void setInterest_amount(BigDecimal interest_amount) {
		this.interest_amount = interest_amount;
	}

	/**
	 * @return the last_change_amount
	 */
	@Column(name = "LAST_CHANGE_AMOUNT")
	public BigDecimal getLast_change_amount() {
		return last_change_amount;
	}

	/**
	 * @param last_change_amount the last_change_amount to set
	 */
	public void setLast_change_amount(BigDecimal last_change_amount) {
		this.last_change_amount = last_change_amount;
	}

	/**
	 * @return the overdue_fee
	 */
	@Column(name = "OVERDUE_FEE")
	public BigDecimal getOverdue_fee() {
		return overdue_fee;
	}

	/**
	 * @param overdue_fee the overdue_fee to set
	 */
	public void setOverdue_fee(BigDecimal overdue_fee) {
		this.overdue_fee = overdue_fee;
	}

	/**
	 * @return the total_waiveoff_amount
	 */
	@Column(name = "TOTAL_WAIVEOFF_AMOUNT")
	public BigDecimal getTotal_waiveoff_amount() {
		return total_waiveoff_amount;
	}

	/**
	 * @param total_waiveoff_amount the total_waiveoff_amount to set
	 */
	public void setTotal_waiveoff_amount(BigDecimal total_waiveoff_amount) {
		this.total_waiveoff_amount = total_waiveoff_amount;
	}

	/**
	 * @return the term_status
	 */
	@Column(name = "TERM_STATUS")
	public String getTerm_status() {
		return term_status;
	}

	/**
	 * @param term_status the term_status to set
	 */
	public void setTerm_status(String term_status) {
		this.term_status = term_status;
	}

	/**
	 * @return the last_due_date
	 */
	@Column(name = "LAST_DUE_DATE")
	public Date getLast_due_date() {
		return last_due_date;
	}

	/**
	 * @param last_due_date the last_due_date to set
	 */
	public void setLast_due_date(Date last_due_date) {
		this.last_due_date = last_due_date;
	}

	/**
	 * @return the waive_off_status
	 */
	@Column(name = "WAIVE_OFF_STATUS")
	public String getWaive_off_status() {
		return waive_off_status;
	}

	/**
	 * @param waive_off_status the waive_off_status to set
	 */
	public void setWaive_off_status(String waive_off_status) {
		this.waive_off_status = waive_off_status;
	}

	/**
	 * @return the repayment_amount
	 */
	@Column(name = "REPAYMENT_AMOUNT")
	public BigDecimal getRepayment_amount() {
		return repayment_amount;
	}

	/**
	 * @param repayment_amount the repayment_amount to set
	 */
	public void setRepayment_amount(BigDecimal repayment_amount) {
		this.repayment_amount = repayment_amount;
	}

	/**
	 * @return the penalty_fees
	 */
	@Column(name = "PENALTY_FEES")
	public BigDecimal getPenalty_fees() {
		return penalty_fees;
	}

	/**
	 * @param penalty_fees the penalty_fees to set
	 */
	public void setPenalty_fees(BigDecimal penalty_fees) {
		this.penalty_fees = penalty_fees;
	}

	/**
	 * @return the effective_dt
	 */
	@Column(name = "EFFECTIVE_DT")
	public Date getEffective_dt() {
		return effective_dt;
	}

	/**
	 * @param effective_dt the effective_dt to set
	 */
	public void setEffective_dt(Date effective_dt) {
		this.effective_dt = effective_dt;
	}

	/**
	 * @return the statusCode
	 */
	@Column(name = "STATUS_CODE")
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * @return the createdUser
	 */
	@Column(name = "REGIS_INF_USER")
	public String getCreatedUser() {
		return createdUser;
	}

	/**
	 * @param createdUser the createdUser to set
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	/**
	 * @return the createdDt
	 */
	@Column(name = "REGIS_INF_DT")
	public Date getCreatedDt() {
		return createdDt;
	}

	/**
	 * @param createdDt the createdDt to set
	 */
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	/**
	 * @return the updatedUser
	 */
	@Column(name = "LCHG_INF_USER")
	public String getUpdatedUser() {
		return updatedUser;
	}

	/**
	 * @param updatedUser the updatedUser to set
	 */
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}

	/**
	 * @return the updatedDt
	 */
	@Column(name = "LCHG_INF_DT")
	public Date getUpdatedDt() {
		return updatedDt;
	}

	/**
	 * @param updatedDt the updatedDt to set
	 */
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TOmsFCLTBMas [loan_no=" + loan_no + ", loan_status=" + loan_status + ", cif=" + cif + ", effective_dt="
				+ effective_dt + ", statusCode=" + statusCode + "]";
	}

}
