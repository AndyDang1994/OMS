/**
 * 
 */
package com.shinhan.fcl.repository.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author shds01
 *
 */
@Entity
@Table(name = "OMS_FCL_MATURITY_INF")
public class TOmsFCLMaturityInf implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String loan_no;
	private String status_code;
	private BigDecimal excess_amount; //rpa amount
	
	private String createdUser;
	private Date createdDt;
	private String updatedUser;
	private Date updatedDt;

	/**
	 * 
	 */
	public TOmsFCLMaturityInf() {
		super();
	}

	/**
	 * @param loanNo
	 * @param statusCode
	 * @param createdUser
	 * @param createdDt
	 * @param updatedUser
	 * @param updatedDt
	 */
	public TOmsFCLMaturityInf(String loan_no, String status_code, String createdUser, Date createdDt, String updatedUser,
			Date updatedDt) {
		super();
		this.loan_no = loan_no;
		this.status_code = status_code;
		this.createdUser = createdUser;
		this.createdDt = createdDt;
		this.updatedUser = updatedUser;
		this.updatedDt = updatedDt;
	}

	/**
	 * @return the loan_no
	 */
	@Id
	@Column(name = "LOAN_NO")
	public String getLoan_no() {
		return loan_no;
	}

	/**
	 * @param loan_no the loan_no to set
	 */
	public void setLoan_no(String loan_no) {
		this.loan_no = loan_no;
	}

	/**
	 * @return the status_code
	 */
	@Column(name = "STATUS_CODE")
	public String getStatus_code() {
		return status_code;
	}

	/**
	 * @param status_code the status_code to set
	 */
	public void setStatus_code(String status_code) {
		this.status_code = status_code;
	}

	/**
	 * @return the excess_amount
	 */
	 @Column(name = "EXCESS_AMOUNT")
	 public BigDecimal getExcess_amount() {
		return excess_amount;
	}

	/**
	 * @param excess_amount the excess_amount to set
	 */
	public void setExcess_amount(BigDecimal excess_amount) {
		this.excess_amount = excess_amount;
	}

	/**
	 * @return the createdUser
	 */
	@Column(name = "REGIS_INF_USER")
	public String getCreatedUser() {
		return createdUser;
	}

	/**
	 * @param createdUser the createdUser to set
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	/**
	 * @return the createdDt
	 */
	@Column(name = "REGIS_INF_DT")
	public Date getCreatedDt() {
		return createdDt;
	}

	/**
	 * @param createdDt the createdDt to set
	 */
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	/**
	 * @return the updatedUser
	 */
	@Column(name = "LCHG_INF_USER")
	public String getUpdatedUser() {
		return updatedUser;
	}

	/**
	 * @param updatedUser the updatedUser to set
	 */
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}

	/**
	 * @return the updatedDt
	 */
	@Column(name = "LCHG_INF_DT")
	public Date getUpdatedDt() {
		return updatedDt;
	}

	/**
	 * @param updatedDt the updatedDt to set
	 */
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

}
