/**
 * 
 */
package com.shinhan.fcl.integration.soap.model;

import com.google.gson.JsonElement;

/**
 * @author shds01
 *
 */
public class Elements {
	private JsonElement ELEMENT;

	/**
	 * 
	 */
	public Elements() {
		super();
	}

	/**
	 * @return the eLEMENT
	 */
	public Object getELEMENT() {
		return ELEMENT;
	}

	/**
	 * @param eLEMENT the eLEMENT to set
	 */
	public void setELEMENT(JsonElement eLEMENT) {
		ELEMENT = eLEMENT;
	}

}
