/**
 * 
 */
package com.shinhan.fcl.core.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.core.env.Environment;

import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.DummyDocumentTrx;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.model.WaiveOffDocumentTrx;
import com.shinhan.fcl.integration.soap.model.Element;
import com.shinhan.fcl.repository.entity.TOmsFCLFollowEMIInf;
import com.shinhan.fcl.repository.entity.TOmsFCLFormInf;
import com.shinhan.fcl.repository.entity.TOmsFCLFormPaymentInf;
import com.shinhan.fcl.repository.entity.TOmsFCLFormPaymentMas;
import com.shinhan.fcl.repository.entity.TOmsFCLMaturityInf;
import com.shinhan.fcl.repository.entity.TOmsFCLMaturityMas;
import com.shinhan.fcl.repository.entity.TOmsFCLPaymentInf;
import com.shinhan.fcl.repository.entity.TOmsFCLTBInf;
import com.shinhan.fcl.repository.entity.TOmsFCLTBMas;

/**
 * @author shds01
 *
 */
public class DTOConverter {

	public static List<?> convertSettoList(Set<?> sets) throws ServiceRuntimeException {
		List<?> list = new ArrayList<>(sets);
		return list;
	}
	
	public static void populateDataMaturityExecuteWaive(EarlyTerminationTrx trx, TOmsFCLMaturityMas mas) {
		trx.setCif(mas.getCif());
		
		trx.setRepayment_amount(mas.getRepayment_amount());
		trx.setPenalty_fees(mas.getPenalty_fees());
		
		trx.setInterest_amount(mas.getInterest_amount());
		trx.setLast_change_amount(mas.getLast_change_amount());
		trx.setOverdue_fee(mas.getOverdue_fee());
	}
	
	public static void populateDataExecuteWaiveTB(EarlyTerminationTrx trx, TOmsFCLTBMas mas) {
		trx.setCif(mas.getCif());
		
		trx.setRepayment_amount(mas.getRepayment_amount());
		trx.setPenalty_fees(mas.getPenalty_fees());
		
		trx.setInterest_amount(mas.getInterest_amount());
		trx.setLast_change_amount(mas.getLast_change_amount());
		trx.setOverdue_fee(mas.getOverdue_fee());
	}
	
	public static void populateDataExecuteWaiveFormPayment(EarlyTerminationTrx trx, TOmsFCLFormPaymentMas mas) {
		trx.setCif(mas.getCif());
		
		trx.setRepayment_amount(mas.getRepayment_amount());
		trx.setPenalty_fees(mas.getPenalty_fees());
		
		trx.setInterest_amount(mas.getInterest_amount());
		trx.setLast_change_amount(mas.getLast_change_amount());
		trx.setOverdue_fee(mas.getOverdue_fee());
	}
	
	public static WaiveOffDocumentTrx populateDataExecuteWaiveForWaiveOffDocumentTrx(EarlyTerminationTrx trx) {
		WaiveOffDocumentTrx doc = new WaiveOffDocumentTrx(trx.getLoan_no(), trx.getCif(), DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		
		BigDecimal int_amt_original = trx.getInterest_amount() == null ? APIConstant.DEC_ZERO : trx.getInterest_amount();
		BigDecimal lpp_amt_original = trx.getLast_change_amount() == null ? APIConstant.DEC_ZERO : trx.getLast_change_amount();
		BigDecimal odf_amt_original = trx.getOverdue_fee() == null ? APIConstant.DEC_ZERO : trx.getOverdue_fee();
		BigDecimal repayment_amt_original = trx.getRepayment_amount() == null ? APIConstant.DEC_ZERO : trx.getRepayment_amount();
		BigDecimal penalty_fees_original = trx.getPenalty_fees() == null ? APIConstant.DEC_ZERO : trx.getPenalty_fees();
		
		BigDecimal total_waiveOff = int_amt_original.add(lpp_amt_original).add(odf_amt_original);
		BigDecimal total_repayment = repayment_amt_original.subtract(penalty_fees_original);
		
		if(total_waiveOff.compareTo(total_repayment) <= 0 ) {
			//Set original no need to calculate
			doc.setLpp_amt(CommonUtil.writeDecimal(lpp_amt_original.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
			doc.setInt_amt(CommonUtil.writeDecimal(int_amt_original.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
			doc.setOverdue_amt(CommonUtil.writeDecimal(odf_amt_original.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
			
			doc.setTotal_amt(CommonUtil.writeDecimal(total_waiveOff.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
		} else {
			if(lpp_amt_original.compareTo(total_repayment) >= 0) {
				//Set new lpp = total_repayment, another is zero
				doc.setLpp_amt(CommonUtil.writeDecimal(total_repayment.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
				doc.setInt_amt(CommonUtil.writeDecimal(APIConstant.DEC_ZERO.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
				doc.setOverdue_amt(CommonUtil.writeDecimal(APIConstant.DEC_ZERO.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
				
				doc.setTotal_amt(doc.getLpp_amt());
			} else {
				if(lpp_amt_original.add(odf_amt_original).compareTo(total_repayment) >= 0) {
					//Set new lpp = current lpp, new odf = total_repayment - lpp, int = zero
					doc.setLpp_amt(CommonUtil.writeDecimal(lpp_amt_original.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
					doc.setOverdue_amt(CommonUtil.writeDecimal(total_repayment.subtract(lpp_amt_original).doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
					doc.setInt_amt(CommonUtil.writeDecimal(APIConstant.DEC_ZERO.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
					
					doc.setTotal_amt(CommonUtil.writeDecimal(total_repayment.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
				} else {
					//Set new lpp = current lpp, new odf = current odf, int = total_repayment - lpp - odf
					doc.setLpp_amt(CommonUtil.writeDecimal(lpp_amt_original.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
					doc.setInt_amt(CommonUtil.writeDecimal(total_repayment.subtract(lpp_amt_original).subtract(odf_amt_original).doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
					doc.setOverdue_amt(CommonUtil.writeDecimal(odf_amt_original.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
					
					doc.setTotal_amt(CommonUtil.writeDecimal(total_repayment.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
				}
			}
		}
		
		return doc;
	}
	
	public static DummyDocumentTrx populateDataExecuteDummyForDummyDocumentTrx(EarlyTerminationTrx trx, boolean isWaive, String userName) {
		DummyDocumentTrx doc = new DummyDocumentTrx(trx.getLoan_no(), APIConstant.DUMMY_DOCUMENT_DUMMY_BANK_FOR_FORECLOSURE,
				DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), userName);
		
		if(isWaive) {
			/** Is Waive off already */
			//pmt_amt = Interest Amount (INT Amount) + Last change Amount (LPP Amount)
			BigDecimal int_amt_original = trx.getInterest_amount();
			BigDecimal lpp_amt_original = trx.getLast_change_amount();
			BigDecimal pmt_amt = int_amt_original.add(lpp_amt_original);
			doc.setPmt_amt(CommonUtil.writeDecimal(pmt_amt.doubleValue(), APIConstant.FORMAT_FACTOR).replace(APIConstant.DOT, APIConstant.BLANK_KEY));
			
			//ref = WAIVEFCL + Loan no
			String ref = "";
			if(APIConstant.DEC_ZERO.compareTo(int_amt_original) == 0 && APIConstant.DEC_ZERO.compareTo(int_amt_original) == 0) {
				ref = APIConstant.DUMMY_DOCUMENT_WAIVEINT + trx.getLoan_no();
			} else if(APIConstant.DEC_ZERO.compareTo(int_amt_original) != 0 && APIConstant.DEC_ZERO.compareTo(int_amt_original) != 0) {
				ref = APIConstant.DUMMY_DOCUMENT_WAIVELPPINT + trx.getLoan_no();
			} else {
				ref = APIConstant.DUMMY_DOCUMENT_WAIVELPP + trx.getLoan_no();
			}
			doc.setRef(ref);
		} else {
			/** Not Waive off yet */
			//pmt_amt = re-payment amt
			if(trx.getRepayment_amount() == null) {
				doc.setPmt_amt(APIConstant.ZERO_STRING);
			}else {
				doc.setPmt_amt(CommonUtil.writeDecimal(trx.getRepayment_amount().doubleValue(), APIConstant.FORMAT_FACTOR).replace(APIConstant.DOT, APIConstant.BLANK_KEY));
			}
			//ref = WAIVEFCL + Loan no
			doc.setRef(APIConstant.DUMMY_DOCUMENT_WAIVEFCL + trx.getLoan_no());
		}
		
		return doc;
	}

	public static TOmsFCLFollowEMIInf populateDataUpdateNoteFollowUpEMINew(EarlyTerminationTrx trx, String userName) {
		TOmsFCLFollowEMIInf inf = new TOmsFCLFollowEMIInf();
		
		inf.setRef_id(trx.getId());
		inf.setStatus_code(trx.getFollowup_note());
		inf.setRemarks(trx.getRemarks());
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsFCLFollowEMIInf populateDataUpdateNoteFollowUpEMIUpdate(EarlyTerminationTrx trx, TOmsFCLFollowEMIInf inf, String userName) {
		
		inf.setStatus_code(trx.getFollowup_note());
		inf.setRemarks(trx.getRemarks());
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsFCLMaturityInf populateDataExecuteWaiveMaturityWaiveOffIncNew(EarlyTerminationTrx trx, String userName) {
		TOmsFCLMaturityInf inf = new TOmsFCLMaturityInf();
		
		inf.setLoan_no(trx.getLoan_no());
		
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_WAIVEOFF_VALUE);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsFCLMaturityInf populateDataExecuteDoneMaturityBookIncNew(EarlyTerminationTrx trx, String userName) {
		TOmsFCLMaturityInf inf = new TOmsFCLMaturityInf();
		
		inf.setLoan_no(trx.getLoan_no());
		
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static void populateDataExecuteDoneMaturityBookIncUpdate(TOmsFCLMaturityInf inf, String userName) {
		
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
	}
	
	public static TOmsFCLMaturityInf populateDataExecuteDoneMaturityRefundNew(EarlyTerminationTrx trx, String userName) {
		TOmsFCLMaturityInf inf = new TOmsFCLMaturityInf();
		
		inf.setLoan_no(trx.getLoan_no());
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE);
		inf.setExcess_amount(trx.getExcess_amount());//Tracking for report
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		
		return inf;
	}
	
	public static void populateDataExecuteDoneMaturityRefundUpdate(TOmsFCLMaturityInf inf, EarlyTerminationTrx trx, String userName) {
		
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE);
		inf.setExcess_amount(trx.getExcess_amount());//Tracking for report
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
	}
	
	public static TOmsFCLTBMas populateDataFromElementToTB6(Element element) throws ServiceRuntimeException{
		TOmsFCLTBMas mas = new TOmsFCLTBMas();
		
		mas.setLoan_no(element.getLOAN_ID());
		mas.setLoan_status("");//TODO
		mas.setCif(element.getCIF());
		mas.setCustomer_name(element.getCUST_NAME());
		
		mas.setPrincipal_bal(CommonUtil.parseStrToBigDecimal(element.getPRINCIPAL()));
		
		mas.setTotal_to_pay(CommonUtil.parseStrToBigDecimal(element.getTOTAL_TO_PAY()));
		
		mas.setTotal_payment_received(CommonUtil.parseStrToBigDecimal(element.getTOTAL_PMT_RECEIVED()));
		
		mas.setInterest_amount(CommonUtil.parseStrToBigDecimal(element.getINT()));
		
		mas.setLast_change_amount(CommonUtil.parseStrToBigDecimal(element.getLPP()));
		
		mas.setOverdue_fee(CommonUtil.parseStrToBigDecimal(element.getODF()));
		
		mas.setTotal_waiveoff_amount(CommonUtil.parseStrToBigDecimal(element.getTOTAL_WAIVE_OFF()));
		
		mas.setTerm_status(element.getTERM_STATUS());
		
		if (DateUtils.isValidate(element.getLAST_DUE_DATE().toString())) {
			mas.setLast_due_date(DateUtils.convertDate(element.getLAST_DUE_DATE().toString(),
					DateUtils.getValidFormat(element.getLAST_DUE_DATE().toString()), DateUtils.DATEFORMAT, false));
		}
		
		mas.setWaive_off_status(element.getWAIVE_OFF());
		
		mas.setRepayment_amount(CommonUtil.parseStrToBigDecimal(element.getREPAYMENT_AMOUNT()));
		
		mas.setPenalty_fees(CommonUtil.parseStrToBigDecimal(element.getPL_EARLY_SETTLE()));
		
		mas.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		mas.setCreatedUser(APIConstant.MIGRATE_BATCH_USER);
		mas.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		mas.setUpdatedUser(APIConstant.MIGRATE_BATCH_USER);
		
		return mas;
	}
	
	public static void populateListDataFailToScanTB6(List<TOmsFCLTBInf> infs) throws ServiceRuntimeException{
		for(TOmsFCLTBInf inf :infs) {
			populateDataFailToScanTB6(inf);
		}
	}
	
	public static void populateDataFailToScanTB6(TOmsFCLTBInf inf) throws ServiceRuntimeException{
		
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_NOT_FOUND_VALUE);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(APIConstant.MIGRATE_BATCH_USER);
	}
	
	public static void populateDataSuccesToScanTB6(TOmsFCLTBInf inf) throws ServiceRuntimeException{
		
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setStatus_code(APIConstant.BLANK_KEY);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(APIConstant.MIGRATE_BATCH_USER);
	}
	
	public static EarlyTerminationTrx convertToUploadTB6(Map mapObject, Environment env) throws ServiceRuntimeException{
		EarlyTerminationTrx item = new EarlyTerminationTrx();
		
		item.setLoan_no(
				mapObject.get(env.getProperty("import.fcl.tb6.loanNo")) != null ? 
						mapObject.get(env.getProperty("import.fcl.tb6.loanNo")).toString() : 
							APIConstant.BLANK_KEY);
		return item;
	}
	
	public static TOmsFCLTBInf populateDataUploadTBNew(EarlyTerminationTrx trx, String userName) {
		TOmsFCLTBInf inf = new TOmsFCLTBInf();
		
		inf.setLoan_no(trx.getLoan_no());
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_INITIAL_VALUE);
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static void populateDataUpdateRemarkTB(TOmsFCLTBInf inf, String userName, String remarks) {
		
		inf.setRemarks(remarks);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
	}
	
	public static void populateDataExecuteDoneTB(TOmsFCLTBInf inf, String userName) {
		
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE);
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
	}
	
	public static void populateDataExecuteRemoveTB(TOmsFCLTBInf inf, String userName) {
		
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_REMOVE_VALUE);
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
	}
	
	public static void populateDataExecuteUnRemoveTB(TOmsFCLTBInf inf, String userName) {
		inf.setStatus_code("");
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
	}
	
	public static void populateDataExecuteWaiveTB(TOmsFCLTBInf inf, String userName) {
		
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_WAIVEOFF_VALUE);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
	}
	
	public static void populateDataExecuteDummyTB(TOmsFCLTBInf inf, String userName) {
		
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DUMMY_VALUE);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
	}
	
	public static TOmsFCLPaymentInf populateDataExecuteRemovePaymentNew(String loanNo, String userName) {
		TOmsFCLPaymentInf inf = new TOmsFCLPaymentInf();
		inf.setLoan_no(loanNo);
		
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_REMOVE_VALUE);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static void populateDataExecuteRemovePayment(TOmsFCLPaymentInf inf, String userName) {
		
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_REMOVE_VALUE);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
	}
	
	public static TOmsFCLPaymentInf populateDataExecuteETPaymentNew(String loanNo, String userName) {
		TOmsFCLPaymentInf inf = new TOmsFCLPaymentInf();
		inf.setLoan_no(loanNo);
		
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_ET_VALUE);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		
		return inf;
	}
	
	public static void populateDataExecuteETPayment(TOmsFCLPaymentInf inf, String userName) {
		
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_ET_VALUE);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		
	}
	
	public static TOmsFCLPaymentInf populateDataUpdateRemarkPaymentNew(String loanNo, String userName, String remarks) {
		TOmsFCLPaymentInf inf = new TOmsFCLPaymentInf();
		inf.setLoan_no(loanNo);
		
		inf.setRemarks(remarks);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);

		return inf;
	}
	
	public static TOmsFCLPaymentInf populateDataUpdateRemarkPayment(TOmsFCLPaymentInf inf, String userName, String remarks) {
		
		inf.setRemarks(remarks);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsFCLFormPaymentInf populateDataExecuteETFormPayment(String loanNo, String userName) {
		TOmsFCLFormPaymentInf inf = new TOmsFCLFormPaymentInf();
		inf.setLoan_no(loanNo);
		inf.setEtCode(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_ET_VALUE);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsFCLFormInf populateDataExecuteRemoveFormNew(String loanNo, String userName) {
		TOmsFCLFormInf inf = new TOmsFCLFormInf();
		inf.setLoan_no(loanNo);
		
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_REMOVE_VALUE);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static void populateDataExecuteRemoveForm(TOmsFCLFormInf inf, String userName) {
		
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_REMOVE_VALUE);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
	}
	
	public static void populateDataExecuteUnRemoveForm(TOmsFCLFormInf inf, String userName) {
		inf.setStatus_code("");
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
	}
	
	public static TOmsFCLFormInf populateDataExecuteETFormNew(String loanNo, String userName) {
		TOmsFCLFormInf inf = new TOmsFCLFormInf();
		inf.setLoan_no(loanNo);
		
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_ET_VALUE);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static void populateDataExecuteETForm(TOmsFCLFormInf inf, String userName) {
		
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_ET_VALUE);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
	}
	
	public static TOmsFCLFormInf populateDataExecuteWaiveFormNew(String loanNo, String userName) {
		TOmsFCLFormInf inf = new TOmsFCLFormInf();
		inf.setLoan_no(loanNo);
		
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_WAIVEOFF_VALUE);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static void populateDataExecuteWaiveForm(TOmsFCLFormInf inf, String userName) {
		
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_WAIVEOFF_VALUE);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
	}
	
	public static TOmsFCLFormInf populateDataUpdateRemarkFormNew(String loanNo, String userName, String remarks) {
		TOmsFCLFormInf inf = new TOmsFCLFormInf();
		inf.setLoan_no(loanNo);

		inf.setRemarks(remarks);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static void populateDataUpdateRemarkForm(TOmsFCLFormInf inf, String userName, String remarks) {
		inf.setRemarks(remarks);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
	}
	
	public static TOmsFCLFormPaymentInf initDataExecuteDoneFormPaymentNew(String loanNo, String userName) {
		TOmsFCLFormPaymentInf inf = new TOmsFCLFormPaymentInf();
		inf.setLoan_no(loanNo);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static void populateDataExecuteDoneFormPayment(TOmsFCLFormPaymentInf inf, String userName) {
		
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
	}
	
	public static void populateDataExecuteCheckedFormPayment(TOmsFCLFormPaymentInf inf, String userName) {
		
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_CHECKED_VALUE);
		
		inf.setChecked_dt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setChecked_user(userName);
	}
	
	public static TOmsFCLFormPaymentInf populateDataExecuteWaiveFormPaymentNew(String loanNo, String userName) {
		TOmsFCLFormPaymentInf inf = new TOmsFCLFormPaymentInf();
		inf.setLoan_no(loanNo);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static void populateDataExecuteWaiveFormPayment(TOmsFCLFormPaymentInf inf, String userName) {
		
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_WAIVEOFF_VALUE);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
	}
	
	public static TOmsFCLFormPaymentInf populateDataExecuteDummyFormPaymentNew(String loanNo, String userName) {
		TOmsFCLFormPaymentInf inf = new TOmsFCLFormPaymentInf();
		inf.setLoan_no(loanNo);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static void populateDataExecuteDummyFormPayment(TOmsFCLFormPaymentInf inf, String userName) {
		
		inf.setEffective_dt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setStatus_code(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DUMMY_VALUE);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
	}
}