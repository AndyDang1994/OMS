/**
 * 
 */
package com.shinhan.fcl.common;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.util.DTOConverter;
import com.shinhan.fcl.repository.entity.TMetadata;
import com.shinhan.fcl.repository.entity.TOmsFCLFollowEMIInf;
import com.shinhan.fcl.repository.entity.TOmsFCLFollowEMIMas;
import com.shinhan.fcl.repository.entity.TOmsFCLFormInf;
import com.shinhan.fcl.repository.entity.TOmsFCLFormPaymentInf;
import com.shinhan.fcl.repository.entity.TOmsFCLFormPaymentMas;
import com.shinhan.fcl.repository.entity.TOmsFCLMaturityInf;
import com.shinhan.fcl.repository.entity.TOmsFCLMaturityMas;
import com.shinhan.fcl.repository.entity.TOmsFCLPaymentInf;
import com.shinhan.fcl.repository.entity.TOmsFCLTBInf;
import com.shinhan.fcl.repository.entity.TOmsFCLTBMas;

/**
 * @author shds01
 *
 */
@Service("validationManagerService")
public class ValidationManagerService extends AbstractRepositoryClass {

	public TOmsFCLFollowEMIInf checkValidationUpdateNoteFollowUpEMI(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no()) 
				|| ("".equalsIgnoreCase(trx.getFollowup_note()) && "".equalsIgnoreCase(trx.getRemarks())) ) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFollowEMIMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLFollowMasTrxById(trx.getId());
			if(mas == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check Metadata Follow up note
		if(StringUtils.isBlank(error) && StringUtils.isNotBlank(trx.getFollowup_note())) {
			TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_FOLLOWUP_EMI_NOTE, trx.getFollowup_note());
			if(item == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getFollowup_note());
			}
		}
		//Check in DB
		if(StringUtils.isBlank(error)) {
			if(trx.getRef_id() == null) {
				return null;
			}
			TOmsFCLFollowEMIInf inf = getRepositoryManagerService().getFollowUpManagerRepositoryService().getFollowUpEMITrxById(trx.getRef_id());
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLMaturityInf checkValidationExecuteWaiveMaturityWaiveOff(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLMaturityMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLMaturityMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null || (APIConstant.FCL_CATEGORY_MATURITY_WAIVEOFF.equalsIgnoreCase(mas.getFcl_category()) == false)) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			} else {
				DTOConverter.populateDataMaturityExecuteWaive(trx, mas);
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLMaturityInf inf = getRepositoryManagerService().getMaturityManagerRepositoryService().getMaturityTrxByLoanNo(trx.getLoan_no());
			if(inf != null && 
					(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_WAIVEOFF_VALUE.equalsIgnoreCase(inf.getStatus_code()) || APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE.equalsIgnoreCase(inf.getStatus_code()))
			) {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_005"), String.valueOf(trx.getLoan_no())));
			}
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLMaturityInf checkValidationExecuteDoneMaturityBookInc(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLMaturityMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLMaturityMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null || (APIConstant.FCL_CATEGORY_MATURITY_BOOK_INC.equalsIgnoreCase(mas.getFcl_category()) == false)) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLMaturityInf inf = getRepositoryManagerService().getMaturityManagerRepositoryService().getMaturityTrxByLoanNo(trx.getLoan_no());
			if(inf != null && APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE.equalsIgnoreCase(inf.getStatus_code())) {
				error = String.format(env.getProperty("MSG_014"), trx.getLoan_no());
				trx.setErrorMessage(error);
			}
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLMaturityInf checkValidationExecuteDoneMaturityRefund(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLMaturityMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLMaturityMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null || (APIConstant.FCL_CATEGORY_MATURITY_REFUND.equalsIgnoreCase(mas.getFcl_category()) == false)) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}else {
				trx.setExcess_amount(mas.getExcess_amount());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLMaturityInf inf = getRepositoryManagerService().getMaturityManagerRepositoryService().getMaturityTrxByLoanNo(trx.getLoan_no());
			if(inf != null && APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE.equalsIgnoreCase(inf.getStatus_code())) {
				error = String.format(env.getProperty("MSG_014"), trx.getLoan_no());
				trx.setErrorMessage(error);
			}
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLTBInf checkValidationUploadTB6(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			throw new ServiceRuntimeException(env.getProperty("MSG_001"));
		}
		
		//Check in DB
		TOmsFCLTBMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLTBMasTrxByLoanNo(trx.getLoan_no());
		if(mas != null) {
			throw new ServiceRuntimeException(String.format(env.getProperty("MSG_006"), trx.getLoan_no()));
		}
		
		//Check in DB
		TOmsFCLTBInf inf = getRepositoryManagerService().getTbManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
		if(inf == null) {
			return null;
		}
		
		throw new ServiceRuntimeException(String.format(env.getProperty("MSG_006"), trx.getLoan_no()));
	}
	
	public TOmsFCLTBInf checkValidationUpdateRemarkTB(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLTBMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLTBMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			return getRepositoryManagerService().getTbManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLTBInf checkValidationExecuteDoneTB(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLTBMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLTBMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			return getRepositoryManagerService().getTbManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLTBInf checkValidationExecuteRemoveTB(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLTBMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLTBMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			return getRepositoryManagerService().getTbManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLTBInf checkValidationExecuteUnRemoveTB(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLTBMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLTBMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLTBInf inf = getRepositoryManagerService().getTbManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
			if(inf == null) {
				error = String.format(env.getProperty("MSG_013"), trx.getLoan_no());
			} else {
				if(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_REMOVE_VALUE.equalsIgnoreCase(inf.getStatus_code()) == false ){
					error = String.format(env.getProperty("MSG_013"), trx.getLoan_no());
				}
			}
			trx.setErrorMessage(error);
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLTBInf checkValidationExecuteWaiveTB(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLTBMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLTBMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			} else {
				DTOConverter.populateDataExecuteWaiveTB(trx, mas);
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLTBInf inf = getRepositoryManagerService().getTbManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
			if(inf == null) {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_007"), String.valueOf(trx.getLoan_no())));
			} else if(inf != null && StringUtils.isNotBlank(inf.getStatus_code())) {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_005"), String.valueOf(trx.getLoan_no())));
			}
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLTBInf checkValidationExecuteDummyTB(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLTBMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLTBMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLTBInf inf = getRepositoryManagerService().getTbManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
			if(inf == null) {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_007"), String.valueOf(trx.getLoan_no())));
			} else if(inf != null && 
					(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DUMMY_VALUE.equalsIgnoreCase(inf.getStatus_code()) 
							|| APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_REMOVE_VALUE.equalsIgnoreCase(inf.getStatus_code())
							|| APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE.equalsIgnoreCase(inf.getStatus_code())
					)
			) {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_005"), String.valueOf(trx.getLoan_no())));
			}
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLPaymentInf checkValidationExecuteRemovePayment(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLFormPaymentMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null || (APIConstant.FCL_CATEGORY_FCL_NOT_FORM.equalsIgnoreCase(mas.getFcl_category()) == false) ) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			return getRepositoryManagerService().getPaymentManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLPaymentInf checkValidationExecuteETPayment(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB Mas
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLFormPaymentMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null || (APIConstant.FCL_CATEGORY_FCL_NOT_FORM.equalsIgnoreCase(mas.getFcl_category()) == false) ) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check in DB FormPayment Inf
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentInf formPaymentInf = getRepositoryManagerService().getFormPaymentManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
			if(formPaymentInf != null) {
				error = String.format(env.getProperty("MSG_014"), trx.getLoan_no());
			}
		}
		
		//Check in DB Payment Inf
		if(StringUtils.isBlank(error)) {
			TOmsFCLPaymentInf inf = getRepositoryManagerService().getPaymentManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
			if(inf != null && StringUtils.isNotBlank(inf.getStatus_code())) {
				error = String.format(env.getProperty("MSG_013"), trx.getLoan_no());
			}
			trx.setErrorMessage(error);
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLPaymentInf checkValidationUpdateRemarkPayment(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLFormPaymentMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null || (APIConstant.FCL_CATEGORY_FCL_NOT_FORM.equalsIgnoreCase(mas.getFcl_category()) == false) ) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			return getRepositoryManagerService().getPaymentManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLFormInf checkValidationExecuteRemoveForm(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLFormPaymentMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null || (APIConstant.FCL_CATEGORY_FCL_NOT_MONEY.equalsIgnoreCase(mas.getFcl_category()) == false) ) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormInf inf = getRepositoryManagerService().getFormManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
			if(inf == null) {
				error = String.format(env.getProperty("MSG_013"), trx.getLoan_no());
			} else {
				if(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_REMOVE_VALUE.equalsIgnoreCase(inf.getStatus_code()) == false ){
					error = String.format(env.getProperty("MSG_013"), trx.getLoan_no());
				}
			}
			trx.setErrorMessage(error);
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLFormInf checkValidationExecuteETForm(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLFormPaymentMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null || (APIConstant.FCL_CATEGORY_FCL_NOT_MONEY.equalsIgnoreCase(mas.getFcl_category()) == false) ) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		//Check in DB FormPayment Inf
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentInf formPaymentInf = getRepositoryManagerService().getFormPaymentManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
			if(formPaymentInf != null) {
				error = String.format(env.getProperty("MSG_014"), trx.getLoan_no());
			}
		}
		
		//Check in DB Payment Inf
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormInf inf = getRepositoryManagerService().getFormManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
			if(inf != null 
					&& (APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_ET_VALUE.equalsIgnoreCase(inf.getStatus_code()) 
							|| APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_REMOVE_VALUE.equalsIgnoreCase(inf.getStatus_code())
							|| APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_WAIVEOFF_VALUE.equalsIgnoreCase(inf.getStatus_code()))) {
				error = String.format(env.getProperty("MSG_013"), trx.getLoan_no());
			}
			trx.setErrorMessage(error);
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLFormInf checkValidationExecuteWaiveForm(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLFormPaymentMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			} else {
				DTOConverter.populateDataExecuteWaiveFormPayment(trx, mas);
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormInf inf = getRepositoryManagerService().getFormManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
			if(inf != null && StringUtils.isNotBlank(inf.getStatus_code())) {
				error = String.format(env.getProperty("MSG_013"), trx.getLoan_no());
			}
			trx.setErrorMessage(error);
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLFormInf checkValidationUpdateRemarkForm(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLFormPaymentMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null || (APIConstant.FCL_CATEGORY_FCL_NOT_MONEY.equalsIgnoreCase(mas.getFcl_category()) == false) ) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			return getRepositoryManagerService().getFormManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLFormPaymentInf checkValidationExecuteDoneFormPayment(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLFormPaymentMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentInf inf = getRepositoryManagerService().getFormPaymentManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
			if(inf == null) {
				return null;
			} else if (APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE.equalsIgnoreCase(inf.getStatus_code()) 
					|| APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_CHECKED_VALUE.equalsIgnoreCase(inf.getStatus_code())){
				error = String.format(env.getProperty("MSG_014"), trx.getLoan_no());
			}
			trx.setErrorMessage(error);
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLFormPaymentInf checkValidationExecuteCheckedFormPayment(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentInf inf = getRepositoryManagerService().getFormPaymentManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
			if(inf == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			} else if (APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE.equalsIgnoreCase(inf.getStatus_code()) == false){
				error = String.format(env.getProperty("MSG_014"), trx.getLoan_no());
			}
			trx.setErrorMessage(error);
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLFormPaymentInf checkValidationExecuteWaiveFormPayment(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLFormPaymentMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentInf inf = getRepositoryManagerService().getFormPaymentManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
			if(inf == null) {
				//throw new ServiceRuntimeException(String.format(env.getProperty("MSG_007"), String.valueOf(trx.getLoan_no())));
				return null;
			} else if (inf != null 
					&& (APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE.equalsIgnoreCase(inf.getStatus_code()) 
							|| APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_CHECKED_VALUE.equalsIgnoreCase(inf.getStatus_code()))
			){
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_013"), String.valueOf(trx.getLoan_no())));
			}
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLFormPaymentInf checkValidationExecuteDummyFormPayment(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLFormPaymentMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFormPaymentInf inf = getRepositoryManagerService().getFormPaymentManagerRepositoryService().getTrxByLoanNo(trx.getLoan_no());
			if(inf == null) {
				//throw new ServiceRuntimeException(String.format(env.getProperty("MSG_007"), String.valueOf(trx.getLoan_no())));
				return null;
			} else if(inf != null && 
					(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DUMMY_VALUE.equalsIgnoreCase(inf.getStatus_code()) 
							|| APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE.equalsIgnoreCase(inf.getStatus_code())
							|| APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_CHECKED_VALUE.equalsIgnoreCase(inf.getStatus_code()))
			) {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_013"), String.valueOf(trx.getLoan_no())));
			}
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
}
