/**
 * 
 */
package com.shinhan.fcl.core.constant;

import java.util.List;

/**
 * @author shds01
 *
 */
public class ListDataOutPut {

	private List<?> data;
	private String count;

	/**
	 * 
	 */
	public ListDataOutPut() {
		super();
	}

	/**
	 * @param data
	 * @param count
	 */
	public ListDataOutPut(List<?> data, String count) {
		super();
		this.data = data;
		this.count = count;
	}

	/**
	 * @return the data
	 */
	public List<?> getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(List<?> data) {
		this.data = data;
	}

	/**
	 * @return the count
	 */
	public String getCount() {
		return count;
	}

	/**
	 * @param count the count to set
	 */
	public void setCount(String count) {
		this.count = count;
	}

}
