/**
 * 
 */
package com.shinhan.fcl.core.model;

/**
 * @author shds01
 *
 */
public class UserPermission {

	private String url;
	private String method;
	private String contentType;

	/**
	 * @param url
	 * @param method
	 * @param contentType
	 */
	public UserPermission(String url, String method, String contentType) {
		super();
		this.url = url;
		this.method = method;
		this.contentType = contentType;
	}

	/**
	 * 
	 */
	public UserPermission() {
		super();
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the method
	 */
	public String getMethod() {
		return method;
	}

	/**
	 * @param method the method to set
	 */
	public void setMethod(String method) {
		this.method = method;
	}

	/**
	 * @return the contentType
	 */
	public String getContentType() {
		return contentType;
	}

	/**
	 * @param contentType the contentType to set
	 */
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

}
