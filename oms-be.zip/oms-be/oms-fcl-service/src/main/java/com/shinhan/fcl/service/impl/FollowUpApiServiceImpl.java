/**
 * 
 */
package com.shinhan.fcl.service.impl;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.fcl.common.AbstractBasicCommonClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.util.CommonUtil;
import com.shinhan.fcl.core.util.DTOConverter;
import com.shinhan.fcl.repository.entity.TOmsFCLFollowEMIInf;
import com.shinhan.fcl.service.FollowUpApiService;

/**
 * @author shds01
 *
 */

@Service("followUpApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class FollowUpApiServiceImpl extends AbstractBasicCommonClass implements FollowUpApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#getListFollowUpEMI(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListFollowUpEMI(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		return getRepositoryManagerService().getFollowUpManagerRepositoryService().getListFollowUpEMI(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#countFollowUpEMITrx(java.util.Map)
	 */
	@Override
	public BigDecimal countFollowUpEMITrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getFollowUpManagerRepositoryService().countFollowUpEMITrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FollowUpApiService#updateNoteFollowUpEMI(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> updateNoteFollowUpEMI(Map<String, Object> inputParams)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLFollowEMIInf> listReg = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLFollowEMIInf inf = getValidationManagerService().checkValidationUpdateNoteFollowUpEMI(trx);
			if(trx.getValid()){
				if (inf == null) {
					inf = DTOConverter.populateDataUpdateNoteFollowUpEMINew(trx, userName);
				} else {
					inf = DTOConverter.populateDataUpdateNoteFollowUpEMIUpdate(trx, inf,userName);
				}
				listReg.add(inf);
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().updateNoteFollowupEMITrxToDB(listReg);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FollowUpApiService#exportReportByTemplate(java.util.Map)
	 */
	@Override
	public File exportReportByTemplate(Map<String, Object> inputParams) throws BaseException {
		inputParams.put(APIConstant._TEMPLATE_NAME, APIConstant.EXPORT_FCL_REPORT_TEMPLATE_NAME_FOLLOWUP_EMI);
		
		File fileExport = getProcessManagerService().getExportReportService().exportReportByTemplate(inputParams);
		if(fileExport == null || !fileExport.exists()) {
			return null;
		}
		return fileExport;
	}

}
