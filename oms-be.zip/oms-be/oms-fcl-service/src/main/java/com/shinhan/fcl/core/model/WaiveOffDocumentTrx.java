/**
 * 
 */
package com.shinhan.fcl.core.model;

import com.shinhan.fcl.core.constant.APIConstant;

/**
 * @author shds01
 *
 */
public class WaiveOffDocumentTrx {

	private String loan_no;
	private String cif;
	private String waive_off_day;
	
	private String total_amt;
	
	private String int_amt;
	private String lpp_amt;
	private String overdue_amt;

	/**
	 * 
	 */
	public WaiveOffDocumentTrx() {
		super();
	}

	/**
	 * @param loan_no
	 * @param cif
	 * @param waive_off_day
	 */
	public WaiveOffDocumentTrx(String loan_no, String cif, String waive_off_day) {
		super();
		this.loan_no = loan_no;
		this.cif = cif;
		this.waive_off_day = waive_off_day;
	}

	/**
	 * @param loan_no
	 * @param cif
	 * @param waive_off_day
	 * @param total_amt
	 * @param int_amt
	 * @param lpp_amt
	 * @param overdue_amt
	 */
	public WaiveOffDocumentTrx(String loan_no, String cif, String waive_off_day, String total_amt, String int_amt,
			String lpp_amt, String overdue_amt) {
		super();
		this.loan_no = loan_no;
		this.cif = cif;
		this.waive_off_day = waive_off_day;
		this.total_amt = total_amt;
		this.int_amt = int_amt;
		this.lpp_amt = lpp_amt;
		this.overdue_amt = overdue_amt;
	}

	/**
	 * @return the loan_no
	 */
	public String getLoan_no() {
		return loan_no;
	}

	/**
	 * @param loan_no the loan_no to set
	 */
	public void setLoan_no(String loan_no) {
		this.loan_no = loan_no;
	}

	/**
	 * @return the cif
	 */
	public String getCif() {
		return cif;
	}

	/**
	 * @param cif the cif to set
	 */
	public void setCif(String cif) {
		this.cif = cif;
	}

	/**
	 * @return the waive_off_day
	 */
	public String getWaive_off_day() {
		return waive_off_day;
	}

	/**
	 * @param waive_off_day the waive_off_day to set
	 */
	public void setWaive_off_day(String waive_off_day) {
		this.waive_off_day = waive_off_day;
	}

	/**
	 * @return the total_amt
	 */
	public String getTotal_amt() {
		return total_amt;
	}

	/**
	 * @param total_amt the total_amt to set
	 */
	public void setTotal_amt(String total_amt) {
		this.total_amt = total_amt;
	}

	/**
	 * @return the int_amt
	 */
	public String getInt_amt() {
		return int_amt;
	}

	/**
	 * @param int_amt the int_amt to set
	 */
	public void setInt_amt(String int_amt) {
		this.int_amt = int_amt;
	}

	/**
	 * @return the lpp_amt
	 */
	public String getLpp_amt() {
		return lpp_amt;
	}

	/**
	 * @param lpp_amt the lpp_amt to set
	 */
	public void setLpp_amt(String lpp_amt) {
		this.lpp_amt = lpp_amt;
	}

	/**
	 * @return the overdue_amt
	 */
	public String getOverdue_amt() {
		return overdue_amt;
	}

	/**
	 * @param overdue_amt the overdue_amt to set
	 */
	public void setOverdue_amt(String overdue_amt) {
		this.overdue_amt = overdue_amt;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WaiveOffDocumentTrx [loan_no=" + loan_no + ", cif=" + cif + ", waive_off_day=" + waive_off_day
				+ ", total_amt=" + total_amt + ", int_amt=" + int_amt + ", lpp_amt=" + lpp_amt + ", overdue_amt="
				+ overdue_amt + "]";
	}

	public String generateWaiveString(){
		return "C" + "," + cif + "," + loan_no+ "," + waive_off_day + "," + total_amt 
				+ "," + APIConstant.ZERO_STRING + "," + APIConstant.ZERO_STRING 
				+ "," + int_amt + "," + lpp_amt 
				+ "," + APIConstant.ZERO_STRING + "," + APIConstant.ZERO_STRING + "," + APIConstant.ZERO_STRING + "," + APIConstant.ZERO_STRING 
				+ "," + APIConstant.ZERO_STRING + "," + APIConstant.ZERO_STRING + "," + APIConstant.ZERO_STRING + "," + APIConstant.ZERO_STRING 
				+ "," + APIConstant.ZERO_STRING + "," + APIConstant.ZERO_STRING + "," + APIConstant.ZERO_STRING + "," + APIConstant.ZERO_STRING 
				+ "," + overdue_amt + "," + APIConstant.CURRENCY_VN + "," + APIConstant.WAIVEOFF_DOCUMENT_PVFCDEV1 + "," + APIConstant.WAIVEOFF_DOCUMENT_PVFCDEV2 
				+ "," + APIConstant.WAIVEOFF_DOCUMENT_SERVICE_NAME
				;
	}
}
