/**
 * 
 */
package com.shinhan.fcl.core.model;

import com.shinhan.fcl.core.constant.APIConstant;

/**
 * @author shds01
 *
 */
public class DummyDocumentTrx {

	private String loan_no;
	private String customer_name;

	private String pmt_amt;
	private String value_date;

	private String ref;

	private String userName;

	/**
	 * 
	 */
	public DummyDocumentTrx() {
		super();
	}

	/**
	 * @param loan_no
	 * @param value_date
	 * @param userName
	 */
	public DummyDocumentTrx(String loan_no, String customer_name, String value_date, String userName) {
		super();
		this.loan_no = loan_no;
		this.customer_name = customer_name;
		this.value_date = value_date;
		this.userName = userName;
	}

	/**
	 * @param loan_no
	 * @param customer_name
	 * @param pmt_amt
	 * @param value_date
	 * @param ref
	 * @param remarks
	 * @param userName
	 */
	public DummyDocumentTrx(String loan_no, String customer_name, String pmt_amt, String value_date, String ref, String userName) {
		super();
		this.loan_no = loan_no;
		this.customer_name = customer_name;
		this.pmt_amt = pmt_amt;
		this.value_date = value_date;
		this.ref = ref;
		this.userName = userName;
	}

	/**
	 * @return the loan_no
	 */
	public String getLoan_no() {
		return loan_no;
	}

	/**
	 * @param loan_no the loan_no to set
	 */
	public void setLoan_no(String loan_no) {
		this.loan_no = loan_no;
	}

	/**
	 * @return the customer_name
	 */
	public String getCustomer_name() {
		return customer_name;
	}

	/**
	 * @param customer_name the customer_name to set
	 */
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	/**
	 * @return the pmt_amt
	 */
	public String getPmt_amt() {
		return pmt_amt;
	}

	/**
	 * @param pmt_amt the pmt_amt to set
	 */
	public void setPmt_amt(String pmt_amt) {
		this.pmt_amt = pmt_amt;
	}

	/**
	 * @return the value_date
	 */
	public String getValue_date() {
		return value_date;
	}

	/**
	 * @param value_date the value_date to set
	 */
	public void setValue_date(String value_date) {
		this.value_date = value_date;
	}

	/**
	 * @return the ref
	 */
	public String getRef() {
		return ref;
	}

	/**
	 * @param ref the ref to set
	 */
	public void setRef(String ref) {
		this.ref = ref;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DummyDocumentTrx [loan_no=" + loan_no + ", customer_name=" + customer_name + ", pmt_amt=" + pmt_amt
				+ ", value_date=" + value_date + ", ref=" + ref + ", userName=" + userName + "]";
	}

	public String generateWaiveString() {
		return this.loan_no + "," + this.customer_name + "," + this.pmt_amt + "," + this.value_date + ","
				+ APIConstant.DUMMY_DOCUMENT_BANK_ACCOUNT_NO + "," + this.ref + APIConstant.DUMMY_DOCUMENT_REMARKS + ","
				+ this.userName

		;
	}
}
