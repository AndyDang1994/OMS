/**
 * 
 */
package com.shinhan.fcl.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.shinhan.fcl.report.ExportReportService;
import com.shinhan.fcl.service.FCLApiService;
import com.shinhan.fcl.service.FollowUpApiService;
import com.shinhan.fcl.service.FormApiService;
import com.shinhan.fcl.service.FormPaymentApiService;
import com.shinhan.fcl.service.MaturityApiService;
import com.shinhan.fcl.service.PaymentApiService;
import com.shinhan.fcl.service.TBApiService;
import com.shinhan.fcl.service.UtilityApiService;

/**
 * @author shds01
 *
 */
@Service("processManagerService")
public class ProcessManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private UtilityApiService utilityApiService;
	
	@Autowired
	private FormApiService formApiService;
	
	@Autowired
	private PaymentApiService paymentApiService;
	
	@Autowired
	private FormPaymentApiService formPaymentApiService;
	
	@Autowired
	private MaturityApiService maturityApiService;
	
	@Autowired
	private FollowUpApiService followUpApiService;
	
	@Autowired
	private ExportReportService exportReportService;
	
	@Autowired
	private TBApiService tbApiService;
	
	@Autowired
	private FCLApiService fclApiService;
	
	/**
	 * @return the utilityApiService
	 */
	public UtilityApiService getUtilityApiService() {
		return utilityApiService;
	}

	/**
	 * @param utilityApiService the utilityApiService to set
	 */
	public void setUtilityApiService(@Qualifier("utilityApiService") UtilityApiService utilityApiService) {
		this.utilityApiService = utilityApiService;
	}

	/**
	 * @return the formApiService
	 */
	public FormApiService getFormApiService() {
		return formApiService;
	}

	/**
	 * @param formApiService the formApiService to set
	 */
	public void setFormApiService(@Qualifier("formApiService") FormApiService formApiService) {
		this.formApiService = formApiService;
	}

	/**
	 * @return the paymentApiService
	 */
	public PaymentApiService getPaymentApiService() {
		return paymentApiService;
	}

	/**
	 * @param paymentApiService the paymentApiService to set
	 */
	public void setPaymentApiService(@Qualifier("paymentApiService") PaymentApiService paymentApiService) {
		this.paymentApiService = paymentApiService;
	}

	/**
	 * @return the formPaymentApiService
	 */
	public FormPaymentApiService getFormPaymentApiService() {
		return formPaymentApiService;
	}

	/**
	 * @param formPaymentApiService the formPaymentApiService to set
	 */
	public void setFormPaymentApiService(@Qualifier("formPaymentApiService") FormPaymentApiService formPaymentApiService) {
		this.formPaymentApiService = formPaymentApiService;
	}

	/**
	 * @return the maturityApiService
	 */
	public MaturityApiService getMaturityApiService() {
		return maturityApiService;
	}

	/**
	 * @param maturityApiService the maturityApiService to set
	 */
	public void setMaturityApiService(@Qualifier("maturityApiService") MaturityApiService maturityApiService) {
		this.maturityApiService = maturityApiService;
	}

	/**
	 * @return the followUpApiService
	 */
	public FollowUpApiService getFollowUpApiService() {
		return followUpApiService;
	}

	/**
	 * @param followUpApiService the followUpApiService to set
	 */
	public void setFollowUpApiService(@Qualifier("followUpApiService") FollowUpApiService followUpApiService) {
		this.followUpApiService = followUpApiService;
	}

	/**
	 * @return the exportReportService
	 */
	public ExportReportService getExportReportService() {
		return exportReportService;
	}

	/**
	 * @param exportReportService the exportReportService to set
	 */
	public void setExportReportService(@Qualifier("exportReportService") ExportReportService exportReportService) {
		this.exportReportService = exportReportService;
	}

	/**
	 * @return the tbApiService
	 */
	public TBApiService getTbApiService() {
		return tbApiService;
	}

	/**
	 * @param tbApiService the tbApiService to set
	 */
	public void setTbApiService(@Qualifier("tbApiService") TBApiService tbApiService) {
		this.tbApiService = tbApiService;
	}

	/**
	 * @return the fclApiService
	 */
	public FCLApiService getFclApiService() {
		return fclApiService;
	}

	/**
	 * @param fclApiService the fclApiService to set
	 */
	public void setFclApiService(@Qualifier("fclApiService") FCLApiService fclApiService) {
		this.fclApiService = fclApiService;
	}


}
