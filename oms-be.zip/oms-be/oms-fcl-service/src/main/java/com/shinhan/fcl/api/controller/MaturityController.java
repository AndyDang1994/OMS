/**
 * 
 */
package com.shinhan.fcl.api.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.util.DateUtils;

/**
 * @author shds01
 *
 */
@RestController
public class MaturityController extends BaseController{
	
	/** Waive Off */
	@RequestMapping(value = "shinhan/service/maturity/waiveoff", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	public String getListMaturityWaiveOff(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _cifNo,
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant._LOAN_NO, _loanNo);
		inputParams.put(APIConstant._CIF_NO, _cifNo);
		
		List<EarlyTerminationTrx> lst = getProcessManagerService().getMaturityApiService().getListMaturityWaiveOff(inputParams);
		BigDecimal countTotal = getProcessManagerService().getMaturityApiService().countMaturityWaiveOffTrx(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
	
	@RequestMapping(value = "shinhan/service/maturity/waiveoff/executeWaive", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	public String executeWaiveMaturityWaiveOff(@RequestBody String document,
			Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		List<EarlyTerminationTrx> lst = getProcessManagerService().getMaturityApiService().executeWaiveMaturityWaiveOff(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	
	@RequestMapping(value = "shinhan/service/maturity/waiveoff/exportreport", produces = {"application/pdf"}, method = RequestMethod.POST)
	public ResponseEntity<Object> exportReportForMaturityWaiveOff(@RequestBody String document,
			@RequestParam(required = false, defaultValue = "" ) String _startDt,
			@RequestParam(required = false, defaultValue = "" ) String _endDt,
			Locale locale) throws BaseException, FileNotFoundException {
		
		Map<String, Object> inputParams = new HashMap<>();
		
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		
		File item = getProcessManagerService().getMaturityApiService().exportReportForMaturityWaiveOff(inputParams);
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_004"));
		}
		return triggerSuccessResponseFile(item);
	}
	
	/** Book Inc */
	@RequestMapping(value = "shinhan/service/maturity/book", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	public String getListMaturityBookInc(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _cifNo,
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant._LOAN_NO, _loanNo);
		inputParams.put(APIConstant._CIF_NO, _cifNo);
		
		List<EarlyTerminationTrx> lst = getProcessManagerService().getMaturityApiService().getListMaturityBookInc(inputParams);
		BigDecimal countTotal = getProcessManagerService().getMaturityApiService().countMaturityBookIncTrx(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
	
	@RequestMapping(value = "shinhan/service/maturity/book/done", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	public String getListMaturityBookIncDone(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _cifNo,
			
			@RequestParam(required = false, defaultValue = "" ) String _startDt,
			@RequestParam(required = false, defaultValue = "" ) String _endDt,
			Locale locale) throws BaseException, ParseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant._LOAN_NO, _loanNo);
		inputParams.put(APIConstant._CIF_NO, _cifNo);
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.formatDate(DateUtils.getBefore30DayDate(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		
		List<EarlyTerminationTrx> lst = getProcessManagerService().getMaturityApiService().getListMaturityBookIncDoneTrx(inputParams);
		BigDecimal countTotal = getProcessManagerService().getMaturityApiService().countMaturityBookIncDoneTrx(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
	
	@RequestMapping(value = "shinhan/service/maturity/book/executeDone", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	public String executeDoneMaturityBookInc(@RequestBody String document,
			Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		List<EarlyTerminationTrx> lst = getProcessManagerService().getMaturityApiService().executeDoneMaturityBookInc(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	
	/** Refund */
	@RequestMapping(value = "shinhan/service/maturity/refund", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	public String getListMaturityRefund(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _cifNo,
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant._LOAN_NO, _loanNo);
		inputParams.put(APIConstant._CIF_NO, _cifNo);
		
		List<EarlyTerminationTrx> lst = getProcessManagerService().getMaturityApiService().getListMaturityRefund(inputParams);
		BigDecimal countTotal = getProcessManagerService().getMaturityApiService().countMaturityRefundTrx(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
	
	@RequestMapping(value = "shinhan/service/maturity/refund/done", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	public String getListMaturityRefundDone(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _cifNo,
			
			@RequestParam(required = false, defaultValue = "" ) String _startDt,
			@RequestParam(required = false, defaultValue = "" ) String _endDt,
			
			Locale locale) throws BaseException, ParseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		;
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.formatDate(DateUtils.getBefore30DayDate(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		
		inputParams.put(APIConstant._LOAN_NO, _loanNo);
		inputParams.put(APIConstant._CIF_NO, _cifNo);
		
		List<EarlyTerminationTrx> lst = getProcessManagerService().getMaturityApiService().getListMaturityRefundDoneTrx(inputParams);
		BigDecimal countTotal = getProcessManagerService().getMaturityApiService().countMaturityRefundDoneTrx(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
	
	@RequestMapping(value = "shinhan/service/maturity/refund/executeDone", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	public String executeDoneMaturityRefund(@RequestBody String document,
			Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		List<EarlyTerminationTrx> lst = getProcessManagerService().getMaturityApiService().executeDoneMaturityRefund(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	
	@RequestMapping(value = "shinhan/service/maturity/refund/exportreport", produces = {"application/pdf"}, method = RequestMethod.POST)
	public ResponseEntity<Object> exportReportForMaturityRefund(@RequestBody String document,
			@RequestParam(required = false, defaultValue = "" ) String _startDt,
			@RequestParam(required = false, defaultValue = "" ) String _endDt,
			Locale locale) throws BaseException, FileNotFoundException {
		
		Map<String, Object> inputParams = new HashMap<>();
		
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		
		File item = getProcessManagerService().getMaturityApiService().exportReportForMaturityRefund(inputParams);
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_004"));
		}
		return triggerSuccessResponseFile(item);
	}
}
