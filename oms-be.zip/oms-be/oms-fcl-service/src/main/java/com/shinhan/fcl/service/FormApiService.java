/**
 * 
 */
package com.shinhan.fcl.service;

import java.io.File;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;

/**
 * @author shds01
 *
 */
public interface FormApiService {
	
	public List<EarlyTerminationTrx> getListFormAvailable(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countFormAvailableTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<EarlyTerminationTrx> executeRemoveForm(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<EarlyTerminationTrx> executeUnRemoveForm(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<EarlyTerminationTrx> executeETForm(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<EarlyTerminationTrx> executeWaiveOff(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<EarlyTerminationTrx> updateRemarkForm(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public File exportReportFormTrx(Map<String, Object> inputParams) throws BaseException;
	
	public File exportETFormByLoan(Map<String, Object> inputParams) throws BaseException;
}
