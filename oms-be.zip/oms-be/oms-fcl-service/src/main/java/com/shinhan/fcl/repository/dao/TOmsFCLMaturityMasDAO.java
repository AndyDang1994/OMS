/**
 * 
 */
package com.shinhan.fcl.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.shinhan.fcl.repository.entity.TOmsFCLMaturityMas;

/**
 * @author shds01
 *
 */
@Repository
public interface TOmsFCLMaturityMasDAO extends JpaRepository<TOmsFCLMaturityMas, String> {

}
