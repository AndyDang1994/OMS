/**
 * 
 */
package com.shinhan.fcl.integration.soap.model;

/**
 * @author shds01
 *
 */
public class Message {

	private Object Header;
	private Body Body;

	/**
	 * 
	 */
	public Message() {
		super();
	}

	/**
	 * @return the header
	 */
	public Object getHeader() {
		return Header;
	}

	/**
	 * @param header the header to set
	 */
	public void setHeader(Object header) {
		Header = header;
	}

	/**
	 * @return the body
	 */
	public Body getBody() {
		return Body;
	}

	/**
	 * @param body the body to set
	 */
	public void setBody(Body body) {
		Body = body;
	}

}
