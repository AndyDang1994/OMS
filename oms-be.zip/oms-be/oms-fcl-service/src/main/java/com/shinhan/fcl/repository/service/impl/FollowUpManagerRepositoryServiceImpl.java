/**
 * 
 */
package com.shinhan.fcl.repository.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.fcl.common.AbstractServiceClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.util.DateUtils;
import com.shinhan.fcl.repository.dao.TOmsFCLFollowEMIINFDAO;
import com.shinhan.fcl.repository.entity.TOmsFCLFollowEMIInf;
import com.shinhan.fcl.repository.service.FollowUpManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("followUpManagerRepositoryService")
public class FollowUpManagerRepositoryServiceImpl extends AbstractServiceClass
		implements FollowUpManagerRepositoryService {

	
	@Autowired
	private TOmsFCLFollowEMIINFDAO objectEMIInfDao;

	public FollowUpManagerRepositoryServiceImpl(TOmsFCLFollowEMIINFDAO objectEMIInfDao) {
		this.objectEMIInfDao = objectEMIInfDao;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormManagerRepositoryService#getListFollowUpEMI(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListFollowUpEMI(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		try {
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			String sql = "SELECT new com.shinhan.fcl.core.model.EarlyTerminationTrx("
					
					+ "mas.id, mas.loan_no, mas.customer_name, mas.customer_phone_no, mas.collection_account, "
					+ "mas.last_payment_bank_ref, mas.bank_narration, mas.bank_credit_amount, "
					+ "mas.emi_amount, mas.transaction_date, "
					+ "mas.outstanding_principle, mas.excess_amount, mas.penalty_fees, mas.partner_bank, mas.last_due_date, "
					+ "inf.id as ref_id, inf.status_code as followup_note, inf.remarks as remarks"
					
					+ ") "
					+ "from TOmsFCLFollowEMIMas mas left join TOmsFCLFollowEMIInf inf on mas.id = inf.ref_id "
					+ "where (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:partner_bank is NULL or mas.partner_bank = :partner_bank) "
					+ "and (:customer_phone_no is NULL or mas.customer_phone_no = :customer_phone_no) "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' "
					;
			
			String orderBy = " order by mas.id, mas.loan_no asc, mas.partner_bank asc";
			
			Query query = entityManager.createQuery(sql + orderBy);
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("partner_bank", inputParams.get(APIConstant._PARTNER_BANK).toString());
			query.setParameter("customer_phone_no", inputParams.get(APIConstant._CUSTOMER_PHONE).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			@SuppressWarnings("unchecked")
			List<EarlyTerminationTrx> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormManagerRepositoryService#countFollowUpEMITrx(java.util.Map)
	 */
	@Override
	public BigDecimal countFollowUpEMITrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			String sql = "select count(mas.id) from oms_fcl_followemi_mas mas "
					+ "where (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:partner_bank is NULL or mas.partner_bank = :partner_bank) "
					+ "and (:customer_phone_no is NULL or mas.customer_phone_no = :customer_phone_no) "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' "
					;
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("partner_bank", inputParams.get(APIConstant._PARTNER_BANK).toString());
			query.setParameter("customer_phone_no", inputParams.get(APIConstant._CUSTOMER_PHONE).toString());
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FollowUpManagerRepositoryService#createAll(java.util.Map)
	 */
	@Override
	public boolean createAll(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			@SuppressWarnings("unchecked")
			List<TOmsFCLFollowEMIInf> items = (List<TOmsFCLFollowEMIInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectEMIInfDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FollowUpManagerRepositoryService#getFollowUpEMITrxById(java.lang.String)
	 */
	@Override
	public TOmsFCLFollowEMIInf getFollowUpEMITrxById(long id) throws ServiceRuntimeException {
		try {
			TOmsFCLFollowEMIInf item = objectEMIInfDao.findById(id).get();
			return item;
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FollowUpManagerRepositoryService#exportReportFollowupEMITrx(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Object[]> exportReportFollowupEMITrx(String startDt, String endDt)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		try {
			String sql = "SELECT "
					
					+ "inf.updatedUser, "
					+ "(SELECT tm.value from TMetadata tm "
					+ "where tm.lookupCode = '"+APIConstant.LOOKUP_CODE_FOLLOWUP_EMI_NOTE+"' and tm.lookupCodeId = inf.status_code) as followup_note, "
					+ "inf.remarks, "
					+ "mas.customer_phone_no, mas.loan_no, mas.customer_name, mas.collection_account, "
					+ "mas.last_payment_bank_ref, mas.bank_narration, mas.bank_credit_amount, "
					+ "mas.transaction_date, mas.partner_bank, mas.last_due_date, "
					+ "inf.updatedDt "
					+ "from TOmsFCLFollowEMIInf inf, TOmsFCLFollowEMIMas mas "
					+ "where inf.ref_id = mas.id "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' "
					+ "and to_date(to_char(inf.updatedDt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') between :startDt and :endDt "
					+ "and inf.status_code is not Null"
					;
			
			String orderBy = " order by inf.updatedDt asc, mas.loan_no";
			
			Query query = entityManager.createQuery(sql + orderBy);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			List<Object[]> list = query.getResultList();
			if(CollectionUtils.isEmpty(list)) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
			}
			return list;
		} catch (ServiceInvalidAgurmentException ex) {
			throw new ServiceInvalidAgurmentException(ex.getMessage());
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
}
