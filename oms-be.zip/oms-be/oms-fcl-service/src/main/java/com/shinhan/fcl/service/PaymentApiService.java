/**
 * 
 */
package com.shinhan.fcl.service;

import java.io.File;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;

/**
 * @author shds01
 *
 */
public interface PaymentApiService {
	
	public List<EarlyTerminationTrx> getListPaymentAvailable(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countPaymentAvailableTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<EarlyTerminationTrx> executeRemovePayment(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<EarlyTerminationTrx> executeETPayment(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<EarlyTerminationTrx> updateRemarkPayment(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public File exportReportForPayment(Map<String, Object> inputParams) throws BaseException;
}
