/**
 * 
 */
package com.shinhan.fcl.repository.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.shinhan.fcl.repository.entity.TOmsFCLFollowEMIInf;

/**
 * @author shds01
 *
 */
@Repository
public interface TOmsFCLFollowEMIINFDAO extends JpaRepository<TOmsFCLFollowEMIInf, Long> {

	@Query("SELECT item FROM TOmsFCLFollowEMIInf item WHERE item.ref_id = :ref_id")
	public List<TOmsFCLFollowEMIInf> getListItemByRefId(@Param("ref_id") long ref_id);
}
