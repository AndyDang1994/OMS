/**
 * 
 */
package com.shinhan.fcl.repository.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.fcl.common.AbstractServiceClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.util.DateUtils;
import com.shinhan.fcl.repository.dao.TOmsFCLFormPaymentDAO;
import com.shinhan.fcl.repository.entity.TOmsFCLFormPaymentInf;
import com.shinhan.fcl.repository.service.FormPaymentManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("formPaymentManagerRepositoryService")
public class FormPaymentManagerRepositoryServiceImpl extends AbstractServiceClass
		implements FormPaymentManagerRepositoryService {

	@Autowired
	private TOmsFCLFormPaymentDAO objectFormPaymentDao;
	
	public FormPaymentManagerRepositoryServiceImpl(TOmsFCLFormPaymentDAO objectFormPaymentDao) {
		this.objectFormPaymentDao = objectFormPaymentDao;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormManagerRepositoryService#getListFormPaymentAvailable(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListFormPaymentAvailable(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		try {
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			String sql = "SELECT new com.shinhan.fcl.core.model.EarlyTerminationTrx("
					
					+ "mas.loan_no, mas.cif, mas.customer_name, mas.excess_amount, mas.et_amount, "
					+ "mas.last_payment_amount, mas.last_payment_bank_ref, mas.last_payment_date, "
					+ "mas.et_form_scan_date, mas.simulated_et_date, inf.status_code as statusCode, "
					+ "CASE WHEN :current_date < mas.simulated_et_date then null "
						+ "ELSE to_char((to_date(:sys_date,'"+DateUtils.DATEFORMAT+"') - to_date(to_char(mas.simulated_et_date, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"'))) "
						+ "End as day_diff "
						
					+ ") "
					
					+ "from TOmsFCLFormPaymentMas mas left join TOmsFCLFormPaymentInf inf on mas.loan_no = inf.loan_no "
					
					+ "where mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' "
					+ "and (1 = DECODE(inf.etCode, '"+ APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_ET_VALUE +"', 1, 0) or (mas.fcl_category = '"+APIConstant.FCL_CATEGORY_FCL_FULL+"')) "
					+ "and (inf.status_code is NULL or inf.status_code not in ('"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE+"', '"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_CHECKED_VALUE+"')) "
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:cifNo is NULL or mas.cif = :cifNo) "
					
					;
		
			String orderBy = " order by mas.simulated_et_date asc, mas.last_payment_date asc, mas.et_form_scan_date asc, mas.loan_no ";
			
			Query query = entityManager.createQuery(sql + orderBy);
			
			query.setParameter("current_date", DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
			query.setParameter("sys_date", DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			@SuppressWarnings("unchecked")
			List<EarlyTerminationTrx> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormManagerRepositoryService#countFormPaymentAvailableTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countFormPaymentAvailableTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			String sql = "select count(*) from oms_fcl_form_payment_mas mas left join oms_fcl_form_payment_inf inf on mas.loan_no = inf.loan_no "
					+ "where mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' "
					+ "and (1 = DECODE(inf.et_code, '"+ APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_ET_VALUE +"', 1, 0) or (mas.fcl_category = '"+APIConstant.FCL_CATEGORY_FCL_FULL+"')) "
					+ "and (inf.status_code is NULL or inf.status_code not in ('"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE+"', '"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_CHECKED_VALUE+"')) "
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:cifNo is NULL or mas.cif = :cifNo) "
					
					;
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormPaymentManagerRepositoryService#getListFormPaymentAvailableDoneTrx(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListFormPaymentAvailableDoneTrx(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		try {
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			String sql = "SELECT new com.shinhan.fcl.core.model.EarlyTerminationTrx("
					
					+ "mas.loan_no, mas.cif, mas.customer_name, mas.last_payment_amount, mas.last_payment_date, "
					+ "mas.last_payment_bank_ref, mas.bank_narration, "
					+ "inf.status_code as statusCode, inf.updatedUser "
					
					+ ") "
					
					+ "from TOmsFCLFormPaymentInf inf, TOmsFCLFormPaymentMas mas "
					
					+ "Where inf.loan_no = mas.loan_no "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' " 
					+ "and to_date(to_char(inf.effective_dt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') between :fromDt and :endDt "
					+ "and inf.status_code = '"+ APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE +"' "
					
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:cifNo is NULL or mas.cif = :cifNo) "
					
					;
			
			String orderBy = "order by inf.effective_dt, mas.loan_no ";
			
			Query query = entityManager.createQuery(sql + orderBy);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			@SuppressWarnings("unchecked")
			List<EarlyTerminationTrx> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormPaymentManagerRepositoryService#countFormPaymentAvailableDoneTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countFormPaymentAvailableDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			String sql = "select count(*) from oms_fcl_form_payment_inf inf, oms_fcl_form_payment_mas mas "
					
					+ "where mas.loan_no = inf.loan_no and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' "
					+ "and to_date(to_char(inf.effective_dt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') between :fromDt and :endDt "
					+ "and inf.status_code = '"+ APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE +"' "
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:cifNo is NULL or mas.cif = :cifNo) "
					;
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormPaymentManagerRepositoryService#getTrxByLoanNo(java.lang.String)
	 */
	@Override
	public TOmsFCLFormPaymentInf getTrxByLoanNo(String loanNo) throws ServiceRuntimeException {
		if (StringUtils.isBlank(loanNo)) {
			return null;
		}
		try {
			return objectFormPaymentDao.getItemByLoanNo(loanNo);
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + loanNo + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormPaymentManagerRepositoryService#createAll(java.util.Map)
	 */
	@Override
	public boolean createAll(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			@SuppressWarnings("unchecked")
			List<TOmsFCLFormPaymentInf> items = (List<TOmsFCLFormPaymentInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectFormPaymentDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormPaymentManagerRepositoryService#exportReportFormPaymentAvaiableTrx(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Object[]> exportReportFormPaymentAvaiableTrx(String startDt, String endDt)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		try {
			String sql = "SELECT "
					+ "rownum, sub.* from ("
					+ "SELECT "
					+ "mas.cif, mas.loan_no, mas.customer_name, "
					+ "to_char(mas.last_payment_date, '"+DateUtils.DATEFORMAT+"'), "
					+ "to_char(mas.et_form_scan_date, '"+DateUtils.DATEFORMAT+"'), "
					+ "to_char(mas.simulated_et_date, '"+DateUtils.DATEFORMAT+"'), "
					
					+ "inf.lchg_inf_user, inf.checked_user, "
					+ "to_char(inf.checked_dt, '"+DateUtils.ddMMyyyy_HH_mm_ss+"') "
					+ "from oms_fcl_form_payment_inf inf, oms_fcl_form_payment_mas mas "
					+ "where inf.loan_no = mas.loan_no and mas.loan_status = '"+APIConstant.LOAN_STATUS_CLOSE+"' "
					+ "and to_date(to_char(inf.effective_dt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') between :startDt and :endDt "
					+ "and inf.status_code in ('"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE+"', '"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_CHECKED_VALUE+"') "
					;
			
			String orderBy = " order by mas.lchg_inf_dt asc, mas.loan_no asc) sub";
			
			Query query = entityManager.createNativeQuery(sql + orderBy);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			List<Object[]> list = query.getResultList();
			if(CollectionUtils.isEmpty(list)) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
			}
			return list;
		} catch (ServiceInvalidAgurmentException ex) {
			throw new ServiceInvalidAgurmentException(ex.getMessage());
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

}
