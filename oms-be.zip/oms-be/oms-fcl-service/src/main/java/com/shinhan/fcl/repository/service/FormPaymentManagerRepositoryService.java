/**
 * 
 */
package com.shinhan.fcl.repository.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.repository.entity.TOmsFCLFormPaymentInf;

/**
 * @author shds01
 *
 */
public interface FormPaymentManagerRepositoryService {
	
	public List<EarlyTerminationTrx> getListFormPaymentAvailable(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countFormPaymentAvailableTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<EarlyTerminationTrx> getListFormPaymentAvailableDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countFormPaymentAvailableDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public TOmsFCLFormPaymentInf getTrxByLoanNo(String loanNo) throws ServiceRuntimeException;
	
	public boolean createAll(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<Object[]> exportReportFormPaymentAvaiableTrx(String startDt, String endDt) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
}
