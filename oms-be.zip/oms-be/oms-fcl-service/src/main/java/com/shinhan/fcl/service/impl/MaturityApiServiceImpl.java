/**
 * 
 */
package com.shinhan.fcl.service.impl;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.fcl.common.AbstractBasicCommonClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.model.WaiveOffDocumentTrx;
import com.shinhan.fcl.core.util.CommonUtil;
import com.shinhan.fcl.core.util.DTOConverter;
import com.shinhan.fcl.core.util.DateUtils;
import com.shinhan.fcl.repository.entity.TOmsFCLMaturityInf;
import com.shinhan.fcl.service.MaturityApiService;

/**
 * @author shds01
 *
 */

@Service("maturityApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class MaturityApiServiceImpl extends AbstractBasicCommonClass implements MaturityApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#getListMaturityWaiveOff(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListMaturityWaiveOff(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		return getRepositoryManagerService().getMaturityManagerRepositoryService().getListMaturityWaiveOff(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#countMaturityWaiveOffTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countMaturityWaiveOffTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getMaturityManagerRepositoryService().countMaturityWaiveOffTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.MaturityApiService#executeWaiveMaturityWaiveOff(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeWaiveMaturityWaiveOff(Map<String, Object> inputParams)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLMaturityInf> listReg = new ArrayList<>();
		List<WaiveOffDocumentTrx> lstWaiveOff = new ArrayList<WaiveOffDocumentTrx>();
		boolean isWriteFile = false;
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLMaturityInf inf = getValidationManagerService().checkValidationExecuteWaiveMaturityWaiveOff(trx);
			if(trx.getValid() && inf == null){
				listReg.add(DTOConverter.populateDataExecuteWaiveMaturityWaiveOffIncNew(trx, userName));
				lstWaiveOff.add(DTOConverter.populateDataExecuteWaiveForWaiveOffDocumentTrx(trx));
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		//Process write csv file 
		String indexWaiveOff = CommonUtil.generateCountWaiveOffMap(env.getProperty(APIConstant.WAIVEOFF_INDEX_VALUE_FORMAT));
		String pathDir = env.getProperty(APIConstant.PATH_EXPORT_FCL);
		String nameFile = APIConstant.WAIVEOFF_DOCUMENT_TITLE + "-" + DateUtils.getSystemDateStr(DateUtils.ddMMyyyy) + "-" 
				+ indexWaiveOff + APIConstant.FILE_TYPE_CSV;
		
		isWriteFile = writeCSVFileToWaiveOff(lstWaiveOff, pathDir, nameFile);
		
		if(countTotal == count && isWriteFile){
			getRepositoryManagerService().executeWaiveMaturityWaiveOffTrxToDB(listReg);
		}
		
		return lst;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.MaturityApiService#exportReportForMaturityWaiveOff(java.util.Map)
	 */
	@Override
	public File exportReportForMaturityWaiveOff(Map<String, Object> inputParams) throws BaseException {
		inputParams.put(APIConstant._TEMPLATE_NAME, APIConstant.EXPORT_FCL_REPORT_TEMPLATE_NAME_MATURITY_WAIVEOFF);
		
		File fileExport = getProcessManagerService().getExportReportService().exportReportByTemplate(inputParams);
		if(fileExport == null || !fileExport.exists()) {
			return null;
		}
		return fileExport;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.MaturityApiService#getListMaturityBookInc(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListMaturityBookInc(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		return getRepositoryManagerService().getMaturityManagerRepositoryService().getListMaturityBookInc(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.MaturityApiService#countMaturityBookIncTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countMaturityBookIncTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getMaturityManagerRepositoryService().countMaturityBookIncTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.MaturityApiService#getListMaturityBookIncDoneTrx(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListMaturityBookIncDoneTrx(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		return getRepositoryManagerService().getMaturityManagerRepositoryService().getListMaturityBookIncDoneTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.MaturityApiService#countMaturityBookIncDoneTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countMaturityBookIncDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getMaturityManagerRepositoryService().countMaturityBookIncTrxDoneTrx(inputParams);
	}
	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.MaturityApiService#executeDoneMaturityBookInc(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeDoneMaturityBookInc(Map<String, Object> inputParams)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLMaturityInf> listReg = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLMaturityInf inf = getValidationManagerService().checkValidationExecuteDoneMaturityBookInc(trx);
			if(trx.getValid()){
				if (inf == null) {
					inf = DTOConverter.populateDataExecuteDoneMaturityBookIncNew(trx, userName);
				} else {
					DTOConverter.populateDataExecuteDoneMaturityBookIncUpdate(inf, userName);
				}
				listReg.add(inf);
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().executeDoneMaturityBookIncTrxToDB(listReg);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.MaturityApiService#getListMaturityRefund(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListMaturityRefund(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		return getRepositoryManagerService().getMaturityManagerRepositoryService().getListMaturityRefund(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.MaturityApiService#countMaturityRefundTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countMaturityRefundTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getMaturityManagerRepositoryService().countMaturityRefundTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.MaturityApiService#getListMaturityRefundDoneTrx(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListMaturityRefundDoneTrx(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		return getRepositoryManagerService().getMaturityManagerRepositoryService().getListMaturityRefundDoneTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.MaturityApiService#countMaturityRefundDoneTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countMaturityRefundDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getMaturityManagerRepositoryService().countMaturityRefundDoneTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.MaturityApiService#executeDoneMaturityRefund(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeDoneMaturityRefund(Map<String, Object> inputParams)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLMaturityInf> listReg = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLMaturityInf inf = getValidationManagerService().checkValidationExecuteDoneMaturityRefund(trx);
			if(trx.getValid()){
				if (inf == null) {
					inf = DTOConverter.populateDataExecuteDoneMaturityRefundNew(trx, userName);
				} else {
					DTOConverter.populateDataExecuteDoneMaturityRefundUpdate(inf, trx, userName);
				}
				listReg.add(inf);
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().executeDoneMaturityRefundTrxToDB(listReg);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.MaturityApiService#exportReportForMaturityRefund(java.util.Map)
	 */
	@Override
	public File exportReportForMaturityRefund(Map<String, Object> inputParams) throws BaseException {
		inputParams.put(APIConstant._TEMPLATE_NAME, APIConstant.EXPORT_FCL_REPORT_TEMPLATE_NAME_MATURITY_REFUND_DONE);
		
		File fileExport = getProcessManagerService().getExportReportService().exportReportByTemplate(inputParams);
		if(fileExport == null || !fileExport.exists()) {
			return null;
		}
		return fileExport;
	}

}
