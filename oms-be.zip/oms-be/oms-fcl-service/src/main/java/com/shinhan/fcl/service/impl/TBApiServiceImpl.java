/**
 * 
 */
package com.shinhan.fcl.service.impl;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.shinhan.fcl.common.AbstractBasicCommonClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.DummyDocumentTrx;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.model.WaiveOffDocumentTrx;
import com.shinhan.fcl.core.util.CommonUtil;
import com.shinhan.fcl.core.util.DTOConverter;
import com.shinhan.fcl.core.util.DateUtils;
import com.shinhan.fcl.core.util.ReadFromExcel;
import com.shinhan.fcl.repository.entity.TMetadata;
import com.shinhan.fcl.repository.entity.TOmsFCLTBInf;
import com.shinhan.fcl.service.TBApiService;

/**
 * @author shds01
 *
 */

@Service("tbApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class TBApiServiceImpl extends AbstractBasicCommonClass implements TBApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.TBApiService#getListTB(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListTB(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getTbManagerRepositoryService().getListTB(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.TBApiService#countTBTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countTBTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getTbManagerRepositoryService().countTBTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.TBApiService#getListTBDoneTrx(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListTBDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getTbManagerRepositoryService().getListTBDoneTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.TBApiService#countTBDoneTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countTBDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getTbManagerRepositoryService().countTBDoneTrx(inputParams);
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.TBApiService#uploadListTBTrx(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> uploadListTBTrx(Map<String, Object> inputParams) throws BaseException {
		ReadFromExcel rw;
		List<EarlyTerminationTrx> lstTrx = new ArrayList<>();
		MultipartFile fileUpload = (MultipartFile) inputParams.get(APIConstant.FILE_UPLOAD);
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		boolean flagTemplate = false;
		ArrayList<TOmsFCLTBInf> listReg = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.UPLOAD_LIMIT_TRX));
		
		try {
			if(fileUpload == null){
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_011"));
			}
			rw = new ReadFromExcel(fileUpload.getInputStream(), fileUpload.getOriginalFilename(),
					env.getProperty(APIConstant.PATH_IMPORT_FCL));
			TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService()
					.getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_FCL_TEMPLATE_UPLOAD_DATA, APIConstant.LOOKUP_CODE_FCL_TEMPLATE_UPLOAD_DATA_TBUPLOAD);
			flagTemplate = rw.isCorrectTemplateHeader(item.getValue(), env.getProperty(APIConstant.PATH_TEMPLATE_UPLOAD_FCL), 0);
			
		} catch (IOException ex) {
			logger.info(ex.getMessage());
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_011"));
		}
		if(!flagTemplate) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_003"));
		}
		
		List<Map> mapObjectLst = rw.readDataFromExcel(0, 1, 0);
		if(CollectionUtils.isNotEmpty(mapObjectLst)) {
			if(mapObjectLst.size() > limitTrx) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
			}
			for (Map mapData : mapObjectLst){
				EarlyTerminationTrx data = DTOConverter.convertToUploadTB6(mapData, env);
				TOmsFCLTBInf inf = getValidationManagerService().checkValidationUploadTB6(data);
				if(inf == null){
					listReg.add(DTOConverter.populateDataUploadTBNew(data, userName));
					count++;
				}
				
				lstTrx.add(data);
				countTotal++;
			}
		}
		
		if(countTotal == count){
			getRepositoryManagerService().uploadTBTrxToDB(listReg);
		}
		
		return lstTrx;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.TBApiService#updateRemark(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> updateRemark(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLTBInf> listUpd = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLTBInf inf = getValidationManagerService().checkValidationUpdateRemarkTB(trx);
			if(trx.getValid() && inf != null){
				DTOConverter.populateDataUpdateRemarkTB(inf, userName, trx.getRemarks());
				listUpd.add(inf);
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().executeDoneTBTrxToDB(listUpd);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.TBApiService#executeDoneTB(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeDoneTB(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLTBInf> listUpd = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLTBInf inf = getValidationManagerService().checkValidationExecuteDoneTB(trx);
			if(trx.getValid() && inf != null){
				DTOConverter.populateDataExecuteDoneTB(inf, userName);
				listUpd.add(inf);
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().executeDoneTBTrxToDB(listUpd);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.TBApiService#executeRemoveTB(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeRemoveTB(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLTBInf> listUpd = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLTBInf inf = getValidationManagerService().checkValidationExecuteRemoveTB(trx);
			if(trx.getValid() && inf != null){
				DTOConverter.populateDataExecuteRemoveTB(inf, userName);
				listUpd.add(inf);
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().executeRemoveTBTrxToDB(listUpd);
		}
		
		return lst;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.TBApiService#executeUnRemoveTB(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeUnRemoveTB(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLTBInf> listUpd = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLTBInf inf = getValidationManagerService().checkValidationExecuteUnRemoveTB(trx);
			if(trx.getValid() && inf != null){
				DTOConverter.populateDataExecuteUnRemoveTB(inf, userName);
				listUpd.add(inf);
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().executeUnRemoveTBTrxToDB(listUpd);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.TBApiService#executeTBWaiveOff(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeTBWaiveOff(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLTBInf> listReg = new ArrayList<>();
		List<WaiveOffDocumentTrx> lstWaiveOff = new ArrayList<WaiveOffDocumentTrx>();
		boolean isWriteFile = false;
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLTBInf inf = getValidationManagerService().checkValidationExecuteWaiveTB(trx);
			if(trx.getValid() && inf != null){
				DTOConverter.populateDataExecuteWaiveTB(inf, userName);
				listReg.add(inf);
				lstWaiveOff.add(DTOConverter.populateDataExecuteWaiveForWaiveOffDocumentTrx(trx));
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		//Process write csv file 
		String indexWaiveOff = CommonUtil.generateCountWaiveOffMap(env.getProperty(APIConstant.WAIVEOFF_INDEX_VALUE_FORMAT));
		String pathDir = env.getProperty(APIConstant.PATH_EXPORT_FCL);
		String nameFile = APIConstant.WAIVEOFF_DOCUMENT_TITLE + "-" + DateUtils.getSystemDateStr(DateUtils.ddMMyyyy) + "-" 
				+ indexWaiveOff + APIConstant.FILE_TYPE_CSV;
		
		isWriteFile = writeCSVFileToWaiveOff(lstWaiveOff, pathDir, nameFile);
		
		if(countTotal == count && isWriteFile){
			getRepositoryManagerService().executeWaiveTBTrxToDB(listReg);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.TBApiService#executeTBDummy(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeTBDummy(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLTBInf> listReg = new ArrayList<>();
		List<DummyDocumentTrx> lstDummy = new ArrayList<DummyDocumentTrx>();
		boolean isWriteFile = false;
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLTBInf inf = getValidationManagerService().checkValidationExecuteDummyTB(trx);
			if(trx.getValid() && inf != null){
				boolean isWaive = false;
				if (APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_WAIVEOFF_VALUE.equalsIgnoreCase(inf.getStatus_code())){
					isWaive = true;
				}
				DTOConverter.populateDataExecuteDummyTB(inf, userName);
				listReg.add(inf);
				lstDummy.add(DTOConverter.populateDataExecuteDummyForDummyDocumentTrx(trx, isWaive, userName));
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		//Process write csv file 
		String pathDir = env.getProperty(APIConstant.PATH_EXPORT_FCL);
		String nameFile = APIConstant.DUMMY_DOCUMENT_TITLE + "-" + DateUtils.getSystemDateStr(DateUtils.ddMMyyyyhhmmss) + APIConstant.FILE_TYPE_CSV;
		isWriteFile = writeCSVFileToDummy(lstDummy, pathDir, nameFile);
		
		if(countTotal == count && isWriteFile){
			getRepositoryManagerService().executeDummyTBTrxToDB(listReg);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.TBApiService#exportReportFormTrx(java.util.Map)
	 */
	@Override
	public File exportReportFormTrx(Map<String, Object> inputParams) throws BaseException {
		inputParams.put(APIConstant._TEMPLATE_NAME, APIConstant.EXPORT_FCL_REPORT_TEMPLATE_NAME_TB6_DONE);
		
		File fileExport = getProcessManagerService().getExportReportService().exportReportByTemplate(inputParams);
		if(fileExport == null || !fileExport.exists()) {
			return null;
		}
		return fileExport;
	}

}
