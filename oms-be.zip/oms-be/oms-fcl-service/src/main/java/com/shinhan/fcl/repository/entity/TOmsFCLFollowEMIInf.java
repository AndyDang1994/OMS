/**
 * 
 */
package com.shinhan.fcl.repository.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author shds01
 *
 */
@Entity
@Table(name = "OMS_FCL_FOLLOWEMI_INF")
public class TOmsFCLFollowEMIInf implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long id;
	private long ref_id;
	private String status_code;
	private String remarks;
	
	private String createdUser;
	private Date createdDt;
	private String updatedUser;
	private Date updatedDt;

	/**
	 * 
	 */
	public TOmsFCLFollowEMIInf() {
		super();
	}

	/**
	 * @return the id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "OMS_FCL_FOLLOWEMI_INF_SEQ_GEN")
	@SequenceGenerator(name = "OMS_FCL_FOLLOWEMI_INF_SEQ_GEN", sequenceName = "OMS_FCL_FOLLOWEMI_INF_SEQ", allocationSize = 1)
	@Column(name = "ID")
	public long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the ref_id
	 */
	@Column(name = "REF_ID")
	public long getRef_id() {
		return ref_id;
	}

	/**
	 * @param ref_id the ref_id to set
	 */
	public void setRef_id(long ref_id) {
		this.ref_id = ref_id;
	}

	/**
	 * @return the status_code
	 */
	@Column(name = "STATUS_CODE")
	public String getStatus_code() {
		return status_code;
	}

	/**
	 * @param status_code the status_code to set
	 */
	public void setStatus_code(String status_code) {
		this.status_code = status_code;
	}

	/**
	 * @return the remarks
	 */
	@Column(name = "REMARKS")
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the createdUser
	 */
	@Column(name = "REGIS_INF_USER")
	public String getCreatedUser() {
		return createdUser;
	}

	/**
	 * @param createdUser the createdUser to set
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	/**
	 * @return the createdDt
	 */
	@Column(name = "REGIS_INF_DT")
	public Date getCreatedDt() {
		return createdDt;
	}

	/**
	 * @param createdDt the createdDt to set
	 */
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	/**
	 * @return the updatedUser
	 */
	@Column(name = "LCHG_INF_USER")
	public String getUpdatedUser() {
		return updatedUser;
	}

	/**
	 * @param updatedUser the updatedUser to set
	 */
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}

	/**
	 * @return the updatedDt
	 */
	@Column(name = "LCHG_INF_DT")
	public Date getUpdatedDt() {
		return updatedDt;
	}

	/**
	 * @param updatedDt the updatedDt to set
	 */
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

}
