/**
 * 
 */
package com.shinhan.fcl.report.impl;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import com.shinhan.fcl.common.AbstractBasicCommonClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.util.DateUtils;
import com.shinhan.fcl.core.util.WriteToExcelTemplate;
import com.shinhan.fcl.report.ExportReportService;
import com.shinhan.fcl.repository.entity.TMetadata;

/**
 * @author shds01
 *
 */
@Service("exportReportService")
public class ExportReportServiceImpl extends AbstractBasicCommonClass implements ExportReportService{


	/* (non-Javadoc)
	 * @see com.shinhan.fcl.report.ADExportReportService#exportReportByTemplate(java.util.Map)
	 */
	@Override
	public File exportReportByTemplate(Map<String, Object> inputParams) throws BaseException {
		String templateName = inputParams.get(APIConstant._TEMPLATE_NAME).toString();
		String startDt = inputParams.get(APIConstant._START_DATE_KEY) != null ? inputParams.get(APIConstant._START_DATE_KEY).toString() : APIConstant.BLANK_KEY;
		String endDt =  inputParams.get(APIConstant._END_DATE_KEY) != null ? inputParams.get(APIConstant._END_DATE_KEY).toString() : APIConstant.BLANK_KEY;
		
		TMetadata templateFileName = getRepositoryManagerService()
				.getUtilityManagerRepositoryService()
				.getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_EXPORT_FCL_REPORT_TEMPLATE_NAME, templateName);
		String fileSource = env.getProperty(APIConstant.PATH_TEMPLATE_FCL_FOR_EXPORT_DATA) + templateFileName.getValue();
		String fileDestinationExport = env.getProperty(APIConstant.PATH_EXPORT_FCL) 
				+ templateName
				+ DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss) + APIConstant.FILE_TYPE_EXCEL_OLD;
		
		Workbook wb;
		int fromRow;
		int fromColumn;
		List<Object[]> data;
		switch (templateName) {
		case APIConstant.EXPORT_FCL_REPORT_TEMPLATE_NAME_FOLLOWUP_EMI:
			data = getRepositoryManagerService().getFollowUpManagerRepositoryService().exportReportFollowupEMITrx(startDt, endDt);
			/** Start Process fill data */
			fromRow = 1; // initial row
			wb = WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, "Data", fromRow, data);
			/** End Process fill data */
			break;
		case APIConstant.EXPORT_FCL_REPORT_TEMPLATE_NAME_MATURITY_REFUND_DONE:
			data = getRepositoryManagerService().getMaturityManagerRepositoryService().exportReportRefundDoneTrx(startDt, endDt);
			/** Start Process fill data */
			fromRow = 1; // initial row
			wb = WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, "Data", fromRow, data);
			/** End Process fill data */
			break;
		case APIConstant.EXPORT_FCL_REPORT_TEMPLATE_NAME_MATURITY_WAIVEOFF:
			data = getRepositoryManagerService().getMaturityManagerRepositoryService().exportReportWaiveOffTrx(startDt, endDt);
			/** Start Process fill data */
			fromRow = 1; // initial row
			wb = WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, "Data", fromRow, data);
			/** End Process fill data */
			break;
		case APIConstant.EXPORT_FCL_REPORT_TEMPLATE_NAME_PAYMENT_AVAIABLE:
			data = getRepositoryManagerService().getPaymentManagerRepositoryService().exportReportPaymentTrx(startDt, endDt);
			/** Start Process fill data */
			fromRow = 1; // initial row
			wb = WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, "Data", fromRow, data);
			/** End Process fill data */
			break;
		case APIConstant.EXPORT_FCL_REPORT_TEMPLATE_NAME_FORM_AVAIABLE:
			data = getRepositoryManagerService().getFormManagerRepositoryService().exportReportFormAvaiableTrx(startDt, endDt);
			/** Start Process fill data */
			fromRow = 1; // initial row
			wb = WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, "Data", fromRow, data);
			/** End Process fill data */
			break;
		case APIConstant.EXPORT_FCL_REPORT_TEMPLATE_NAME_FORM_PAYMENT_AVAIABLE:
			data = getRepositoryManagerService().getFormPaymentManagerRepositoryService().exportReportFormPaymentAvaiableTrx(startDt, endDt);
			/** Start Process fill data */
			fromRow = 1; // initial row
			wb = WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, "Data", fromRow, data);
			/** End Process fill data */
			break;
		case APIConstant.EXPORT_FCL_REPORT_TEMPLATE_NAME_TB6_DONE:
			data = getRepositoryManagerService().getTbManagerRepositoryService().exportReportTBTrx(startDt, endDt);
			/** Start Process fill data */
			fromRow = 1; // initial row
			wb = WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, "Data", fromRow, data);
			/** End Process fill data */
			break;
		default :
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_010"), templateName));
		}
		
		/** Start Write Excel file */
		WriteToExcelTemplate.writeWorkbook(wb, fileDestinationExport);
		File file = new File(fileDestinationExport);
		if(!file.exists()) {
			throw new ServiceRuntimeException(env.getProperty("MSG_004"));
		}
		/** End Write Excel file */
		return file;
	}

}
