/**
 * 
 */
package com.shinhan.fcl.repository.service;

import java.util.List;

import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.repository.entity.TMetadata;
import com.shinhan.fcl.repository.entity.TOmsFCLFollowEMIMas;
import com.shinhan.fcl.repository.entity.TOmsFCLFormPaymentMas;
import com.shinhan.fcl.repository.entity.TOmsFCLMaturityMas;
import com.shinhan.fcl.repository.entity.TOmsFCLTBMas;

/**
 * @author shds01
 *
 */
public interface UtilityManagerRepositoryService {
	
	public List<TMetadata> getMetadataByLookupCode(String lookupCode) throws ServiceRuntimeException;
	
	public TMetadata getMetadataById(Long id) throws ServiceRuntimeException;
	
	public TMetadata getMetadataByLookupCodeAndId(String lookupCode, String lookupId) throws ServiceRuntimeException;
	
	public TOmsFCLFollowEMIMas getFCLFollowMasTrxById(long id) throws ServiceRuntimeException;
	
	public TOmsFCLMaturityMas getFCLMaturityMasTrxByLoanNo(String loanNo) throws ServiceRuntimeException;
	
	public TOmsFCLTBMas getFCLTBMasTrxByLoanNo(String loanNo) throws ServiceRuntimeException;
	
	public TOmsFCLFormPaymentMas getFCLFormPaymentMasTrxByLoanNo(String loanNo) throws ServiceRuntimeException;
}
