/**
 * 
 */
package com.shinhan.fcl.api.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.shinhan.fcl.configure.NFSSourceProperties;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.util.CommonUtil;
import com.shinhan.fcl.core.util.NFSUtils;


/**
 * @author shds01
 *
 */
@RestController
public class UtilityController extends BaseController{
	
	@Autowired
	private NFSSourceProperties nfsProperties;
	
	@RequestMapping(value = "shinhan/common/connection", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public String testGet() throws ServiceRuntimeException, InterruptedException {
		return triggerSuccessOutPut(null, JsonObject.class, "connect server successfully");
	}

	@RequestMapping(value = "shinhan/common/exception", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public String testException(Locale locale) throws BaseException {
		testException();
		return "Success";
	}
	
	@RequestMapping(value = "shinhan/service/fcl/template", produces = {"application/json;charset=utf-8", "application/pdf"}, method = RequestMethod.GET)
	public ResponseEntity<Object> exportReconcileReport (
			@RequestParam(required = true) String _templateName,
			Locale locale) throws BaseException, FileNotFoundException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._TEMPLATE_NAME_KEY, _templateName);
		
		File item = getProcessManagerService().getUtilityApiService().getTemplateNameToImport(inputParams);
		
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_004"));
		}
		
		return triggerSuccessResponseFile(item);
	}
	
	@Scheduled(cron = "${spring.job.remove.file.everyday}") // 0 PM everyday
	public void cleanFileReport() throws BaseException, IOException {
		logger.info("***** Start remove file export data Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_EXPORT_FCL));
		logger.info("***** End remove file export data Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		logger.info("***** Start remove file import data Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_IMPORT_FCL));
		logger.info("***** End remove file import data Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		logger.info("***** Start remove file temp Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_FCL_TEMP));
		logger.info("***** End remove file temp Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		logger.info("***** Start remove file waiveOff Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_EXPORT_FCL_WAIVEOFF_DONE));
		logger.info("***** End remove file waiveOff Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		logger.info("***** Start remove file dummy trx Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_EXPORT_FCL_DUMMY_DONE));
		logger.info("***** End remove file dummy trx Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		logger.info("***** Start Reset Waive Off Count Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		CommonUtil.resetCountWaiveOffMap();
		logger.info("***** End Reset Waive Off Count  Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
	
	@Scheduled(fixedDelayString = "${spring.job.application.fixedDelay.waiveoff.sendToNFS}") // 1 minutes
	public void jobScanTrxToSendingFileToWaiveOff() throws BaseException, IOException {
		logger.info("***** Start Sent File to NFS for Waive Trx Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		String[] types = {"csv"};
		Collection<File> files = new ArrayList<File>();
		File ftpOutDir = new File(env.getProperty(APIConstant.PATH_EXPORT_FCL_WAIVEOFF_DONE));
		if (ftpOutDir.exists()) {
			files = FileUtils.listFiles(ftpOutDir, types, true);
		} else {
			logger.info("***** Folder Waive Done doesn't exist *****");
			logger.info(env.getProperty(APIConstant.PATH_EXPORT_FCL_WAIVEOFF_DONE));
		}
		
		for (File file : files) {
			logger.info("***** Start Sent File to NFS *****");
			logger.info("***** fileName : " + file.getAbsolutePath() +" *****");
			NFSUtils.uploadViaNFS(nfsProperties.getHost(), nfsProperties.getUsername(), nfsProperties.getPassword(),
					nfsProperties.getWaiveoffDirectory(), env.getProperty(APIConstant.PATH_EXPORT_FCL_WAIVEOFF_DONE), file.getName());
			
			logger.info("***** End Sent File to NFS *****");
		}
		
		if(CollectionUtils.isNotEmpty(files)) {
			logger.info("***** Start Clean Folder *****");
			//CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_EXPORT_FCL_WAIVEOFF_DONE));
			logger.info("***** End Clean Folder *****");
		} else {
			logger.info("***** No file to scan from : " + env.getProperty(APIConstant.PATH_EXPORT_FCL_WAIVEOFF_DONE));
		}
		
		logger.info("***** End Sent File to NFS for Waive Trx Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
	
	@Scheduled(fixedDelayString = "${spring.job.application.fixedDelay.dummy.sendToNFS}") // 1 minutes
	public void jobScanTrxToSendingFileToDummy() throws BaseException, IOException {
		logger.info("***** Start Sent File to NFS for Dummy Trx Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		String[] types = {"csv"};
		Collection<File> files = new ArrayList<File>();
		File ftpOutDir = new File(env.getProperty(APIConstant.PATH_EXPORT_FCL_DUMMY_DONE));
		if (ftpOutDir.exists()) {
			files = FileUtils.listFiles(ftpOutDir, types, true);
		}else {
			logger.info("***** Folder Dummy Done doesn't exist *****");
			logger.info(env.getProperty(APIConstant.PATH_EXPORT_FCL_DUMMY_DONE));
		}
		
		for (File file : files) {
			logger.info("***** Start Sent File to NFS *****");
			logger.info("***** fileName : " + file.getAbsolutePath() +" *****");
			NFSUtils.uploadViaNFS(nfsProperties.getHost(), nfsProperties.getUsername(), nfsProperties.getPassword(),
					nfsProperties.getDummyDirectory(), env.getProperty(APIConstant.PATH_EXPORT_FCL_DUMMY_DONE), file.getName());
			
			logger.info("***** End Sent File to NFS *****");
		}
		
		if(CollectionUtils.isNotEmpty(files)) {
			logger.info("***** Start Clean Folder *****");
			//CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_EXPORT_FCL_DUMMY_DONE));
			logger.info("***** End Clean Folder *****");
		}else {
			logger.info("***** No file to scan from : " + env.getProperty(APIConstant.PATH_EXPORT_FCL_DUMMY_DONE));
		}
		
		logger.info("***** End Sent File to NFS for Dummy Trx Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
}
