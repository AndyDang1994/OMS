package com.shinhan.fcl.core.util;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.xfile.XFile;
import com.sun.xfile.XFileInputStream;
import com.sun.xfile.XFileOutputStream;

public class NFSUtils {

	protected static final Logger logger = LoggerFactory.getLogger(NFSUtils.class);

	public static void main(String[] args) {
		
	}

	public static void downloadViaNFS(final String ip, final String user, final String password, final String dir, String destPath) {
		try {
			String url = ip + "\\" + dir;
			XFile xf = new XFile(url);
			if (xf.exists()) {
				logger.info("URL is OK!");
			} else {
				logger.info("URL is bad!");
				return;
			}

			String[] fileList = xf.list();
			XFile temp = null;
			int filesz = 0;
			for (String file : fileList) {
				temp = new XFile(url + "/" + file);
				XFileInputStream in = new XFileInputStream(temp);
				XFileOutputStream out = new XFileOutputStream(destPath + "/" + file);
				
				int c;
				byte[] buf = new byte[8196];
				
				while ((c = in.read(buf)) > 0) {
					filesz += c;
					out.write(buf, 0, c);
				}
				
				logger.info(file + " is downloaded!");
				in.close();
				out.close();
				if (temp.canWrite()) {
					temp.delete();
					logger.info(file + " is deleted!");
				} else {
					logger.info(file + " can not be deleted!");
				}
			}
			logger.info(filesz + " bytes copied @ ");
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
	}

	public static void uploadViaNFS(final String ip, final String user, final String password
			, final String dir, String resPath, String resFileName) {
		try {
			String url = ip + "\\" + dir;
			XFile temp = null;
			int filesz = 0;
			temp = new XFile(resPath + "/" + resFileName);
			XFileInputStream in = new XFileInputStream(temp); // to make temporary directory
			XFileOutputStream out = new XFileOutputStream(url + "\\" + resFileName);
			
			int c;
			byte[] buf = new byte[8196];
			
			while ((c = in.read(buf)) > 0) {
				filesz += c;
				out.write(buf, 0, c);
			}
			
			logger.info(resFileName + " is uploaded!");
			in.close();
			out.close();
			if (temp.canWrite()) {
				temp.delete();
				logger.info(resFileName + " is deleted!");
			} else {
				logger.info(resFileName + " can not be deleted!");
			}
			logger.info(filesz + " bytes copied @ ");
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
	}
}
