/**
 * 
 */
package com.shinhan.fcl.repository.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.repository.entity.TOmsFCLTBInf;
import com.shinhan.fcl.repository.entity.TOmsFCLTBMas;

/**
 * @author shds01
 *
 */
public interface TBManagerRepositoryService {
	
	public List<EarlyTerminationTrx> getListTB(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countTBTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<EarlyTerminationTrx> getListTBDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countTBDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public TOmsFCLTBInf getTrxByLoanNo(String loanNo) throws ServiceRuntimeException;
	
	public boolean createAll(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public boolean deleteAll(List<TOmsFCLTBInf> items) throws ServiceRuntimeException;
	
	public boolean createAllMas(List<TOmsFCLTBMas> items) throws ServiceRuntimeException;
	
	public List<Object[]> exportReportTBTrx(String startDt, String endDt) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<TOmsFCLTBInf> getListTBTrxScanning() throws ServiceRuntimeException;
	
	public List<TOmsFCLTBInf> getListTBTrxScanningNotFound() throws ServiceRuntimeException;
	
	public List<TOmsFCLTBInf> getListTBTrxScanningNotFoundForRemove() throws ServiceRuntimeException;
	
}
