/**
 * 
 */
package com.shinhan.fcl.service;

import java.io.File;
import java.util.Map;

import com.shinhan.fcl.core.exception.BaseException;

/**
 * @author shds01
 *
 */
public interface UtilityApiService {
	
	public File getTemplateNameToImport (Map<String, Object> inputParams) throws BaseException;
}
