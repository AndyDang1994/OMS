/**
 * 
 */
package com.shinhan.fcl.integration.soap.model;

/**
 * @author shds01
 *
 */
public class Body {

	private Elements ELEMENTS;
	private String Result_Code;
	private String Result_Msg;

	/**
	 * 
	 */
	public Body() {
		super();
	}

	/**
	 * @return the eLEMENTS
	 */
	public Elements getELEMENTS() {
		return ELEMENTS;
	}

	/**
	 * @param eLEMENTS the eLEMENTS to set
	 */
	public void setELEMENTS(Elements eLEMENTS) {
		ELEMENTS = eLEMENTS;
	}

	/**
	 * @return the result_Code
	 */
	public String getResult_Code() {
		return Result_Code;
	}

	/**
	 * @param result_Code the result_Code to set
	 */
	public void setResult_Code(String result_Code) {
		Result_Code = result_Code;
	}

	/**
	 * @return the result_Msg
	 */
	public String getResult_Msg() {
		return Result_Msg;
	}

	/**
	 * @param result_Msg the result_Msg to set
	 */
	public void setResult_Msg(String result_Msg) {
		Result_Msg = result_Msg;
	}

}
