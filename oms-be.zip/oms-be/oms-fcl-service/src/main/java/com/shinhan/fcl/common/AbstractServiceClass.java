/**
 * 
 */
package com.shinhan.fcl.common;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.nio.charset.StandardCharsets;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPMessage;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.util.CommonUtil;
import com.shinhan.fcl.core.util.DateUtils;
/**
 * @author shds01
 *
 */
public abstract class AbstractServiceClass extends AbstractRepositoryClass {

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	protected SOAPConnectionFactory soapConnectionFactory = null;
	protected SOAPConnection connection;
	
	
	@Autowired
	public Environment env;

	@Autowired
	private ProcessManagerService processManagerService;

	@Autowired
	private AsyncManagerService asyncManagerService;

	@Autowired
	private ValidationManagerService validationManagerService;

	/**
	 * @return the processManagerService
	 */
	public ProcessManagerService getProcessManagerService() {
		return processManagerService;
	}

	/**
	 * @param processManagerService the processManagerService to set
	 */
	public void setProcessManagerService(
			@Qualifier("processManagerService") ProcessManagerService processManagerService) {
		this.processManagerService = processManagerService;
	}

	/**
	 * @return the asyncManagerService
	 */
	public AsyncManagerService getAsyncManagerService() {
		return asyncManagerService;
	}

	/**
	 * @param asyncManagerService the asyncManagerService to set
	 */
	public void setAsyncManagerService(@Qualifier("asyncManagerService") AsyncManagerService asyncManagerService) {
		this.asyncManagerService = asyncManagerService;
	}

	/**
	 * @return the validationManagerService
	 */
	public ValidationManagerService getValidationManagerService() {
		return validationManagerService;
	}

	/**
	 * @param validationManagerService the validationManagerService to set
	 */
	public void setValidationManagerService(@Qualifier("validationManagerService") ValidationManagerService validationManagerService) {
		this.validationManagerService = validationManagerService;
	}
	
	public String buildTheSoapMessageDownloadFileByRefId(String refDocId) {
		int minRandom = 100000;
		int maxRandom = 999999;
		int randValue = (int) (Math.random() * (maxRandom - minRandom + 1) + minRandom);
		String refNo = DateUtils.getSystemDateStr(DateUtils.yyyyMMddHHmmss);

		StringBuilder sb = new StringBuilder();
		sb.append("<![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		
		sb.append("<Message>");
		
			sb.append("<Header>");
				sb.append("<RefNo>").append(refNo + randValue).append("</RefNo>");
				sb.append("<SourceChannel>").append(APIConstant.SOAP_LMS_SOURCECHANNEL_DOWNLOAD_DOCUMENT_BY_REF_ID).append("</SourceChannel>");
				sb.append("<TargetChannel>").append(APIConstant.SOAP_LMS_TARGET_CHANNEL_DOWNLOAD_DOCUMENT_BY_REF_ID).append("</TargetChannel>");
				sb.append("<InterfaceName>").append(APIConstant.SOAP_LMS_INTERFACENAME_DOWNLOAD_DOCUMENT_BY_REF_ID).append("</InterfaceName>");
				sb.append("<ReqTxnDt>").append(refNo).append("</ReqTxnDt>");
				sb.append("<Signature></Signature>");
			
			sb.append("</Header>");
		
			sb.append("<Body>");
				sb.append("<Doc_Ref_ID>").append(refDocId).append("</Doc_Ref_ID>");
			sb.append("</Body>");
			
		sb.append("</Message>");
		
		sb.append("]]>");

		return sb.toString();
	}
	
	public String buildTheSoapMessageSearchDocumentString(String loanNo) {
		int minRandom = 100000;
		int maxRandom = 999999;
		int randValue = (int) (Math.random() * (maxRandom - minRandom + 1) + minRandom);
		String refNo = DateUtils.getSystemDateStr(DateUtils.yyyyMMddHHmmss);

		StringBuilder sb = new StringBuilder();
		sb.append("<![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		
		sb.append("<Message>");
		
			sb.append("<Header>");
				sb.append("<RefNo>").append(refNo + randValue).append("</RefNo>");
				sb.append("<SourceChannel>").append(APIConstant.SOAP_LMS_SOURCECHANNEL_SEARCH_DOCUMENT_BY_LOANNO).append("</SourceChannel>");
				sb.append("<TargetChannel>").append(APIConstant.SOAP_LMS_TARGET_CHANNEL_SEARCH_DOCUMENT_BY_LOANNO).append("</TargetChannel>");
				sb.append("<InterfaceName>").append(APIConstant.SOAP_LMS_INTERFACENAME_SEARCH_DOCUMENT_BY_LOANNO).append("</InterfaceName>");
				sb.append("<ReqTxnDt>").append(refNo).append("</ReqTxnDt>");
				sb.append("<Signature></Signature>");
			
			sb.append("</Header>");
		
			sb.append("<Body>");
				sb.append("<LoanAgrNo>").append(loanNo).append("</LoanAgrNo>");
			sb.append("</Body>");
			
		sb.append("</Message>");
		
		sb.append("]]>");

		return sb.toString();
	}
	
	public String buildTheSoapMessageScanTBString(String listLoanNo) {
		int minRandom = 100000;
		int maxRandom = 999999;
		int randValue = (int) (Math.random() * (maxRandom - minRandom + 1) + minRandom);
		String refNo = DateUtils.getSystemDateStr(DateUtils.yyyyMMddHHmmss);

		StringBuilder sb = new StringBuilder();
		sb.append("<![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		
		sb.append("<Message>");
		
			sb.append("<Header>");
				sb.append("<RefNo>").append(refNo + randValue).append("</RefNo>");
				sb.append("<SourceChannel>").append(APIConstant.SOAP_LMS_SOURCECHANNEL_SCAN_TB_TRX).append("</SourceChannel>");
				sb.append("<TargetChannel>").append(APIConstant.SOAP_LMS_TARGET_CHANNEL_SCAN_TB_TRX).append("</TargetChannel>");
				sb.append("<InterfaceName>").append(APIConstant.SOAP_LMS_INTERFACENAME_SCAN_TB_TRX).append("</InterfaceName>");
				sb.append("<ReqTxnDt>").append(refNo).append("</ReqTxnDt>");
				sb.append("<Signature></Signature>");
			
			sb.append("</Header>");
		
			sb.append("<Body>");
				sb.append("<REQ_LOANID>").append(listLoanNo).append("</REQ_LOANID>");
			sb.append("</Body>");
			
		sb.append("</Message>");
		
		sb.append("]]>");

		return sb.toString();
	}
	
	public String submitDataSOAP(Document document, String url, String soapAction) throws ServiceRuntimeException{
		try{
			logger.info("Start Call Web Service LMS : ");
			logger.info("ULR Web Service : " + url);
			
			logger.info("Start At : " + DateUtils.getSystemDateStr(DateUtils. ddMMyyyy_HH_mm_ss));
			long starttime = System.currentTimeMillis();
			
			String xmlDocument = CommonUtil.converterDOMToXML(document);
			xmlDocument = StringUtils.replace(xmlDocument, "&lt;", "<");
			xmlDocument = StringUtils.replace(xmlDocument, "&gt;", ">");
			
			InputStream stream = new ByteArrayInputStream(xmlDocument.getBytes(StandardCharsets.UTF_8));
			logger.info("Message :" + xmlDocument);
			
			MimeHeaders headers = new MimeHeaders();
			headers.addHeader("SOAPAction", soapAction);
			SOAPMessage request = MessageFactory.newInstance().createMessage(headers, stream);
			
			String xmlContent = invokeSOAPService(request, new URL(url));
			logger.info("Response Web Service : " + xmlContent);
			
			long endTime = System.currentTimeMillis();
			long spentTime = (endTime - starttime);
			logger.info("Time Execution : " + spentTime);
			logger.info("End At : " + DateUtils.getSystemDateStr(DateUtils. ddMMyyyy_HH_mm_ss));
			
			return xmlContent;
		}
		catch(Exception ex){
			ex.printStackTrace();
			return null;
		}
	}
	
	public String invokeSOAPService(SOAPMessage message, URL endpoint) throws Exception {
		
		if(soapConnectionFactory == null){
			soapConnectionFactory = SOAPConnectionFactory.newInstance();
		}
		
		URL endpointCall = new URL(endpoint, "", new URLStreamHandler() {
			@Override
			protected URLConnection openConnection(URL url) throws IOException {
				int connectTimeOut = Integer.valueOf(env.getProperty("soap.connnec.timeout"));
				int readTimeOut = Integer.valueOf(env.getProperty("soap.read.timeout"));
				URL target = new URL(url.toString());
				URLConnection connection = target.openConnection();
				// Connection settings
				connection.setConnectTimeout(connectTimeOut); // 10 sec
				connection.setReadTimeout(readTimeOut); // 5 min
				return (connection);
			}
		});
		
		connection = soapConnectionFactory.createConnection();
		
		try {
			SOAPMessage soapResponse = connection.call(message, endpointCall);
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			soapResponse.writeTo(out);
			
			String responseBody = soapResponse.getSOAPBody().getElementsByTagName("ns1:return").item(0).getTextContent();
			return responseBody;
		} catch (Exception e) {
			logger.error("Call to ESB with endpoind {}: ", endpoint, e);
			return null;
		} finally {
			connection.close();
		}
	}
	
	public String searchDocumentFormByLoanNo(String loanNo) throws ServiceRuntimeException {
		/** Start Call WS to searching */
		//Build input data for Soap message
		String argData = buildTheSoapMessageSearchDocumentString(loanNo);
		
		String xmlPath = "META-INF/sampleXML/FCLSearchDocument_Request.xml";
		Document document = CommonUtil.getSampleInputToCallWS(xmlPath);
		
		Node lmsInputArgNode = CommonUtil.getNodeByXpath(document, "Body/process/arg0");
		
		if(lmsInputArgNode == null || StringUtils.isBlank(argData)) {
			logger.info("***** No lmsInputArgNode Error *****");
			throw new ServiceRuntimeException(env.getProperty("MSG_004"));
		}
		lmsInputArgNode.setTextContent(argData);
		
		String rs = submitDataSOAP(document, env.getProperty(APIConstant.SOAP_LMS_URL_GET_DOCUMENT_BY_LOANNO), "");
		if(StringUtils.isBlank(rs)){
			logger.info("***** Call submitDataSOAP Error *****");
			throw new ServiceRuntimeException(env.getProperty("MSG_018"));
		}
		
		Document docSoap = CommonUtil.converterXMLtoDOM(rs);
		Node resultCodeNode = CommonUtil.getNodeByXpath(docSoap, "//Result_Code");
		if(resultCodeNode == null || APIConstant.SUCCESS_LMS_WS_RESPONSE_KEY.equalsIgnoreCase(resultCodeNode.getTextContent()) == false){
			//Request SOAP service is Fail or time out
			logger.info("***** Call submitDataSOAP Fail *****" + resultCodeNode.getTextContent());
			throw new ServiceRuntimeException(env.getProperty("MSG_018"));
		}
		
		//Check Search document is existed or not
		Node bodyNode = CommonUtil.getNodeByXpath(docSoap, "Body");
		NodeList bodyNodeLst = bodyNode.getChildNodes();
		String refDocId = "";
		for (int i = 0; i < bodyNodeLst.getLength(); i++) {
			Node itemNode = bodyNodeLst.item(i);
			if (itemNode.getNodeType() != Node.ELEMENT_NODE) {
				continue;
			}
			
			if("Document".equalsIgnoreCase(itemNode.getNodeName())) {
				Node docIDNode = CommonUtil.getNodeByXpath(itemNode, "DocID");
				if(docIDNode == null) {
					continue;
				}
				
				if(APIConstant.ET_DOCUMENT_ID_VALUE.equalsIgnoreCase(docIDNode.getTextContent())) {
					Node docRefIdNode = CommonUtil.getNodeByXpath(itemNode, "Doc_Ref_ID");
					if(docRefIdNode == null) {
						continue;
					}
					
					refDocId = docRefIdNode.getTextContent();
					break;
				}
			}
			
		}
		/** End Call WS to searching */
		
		return refDocId;
	}
	
	public File downloadDocumentFormByRefId(String refDocId) throws ServiceRuntimeException {
		/** Start Call WS to download file */
		//Build input data for Soap message
		String argData = buildTheSoapMessageDownloadFileByRefId(refDocId);
		
		String xmlPath = "META-INF/sampleXML/FCLDownloadDocument_Request.xml";
		Document document = CommonUtil.getSampleInputToCallWS(xmlPath);
		
		Node lmsInputArgNode = CommonUtil.getNodeByXpath(document, "Body/process/arg0");
		
		if(lmsInputArgNode == null || StringUtils.isBlank(argData)) {
			logger.info("***** No lmsInputArgNode Error *****");
			throw new ServiceRuntimeException(env.getProperty("MSG_004"));
		}
		lmsInputArgNode.setTextContent(argData);
		
		String rs = submitDataSOAP(document, env.getProperty(APIConstant.SOAP_LMS_URL_DOWNLOAD_DOCUMENT_BY_REF_ID), "");
		if(StringUtils.isBlank(rs)){
			logger.info("***** Call submitDataSOAP Error *****");
			throw new ServiceRuntimeException(env.getProperty("MSG_018"));
		}
		
		Document docSoap = CommonUtil.converterXMLtoDOM(rs);
		Node resultCodeNode = CommonUtil.getNodeByXpath(docSoap, "//Result_Code");
		if(resultCodeNode == null || APIConstant.SUCCESS_LMS_WS_RESPONSE_KEY.equalsIgnoreCase(resultCodeNode.getTextContent()) == false){
			//Request SOAP service is Fail or time out
			logger.info("***** Call submitDataSOAP Fail *****" + resultCodeNode.getTextContent());
			throw new ServiceRuntimeException(env.getProperty("MSG_018"));
		}
		
		Node fileNameNode = CommonUtil.getNodeByXpath(docSoap, "//FileName");
		String fileName = fileNameNode.getTextContent();
		
		Node fileContentNode = CommonUtil.getNodeByXpath(docSoap, "//FileContent");
		String raw = fileContentNode.getTextContent();
		/** End Call WS to download file */
		
		boolean isSave = CommonUtil.convertBase64ToFile(raw, fileName, env.getProperty(APIConstant.PATH_FCL_TEMP));
		
		if(isSave) {
			return new File(env.getProperty(APIConstant.PATH_FCL_TEMP) + fileName);
		}
		
		return null;
	}
	
}
