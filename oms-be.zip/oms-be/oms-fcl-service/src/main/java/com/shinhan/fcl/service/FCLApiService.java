package com.shinhan.fcl.service;

import com.shinhan.fcl.core.exception.BaseException;

public interface FCLApiService {
	
	public boolean populateDataForTBTrx() throws BaseException;
	
	public boolean populateNotFoundDataForTBTrx() throws BaseException;
	
	public boolean removeNotFoundDataForTBTrx() throws BaseException;
}
