package com.shinhan.fcl.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.google.gson.JsonObject;
import com.shinhan.fcl.common.AbstractBasicCommonClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.util.CommonUtil;
import com.shinhan.fcl.core.util.DTOConverter;
import com.shinhan.fcl.integration.soap.model.Element;
import com.shinhan.fcl.integration.soap.model.ResponseData;
import com.shinhan.fcl.repository.entity.TOmsFCLTBInf;
import com.shinhan.fcl.repository.entity.TOmsFCLTBMas;
import com.shinhan.fcl.service.FCLApiService;

@Service("fclApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class FCLApiServiceImpl extends AbstractBasicCommonClass implements FCLApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.migrate.service.FCLApiService#populateDataForTBTrx()
	 */
	@Override
	public boolean populateDataForTBTrx() throws BaseException {
		logger.info("***** Start Call LMS to Get TB Trx Schedule *****");
		
		List<TOmsFCLTBInf> lstScan = getRepositoryManagerService().getTbManagerRepositoryService().getListTBTrxScanning();
		if(CollectionUtils.isEmpty(lstScan)){
			logger.info("***** No Record Found *****");
			logger.info("***** End Call LMS to Get TB Trx Schedule *****");
			return true;
		}
		
		String scanLoanStr = lstScan.stream().map(TOmsFCLTBInf::getLoan_no).collect(Collectors.joining(", "));
		if(StringUtils.isBlank(scanLoanStr)) {
			logger.info("***** No scanLoanStr Found *****");
			logger.info("***** End Call LMS to Get TB Trx Schedule *****");
			return false;
		}
		//Build input data for Soap message
		String argData = buildTheSoapMessageScanTBString(scanLoanStr);
		
		String xmlPath = "META-INF/sampleXML/FCLScanningTBTrx_Request.xml";
		Document document = CommonUtil.getSampleInputToCallWS(xmlPath);
		
		Node lmsInputArgNode = CommonUtil.getNodeByXpath(document, "Body/process/arg0");
		
		if(lmsInputArgNode == null || StringUtils.isBlank(argData)) {
			logger.info("***** No lmsInputArgNode Error *****");
			logger.info("***** End Call LMS to Get TB Trx Schedule *****");
			return false;
		}
		lmsInputArgNode.setTextContent(argData);
		
		//Call SOAP Service
		boolean isCallSuccess = false;//For call LMS
		boolean isFound = false;//Found trx in LMS
		
		String rs = submitDataSOAP(document, env.getProperty(APIConstant.SOAP_LMS_URL_SCAN_TB_TRX), "");
		if(StringUtils.isBlank(rs)){
			logger.info("***** Call submitDataSOAP Error *****");
			logger.info("***** End Call LMS to Get TB Trx Schedule *****");
			return false;
		}
		
		Document docSoap = CommonUtil.converterXMLtoDOM(rs);
		Node resultCodeNode = CommonUtil.getNodeByXpath(docSoap, "//Result_Code");
		if(resultCodeNode == null || APIConstant.SUCCESS_LMS_WS_RESPONSE_KEY.equalsIgnoreCase(resultCodeNode.getTextContent()) == false){
			//Request SOAP service is Fail or time out
			logger.info("***** Call submitDataSOAP Fail *****" + resultCodeNode.getTextContent());
			logger.info("***** End Call LMS to Get TB Trx Schedule *****");
			return false;
		} else if(resultCodeNode != null && APIConstant.SUCCESS_LMS_WS_RESPONSE_KEY.equalsIgnoreCase(resultCodeNode.getTextContent())){
			//Call Success
			isCallSuccess = true;
			
			//Check isFound or not
			Node elementsNode = CommonUtil.getNodeByXpath(docSoap, "//ELEMENTS");
			NodeList elementNodeLst = elementsNode.getChildNodes();
			for (int i = 0; i < elementNodeLst.getLength(); i++) {
				Node item = elementNodeLst.item(i);
				if (item.getNodeType() != Node.ELEMENT_NODE) {
					continue;
				}
				
				if("ELEMENT".equalsIgnoreCase(item.getNodeName())) {
					isFound = true;
					break;
				}
				
			}
		} else {
			logger.info("***** End Call LMS to Get TB Trx Schedule *****");
			return false;
		}
		
		if(isCallSuccess && !isFound) {
			//Request success but not found
			DTOConverter.populateListDataFailToScanTB6(lstScan);
			//Update All list to not-found
			if(CollectionUtils.isNotEmpty(lstScan)) {
				getRepositoryManagerService().updateTBTrxNotFoundInLMSToDB(lstScan);
			}
			logger.info("***** Call submitDataSOAP Success But No records Found ***** " + resultCodeNode.getTextContent());
			logger.info("*****" + scanLoanStr + "*****");
			logger.info("***** End Call LMS to Get TB Trx Schedule *****");
			return false;
		}
		
		
		if(!isCallSuccess) {
			return false;
		}
		try {
			List<TOmsFCLTBMas> lstMas = new ArrayList<TOmsFCLTBMas>();
			String jsonRs = CommonUtil.convertXMLtoJSON(rs);
			ResponseData response = (ResponseData) CommonUtil.toPojo(jsonRs, ResponseData.class);
			
			if(response == null || response.getMessage() == null || response.getMessage().getBody() == null
					|| APIConstant.SUCCESS_LMS_WS_RESPONSE_KEY.equalsIgnoreCase(response.getMessage().getBody().getResult_Code()) == false){
				//Request SOAP service is Fail or time out
				logger.info("***** Call submitDataSOAP Fail *****" + response.getMessage().getBody().getResult_Code());
				logger.info("***** End Call LMS to Get TB Trx Schedule *****");
				return false;
			} else if (APIConstant.SUCCESS_LMS_WS_RESPONSE_KEY.equalsIgnoreCase(response.getMessage().getBody().getResult_Code()) && response.getMessage().getBody().getELEMENTS() == null){
				//Request success but not found
				DTOConverter.populateListDataFailToScanTB6(lstScan);
				//Update All list to not-found
				if(CollectionUtils.isNotEmpty(lstScan)) {
					getRepositoryManagerService().updateTBTrxNotFoundInLMSToDB(lstScan);
				}
				logger.info("***** Call submitDataSOAP Success But No records Found ***** " + response.getMessage().getBody().getResult_Code());
				logger.info("*****" + scanLoanStr + "*****");
				logger.info("***** End Call LMS to Get TB Trx Schedule *****");
				return false;
			} else if (APIConstant.SUCCESS_LMS_WS_RESPONSE_KEY.equalsIgnoreCase(response.getMessage().getBody().getResult_Code()) && response.getMessage().getBody().getELEMENTS() != null){
				//Get data.
				isFound = true;
			}
			
			if(isFound) {
				logger.info("***** Call submitDataSOAP Success ***** " + response.getMessage().getBody().getResult_Code());
				//Parsing List model
				List<Element> elements = new ArrayList<Element>();
				if(response.getMessage().getBody().getELEMENTS().getELEMENT() instanceof JsonObject) {
					Element ele = (Element) CommonUtil.toPojo(response.getMessage().getBody().getELEMENTS().getELEMENT(), Element.class);
					elements.add(ele);
				} else {
					elements = CommonUtil.toListPojo(response.getMessage().getBody().getELEMENTS().getELEMENT(), Element.class);
				}
				
				for(TOmsFCLTBInf inf : lstScan) {
					boolean isFoundLoanNo = false;
					for(Element element :elements) {
						if(inf.getLoan_no().equals(element.getLOAN_ID())) {
							isFoundLoanNo = true;
							lstMas.add(DTOConverter.populateDataFromElementToTB6(element));
							break;
						}
					}
					if(!isFoundLoanNo) {
						logger.info("***** Not Found In WS *****" + inf.getLoan_no());
						//set value to not found
						DTOConverter.populateDataFailToScanTB6(inf);
					}else {
						//set value to found
						DTOConverter.populateDataSuccesToScanTB6(inf);
					}
				}
				
				//Update trx to DB
				if(CollectionUtils.isNotEmpty(lstMas) && CollectionUtils.isNotEmpty(lstScan)) {
					getRepositoryManagerService().updateTBTrxFoundInLMSToDB(lstScan, lstMas);
					logger.info("***** Update Trx to DB Success *****");
					logger.info("***** End Call LMS to Get TB Trx Schedule *****");
					return true;
				}
			}
			
		}catch (Exception ex) {
			ex.printStackTrace();
			return false;
		}
		
		
		logger.info("***** End Call LMS to Get TB Trx Schedule *****");
		return false;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FCLApiService#populateNotFoundDataForTBTrx()
	 */
	@Override
	public boolean populateNotFoundDataForTBTrx() throws BaseException {
		logger.info("***** Start Call LMS to Re-Scan Not Found TB Trx Schedule *****");
		
		List<TOmsFCLTBInf> lstScan = getRepositoryManagerService().getTbManagerRepositoryService().getListTBTrxScanningNotFound();
		if(CollectionUtils.isEmpty(lstScan)){
			logger.info("***** No Record Found *****");
			logger.info("***** End Call LMS to Re-Scan Not Found TB Trx Schedule *****");
			return true;
		}
		
		String scanLoanStr = lstScan.stream().map(TOmsFCLTBInf::getLoan_no).collect(Collectors.joining(", "));
		if(StringUtils.isBlank(scanLoanStr)) {
			logger.info("***** No scanLoanStr Found *****");
			logger.info("***** End LMS to Re-Scan Not Found TB Trx Schedule *****");
			return false;
		}
		//Build input data for Soap message
		String argData = buildTheSoapMessageScanTBString(scanLoanStr);
		
		String xmlPath = "META-INF/sampleXML/FCLScanningTBTrx_Request.xml";
		Document document = CommonUtil.getSampleInputToCallWS(xmlPath);
		
		Node lmsInputArgNode = CommonUtil.getNodeByXpath(document, "Body/process/arg0");
		
		if(lmsInputArgNode == null || StringUtils.isBlank(argData)) {
			logger.info("***** No lmsInputArgNode Error *****");
			logger.info("***** End LMS to Re-Scan Not Found TB Trx Schedule *****");
			return false;
		}
		lmsInputArgNode.setTextContent(argData);
		
		//Call SOAP Service
		boolean isCallSuccess = false;//For call LMS
		boolean isFound = false;//Found trx in LMS
		
		String rs = submitDataSOAP(document, env.getProperty(APIConstant.SOAP_LMS_URL_SCAN_TB_TRX), "");
		if(StringUtils.isBlank(rs)){
			logger.info("***** Call submitDataSOAP Error *****");
			DTOConverter.populateListDataFailToScanTB6(lstScan);
			//Update All list to not-found
			if(CollectionUtils.isNotEmpty(lstScan)) {
				getRepositoryManagerService().updateTBTrxNotFoundInLMSToDB(lstScan);
			}
			logger.info("***** End LMS to Re-Scan Not Found TB Trx Schedule *****");
			return false;
		} else {
			Document docSoap = CommonUtil.converterXMLtoDOM(rs);
			Node resultCodeNode = CommonUtil.getNodeByXpath(docSoap, "//Result_Code");
			if(resultCodeNode == null || APIConstant.SUCCESS_LMS_WS_RESPONSE_KEY.equalsIgnoreCase(resultCodeNode.getTextContent()) == false){
				//Request SOAP service is Fail or time out
				logger.info("***** Call submitDataSOAP Fail *****" + resultCodeNode.getTextContent());
				logger.info("***** End LMS to Re-Scan Not Found TB Trx Schedule *****");
				return false;
			} else if(resultCodeNode != null && APIConstant.SUCCESS_LMS_WS_RESPONSE_KEY.equalsIgnoreCase(resultCodeNode.getTextContent())){
				//Call Success
				isCallSuccess = true;
				
				//Check isFound or not
				Node elementsNode = CommonUtil.getNodeByXpath(docSoap, "//ELEMENTS");
				NodeList elementNodeLst = elementsNode.getChildNodes();
				for (int i = 0; i < elementNodeLst.getLength(); i++) {
					Node item = elementNodeLst.item(i);
					if (item.getNodeType() != Node.ELEMENT_NODE) {
						continue;
					}
					
					if("ELEMENT".equalsIgnoreCase(item.getNodeName())) {
						isFound = true;
						break;
					}
					
				}
			} else {
				logger.info("***** End LMS to Re-Scan Not Found TB Trx Schedule *****");
				return false;
			}
			
			if(isCallSuccess && !isFound) {
				//Request success but not found
				DTOConverter.populateListDataFailToScanTB6(lstScan);
				//Update All list to not-found
				if(CollectionUtils.isNotEmpty(lstScan)) {
					getRepositoryManagerService().updateTBTrxNotFoundInLMSToDB(lstScan);
				}
				logger.info("***** Call submitDataSOAP Success But No records Found ***** " + resultCodeNode.getTextContent());
				logger.info("*****" + scanLoanStr + "*****");
				logger.info("***** End LMS to Re-Scan Not Found TB Trx Schedule *****");
				return false;
			}
		}
		
		if(!isCallSuccess) {
			return false;
		}
		try {
			List<TOmsFCLTBMas> lstMas = new ArrayList<TOmsFCLTBMas>();
			String jsonRs = CommonUtil.convertXMLtoJSON(rs);
			ResponseData response = (ResponseData) CommonUtil.toPojo(jsonRs, ResponseData.class);
			
			if(response == null || response.getMessage() == null || response.getMessage().getBody() == null
					|| APIConstant.SUCCESS_LMS_WS_RESPONSE_KEY.equalsIgnoreCase(response.getMessage().getBody().getResult_Code()) == false){
				//Request SOAP service is Fail or time out
				logger.info("***** Call submitDataSOAP Fail *****" + response.getMessage().getBody().getResult_Code());
				logger.info("***** End LMS to Re-Scan Not Found TB Trx Schedule *****");
				return false;
			} else if (APIConstant.SUCCESS_LMS_WS_RESPONSE_KEY.equalsIgnoreCase(response.getMessage().getBody().getResult_Code()) && response.getMessage().getBody().getELEMENTS() != null){
				//Get data.
				isFound = true;
			}
			
			if(isFound) {
				logger.info("***** Call submitDataSOAP Success ***** " + response.getMessage().getBody().getResult_Code());
				//Parsing List model
				List<Element> elements = new ArrayList<Element>();
				if(response.getMessage().getBody().getELEMENTS().getELEMENT() instanceof JsonObject) {
					Element ele = (Element) CommonUtil.toPojo(response.getMessage().getBody().getELEMENTS().getELEMENT(), Element.class);
					elements.add(ele);
				} else {
					elements = CommonUtil.toListPojo(response.getMessage().getBody().getELEMENTS().getELEMENT(), Element.class);
				}
				
				for(TOmsFCLTBInf inf : lstScan) {
					boolean isFoundLoanNo = false;
					for(Element element :elements) {
						if(inf.getLoan_no().equals(element.getLOAN_ID())) {
							isFoundLoanNo = true;
							lstMas.add(DTOConverter.populateDataFromElementToTB6(element));
							break;
						}
					}
					if(!isFoundLoanNo) {
						logger.info("***** Not Found In WS *****" + inf.getLoan_no());
						//set value to not found
						DTOConverter.populateDataFailToScanTB6(inf);
					}else {
						//set value to found
						DTOConverter.populateDataSuccesToScanTB6(inf);
					}
				}
				
				//Update trx to DB
				if(CollectionUtils.isNotEmpty(lstMas) && CollectionUtils.isNotEmpty(lstScan)) {
					getRepositoryManagerService().updateTBTrxFoundInLMSToDB(lstScan, lstMas);
					logger.info("***** Update Trx to DB Success *****");
					logger.info("***** End LMS to Re-Scan Not Found TB Trx Schedule *****");
					return true;
				}
			}
			
		}catch (Exception ex) {
			ex.printStackTrace();
			return false;
		}
		
		
		logger.info("***** End LMS to Re-Scan Not Found TB Trx Schedule *****");
		return false;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FCLApiService#removeNotFoundDataForTBTrx()
	 */
	@Override
	public boolean removeNotFoundDataForTBTrx() throws BaseException {
		logger.info("***** Start Scan Not Found TB Trx To Remove Schedule *****");
		
		List<TOmsFCLTBInf> lstScan = getRepositoryManagerService().getTbManagerRepositoryService().getListTBTrxScanningNotFoundForRemove();
		if(CollectionUtils.isEmpty(lstScan)){
			logger.info("***** No Record Found *****");
			logger.info("***** End Scan Not Found TB Trx To Remove Schedule *****");
			return true;
		} else {
			//Remove Not Found to TB
			getRepositoryManagerService().deleteTBTrxNotFoundInLMSToDB(lstScan);
			logger.info("***** Remove Trx Success *****");
		}
		
		logger.info("***** End Scan Not Found TB Trx To Remove Schedule *****");
		return false;
	}

}
