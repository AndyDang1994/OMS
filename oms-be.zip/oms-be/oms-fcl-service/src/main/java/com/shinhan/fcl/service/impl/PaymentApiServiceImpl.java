/**
 * 
 */
package com.shinhan.fcl.service.impl;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.fcl.common.AbstractBasicCommonClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.util.CommonUtil;
import com.shinhan.fcl.core.util.DTOConverter;
import com.shinhan.fcl.repository.entity.TOmsFCLFormPaymentInf;
import com.shinhan.fcl.repository.entity.TOmsFCLPaymentInf;
import com.shinhan.fcl.service.PaymentApiService;

/**
 * @author shds01
 *
 */

@Service("paymentApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class PaymentApiServiceImpl extends AbstractBasicCommonClass implements PaymentApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#getListPaymentAvailable(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListPaymentAvailable(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		return getRepositoryManagerService().getPaymentManagerRepositoryService().getListPaymentAvailable(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#countPaymentAvailableTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countPaymentAvailableTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getPaymentManagerRepositoryService().countPaymentAvailableTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.PaymentApiService#executeRemovePayment(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeRemovePayment(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLPaymentInf> listUpd = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLPaymentInf inf = getValidationManagerService().checkValidationExecuteRemovePayment(trx);
			if(trx.getValid() && inf == null){
				listUpd.add(DTOConverter.populateDataExecuteRemovePaymentNew(trx.getLoan_no(), userName));
				count++;
			} else {
				if(inf != null && StringUtils.isNotBlank(inf.getStatus_code())) {
					throw new ServiceRuntimeException(String.format(env.getProperty("MSG_014"), trx.getLoan_no()));
				} else if(inf != null && StringUtils.isBlank(inf.getStatus_code())) {
					DTOConverter.populateDataExecuteRemovePayment(inf, userName);
					listUpd.add(inf);
					count++;
				} else {
					throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
				}
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().executeRemovePaymentTrxToDB(listUpd);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.PaymentApiService#executeETPayment(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> executeETPayment(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLPaymentInf> listReg = new ArrayList<>();
		ArrayList<TOmsFCLFormPaymentInf> listRegFormPayment = new ArrayList<>();
		int count = 0;
		int countTotal = 0;

		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLPaymentInf inf = getValidationManagerService().checkValidationExecuteETPayment(trx);
			if(trx.getValid()){
				if(inf == null) {
					listReg.add(DTOConverter.populateDataExecuteETPaymentNew(trx.getLoan_no(), userName));
				} else {
					DTOConverter.populateDataExecuteETPayment(inf, userName);
					listReg.add(inf);
				}
				listRegFormPayment.add(DTOConverter.populateDataExecuteETFormPayment(trx.getLoan_no(), userName));
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().executeETPaymentTrxToDB(listReg, listRegFormPayment);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.PaymentApiService#updateRemarkPayment(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> updateRemarkPayment(Map<String, Object> inputParams)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<EarlyTerminationTrx> lst = CommonUtil.toListPojo(document, EarlyTerminationTrx.class);
		ArrayList<TOmsFCLPaymentInf> listReg = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.ACTION_LIMIT_TRX));
		if(CollectionUtils.isNotEmpty(lst) && lst.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(EarlyTerminationTrx trx : lst) {
			TOmsFCLPaymentInf inf = getValidationManagerService().checkValidationUpdateRemarkPayment(trx);
			if(trx.getValid()){
				if(inf == null) {
					listReg.add(DTOConverter.populateDataUpdateRemarkPaymentNew(trx.getLoan_no(), userName, trx.getRemarks()));
				} else {
					DTOConverter.populateDataUpdateRemarkPayment(inf, userName, trx.getRemarks());
					listReg.add(inf);
				}
				count++;
			} else {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_009"), String.valueOf(trx.getLoan_no()), String.valueOf(trx.getErrorMessage())));
			}
			countTotal++;
		}
		
		if(countTotal == count){
			getRepositoryManagerService().executeUpdateRemarkPaymentTrxToDB(listReg);
		}
		
		return lst;
	
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.PaymentApiService#exportReportForPayment(java.util.Map)
	 */
	@Override
	public File exportReportForPayment(Map<String, Object> inputParams) throws BaseException {
		inputParams.put(APIConstant._TEMPLATE_NAME, APIConstant.EXPORT_FCL_REPORT_TEMPLATE_NAME_PAYMENT_AVAIABLE);
		
		File fileExport = getProcessManagerService().getExportReportService().exportReportByTemplate(inputParams);
		if(fileExport == null || !fileExport.exists()) {
			return null;
		}
		return fileExport;
	}

}
