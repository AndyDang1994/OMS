/**
 * 
 */
package com.shinhan.fcl.service;

import java.io.File;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;

/**
 * @author shds01
 *
 */
public interface TBApiService {
	
	public List<EarlyTerminationTrx> getListTB(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countTBTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<EarlyTerminationTrx> getListTBDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countTBDoneTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<EarlyTerminationTrx> uploadListTBTrx(Map<String, Object> inputParams) throws BaseException;
	
	public List<EarlyTerminationTrx> updateRemark(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<EarlyTerminationTrx> executeDoneTB(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<EarlyTerminationTrx> executeRemoveTB(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<EarlyTerminationTrx> executeUnRemoveTB(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<EarlyTerminationTrx> executeTBWaiveOff(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<EarlyTerminationTrx> executeTBDummy(Map<String, Object> inputParams) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public File exportReportFormTrx(Map<String, Object> inputParams) throws BaseException;
}
