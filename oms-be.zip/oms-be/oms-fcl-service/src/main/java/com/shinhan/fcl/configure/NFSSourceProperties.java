package com.shinhan.fcl.configure;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "nfs.client.oms")
public class NFSSourceProperties {

	private String host;

	private String username;

	private String password;

	private String waiveoffDirectory;

	private String dummyDirectory;

	/**
	 * @return the host
	 */
	public String getHost() {
		return host;
	}

	/**
	 * @param host the host to set
	 */
	public void setHost(String host) {
		this.host = host;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the waiveoffDirectory
	 */
	public String getWaiveoffDirectory() {
		return waiveoffDirectory;
	}

	/**
	 * @param waiveoffDirectory the waiveoffDirectory to set
	 */
	public void setWaiveoffDirectory(String waiveoffDirectory) {
		this.waiveoffDirectory = waiveoffDirectory;
	}

	/**
	 * @return the dummyDirectory
	 */
	public String getDummyDirectory() {
		return dummyDirectory;
	}

	/**
	 * @param dummyDirectory the dummyDirectory to set
	 */
	public void setDummyDirectory(String dummyDirectory) {
		this.dummyDirectory = dummyDirectory;
	}

}
