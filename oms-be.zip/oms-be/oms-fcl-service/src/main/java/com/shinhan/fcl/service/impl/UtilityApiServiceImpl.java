/**
 * 
 */
package com.shinhan.fcl.service.impl;

import java.io.File;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.fcl.common.AbstractBasicCommonClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.repository.entity.TMetadata;
import com.shinhan.fcl.service.UtilityApiService;

/**
 * @author shds01
 *
 */

@Service("utilityApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class UtilityApiServiceImpl extends AbstractBasicCommonClass implements UtilityApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.UtilityApiService#getTemplateNameToImport(java.util.Map)
	 */
	@Override
	public File getTemplateNameToImport(Map<String, Object> inputParams) throws BaseException {

		String templateName = inputParams.get(APIConstant._TEMPLATE_NAME_KEY).toString();
		String folderDir = env.getProperty(APIConstant.PATH_TEMPLATE_UPLOAD_FCL);
		if(StringUtils.isBlank(templateName)) {
			return null;
		}
		
		TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService()
				.getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_FCL_TEMPLATE_UPLOAD_DATA, templateName);
		if(item == null) {
			return null;
		}
		
		return new File(folderDir + item.getValue());
	
	}

}
