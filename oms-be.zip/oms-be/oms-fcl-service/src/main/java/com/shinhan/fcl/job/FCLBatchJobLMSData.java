/**
 * 
 */
package com.shinhan.fcl.job;

import java.time.LocalDateTime;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.shinhan.fcl.common.AbstractBasicCommonClass;
import com.shinhan.fcl.core.exception.BaseException;


/**
 * @author shds01
 *
 */
@Component
public class FCLBatchJobLMSData extends AbstractBasicCommonClass {

	@Scheduled(fixedDelayString = "${spring.job.application.fixedDelay.fcl.tb.lmsData}") // 1 minutes
	public void getDataForTBTrx() throws BaseException {
		logger.info("***** Start FCL Get data for TB in LMS Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		getProcessManagerService().getFclApiService().populateDataForTBTrx();
		logger.info("***** End FCL Get data for TB in LMS Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
	
	@Scheduled(cron = "${spring.job.application.everyday.scanTBFailTrx.lmsData}") // 6:00 AM to 8:00 AM everyday, 30 minutes each running
	public void scanDataNotFoundForTBTrx() throws BaseException {
		logger.info("***** Start FCL Scan Not Found data for TB re-scan in LMS Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		getProcessManagerService().getFclApiService().populateNotFoundDataForTBTrx();
		logger.info("***** End FCL Scan Not Found data for TB re-scan LMS Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
	
	@Scheduled(cron = "${spring.job.application.everyday.removeTBFailTrx.lmsData}") // 1AM - 2AM everyday, 30 minutes each running
	public void scanDataNotFoundToRemoveForTBTrx() throws BaseException {
		logger.info("***** Start FCL Scan Not Found data for TB re-scan in LMS Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		getProcessManagerService().getFclApiService().removeNotFoundDataForTBTrx();
		logger.info("***** End FCL Scan Not Found data for TB re-scan LMS Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
	

}
