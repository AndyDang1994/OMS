package com.shinhan.creditshield.repository.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.shinhan.creditshield.repository.entity.TOmsCreditShieldLmsInf;
import com.shinhan.creditshield.repository.entity.TOmsCreditShieldLmsMas;

public interface TOmsCreditShieldLmsMasDAO extends JpaRepository<TOmsCreditShieldLmsMas, Long>, JpaSpecificationExecutor<TOmsCreditShieldLmsMas> {
	
	@Query("SELECT mas FROM TOmsCreditShieldLmsMas mas WHERE mas.loanNo IN :lstLoanNo")
	public List<TOmsCreditShieldLmsMas> getAllByLoanNo(@Param("lstLoanNo") List<String> lstLoanNo);
	
	@Query("SELECT mas FROM TOmsCreditShieldLmsMas mas WHERE mas.loanNo = :loanNo")
	public TOmsCreditShieldLmsMas getByLoanNo(@Param("loanNo") String loanNo);
	
}
