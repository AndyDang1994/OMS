package com.shinhan.creditshield.core.model;

import org.apache.commons.lang3.StringUtils;

public class UpdateActionAndNoteTemplateInfo {
	private String loanNo;
	private String action;
	private String note;
	private String errorMessage;
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public boolean getValid() {
		if (StringUtils.isNotBlank(errorMessage)) {
			return false;
		}
		return true;
	}
	
}
