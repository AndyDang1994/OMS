package com.shinhan.creditshield.core.constant;

public enum CitiBankRefundReportHeader {
	Payment_Method("Payment Method"),
	Value_Date("Value Date"),
	Transaction_Reference_Number("Transaction Reference Number"),
	Beneficiary_name("Beneficiary name"),
	Beneficiary_Address("Beneficiary Address"),
	Payment_Amount("Payment Amount"),
	Payment_Currency("Payment Currency"),
	Beneficiary_Account_Number_Or_Other_ID("Beneficiary Account Number or Other ID"),
	Bank_Code("Bank  Code"),
	Beneficiary_Bank_Name("Beneficiary Bank Name"),
	Beneficiary_Bank_Address("Beneficiary Bank Address"),
	Debit_Account_Number("Debit Account Number"),
	Payment_Details("Payment Details"),
	Charges_Indicator("Charges Indicator");

	public final String label;
	CitiBankRefundReportHeader(String label) {
		// TODO Auto-generated constructor stub
		this.label = label;
	}
	
}
