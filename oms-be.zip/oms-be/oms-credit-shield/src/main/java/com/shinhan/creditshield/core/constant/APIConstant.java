/**
 * 
 */
package com.shinhan.creditshield.core.constant;

import java.math.BigDecimal;

/**
 * @author shds01
 *
 */

public class APIConstant {

	/** Common Constant */
	public static final String ALL = "all";
	public static final String DOCUMENT = "document";
	public static final String DOCTYPE = "docType";
	public static final String DATA = "data";
	public static final String COUNT = "count";

	public static final String DATA_LIMIT_CONDTION_SEARCHING_IN = "search.limit.condition.in";
	public static final String UPLOAD_LIMIT_TRX = "UPLOAD_LIMIT_TRX";
	public static final String _START_DATE_KEY = "_startDt";
	public static final String _END_DATE_KEY = "_endDt";
	public static final String _STATUS_KEY = "status";
	public static final String _START_KEY = "_start";
	public static final String _TYPE_KEY = "_type";
	public static final String _NUMBER_KEY = "_number";
	public static final String USERNAME_KEY = "userName";
	public static final String EXPIRY_DATE = "expiryDate";
	public static final String TRACKING_LOG_INSTANCE = "trackingLogInstance";
	
	public static final String SUPERGEN_KEY = "super_user";
	public static final String SHINHAN_USERNAME_KEY = "shinhan.common.userName";
	public static final String SHINHAN_PASSWORD_KEY = "shinhan.common.password";
	
	/** Common Document Constant */
	public static final String FILE_TYPE_JSON = ".json";
	public static final String FILE_TYPE_XML = ".xml";
	public static final String FILE_TYPE_EXCEL_OLD = ".xls";
	public static final String FILE_TYPE_EXCEL_NEW = ".xlsx";
	public static final String FILE_TYPE_CSV = ".csv";
	public static final String SHEET_NAME_DATA = "Data";
	public static final String SHEET_NAME_TCB = "TCB trong";
	public static final String SHEET_NAME_CITI = "CITI trong";
	
	/** UPLOAD Constant **/
	public static final String PATH_SCAN_BANK_STATEMENT_FTP_FOLDER= "PATH_SCAN_BANK_STATEMENT_FTP_FOLDER";
	public static final String PATH_SCAN_BANK_TEMP_FOLDER= "PATH_SCAN_BANK_TEMP_FOLDER";
	public static final String FOLDER_TEMPLATE_REPORT= "FOLDER_TEMPLATE_REPORT";
	public static final String FOLDER_EXPORT_REPORT= "FOLDER_EXPORT_REPORT";
	public static final String PATH_SHARE_FOLDER = "PATH_SHARE_FOLDER";
	

	/** HTTP Description **/
	public static final String HTTP_REQUEST_BODY_STR = "HttpRequestBody";
	public static final String METHOD_NOT_ALLOWED = "Method is not allowed";
	public static final String UNSUPPORTED_MEDIA_TYPE = "Media type is unsupported";
	public static final String NOT_ACCEPTABLE = "Not Acceptable";

	public static final String ANONYMOUS_USER = "Anonymous";

	public static final String TEXT_HTML_CHARSET_UTF8_CHARSET_TYPE = "text/html;charset=UTF-8";
	public static final String UTF_8_CHARSET_TYPE = "UTF-8";
	public static final String CONTENT_TYPE_REQUEST_HEADER = "Content-Type";

	public static final String CONTENT_TYPE_IMAGE_PNG = "image/png";
	public static final String CONTENT_TYPE_IMAGE_JPG = "image/jpeg";

	public static final String CONTENT_TYPE_JSON = "application/json";
	public static final String CONTENT_TYPE_XML = "application/xml";
	public static final String CONTEXT_FILTER_PATH = "shinhan/service/";
	
	public static final String REQUEST_URI_STR = "requestURI";
	public static final String OMS_AUTHENTICATION_SERVICE_USERPROFILE = "oms_authen_service_profile";
	public static final String OMS_AUTHENTICATION_SERVICE_USERPERMISSION = "oms_authen_service_userPermission";

	/** Exception Constant **/
	public static final String THE_TOKEN_IS_INVALID_ERROR = "The Token is invalid";
	public static final String THE_TOKEN_IS_INCORRECT_FORMAT_ERROR = "The Token is incorrect format";
	public static final String THE_TOKEN_IS_BLANK_ERROR = "The Token is blank";
	public static final String NO_RECORD_FOUND_KEY = "No record found";
	/** SECURE Constant **/
	public static final String SYSADMIN_STR = "SYSADMIN";
	public static final String ACCESS_TOKEN_KEY = "access-token";
	
	public static final String PUBLIC_KEY = "public_key";
	public static final String EXECUTION_TIME_KEY = "executionTime";

	/** Other Constant **/
	public static final String YES_KEY = "Y";
	public static final String NULL_KEY = "NULL";
	public static final String SUCCESS_KEY = "SUCCESS";
	public static final String JSON_KEY_OBJECT_INFO = "info";
	public static final String JSON_KEY_OBJECT_ACTION = "action";
	
	public static final BigDecimal DEC_ZERO = new BigDecimal("0");
//	/** Metadata Constant */
	public static final String _LOOKUP_CODE_KEY = "lookupCode";
//	public static final String _LOOKUP_CODE_BANK_VALUE_ = "BANK_CODE";
//	public static final String _LOOKUP_CODE_BANK_DISB_VALUE_ = "BANK_CODE_DISB";
//	public static final String _LOOKUP_CODE_BANK_REPORT_VALUE_ = "BANK_REPORT_NM";
//	public static final String _UPLOADED_FILE_KEY = "UPLOAD_FILE_STATUS";
//	public static final String _BANK_STATEMENT_STATUS_KEY = "BANK_STATEMENT_TRX_STATUS";
	public static final String LOOKUP_CODE_RF_TEMPLATE_EXPORT_DATA_BANK = "RF_TEMPLATE_EXPORT_DATA";
	public static final String LOOKUP_CODE_CREDIT_SHIELD_BANK_NAME = "EXPORT_CREDIT_SHIELD_BANK_NAME";
//	
//	/** LMS Trx Status **/
//	public static final long LMS_TRX_MATCHED = 1;
//	public static final long LMS_MONEY_IN_TRANSIT = 9;
	public static final long LMS_EXCESS_MONEY_STATUS = 10;
//	public static final long LMS_OTHER_CASE_STATUS = 8;
//	public static final long LMS_REVERT = 11;
//	public static final long LMS_UPLOAD_PENDING = 2;
//	public static final long LMS_UPLOADED_PENDING = 3;
//	public static final long LMS_CANCEL_TRX = 4;
//	public static final long LMS_DELETE_TRX = 7;
//	public static final long LMS_CASE_HANDLED_TRX = 6;
//	public static final long _LMS_LOAN_STATUS_ACTIVE = 1;
//	public static final long _LMS_LOAN_STATUS_UNACTIVE = 2;
//	
//	/** Metadata Value Constant */
//	public static final long _BANK_STATEMENT_MATCH_STATUS = 1;
//	public static final long _BANK_STATEMENT_PENDING_STATUS = 2;
//	public static final long _BANK_STATEMENT_FIN_DAILY_STATUS = 11;
//	public static final long _BANK_STATEMENT_REVERT_STATUS = 3;
//	public static final long _BANK_STATEMENT_REFUND_STATUS = 4;
//	public static final long _BANK_STATEMENT_FINANCE_STATUS = 5;
//	public static final long _BANK_STATEMENT_CASE_HANDLED_STATUS = 6;
//	public static final long _BANK_STATEMENT_OTHER_CASE_STATUS = 8;
//	public static final long _BANK_STATEMENT_DELETED_STATUS = 7;
//	public static final long _UPLOAD_FILE_PENDING_STATUS = 16;
//	public static final long _UPLOAD_FILE_NORMAL_STATUS = 10;
//	public static final long _UPLOAD_FILE_DELETE_STATUS = 20;
//	public static final long _UPLOAD_FILE_PENDING_DELETE_STATUS = 19;
//	public static final long _RECONCILE_PROCESSING_STATUS = 11;
//	public static final long _RECONCILE_DONE_STATUS = 10;
//	public static final long _RECONCILE_ERROR_STATUS = 19;
//	public static final long _SUSPENSE_PENDING_STATUS = 2;
//	public static final long _SUSPENSE_DONE_STATUS = 1;
//	public static final long _SUSPENSE_DELETE_STATUS = 3;
//	public static final long _LOAN_CORRECT_SUBSTATUS = 1;
//	public static final long _LOAN_INCORRECT_SUBSTATUS = 2;
//	public static final long _LOAN_INPARSE_SUBSTATUS = 3;
//	public static final long _BANK_DISBURSAL_STATUS_MATCHED = 1;
//	public static final long _BANK_DISBURSAL_STATUS_PENDING = 2;
//	public static final long _BANK_DISBURSAL_STATUS_REVERTED = 3;
//	public static final long _BANK_DISBURSAL_STATUS_CRSHIELD = 4;
//	public static final long _BANK_DISBURSAL_STATUS_FINANCE = 5;
//	public static final long _BANK_DISBURSAL_STATUS_EXCESS  = 6;
//	public static final long _BANK_DISBURSAL_STATUS_RE_DISB  = 8;
//	public static final long _BANK_DISBURSAL_STATUS_DELETE  = 7;
//	
//	
//	/** File Statement Mas Constant **/
//	public static final String UPLOAD_DATE_KEY = "uploadDt";
//	public static final String UPLOAD_BANKCODE_KEY = "bankCode";
//	public static final String UPLOAD_BANKSTATUS_KEY = "status";
	public static final String UPLOAD_TRXTYPE_KEY = "transactionType";
//	public static final String VALUE_DATE_KEY = "valueDt";
//	public static final String TRX_DATE_KEY = "trxDt";
//	public static final String FILE_NAME = "FILE_NAME";
//	public static final String FILE_ID = "fileId";
//	
//	
//	/** Bank Statement Transaction Constant **/
//	public static final String REF_KEY = "ref";
	public static final String LOAN_NO_KEY = "loanNo";
//	public static final String PAY_MODE_KEY = "payMode";
	public static final String CIF_KEY = "cif";
	public static final String _BANK_CODE_KEY = "bankCode";
//	public static final String _BANK_NAME_KEY = "bankName";
	public static final String ACTION_KEY = "action";
//
//	/** Common Constant */
//	public static final String _BIZCODE_KEY = "biz_code";
//	public static final String _BANK_STATEMENT_MATCHING = "MATCHING_LIST";
//	public static final String _BANK_LMS_MATCHING = "LMS_MATCHING_LIST";
//	public static final String _BANK_STATEMENT_REVERSAL = "REVERSAL_LIST";
//	public static final String _BANK_STATEMENT_FINANCE = "FINANCE_LIST";
//	public static final String _BANK_STATEMENT_FINANCE_PENDING = "FINANCE_PENDING_LIST";
//	public static final  String _BANK_STATEMENT_UNMATCHING = "UN_MATCHING_LIST";
//	public static final  String _BANK_LMS_UNMATCHING = "UN_MATCHING_LMS_LIST";
//	public static final  String _BANK_SUSPEND_LIST = "SUSPEND_LIST";
//	public static final  String _BANK_DISBURS_MATCHED = "BANK_DISBURS_MATCHED";
//	public static final  String _BANK_DISBURS_FINANCE = "BANK_DISBURS_FINANCE";
//	public static final  String _BANK_DISBURS_UNMATCH = "BANK_DISBURS_UNMATCH";
//	public static final  String _BANK_DISBURS_REVERT = "BANK_DISBURS_REVERT";
//	public static final  String _BANK_DISBURS_CRSHIELD = "BANK_DISBURS_CRSHIELD";
//	public static final String _OMS_ADMINSTRATOR_ = "Admin";
//	public static final String _OMS_FILESCANBATCH_ = "Scan_File_Batch_Job";
//	public static final String _OMS_RECONBATCH_ = "Recon_Batch_Job";
//	
//	
//	/** Bank Common **/
//	public static final String _BANK_COMMON_BIZ_TEMPLATE_VALUE_ = "BANK_FILE_TEMPLATE";
//	public static final String _BANK_COMMON_BIZ_DISBURSAL_TEMPLATE_VALUE_ = "BANK_FILE_DISBURSAL_TEMPLATE";
//	public static final String _BANK_COMMON_BIZ_FILE_VALUE_ = "BANK_FILE_VAL";
//	public static final String _BANK_COMMON_BIZ_VALUE_ = "BIZ_VALUE";
//	
//	/** Regex Contain **/
//	public static final String _BANK_REGEX_FINANCE = "REGEX_FINANCE";
//	public static final String _REGEX_CHECK_LOAN_SUSPENSE = "REGEX_CHECK_LOAN_SUSPENSE";
//	public static final String _BANK_REGEX_REVERSAL = "REGEX_REVERSAL";
//	public static final String _BANK_REGEX_FINANCE_VCB = "REGEX_REVERSAL_VCB";
//	public static final String _REGEX_GET_REF_AGRIBANK = "REGEX_GET_REF_AGRIBANK";
//	public static final String _REGEX_GET_REF_OCB061 = "REGEX_GET_REF_OCB061";
//	public static final String _REGEX_EXCPT_OCB061 = "REGEX_EXCPT_OCB061";
//	public static final String _REGEX_GET_LOAN_NO = "REGEX_GET_LOAN_NO";
//	public static final String _REGEX_DISB_FINANCE_VCB = "REGEX_DISB_FINANCE_VCB";
//	public static final String _REGEX_DISB_CRSHIELD_VCB = "REGEX_DISB_CRSHIELD_VCB";
//	public static final String _REGEX_DISB_REVERT_VCB = "REGEX_DISB_REVERT_VCB";
//	
//	/** LMS Transaction Type **/
	public static final long LMS_TRX_TYPE_REPAYMENT = 1;
//	public static final long LMS_TRX_TYPE_DISBURSAL = 3;
//	
//	
//	/** Suspense Report Note **/
//	public static final String _SUSPENSE_NOTE_UNDFT = "Unidentified receipts";
//	public static final String _SUSPENSE_NOTE_LATE_UPLOAD = "Late upload of bank statement";
//	public static final String _SUSPENSE_NOTE_OVERPAY = "Over-payment from customers";
//	public static final String _SUSPENSE_NOTE_WRONG_ACC = "Wrong credit to SVFC’s accounts";
//	
//	/** Report file type **/
//	public static final long _DAILY_SUMMARY = 1;
//	public static final long _DAILY_OPS = 2;
//	public static final long _DAILY_OPS_DISB = 3;
//	public static final long _DAILY_COLLECTION = 4;
//	
//	/** Suspense Report Type **/
//	public static final long _SUSPENSE_RPT = 1;
//	public static final long _WRITEOFF_RPT = 2;
//	
//	/** input report type **/
//	public static final String _STMT_ = "STMT";
//	public static final String _LMS_ = "LMS";
//	public static final String _DISB_ = "DISB";
//	
//	
//	/** pending report sheet name **/
//	public static final String _REPMT_SHEET_NM = "Pending_Repayment";
//	public static final String _DISB_SHEET_NM = "Pending_Disbursal";
	/** UPLOAD Constant **/
	public static final String PATH_TEMPLATE_BANK_REFUND = "PATH_TEMPLATE_BANK_REFUND";
	public static final String PATH_EXPORT_BANK_REFUND ="PATH_EXPORT_REFUND";
	
	/** Refund Template */
	public static final String CITIBANK_BANK_TEMPLATE_REFUND = "CITIBANK";
	public static final String TECHCOMBANK_BANK_TEMPLATE_REFUND = "TECHCOMBANK";
	
	public static final String CITIBANK_REFUND_FILE_NAME = "Refund_trong_Citibank_";
	public static final String TCB_REFUND_FILE_NAME = "Refund_trong_TCB_";
	public static final String BANK_NAME_OF_SACOMBANK= "VIETCOMBANK";
	public static final int BANK_CODE_IN_HCM_CITY = 79;
	public static final int TRANSFERFEE_OF_SACOMBANK = 11000;
	public static final int TRANSFERFEE_FOR_BANK_OF_HCM_CITY = 4400;
	public static final int DEFAULT_TRANSFERFEE = 18700;
	
	public static final String PAYMENT_DETAILS_OF_REFUND = "TAI CHINH SHINHAN VIET NAM HOAN TRA TIEN NOP DU [Customer Name] TAI [Bank Branch] THEO HOP DONG [Loan No]";
	
	/** RF_TEMPLATE_EXPORT_DATA_BANK_REGISTRATION */
	public static final String ACB_TEMPLATE_BANK_REFUND = "ACB";
	public static final String AGRIBANK_TEMPLATE_BANK_REFUND = "AGRIBANK";
	public static final String SACOMBANK_TEMPLATE_BANK_REFUND = "SACOMBANK";
	public static final String VCB_TEMPLATE_BANK_REFUND = "VIETCOMBANK";
	public static final String VIETTINBANK_TEMPLATE_BANK_REFUND = "VIETINBANK";
	public static final String BIDV_TEMPLATE_BANK_REFUND = "BIDV";
	
	/**Service name Metadata*/
	public static final String SERVICENAME_REFUND = "REFUND";
	
	/**Constant refund citi bank*/
	public static final String CITIBANK_REFUND_PAYMENT = "DFT";
	public static final String REFUND_CURRENCY = "VND";
	public static final String CHARGES_INDICATOR = "OUR";
	
	/** TOmsAutoDebitLmsMas Constant */
	public static final String _BANK = "_bank";
	
	
	//Credit Shield
	public static final String BENEFICIARY_BRANCH_BANK_FILE_NAME = "Bank_Name_Convert_List";
	public static final String KEY_WORD_BENEFICIARY_BANK_NAME = "KEY WORD _ Beneficiary Bank Name";
	public static final String REVISED_BENEFICIARY_BANK_NAME = "Revised Beneficiary Bank Name";
	public static final String CREDIT_SHIELD_REPORT_NEW_LIFE_PAYMENT = "New_Credit_Life_Payment_List_10";
	public static final String CREDIT_SHIELD_REPORT_NEW_LIFE_PRETER_SVFC = "New_Credit_Life_Preter_SVFC_10";
	public static final String _TYPE_REPORT = "_type";
	public static final String TYPE_ACTION_SURRENDER = "SR";
	public static final String TYPE_ACTION_CSFOLLOWUP = "CSF";
	public static final String TYPE_ACTION_CFI = "CFI";
	public static final String BEN_ACCOUNT_ZERO = "0";
	public static final String BEN_ACCOUNT_DUMMY = "Dummy";
	public static final String BEN_ACCOUNT_DOT = ".";
	public static final String BEN_ACCOUNT_EMPTY = " ";
	
	
}
