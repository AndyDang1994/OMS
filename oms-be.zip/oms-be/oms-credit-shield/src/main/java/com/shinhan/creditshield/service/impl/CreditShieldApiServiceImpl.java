/**
 * 
 */
package com.shinhan.creditshield.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.creditshield.common.AbstractBasicCommonClass;
import com.shinhan.creditshield.core.constant.APIConstant;
import com.shinhan.creditshield.core.exception.BaseException;
import com.shinhan.creditshield.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.creditshield.core.model.CsCfiInfo;
import com.shinhan.creditshield.core.model.DrCfiInfo;
import com.shinhan.creditshield.core.model.UpdateActionAndNoteTemplateInfo;
import com.shinhan.creditshield.core.model.UpdateCustomerInfTemplateInfo;
import com.shinhan.creditshield.core.util.CommonUtil;
import com.shinhan.creditshield.core.util.DTOConverter;
import com.shinhan.creditshield.repository.entity.TOmsCreditShieldLmsInf;
import com.shinhan.creditshield.repository.entity.TOmsCreditShieldLmsMas;
import com.shinhan.creditshield.service.CreditShieldApiService;

/**
 * @author shds06
 *
 */
@Service("creditShieldApiService")

public class CreditShieldApiServiceImpl extends AbstractBasicCommonClass implements CreditShieldApiService {

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	@Override
	public List<CsCfiInfo> getDataCsCfi(Map<String, Object> inputParams) throws BaseException {

		return getRepositoryManagerService().gettOmsCreditShieldLmsManagerRepositoryService().getDataCsCfi(inputParams);
	}

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	@Override
	public List<DrCfiInfo> getDataDrCfi(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().gettOmsCreditShieldLmsManagerRepositoryService().getDataDrCfi(inputParams);
	}

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	@Override
	public List<CsCfiInfo> getDataCsNoBankAcc(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().gettOmsCreditShieldLmsManagerRepositoryService()
				.getDataCsNoBankAcc(inputParams);
	}

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	@Override
	public List<CsCfiInfo> getDataSurrenderReport(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().gettOmsCreditShieldLmsManagerRepositoryService()
				.getDataSurrenderReport(inputParams);
	}

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	@Override
	public Long countDataCsCfi(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().gettOmsCreditShieldLmsManagerRepositoryService()
				.countTotalDataCsCfi(inputParams);
	}

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	@Override
	public Long countDataDrCfi(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().gettOmsCreditShieldLmsManagerRepositoryService()
				.countTotalDataDrCfi(inputParams);
	}

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	@Override
	public Long countDataCsNoBank(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().gettOmsCreditShieldLmsManagerRepositoryService()
				.countTotalDataCsNoBank(inputParams);
	}

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	@Override
	public Long countDataSurrender(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().gettOmsCreditShieldLmsManagerRepositoryService()
				.countTotalDataSurrender(inputParams);
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED)
	@Override
	public boolean update(Map<String, Object> inputParams) throws BaseException, JSONException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		//get data update from JSON
		JSONArray jsonArr = new JSONArray(document);
		List<String> lstUpdate = new ArrayList<String>();
		
		List<TOmsCreditShieldLmsInf> lstItemInfInDB = new ArrayList<>();
		
		List<TOmsCreditShieldLmsMas> lstItemMasInDB = new ArrayList<>();
		//Convert list data json to object
		for(int i = 0; i < jsonArr.length(); i++) {
			String item = jsonArr.getJSONObject(i).get("trx").toString();
			lstUpdate.add(item);
		}
		boolean flag = false;
		if(CollectionUtils.isEmpty(lstUpdate)) {
			return false;
		}
		int countInf = 0;
		int countTotalInf = 0;
		int countMas = 0;
		int countTotalMas = 0;
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.DATA_LIMIT_CONDTION_SEARCHING_IN));
		
		if(CollectionUtils.isNotEmpty(lstUpdate) && lstUpdate.size() > limitTrx) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
		}
		
		for(String item : lstUpdate) {
			JSONObject jsonObject = new JSONObject(item);
			//get object action from json
			UpdateActionAndNoteTemplateInfo updateActionInfo = (UpdateActionAndNoteTemplateInfo) CommonUtil.toPojo(
					jsonObject.get(APIConstant.JSON_KEY_OBJECT_ACTION).toString(), UpdateActionAndNoteTemplateInfo.class);
			
			TOmsCreditShieldLmsInf itemInf = getValidationManagerService().checkValidationUpdateCreditShieldInf(updateActionInfo);
			
			//get object info from json
			UpdateCustomerInfTemplateInfo updateCustomerInfo = (UpdateCustomerInfTemplateInfo) CommonUtil.toPojo(
					jsonObject.get(APIConstant.JSON_KEY_OBJECT_INFO).toString(), UpdateCustomerInfTemplateInfo.class);
			
			TOmsCreditShieldLmsMas itemMas = getValidationManagerService().checkValidationUpdateCreditShieldMas(updateCustomerInfo);
			
			
			if(updateActionInfo.getValid()) {
				//case record not exist in database then set data to insert
				if(itemInf == null) {
					DTOConverter.getDataCreditInfFromInfoToCreate(updateActionInfo);
					
				}else {
					DTOConverter.setDataCreditInfFromInfo(itemInf, updateActionInfo);
				}
				countInf++;
				lstItemInfInDB.add(itemInf);
			} 
			countTotalInf++;
			if(updateCustomerInfo.getValid()) {
				if(itemMas != null) {
					DTOConverter.setDataCreditFromInfo(itemMas, updateCustomerInfo);
					//case type update action is surrender then update ben account no 
					if(APIConstant.TYPE_ACTION_SURRENDER.equals(updateActionInfo.getAction())){
						DTOConverter.setBenAccountNoFromInfo(itemMas);
					}
					
					countMas++;
					lstItemMasInDB.add(itemMas);
				}
			}
			countTotalMas++;
		}
		
		//update or insert to table TOmsCreditShieldLmsInf
		if(countTotalInf == countInf) {
			 flag = getRepositoryManagerService().gettOmsCreditShieldLmsManagerRepositoryService().updateNoteLoanNo(lstItemInfInDB);
		}
		
		//update or insert to table TOmsCreditShieldLmsMas
		if(countTotalMas == countMas) {
			 flag = getRepositoryManagerService().gettOmsCreditShieldLmsManagerRepositoryService().updateActionByLoanNo(lstItemMasInDB);
		}
		
		return flag;
	}
}
