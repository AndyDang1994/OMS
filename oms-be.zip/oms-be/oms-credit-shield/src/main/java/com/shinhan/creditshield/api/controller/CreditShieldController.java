package com.shinhan.creditshield.api.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.shinhan.creditshield.core.constant.APIConstant;
import com.shinhan.creditshield.core.exception.BaseException;
import com.shinhan.creditshield.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.creditshield.core.model.CsCfiInfo;
import com.shinhan.creditshield.core.model.DrCfiInfo;

@RestController
public class CreditShieldController extends BaseController {

	@RequestMapping(value = "shinhan/service/creditshield/getcscfi", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getDataCsCfiByLoanNo(
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number, Locale locale) throws BaseException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.LOAN_NO_KEY, StringUtils.isEmpty(_loanNo) ? APIConstant.ALL : _loanNo);
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		List<CsCfiInfo> list = getProcessManagerService().getCreditShieldApiService().getDataCsCfi(inputParams);
		Long totalRecords = getProcessManagerService().getCreditShieldApiService().countDataCsCfi(inputParams);
		return triggerSuccessOutPut(list, totalRecords);
	}

	@RequestMapping(value = "shinhan/service/creditshield/updateaction", produces = { "application/json;charset=utf-8",
			"application/xml;charset=utf-8" }, method = RequestMethod.PATCH)
	public ResponseEntity<Object> updateActionByLoanNo(@RequestBody(required = true) String document, Locale locale)
			throws BaseException, JSONException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.DOCUMENT, document);
		boolean flag = getProcessManagerService().getCreditShieldApiService().update(inputParams);
		
		if (!flag) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		return triggerSuccessOutPut(APIConstant.SUCCESS_KEY, JsonObject.class, null);
	}

	@RequestMapping(value = "shinhan/service/creditshield/getdrcfi", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getDataDrCfiByLoanNo(
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _cif,
			@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number, Locale locale) throws BaseException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.LOAN_NO_KEY, StringUtils.isEmpty(_loanNo) ? APIConstant.ALL : _loanNo);
		inputParams.put(APIConstant.CIF_KEY, StringUtils.isEmpty(_cif) ? APIConstant.ALL : _cif);
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		List<DrCfiInfo> list = getProcessManagerService().getCreditShieldApiService().getDataDrCfi(inputParams);
		Long totalRecords = getProcessManagerService().getCreditShieldApiService().countDataDrCfi(inputParams);
		return triggerSuccessOutPut(list, totalRecords);
	}

	@RequestMapping(value = "shinhan/service/creditshield/getcsnobankacc", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getDataCsNoBankAccByLoanNo(
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number, Locale locale) throws BaseException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.LOAN_NO_KEY, StringUtils.isEmpty(_loanNo) ? APIConstant.ALL : _loanNo);
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		List<CsCfiInfo> list = getProcessManagerService().getCreditShieldApiService().getDataCsNoBankAcc(inputParams);
		Long totalRecords = getProcessManagerService().getCreditShieldApiService().countDataCsNoBank(inputParams);
		return triggerSuccessOutPut(list, totalRecords);
	}

	@RequestMapping(value = "shinhan/service/creditshield/getsurrenderreport", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getDataSurrenderReport(
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number, Locale locale) throws BaseException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.LOAN_NO_KEY, StringUtils.isEmpty(_loanNo) ? APIConstant.ALL : _loanNo);
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		List<CsCfiInfo> list = getProcessManagerService().getCreditShieldApiService()
				.getDataSurrenderReport(inputParams);
		Long totalRecords = getProcessManagerService().getCreditShieldApiService().countDataSurrender(inputParams);
		return triggerSuccessOutPut(list, totalRecords);
	}

	@RequestMapping(value = "shinhan/service/creditshield/exportsurrenderreport", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> exportDataSurrenderReport(@RequestParam(required = true, defaultValue = "") String _type, Locale locale)
			throws BaseException, IOException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._TYPE_KEY, _type);
		File item = getProcessManagerService().getCreditShieldExportReportService()
				.exportNewCreditLifeReport(inputParams);
		if (item == null) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_004"));
		}

		return triggerSuccessOutPut(APIConstant.SUCCESS_KEY, JsonObject.class, null);
	}
}
