package com.shinhan.creditshield.repository.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.shinhan.creditshield.common.AbstractServiceClass;
import com.shinhan.creditshield.core.constant.APIConstant;
import com.shinhan.creditshield.core.exception.BaseException;
import com.shinhan.creditshield.core.exception.ServiceRuntimeException;
import com.shinhan.creditshield.core.model.CsCfiInfo;
import com.shinhan.creditshield.core.model.DrCfiInfo;
import com.shinhan.creditshield.core.util.DateUtils;
import com.shinhan.creditshield.repository.dao.TOmsCreditShieldLmsInfDAO;
import com.shinhan.creditshield.repository.dao.TOmsCreditShieldLmsMasDAO;
import com.shinhan.creditshield.repository.entity.TOmsCreditShieldLmsInf;
import com.shinhan.creditshield.repository.entity.TOmsCreditShieldLmsMas;
import com.shinhan.creditshield.repository.service.TOmsCreditShieldLmsManagerRepositoryService;

@Service("tomsCreditShieldLmsInfManagerRepositoryService")
public class TOmsCreditShieldLmsManagerRepositoryServiceImpl extends AbstractServiceClass
		implements TOmsCreditShieldLmsManagerRepositoryService {

	@Autowired
	private TOmsCreditShieldLmsMasDAO objectDao;
	
	@Autowired
	private TOmsCreditShieldLmsInfDAO infDao;

	@Override
	public List<CsCfiInfo> getDataCsCfi(Map<String, Object> inputParams) throws BaseException {

		String loanNo = inputParams.get(APIConstant.LOAN_NO_KEY).toString();
		int pageNumber = inputParams.get(APIConstant._START_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
						? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
						: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());

		int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
						? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
						: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
						
		String sql = "SELECT new com.shinhan.creditshield.core.model.CsCfiInfo("
				+ " mas.benName as benName, mas.benBank as benBank, mas.benAccountNo as benAccountNo,"
				+ " mas.loanNo as loanNo, mas.cif as cif, mas.customerName as customerName, "
				+ " mas.disbursalDate as disbursalDate, mas.closureDate as closureDate,"
				+ " mas.loanAmount as loanAmount, mas.creditShieldAmount as creditShieldAmount,"
				+ " inf.cfiDate as cfiDate, inf.action as action, inf.note as note" + " ) "
				+ " FROM TOmsCreditShieldLmsMas mas LEFT JOIN TOmsCreditShieldLmsInf inf ON mas.loanNo = inf.loanNo "
				+ " WHERE mas.closureDate IS NOT NULL AND mas.disbursalDate IS NOT NULL AND (mas.closureDate - mas.disbursalDate) <= 21 " 
				+ " AND (TO_DATE(:current_date, '"+DateUtils.DATEFORMAT+"') -  TO_DATE(TO_CHAR(mas.closureDate, '"+DateUtils.DATEFORMAT+"'), '"+DateUtils.DATEFORMAT+"')) <= 30"
				+ " AND (inf.action IS NULL OR inf.action = '"+ APIConstant.TYPE_ACTION_CSFOLLOWUP +"')"
				+ " AND ( :loanNo = '" + APIConstant.ALL+"' or mas.loanNo = :loanNo )"
				+ " ORDER BY mas.closureDate ASC, mas.loanNo ";

		
		Query query = entityManager.createQuery(sql);
		
		
		query.setParameter("loanNo", loanNo);
		query.setParameter("current_date", DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		
		query.setFirstResult((pageNumber - 1) * pageSize);
		query.setMaxResults(pageSize);

		List<CsCfiInfo> list = query.getResultList();
		return list;
	}

	@Override
	public boolean updateActionByLoanNo(List<TOmsCreditShieldLmsMas> item) throws BaseException {
		try {
			//update record to database
			if (CollectionUtils.isNotEmpty(item)) {
				objectDao.saveAll(item);
				return true;
			}
			
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public List<DrCfiInfo> getDataDrCfi(Map<String, Object> inputParams) throws BaseException {
		String loanNo = inputParams.get(APIConstant.LOAN_NO_KEY).toString();
		String cif = inputParams.get(APIConstant.CIF_KEY).toString();
		int pageNumber = inputParams.get(APIConstant._START_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
						? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
						: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());

		int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
						? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
						: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());

		String sql = "SELECT new com.shinhan.creditshield.core.model.DrCfiInfo ( "
				+ " mas.loanNo as loanNo, mas.cif as cif, mas.benName as customerName,"
				+ " mas.disbursalDate as disbursalDate, mas.loanAmount as loanAmount,"
				+ " mas.creditShieldAmount as creditShieldAmount, inf.cfiDate as cfiDate" + " ) "
				+ " FROM TOmsCreditShieldLmsMas mas  JOIN TOmsCreditShieldLmsInf inf ON mas.loanNo = inf.loanNo " ///join
				+ " WHERE MONTHS_BETWEEN(:currentDate, To_date(to_char(mas.disbursalDate, '"+DateUtils.DATEFORMAT+"'), '"+DateUtils.DATEFORMAT+"')) <= 48"
				+ " AND inf.action = '" + APIConstant.TYPE_ACTION_CFI + "'"
				+ " AND ( :loanNo = '" + APIConstant.ALL + "' or mas.loanNo = :loanNo)"
				+ " AND ( :cif = '" + APIConstant.ALL +"' or mas.cif = :cif)"
				+ " ORDER BY inf.cfiDate DESC, mas.loanNo ";

		Query query = entityManager.createQuery(sql);

		query.setParameter("loanNo", loanNo);
		query.setParameter("cif", cif);
		query.setParameter("currentDate", DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		query.setFirstResult((pageNumber - 1) * pageSize);
		query.setMaxResults(pageSize);

		List<DrCfiInfo> list = query.getResultList();
		return list;
	}

	@Override
	public List<CsCfiInfo> getDataCsNoBankAcc(Map<String, Object> inputParams) throws BaseException {
		String loanNo = inputParams.get(APIConstant.LOAN_NO_KEY).toString();
		int pageNumber = inputParams.get(APIConstant._START_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
						? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
						: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());

		int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
						? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
						: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
						
		String sql = "SELECT new com.shinhan.creditshield.core.model.CsCfiInfo("
				+ " mas.benName as benName, mas.benBank as benBank,"
				+ " CASE WHEN mas.benAccountNoTemp IS NOT NULL THEN mas.benAccountNoTemp ELSE  mas.benAccountNo END as benAccountNo,"
				+ " mas.loanNo as loanNo, mas.cif as cif, mas.customerName as customerName, "
				+ " mas.disbursalDate as disbursalDate, mas.closureDate as closureDate,"
				+ " mas.loanAmount as loanAmount, mas.creditShieldAmount as creditShieldAmount,"
				+ " inf.cfiDate as cfiDate, inf.action as action, inf.note as note, mas.phoneNo as phoneNo" + " ) "
				+ " FROM TOmsCreditShieldLmsMas mas LEFT JOIN TOmsCreditShieldLmsInf inf ON mas.loanNo = inf.loanNo "
				+ " WHERE MONTHS_BETWEEN(:currentDate, to_date(to_char(mas.disbursalDate, '"+DateUtils.DATEFORMAT+"'), '"+DateUtils.DATEFORMAT+"')) <= 48 "
				+ " AND (inf.action IS NULL OR inf.action NOT IN ('" + APIConstant.TYPE_ACTION_CSFOLLOWUP+"', '" + APIConstant.TYPE_ACTION_CFI + "'))"
				+ " AND mas.benAccountNo IN ('" + APIConstant.BEN_ACCOUNT_ZERO +"' "
				+ " , '" + APIConstant.BEN_ACCOUNT_DUMMY +"' "
				+ " , '" + APIConstant.BEN_ACCOUNT_DOT +"' "
				+ " , '" + APIConstant.BEN_ACCOUNT_EMPTY +"')"
				+ " AND ( :loanNo = '"+ APIConstant.ALL + "' or mas.loanNo = :loanNo)"
				+ " ORDER BY mas.closureDate ASC, mas.loanNo ";
		
		
		Query query = entityManager.createQuery(sql);
		query.setParameter("loanNo", loanNo);
		query.setParameter("currentDate", DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		query.setFirstResult((pageNumber - 1) * pageSize);
		query.setMaxResults(pageSize);

		List<CsCfiInfo> list = query.getResultList();
		return list;
	}

	@Override
	public List<CsCfiInfo> getDataSurrenderReport(Map<String, Object> inputParams) throws BaseException {
		String loanNo = inputParams.get(APIConstant.LOAN_NO_KEY).toString();
		int pageNumber = inputParams.get(APIConstant._START_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
						? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
						: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());

		int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
						? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
						: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
		String sql = "SELECT new com.shinhan.creditshield.core.model.CsCfiInfo("
				+ " mas.benName as benName, mas.benBank as benBank, mas.benAccountNo as benAccountNo,"
				+ " mas.loanNo as loanNo, mas.cif as cif, mas.customerName as customerName, "
				+ " mas.disbursalDate as disbursalDate, mas.closureDate as closureDate,"
				+ " mas.loanAmount as loanAmount, mas.creditShieldAmount as creditShieldAmount,"
				+ " inf.cfiDate as cfiDate, inf.action as action, inf.note as note, mas.phoneNo as phoneNo, mas.beneficiaryBankBranchName as beneficiaryBankBrachName" 
				+ " ) "
				+ " FROM TOmsCreditShieldLmsMas mas JOIN TOmsCreditShieldLmsInf inf ON mas.loanNo = inf.loanNo "
				+ " WHERE inf.action = '"+APIConstant.TYPE_ACTION_SURRENDER +"' "
				+ " AND MONTHS_BETWEEN(:currentDate, to_date(to_char(mas.disbursalDate, '"+DateUtils.DATEFORMAT+"'), '"+DateUtils.DATEFORMAT+"')) <= 48 "
				+ " AND ( :loanNo = '" + APIConstant.ALL + "' or mas.loanNo = :loanNo)";

		sql += " ORDER BY mas.closureDate ASC, mas.loanNo ";
		
		
		Query query = entityManager.createQuery(sql);
		
		query.setParameter("loanNo", loanNo);
		query.setParameter("currentDate", DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		query.setFirstResult((pageNumber - 1) * pageSize);
		query.setMaxResults(pageSize);

		List<CsCfiInfo> list = query.getResultList();
		return list;
	}

	@Override
	public TOmsCreditShieldLmsMas getCreditByLoanNo(String loanNo) {
		if(StringUtils.isEmpty(loanNo)) {
			return null;
		}
		return objectDao.getByLoanNo(loanNo);
	}

	@Override
	public Long countTotalDataCsCfi(Map<String, Object> inputParams) throws BaseException {
		String loanNo = inputParams.get(APIConstant.LOAN_NO_KEY).toString();
		String sql = "SELECT count(mas.loanNo) "
				+ " FROM TOmsCreditShieldLmsMas mas LEFT JOIN TOmsCreditShieldLmsInf inf ON mas.loanNo = inf.loanNo "
				+ " WHERE (mas.closureDate - mas.disbursalDate) <= 21 " 
				+ " AND (TO_DATE(:currentDate, '"+DateUtils.DATEFORMAT+"') -  TO_DATE(TO_CHAR(mas.closureDate, '"+DateUtils.DATEFORMAT+"'), '"+DateUtils.DATEFORMAT+"')) <= 30"
				+ " AND (inf.action IS NULL OR inf.action =  '"+ APIConstant.TYPE_ACTION_CSFOLLOWUP +"')"
				+ " AND ( :loanNo = '" + APIConstant.ALL+"' or mas.loanNo = :loanNo )";

		Query query = entityManager.createQuery(sql);
		
		query.setParameter("loanNo", loanNo);
		query.setParameter("currentDate", DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		Long count = (Long) query.getSingleResult();
		return count;
	}

	@Override
	public Long countTotalDataDrCfi(Map<String, Object> inputParams) throws BaseException {
		String loanNo = inputParams.get(APIConstant.LOAN_NO_KEY).toString();
		String cif = inputParams.get(APIConstant.CIF_KEY).toString();
		String sql = "SELECT count(mas.loanNo) "
				+ " FROM TOmsCreditShieldLmsMas mas JOIN TOmsCreditShieldLmsInf inf ON mas.loanNo = inf.loanNo " 
				+ " WHERE MONTHS_BETWEEN(:currentDate, to_date(to_char(mas.disbursalDate, '"+DateUtils.DATEFORMAT+"'), '"+DateUtils.DATEFORMAT+"')) <= 48"
				+ " AND inf.action = '" + APIConstant.TYPE_ACTION_CFI + "'"
				+ " AND ( :loanNo = '" + APIConstant.ALL + "' or mas.loanNo = :loanNo)"
				+ " AND ( :cif = '" + APIConstant.ALL +"' or mas.cif = :cif)";

		Query query = entityManager.createQuery(sql);
		
		query.setParameter("loanNo", loanNo);
		query.setParameter("cif", cif);
		query.setParameter("currentDate", DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		
		Long count = (Long) query.getSingleResult();
		return count;
	}

	@Override
	public Long countTotalDataCsNoBank(Map<String, Object> inputParams) throws BaseException {
		String loanNo = inputParams.get(APIConstant.LOAN_NO_KEY).toString();
		String sql = "SELECT count(mas.loanNo)"
				+ " FROM TOmsCreditShieldLmsMas mas LEFT JOIN TOmsCreditShieldLmsInf inf ON mas.loanNo = inf.loanNo "
				+ " WHERE MONTHS_BETWEEN(:currentDate, to_date(to_char(mas.disbursalDate, '"+DateUtils.DATEFORMAT+"'), '"+DateUtils.DATEFORMAT+"')) <= 48 "
				+ " AND inf.action IS NULL OR inf.action NOT IN ( '" + APIConstant.TYPE_ACTION_CSFOLLOWUP+"', '" + APIConstant.TYPE_ACTION_CFI + "')"
				+ " AND mas.benAccountNo IN ('" + APIConstant.BEN_ACCOUNT_ZERO +"' "
				+ " , '" + APIConstant.BEN_ACCOUNT_DUMMY +"' "
				+ " , '" + APIConstant.BEN_ACCOUNT_DOT +"' "
				+ " , '" + APIConstant.BEN_ACCOUNT_EMPTY +"')"
				+ " AND ( :loanNo = '"+ APIConstant.ALL + "' or mas.loanNo = :loanNo)";
		
		Query query = entityManager.createQuery(sql);
		query.setParameter("loanNo", loanNo);
		query.setParameter("currentDate", DateUtils.getCurrentDate(DateUtils.DATEFORMAT));

		Long count = (Long) query.getSingleResult();
		return count;
	}

	@Override
	public Long countTotalDataSurrender(Map<String, Object> inputParams) throws BaseException {
		String loanNo = inputParams.get(APIConstant.LOAN_NO_KEY).toString();
		String sql = "SELECT count(mas.loanNo) "
				+ " FROM TOmsCreditShieldLmsMas mas JOIN TOmsCreditShieldLmsInf inf ON mas.loanNo = inf.loanNo "
				+ " WHERE inf.action = '"+APIConstant.TYPE_ACTION_SURRENDER +"' "
				+ " AND MONTHS_BETWEEN(:currentDate, to_date(to_char(mas.disbursalDate, '"+DateUtils.DATEFORMAT+"'), '"+DateUtils.DATEFORMAT+"')) <= 48 "
			 	+ " AND ( :loanNo = '" + APIConstant.ALL + "'  or mas.loanNo = :loanNo)";

		
		Query query = entityManager.createQuery(sql);
		query.setParameter("loanNo", loanNo);
		query.setParameter("currentDate", DateUtils.getCurrentDate(DateUtils.DATEFORMAT));

		Long count = (Long) query.getSingleResult();
		return count;
	}

	@Override
	public List<Object[]> getDataSurrenderReportNewCreditLifeExport(String type) throws BaseException {
		String sql = "SELECT "
				+ " rownum, sub.*  "
				+ " From ( SELECT  "
				+ " (SELECT tm.VALUE "
				+ " from OMS_METADATA tm  "
				+ " where tm.LOOKUPCODE = '"+APIConstant.LOOKUP_CODE_CREDIT_SHIELD_BANK_NAME+"' and tm.LOOKUPCODEID = mas.BENEFICIARY_BANK_BRANCH_NAME) as bankBranch, "
				+ " mas.BEN_BANK , mas.BEN_ACCOUNT_NO, mas.LOAN_NO , null as amount, null as paymentDetail  "
				+ " FROM OMS_CREDITSHIELD_LMS_MAS mas JOIN OMS_CREDITSHIELD_LMS_INF inf ON mas.LOAN_NO = inf.LOAN_NO "
				+ " WHERE inf.action = '"+APIConstant.TYPE_ACTION_SURRENDER +"' "
				+ " AND MONTHS_BETWEEN(:currentDate, to_date(to_char(mas.DISBURSAL_DATE, '"+DateUtils.DATEFORMAT+"'), '"+DateUtils.DATEFORMAT+"')) <= 48 "
		
				+  " ORDER BY mas.CLOSURE_DATE ASC, mas.LOAN_NO)  sub";
		
		System.out.println("SQL: " + sql);
		
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("currentDate", DateUtils.getCurrentDate(DateUtils.DATEFORMAT));

		List<Object[]> list = query.getResultList();
		if(CollectionUtils.isEmpty(list)) {
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
		return list;
	}

	@Override
	public List<TOmsCreditShieldLmsMas> getAllCreditMas(List<String> lstLoanNo) throws BaseException {
		int limit = Integer.valueOf(env.getProperty(APIConstant.DATA_LIMIT_CONDTION_SEARCHING_IN));
		int sizes = lstLoanNo.size();
		if(sizes >= limit) {
			int times = sizes / limit;
			int start = 0;
			int end = limit;
			List<TOmsCreditShieldLmsMas> rs = new ArrayList<TOmsCreditShieldLmsMas>();
			for(int i = 0; i <= times; i++) {
				List<String> loanNoList = lstLoanNo.subList(start, end);
				
				rs.addAll(objectDao.findAll(new Specification<TOmsCreditShieldLmsMas>() {
					private static final long serialVersionUID = 4026019747432813696L;

					@Override
					public Predicate toPredicate(Root<TOmsCreditShieldLmsMas> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
						List<Predicate> predicates = new ArrayList<>();
						if (CollectionUtils.isNotEmpty(loanNoList)) {
							predicates.add(root.get("loanNo").in(loanNoList));
						}
						
						return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
					}
				}));
				
				start += limit;
				end += limit;
				if(end > sizes) {
					end = sizes;
				}
			}
			return rs;
			
		} else {
			return objectDao.findAll(new Specification<TOmsCreditShieldLmsMas>() {
				/**
				 * 
				 */
				private static final long serialVersionUID = 4026019747432813696L;

				@Override
				public Predicate toPredicate(Root<TOmsCreditShieldLmsMas> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
					List<Predicate> predicates = new ArrayList<>();
					if (CollectionUtils.isNotEmpty(lstLoanNo)) {
						predicates.add(root.get("loanNo").in(lstLoanNo));
					}
					
					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}
			});
		}
	}

	@Override
	public List<TOmsCreditShieldLmsInf> getAllCreditInf(List<String> lstLoanNo) throws BaseException {
		int limit = Integer.valueOf(env.getProperty(APIConstant.DATA_LIMIT_CONDTION_SEARCHING_IN));
		int sizes = lstLoanNo.size();
		if(sizes >= limit) {
			int times = sizes / limit;
			int start = 0;
			int end = limit;
			List<TOmsCreditShieldLmsInf> rs = new ArrayList<TOmsCreditShieldLmsInf>();
			for(int i = 0; i <= times; i++) {
				List<String> loanNoList = lstLoanNo.subList(start, end);
				
				rs.addAll(infDao.findAll(new Specification<TOmsCreditShieldLmsInf>() {
					private static final long serialVersionUID = 4026019747432813696L;

					@Override
					public Predicate toPredicate(Root<TOmsCreditShieldLmsInf> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
						List<Predicate> predicates = new ArrayList<>();
						if (CollectionUtils.isNotEmpty(loanNoList)) {
							predicates.add(root.get("loanNo").in(loanNoList));
						}
						
						return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
					}
				}));
				
				start += limit;
				end += limit;
				if(end > sizes) {
					end = sizes;
				}
			}
			return rs;
			
		} else {
			return infDao.findAll(new Specification<TOmsCreditShieldLmsInf>() {
				/**
				 * 
				 */
				private static final long serialVersionUID = 4026019747432813696L;

				@Override
				public Predicate toPredicate(Root<TOmsCreditShieldLmsInf> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
					List<Predicate> predicates = new ArrayList<>();
					if (CollectionUtils.isNotEmpty(lstLoanNo)) {
						predicates.add(root.get("loanNo").in(lstLoanNo));
					}
					
					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}
			});
		}
	}

	@Override
	public boolean updateNoteLoanNo(List<TOmsCreditShieldLmsInf> itemInDB) throws BaseException {
		try {
			if (CollectionUtils.isNotEmpty(itemInDB)) {
				infDao.saveAll(itemInDB);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean createNoteLoanNo(List<TOmsCreditShieldLmsInf> itemInDB) throws BaseException {
		try {
			if (CollectionUtils.isNotEmpty(itemInDB)) {
				infDao.saveAll(itemInDB);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public List<Object[]> getDataSurrenderReportPreterCreditLifeExport(String type) throws BaseException {
		String sql = "SELECT "
				+ " rownum, sub.*  "
				+ " from ( SELECT mas.BEN_NAME , null as dateOfBirth, null as civilId ,mas.LOAN_NO, null as d , mas.DISBURSAL_DATE, "
				+ " mas.CLOSURE_DATE , mas.LOAN_AMOUNT , mas.CREDIT_SHIELD_AMOUNT "
				+ " FROM OMS_CREDITSHIELD_LMS_MAS mas JOIN OMS_CREDITSHIELD_LMS_INF inf ON mas.LOAN_NO = inf.LOAN_NO "
				+ " WHERE inf.action = '" + APIConstant.TYPE_ACTION_SURRENDER + "' "
				+ " AND MONTHS_BETWEEN(:currentDate, to_date(to_char(mas.DISBURSAL_DATE, '" + DateUtils.DATEFORMAT
				+ "'), '" + DateUtils.DATEFORMAT + "')) <= 48 " + " ORDER BY mas.CLOSURE_DATE ASC, mas.LOAN_NO) sub ";

		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("currentDate", DateUtils.getCurrentDate(DateUtils.DATEFORMAT));

		List<Object[]> list = query.getResultList();
		if (CollectionUtils.isEmpty(list)) {
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
		return list;
	}

	@Override
	public TOmsCreditShieldLmsInf getCreditInfByLoanNo(String loanNo) throws BaseException {
		if(StringUtils.isEmpty(loanNo)) {
			return null;
		}
		return infDao.getByLoanNo(loanNo);
	}

}
