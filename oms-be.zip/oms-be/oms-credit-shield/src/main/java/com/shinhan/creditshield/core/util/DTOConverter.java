/**
 * 
 */
package com.shinhan.creditshield.core.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.shinhan.creditshield.core.constant.APIConstant;
import com.shinhan.creditshield.core.exception.ServiceRuntimeException;
import com.shinhan.creditshield.core.model.ConvertInfo;
import com.shinhan.creditshield.core.model.CsCfiInfo;
import com.shinhan.creditshield.core.model.UpdateActionAndNoteTemplateInfo;
import com.shinhan.creditshield.core.model.UpdateCustomerInfTemplateInfo;
import com.shinhan.creditshield.repository.entity.TOmsCreditShieldLmsInf;
import com.shinhan.creditshield.repository.entity.TOmsCreditShieldLmsMas;

/**
 * @author shds01
 *
 */
public class DTOConverter {

	public static List<?> convertSettoList(Set<?> sets) throws ServiceRuntimeException {
		List<?> list = new ArrayList<>(sets);
		return list;
	}

	public static List<CsCfiInfo> convertDate(List<CsCfiInfo> lstData) {
		List<CsCfiInfo> rs = new ArrayList<>();
		for (CsCfiInfo item : lstData) {

			if (item.getClosureDate() != null) {
				item.setClosureDate(item.getClosureDate());
			}

			if (item.getCfiDate() != null) {
				item.setCfiDate(item.getCfiDate());
			}

			if (item.getDisbursalDate() != null) {
				item.setDisbursalDate(item.getDisbursalDate());
			}
			rs.add(item);
		}

		return rs;
	}

//	public static List<CsCfiInfo> buildDataForNewCreditLifePaymentReport(List<CsCfiInfo> lstData, List<Map> lstKey) {
//		List<CsCfiInfo> rs = new ArrayList<>();
//		List<ConvertInfo> lstConvert = new ArrayList<>();
//		for (Map item : lstKey) {
//			ConvertInfo cv = new ConvertInfo();
//			cv.setKey(item.get(APIConstant.KEY_WORD_BENEFICIARY_BANK_NAME).toString());
//			cv.setRevise(item.get(APIConstant.REVISED_BENEFICIARY_BANK_NAME).toString());
//			lstConvert.add(cv);
//		}
//
//		Map<String, String> nameToConvert = lstConvert.stream()
//				.collect(Collectors.toMap(ConvertInfo::getKey, ConvertInfo::getRevise));
//
//		
//		rs = 
//
//		
//
//		return rs;
//
//	}
	
	public static List<Object[]> transferDataToFillHeaderForCreditShieldReport(List<CsCfiInfo> csLst, String typrReport){
		List<Object[]> datas = new ArrayList<>();
		int count = 1;
		for(CsCfiInfo item : csLst) {
			switch (typrReport) {
			case APIConstant.CREDIT_SHIELD_REPORT_NEW_LIFE_PAYMENT:
				Object[] objectNewLifePayment = {count, item.getBeneficiaryBankBrachName(), item.getBenBank(), item.getBenAccountNo(), item.getLoanNo(), StringUtils.SPACE, StringUtils.SPACE};
				datas.add(objectNewLifePayment);
				break;
			case APIConstant.CREDIT_SHIELD_REPORT_NEW_LIFE_PRETER_SVFC:
				Object[] objectNewLifePreter = {count, item.getBenName(), StringUtils.SPACE, StringUtils.SPACE, item.getLoanNo(), StringUtils.SPACE, item.getDisbursalDate(), item.getClosureDate(), item.getLoanAmount(), item.getCreditShieldAmount()};
				datas.add(objectNewLifePreter);
				break;
			default:
				return null;
			}
			count++;
		}
		return datas;
	}
	
	public static void setDataCreditFromInfo(TOmsCreditShieldLmsMas itemIndb, UpdateCustomerInfTemplateInfo itemInfo) {
		
//		if(StringUtils.isNotEmpty(itemInfo.getAction())) {
//			itemIndb.setAction(itemInfo.getAction());
//		}
		
		if(StringUtils.isNotEmpty(itemInfo.getBenAccountNo())) {
			itemIndb.setBenAccountNoTemp(itemInfo.getBenAccountNo());
		}
		
		if(StringUtils.isNotEmpty(itemInfo.getBenBank())) {
			itemIndb.setBenBank(itemInfo.getBenBank());
		}
		
		if(StringUtils.isNotEmpty(itemInfo.getBenName())) {
			itemIndb.setBenName(itemInfo.getBenName());
		}
		
		
	}

	public static void setDataCreditInfFromInfo(TOmsCreditShieldLmsInf itemIndb, UpdateActionAndNoteTemplateInfo itemInfo) {

		if (StringUtils.isNotEmpty(itemInfo.getNote())) {
			itemIndb.setNote(itemInfo.getNote());
		}
		if(StringUtils.isNotEmpty(itemInfo.getAction())) {
			itemIndb.setAction(itemInfo.getAction());
		}
		
		itemIndb.setCfiDate(DateUtils.getCurrentDate());

	}
	
	public static TOmsCreditShieldLmsInf getDataCreditInfFromInfoToCreate( UpdateActionAndNoteTemplateInfo itemInfo) {
		
		if(StringUtils.isEmpty(itemInfo.getLoanNo())) {
			return null;
		}
		
		TOmsCreditShieldLmsInf itemUpdate = new TOmsCreditShieldLmsInf();
		itemUpdate.setLoanNo(itemInfo.getLoanNo());
		
		if(StringUtils.isNotEmpty(itemInfo.getAction())) {
			itemUpdate.setAction(itemInfo.getAction());
			itemUpdate.setCfiDate(DateUtils.getCurrentDate());
		}
		
		if(StringUtils.isNotEmpty(itemInfo.getNote())) {
			itemUpdate.setNote(itemInfo.getNote());
		}
		
		return itemUpdate;
		

	}
	
	
	public static ConvertInfo setBankNameFromInfo(Map item){
		ConvertInfo cv = new ConvertInfo();
		cv.setKey(item.get(APIConstant.KEY_WORD_BENEFICIARY_BANK_NAME).toString());
		cv.setRevise(item.get(APIConstant.REVISED_BENEFICIARY_BANK_NAME).toString());
		return cv;
	}
	
	public static void setBenAccountNoFromInfo(TOmsCreditShieldLmsMas item) {
		if(StringUtils.isNotEmpty(item.getBenAccountNoTemp())) {
			item.setBenAccountNo(item.getBenAccountNoTemp());
		}
		item.setBenAccountNoTemp(null);
	}

}
