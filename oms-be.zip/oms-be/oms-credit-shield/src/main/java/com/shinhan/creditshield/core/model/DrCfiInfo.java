package com.shinhan.creditshield.core.model;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class DrCfiInfo {
	
	private String loanNo;
	private String cif;
	private String customerName;
	@JsonFormat(pattern="dd/MM/YYYY", timezone = "GMT+07:00")
	private Date disbursalDate;
	private BigDecimal loanAmount;
	private BigDecimal creditShieldAmount;
	@JsonFormat(pattern="dd/MM/YYYY", timezone = "GMT+07:00")
	private Date cfiDate;
	
	public DrCfiInfo(String loanNo, String cif, String customerName, Date disbursalDate, BigDecimal loanAmount,
			BigDecimal creditShieldAmount, Date cfiDate) {
		super();
		this.loanNo = loanNo;
		this.cif = cif;
		this.customerName = customerName;
		this.disbursalDate = disbursalDate;
		this.loanAmount = loanAmount;
		this.creditShieldAmount = creditShieldAmount;
		this.cfiDate = cfiDate;
	}

	public String getLoanNo() {
		return loanNo;
	}

	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cfi) {
		this.cif = cfi;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Date getDisbursalDate() {
		return disbursalDate;
	}

	public void setDisbursalDate(Date disbursalDate) {
		this.disbursalDate = disbursalDate;
	}

	public BigDecimal getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(BigDecimal loanAmount) {
		this.loanAmount = loanAmount;
	}

	public BigDecimal getCreditShieldAmount() {
		return creditShieldAmount;
	}

	public void setCreditShieldAmount(BigDecimal creditShieldAmount) {
		this.creditShieldAmount = creditShieldAmount;
	}

	public Date getCfiDate() {
		return cfiDate;
	}

	public void setCfiDate(Date cfiDate) {
		this.cfiDate = cfiDate;
	}
	
	

}
