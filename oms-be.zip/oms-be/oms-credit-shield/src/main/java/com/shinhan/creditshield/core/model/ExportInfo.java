package com.shinhan.creditshield.core.model;

public class ExportInfo {
	private String typeExport;
	private String loanNo;
	public String getTypeExport() {
		return typeExport;
	}
	public void setTypeExport(String typeExport) {
		this.typeExport = typeExport;
	}
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	
	
}
