package com.shinhan.creditshield.core.constant;

public enum TechcomBankRefundReportHeader {
	Customer_Reference("Customer reference"),
	From_Account("From Account"),
	Amount("Amount"),
	Beneficiary_Name("Beneficiary name"),
	Beneficiary_Account("Beneficiary Account"),
	Currency("Currency"),
	Narratives("Narratives"),
	Beneficiary_Bank_Code("Beneficiary bank code"),
	Beneficiary_Bank_Name("Beneficiary Bank Name");
	
	public String label;

	private TechcomBankRefundReportHeader(String label) {
		this.label = label;
	}
	

}
