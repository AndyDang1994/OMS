/**
 * 
 */
package com.shinhan.creditshield.report;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.shinhan.creditshield.core.exception.BaseException;


/**
 * @author shds01
 *
 */
public interface CreditShieldExportReportService {

	
	public File exportNewCreditLifeReport(Map<String, Object> inputParams) throws BaseException, IOException;

}
