/**
 * 
 */
package com.shinhan.creditshield.api.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.shinhan.creditshield.core.constant.APIConstant;
import com.shinhan.creditshield.core.exception.BaseException;
import com.shinhan.creditshield.core.exception.ServiceRuntimeException;
import com.shinhan.creditshield.core.model.CsCfiInfo;
import com.shinhan.creditshield.core.model.UserInfo;
import com.shinhan.creditshield.repository.entity.TMetadata;

/**
 * @author shds01
 *
 */
@RestController
public class UtilityController extends BaseController{

	
	@RequestMapping(value = "shinhan/common/connection", method = RequestMethod.GET)
	public ResponseEntity<Object> testGet() throws ServiceRuntimeException, InterruptedException {
		return triggerSuccessOutPut(null, JsonObject.class, "connect server successfully");
	}

	@RequestMapping(value = "shinhan/common/exception", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	@ResponseBody
	public String testException(Locale locale) throws BaseException {
		testException();
		return "Success";
	}
	
}
