package com.shinhan.creditshield.core.model;

public class CustomerInfoTest {
	private String loanNo;
	private String cusBankAcc;
	private String cusBankCode;
	private String cusBankName;
	private String branch;
	
	
	public CustomerInfoTest(String loanNo, String customerBankAccount, String customerBankCode, String customerBankName,
			String bankBranch) {
		super();
		this.loanNo = loanNo;
		this.cusBankAcc = customerBankAccount;
		this.cusBankCode = customerBankCode;
		this.cusBankName = customerBankName;
		this.branch = bankBranch;
	}
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	public String getCustomerBankAccount() {
		return cusBankAcc;
	}
	public void setCustomerBankAccount(String customerBankAccount) {
		this.cusBankAcc = customerBankAccount;
	}
	public String getCustomerBankCode() {
		return cusBankCode;
	}
	public void setCustomerBankCode(String customerBankCode) {
		this.cusBankCode = customerBankCode;
	}
	public String getCustomerBankName() {
		return cusBankName;
	}
	public void setCustomerBankName(String customerBankName) {
		this.cusBankName = customerBankName;
	}
	public String getBankBranch() {
		return branch;
	}
	public void setBankBranch(String bankBranch) {
		this.branch = bankBranch;
	}
	
	

}
