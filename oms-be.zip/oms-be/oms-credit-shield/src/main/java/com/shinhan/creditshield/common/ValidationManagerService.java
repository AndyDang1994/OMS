package com.shinhan.creditshield.common;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.stereotype.Service;

import com.shinhan.creditshield.core.exception.BaseException;
import com.shinhan.creditshield.core.exception.ServiceRuntimeException;
import com.shinhan.creditshield.core.model.UpdateActionAndNoteTemplateInfo;
import com.shinhan.creditshield.core.model.UpdateCustomerInfTemplateInfo;
import com.shinhan.creditshield.repository.entity.TOmsCreditShieldLmsInf;
import com.shinhan.creditshield.repository.entity.TOmsCreditShieldLmsMas;

@Service("validationManagerService")
public class ValidationManagerService extends AbstractRepositoryClass {

	public TOmsCreditShieldLmsInf checkValidationUpdateCreditShieldInf(UpdateActionAndNoteTemplateInfo updateActionInfo)
			throws JSONException, BaseException {
		String error = "";
		
		if(ObjectUtils.isEmpty(updateActionInfo)) {
			return null;
		}
		//check in db 
		TOmsCreditShieldLmsInf itemInf = getRepositoryManagerService().gettOmsCreditShieldLmsManagerRepositoryService().getCreditInfByLoanNo(updateActionInfo.getLoanNo());
		
		if(itemInf == null) {
			error = String.format(env.getProperty("MSG_002"));
		}
		updateActionInfo.setErrorMessage(error);
		return itemInf;
	}
	
	public TOmsCreditShieldLmsMas checkValidationUpdateCreditShieldMas(UpdateCustomerInfTemplateInfo updateCustomerInfo) throws JSONException, ServiceRuntimeException {
	
		String error = "";
		
		if(ObjectUtils.isEmpty(updateCustomerInfo)) {
			return null;
		}
		//check in db 
		TOmsCreditShieldLmsMas itemMas = getRepositoryManagerService().gettOmsCreditShieldLmsManagerRepositoryService().getCreditByLoanNo(updateCustomerInfo.getLoanNo());
		if(itemMas == null) {
			error = String.format(env.getProperty("MSG_002"));
		}
		updateCustomerInfo.setError(error);
		return itemMas;
	}

}
