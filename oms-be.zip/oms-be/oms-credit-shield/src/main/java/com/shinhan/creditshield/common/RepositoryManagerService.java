/**
 * 
 */
package com.shinhan.creditshield.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.shinhan.creditshield.repository.service.TOmsCreditShieldLmsManagerRepositoryService;
import com.shinhan.creditshield.repository.service.UtilityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("repositoryManagerService")
public class RepositoryManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private UtilityManagerRepositoryService utilityManagerRepositoryService;
	
	@Autowired 
	private TOmsCreditShieldLmsManagerRepositoryService tOmsCreditShieldLmsManagerRepositoryService;
	
	/**
	 * @return the utilityManagerRepositoryService
	 */
	public UtilityManagerRepositoryService getUtilityManagerRepositoryService() {
		return utilityManagerRepositoryService;
	}

	/**
	 * @param utilityManagerRepositoryService the utilityManagerRepositoryService to
	 *                                        set
	 */
	public void setUtilityManagerRepositoryService(
			@Qualifier("utilityManagerRepositoryService") UtilityManagerRepositoryService utilityManagerRepositoryService) {
		this.utilityManagerRepositoryService = utilityManagerRepositoryService;
	}

	public TOmsCreditShieldLmsManagerRepositoryService gettOmsCreditShieldLmsManagerRepositoryService() {
		return tOmsCreditShieldLmsManagerRepositoryService;
	}

	public void settOmsCreditShieldLmsManagerRepositoryService(
			TOmsCreditShieldLmsManagerRepositoryService tOmsCreditShieldLmsManagerRepositoryService) {
		this.tOmsCreditShieldLmsManagerRepositoryService = tOmsCreditShieldLmsManagerRepositoryService;
	}

}
