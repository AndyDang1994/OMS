package com.shinhan.creditshield.core.model;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class CsCfiInfo{
	
	private String benName;
	private String benBank;
	private String benAccountNo;
	private String loanNo;
	private String cif;
	private String customerName;
	@JsonFormat(pattern="dd/MM/YYYY", timezone = "GMT+07:00")
	private Date disbursalDate;
	@JsonFormat(pattern="dd/MM/YYYY", timezone = "GMT+07:00")
	private Date closureDate;
	private BigDecimal loanAmount;
	private BigDecimal creditShieldAmount;
	@JsonFormat(pattern="dd/MM/YYYY", timezone = "GMT+07:00")
	private Date cfiDate;
	private String action;
	private String note;
	private String phoneNo;
	private String beneficiaryBankBrachName;
	
	
	public CsCfiInfo(String benName, String benBank, String benAccountNo, String loanNo, String cif,
			String customerName, Date disbursalDate, Date closureDate, BigDecimal loanAmount,
			BigDecimal creditShieldAmount, Date cfiDate, String action, String note) {
		super();
		this.benName = benName;
		this.benBank = benBank;
		this.benAccountNo = benAccountNo;
		this.loanNo = loanNo;
		this.cif = cif;
		this.customerName = customerName;
		this.disbursalDate = disbursalDate;
		this.closureDate = closureDate;
		this.loanAmount = loanAmount;
		this.creditShieldAmount = creditShieldAmount;
		this.cfiDate = cfiDate;
		this.action = action;
		this.note = note;
	}
	
	public CsCfiInfo(String benName, String benBank, String benAccountNo, String loanNo, String cif,
			String customerName, Date disbursalDate, Date closureDate, BigDecimal loanAmount,
			BigDecimal creditShieldAmount, Date cfiDate, String action, String note, String phoneNo) {
		super();
		this.benName = benName;
		this.benBank = benBank;
		this.benAccountNo = benAccountNo;
		this.loanNo = loanNo;
		this.cif = cif;
		this.customerName = customerName;
		this.disbursalDate = disbursalDate;
		this.closureDate = closureDate;
		this.loanAmount = loanAmount;
		this.creditShieldAmount = creditShieldAmount;
		this.cfiDate = cfiDate;
		this.action = action;
		this.note = note;
		this.phoneNo = phoneNo;
	}



	public CsCfiInfo(String benName, String benBank, String benAccountNo, String loanNo, String cif,
			String customerName, Date disbursalDate, Date closureDate, BigDecimal loanAmount,
			BigDecimal creditShieldAmount, Date cfiDate, String action, String note, String phoneNo,
			String beneficiaryBankBrachName) {
		super();
		this.benName = benName;
		this.benBank = benBank;
		this.benAccountNo = benAccountNo;
		this.loanNo = loanNo;
		this.cif = cif;
		this.customerName = customerName;
		this.disbursalDate = disbursalDate;
		this.closureDate = closureDate;
		this.loanAmount = loanAmount;
		this.creditShieldAmount = creditShieldAmount;
		this.cfiDate = cfiDate;
		this.action = action;
		this.note = note;
		this.phoneNo = phoneNo;
		this.beneficiaryBankBrachName = beneficiaryBankBrachName;
	}

	public String getBenName() {
		return benName;
	}

	public void setBenName(String benName) {
		this.benName = benName;
	}

	public String getBenBank() {
		return benBank;
	}

	public void setBenBank(String benBank) {
		this.benBank = benBank;
	}

	public String getBenAccountNo() {
		return benAccountNo;
	}

	public void setBenAccountNo(String benAccountNo) {
		this.benAccountNo = benAccountNo;
	}

	public String getLoanNo() {
		return loanNo;
	}

	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Date getDisbursalDate() {
		return disbursalDate;
	}

	public void setDisbursalDate(Date disbursalDate) {
		this.disbursalDate = disbursalDate;
	}

	public Date getClosureDate() {
		return closureDate;
	}

	public void setClosureDate(Date closureDate) {
		this.closureDate = closureDate;
	}

	public BigDecimal getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(BigDecimal loanAmount) {
		this.loanAmount = loanAmount;
	}

	public BigDecimal getCreditShieldAmount() {
		return creditShieldAmount;
	}

	public void setCreditShieldAmount(BigDecimal creditShieldAmount) {
		this.creditShieldAmount = creditShieldAmount;
	}

	public Date getCfiDate() {
		return cfiDate;
	}

	public void setCfiDate(Date cfiDate) {
		this.cfiDate = cfiDate;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getBeneficiaryBankBrachName() {
		return beneficiaryBankBrachName;
	}

	public void setBeneficiaryBankBrachName(String beneficiaryBankBrachName) {
		this.beneficiaryBankBrachName = beneficiaryBankBrachName;
	}
	
}
