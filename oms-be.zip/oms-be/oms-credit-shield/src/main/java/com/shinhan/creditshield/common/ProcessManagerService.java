/**
 * 
 */
package com.shinhan.creditshield.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.creditshield.report.CreditShieldExportReportService;
import com.shinhan.creditshield.service.CreditShieldApiService;

/**
 * @author shds01
 *
 */
@Service("processManagerService")
public class ProcessManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	
	@Autowired
	private CreditShieldApiService creditShieldApiService;
	
	@Autowired
	private CreditShieldExportReportService creditShieldExportReportService;
	

	public CreditShieldApiService getCreditShieldApiService() {
		return creditShieldApiService;
	}

	public void setCreditShieldApiService(CreditShieldApiService creditShieldApiService) {
		this.creditShieldApiService = creditShieldApiService;
	}


	public CreditShieldExportReportService getCreditShieldExportReportService() {
		return creditShieldExportReportService;
	}

	public void setCreditShieldExportReportService(CreditShieldExportReportService creditShieldExportReportService) {
		this.creditShieldExportReportService = creditShieldExportReportService;
	}
	
	
}
