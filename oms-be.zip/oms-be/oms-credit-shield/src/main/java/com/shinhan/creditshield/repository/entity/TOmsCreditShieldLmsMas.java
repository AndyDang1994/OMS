package com.shinhan.creditshield.repository.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "OMS_CREDITSHIELD_LMS_MAS")
public class TOmsCreditShieldLmsMas {
	private Long id;
	private String loanNo;
	private String cif;
	private Date disbursalDate;
	private BigDecimal loanAmount;
	private BigDecimal creditShieldAmount;
	
	private String customerName;
	private String benName;
	private String benBank;
	private String benAccountNo;
	private Date closureDate;
	private String phoneNo;
	private String beneficiaryBankBranchName;
	private String regisInfUser;
	private Date regisInfDate;
	private String lchgInfUser;
	private Date lchgInfDate;
	private String benAccountNoTemp;

	public TOmsCreditShieldLmsMas() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "OMS_CREDITSHIELD_LMS_MAS_SEQ_GEN")
	@SequenceGenerator(name = "OMS_CREDITSHIELD_LMS_MAS_SEQ_GEN", sequenceName = "OMS_CREDITSHIELD_LMS_MAS_SEQ", allocationSize = 1)
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "LOAN_NO")
	public String getLoanNo() {
		return loanNo;
	}

	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	@Column(name = "CIF")
	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	@Column(name = "DISBURSAL_DATE")
	public Date getDisbursalDate() {
		return disbursalDate;
	}

	public void setDisbursalDate(Date disbursalDate) {
		this.disbursalDate = disbursalDate;
	}

	@Column(name = "LOAN_AMOUNT")
	public BigDecimal getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(BigDecimal loanAmount) {
		this.loanAmount = loanAmount;
	}

	@Column(name = "CREDIT_SHIELD_AMOUNT")
	public BigDecimal getCreditShieldAmount() {
		return creditShieldAmount;
	}

	public void setCreditShieldAmount(BigDecimal creditShieldAmount) {
		this.creditShieldAmount = creditShieldAmount;
	}


	@Column(name = "BEN_NAME")
	public String getBenName() {
		return benName;
	}

	public void setBenName(String benName) {
		this.benName = benName;
	}

	@Column(name = "BEN_BANK")
	public String getBenBank() {
		return benBank;
	}

	public void setBenBank(String benBank) {
		this.benBank = benBank;
	}

	@Column(name = "BEN_ACCOUNT_NO")
	public String getBenAccountNo() {
		return benAccountNo;
	}

	public void setBenAccountNo(String benAccountNo) {
		this.benAccountNo = benAccountNo;
	}

	@Column(name = "CLOSURE_DATE")
	public Date getClosureDate() {
		return closureDate;
	}

	public void setClosureDate(Date closureDate) {
		this.closureDate = closureDate;
	}

	@Column(name = "PHONE_NO")
	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Column(name = "BENEFICIARY_BANK_BRANCH_NAME")
	public String getBeneficiaryBankBranchName() {
		return beneficiaryBankBranchName;
	}

	public void setBeneficiaryBankBranchName(String beneficiaryBankBranchName) {
		this.beneficiaryBankBranchName = beneficiaryBankBranchName;
	}

	@Column(name = "REGIS_INF_USER")
	public String getRegisInfUser() {
		return regisInfUser;
	}

	public void setRegisInfUser(String regisInfUser) {
		this.regisInfUser = regisInfUser;
	}

	@Column(name = "REGIS_INF_DT")
	public Date getRegisInfDate() {
		return regisInfDate;
	}

	public void setRegisInfDate(Date regisInfDate) {
		this.regisInfDate = regisInfDate;
	}

	@Column(name = "LCHG_INF_USER")
	public String getLchgInfUser() {
		return lchgInfUser;
	}

	public void setLchgInfUser(String lchgInfUser) {
		this.lchgInfUser = lchgInfUser;
	}

	@Column(name = "LCHG_INF_DT")
	public Date getLchgInfDate() {
		return lchgInfDate;
	}

	public void setLchgInfDate(Date lchgInfDate) {
		this.lchgInfDate = lchgInfDate;
	}

	@Column(name = "CUSTOMER_NAME")
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	@Column(name = "BEN_ACCOUNT_NO_TEMP")
	public String getBenAccountNoTemp() {
		return benAccountNoTemp;
	}

	public void setBenAccountNoTemp(String benAccountNoTemp) {
		this.benAccountNoTemp = benAccountNoTemp;
	}

}
