package com.shinhan.creditshield.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.shinhan.creditshield.repository.entity.TOmsCreditShieldLmsInf;
import com.shinhan.creditshield.repository.entity.TOmsCreditShieldLmsMas;

public interface TOmsCreditShieldLmsInfDAO extends JpaRepository<TOmsCreditShieldLmsInf, String>,JpaSpecificationExecutor<TOmsCreditShieldLmsInf>{
	@Query("SELECT inf FROM TOmsCreditShieldLmsInf inf WHERE inf.loanNo = :loanNo")
	public TOmsCreditShieldLmsInf getByLoanNo(@Param("loanNo") String loanNo);
}
