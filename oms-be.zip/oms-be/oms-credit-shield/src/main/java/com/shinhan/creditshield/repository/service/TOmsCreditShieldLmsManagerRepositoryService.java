package com.shinhan.creditshield.repository.service;

import java.util.List;
import java.util.Map;

import com.shinhan.creditshield.core.exception.BaseException;
import com.shinhan.creditshield.core.model.CsCfiInfo;
import com.shinhan.creditshield.core.model.DrCfiInfo;
import com.shinhan.creditshield.repository.entity.TOmsCreditShieldLmsInf;
import com.shinhan.creditshield.repository.entity.TOmsCreditShieldLmsMas;

public interface TOmsCreditShieldLmsManagerRepositoryService {

	public List<CsCfiInfo> getDataCsCfi(Map<String, Object> inputParams) throws BaseException;

	public boolean updateActionByLoanNo(List<TOmsCreditShieldLmsMas> itemInDB) throws BaseException;
	
	public List<DrCfiInfo> getDataDrCfi(Map<String, Object> inputParams) throws BaseException;
	
	public List<CsCfiInfo> getDataCsNoBankAcc(Map<String, Object> inputParams) throws BaseException;
	
	public List<CsCfiInfo> getDataSurrenderReport(Map<String, Object> inputParams) throws BaseException;
	
	public TOmsCreditShieldLmsMas getCreditByLoanNo(String loanNo);
	
	public Long countTotalDataCsCfi(Map<String, Object> inputParams) throws BaseException;
	
	public Long countTotalDataDrCfi(Map<String, Object> inputParams) throws BaseException;
	
	public Long countTotalDataCsNoBank(Map<String, Object> inputParams) throws BaseException;
	
	public Long countTotalDataSurrender(Map<String, Object> inputParams) throws BaseException;
	
	public List<Object[]> getDataSurrenderReportNewCreditLifeExport(String type) throws BaseException;
	
	public List<Object[]> getDataSurrenderReportPreterCreditLifeExport(String type) throws BaseException;
	
	public List<TOmsCreditShieldLmsMas> getAllCreditMas(List<String> loanNos)throws BaseException;
	
	public List<TOmsCreditShieldLmsInf> getAllCreditInf(List<String> loanNos)throws BaseException;
	
	public boolean updateNoteLoanNo(List<TOmsCreditShieldLmsInf> itemInDB) throws BaseException;
	
	public boolean createNoteLoanNo(List<TOmsCreditShieldLmsInf> itemInDB) throws BaseException;
	
	public TOmsCreditShieldLmsInf getCreditInfByLoanNo(String loanNo)throws BaseException;
	
}
