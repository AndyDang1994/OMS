package com.shinhan.creditshield.repository.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "OMS_CREDITSHIELD_LMS_INF")
public class TOmsCreditShieldLmsInf {
	private String loanNo;
	private String note;
	private String action;
	private Date cfiDate;
	private String regisInfUser;
	private Date regisInfDate;
	private String lchgInfUser;
	private Date lchgInfDate;
	
	
	public TOmsCreditShieldLmsInf() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Id
	@Column(name = "LOAN_NO")
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	@Column(name = "NOTE")
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	
	@Column(name = "REGIS_INF_USER")
	public String getRegisInfUser() {
		return regisInfUser;
	}
	
	public void setRegisInfUser(String regisInfUser) {
		this.regisInfUser = regisInfUser;
	}
	
	@Column(name = "REGIS_INF_DT")
	public Date getRegisInfDate() {
		return regisInfDate;
	}
	public void setRegisInfDate(Date regisInfDate) {
		this.regisInfDate = regisInfDate;
	}
	
	@Column(name = "LCHG_INF_USER")
	public String getLchgInfUser() {
		return lchgInfUser;
	}
	public void setLchgInfUser(String lchgInfUser) {
		this.lchgInfUser = lchgInfUser;
	}
	
	@Column(name = "LCHG_INF_DT")
	public Date getLchgInfDate() {
		return lchgInfDate;
	}
	public void setLchgInfDate(Date lchgInfDate) {
		this.lchgInfDate = lchgInfDate;
	}

	@Column(name = "ACTION")
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Column(name = "CFI_DATE")
	public Date getCfiDate() {
		return cfiDate;
	}

	public void setCfiDate(Date cfiDate) {
		this.cfiDate = cfiDate;
	}

	
}
