/**
 * 
 */
package com.shinhan.creditshield.report.impl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.creditshield.common.AbstractBasicCommonClass;
import com.shinhan.creditshield.core.constant.APIConstant;
import com.shinhan.creditshield.core.exception.BaseException;
import com.shinhan.creditshield.core.model.ConvertInfo;
import com.shinhan.creditshield.core.model.CsCfiInfo;
import com.shinhan.creditshield.core.util.DTOConverter;
import com.shinhan.creditshield.core.util.NFsUtils;
import com.shinhan.creditshield.core.util.ReadFromExcel;
import com.shinhan.creditshield.report.CreditShieldExportReportService;

/**
 * @author shds06
 *
 */
@Service("adExportRefundReportService")
public class CreditShieldExportReportServiceImpl extends AbstractBasicCommonClass
		implements CreditShieldExportReportService {

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	@Override
	public File exportNewCreditLifeReport(Map<String, Object> inputParams) throws BaseException, IOException {
		String type = inputParams.get(APIConstant._TYPE_KEY).toString();
		
		switch (type) {
		case APIConstant.CREDIT_SHIELD_REPORT_NEW_LIFE_PAYMENT:
		
			//get data export from database
			List<Object[]> dataExport = getRepositoryManagerService()
					.gettOmsCreditShieldLmsManagerRepositoryService().getDataSurrenderReportNewCreditLifeExport(type);

			//case data export is null
			if (CollectionUtils.isEmpty(dataExport)) {
				return null;
			}
			
			File itemNewLifePayment = exportCreditLifePaymentReport(dataExport);
			
			if(itemNewLifePayment.exists()) {
				NFsUtils.uploadViaNFS("", "", "", env.getProperty(APIConstant.PATH_SHARE_FOLDER), itemNewLifePayment.getParent(), itemNewLifePayment.getName());
			}
			
			return itemNewLifePayment;
			
		case APIConstant.CREDIT_SHIELD_REPORT_NEW_LIFE_PRETER_SVFC:
			
			List<Object[]> dataForNewLifePreter =  getRepositoryManagerService()
					.gettOmsCreditShieldLmsManagerRepositoryService().getDataSurrenderReportPreterCreditLifeExport(type);
			File itemCreditLifePreter = exportCreditLifePreterReport(dataForNewLifePreter);
			
			if(itemCreditLifePreter.exists()) {
				NFsUtils.uploadViaNFS("", "", "", env.getProperty(APIConstant.PATH_SHARE_FOLDER), itemCreditLifePreter.getParent(), itemCreditLifePreter.getName());
			}
			
			return itemCreditLifePreter;
		default:
			return null;
		}
	}

}
