package com.shinhan.creditshield.core.model;

public class ConvertInfo {
	private String key;
	private String revise;
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getRevise() {
		return revise;
	}
	public void setRevise(String revise) {
		this.revise = revise;
	}
	
	
}
