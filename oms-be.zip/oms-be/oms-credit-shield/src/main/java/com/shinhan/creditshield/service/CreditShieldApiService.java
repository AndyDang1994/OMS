/**
 * 
 */
package com.shinhan.creditshield.service;

import java.util.List;
import java.util.Map;

import org.springframework.boot.configurationprocessor.json.JSONException;

import com.shinhan.creditshield.core.exception.BaseException;
import com.shinhan.creditshield.core.model.CsCfiInfo;
import com.shinhan.creditshield.core.model.DrCfiInfo;

/**
 * @author shds01
 *
 */
public interface CreditShieldApiService {

	public List<CsCfiInfo> getDataCsCfi(Map<String, Object> inputParams) throws BaseException;

	public List<DrCfiInfo> getDataDrCfi(Map<String, Object> inputParams) throws BaseException;
	
	public List<CsCfiInfo> getDataCsNoBankAcc(Map<String, Object> inputParams) throws BaseException;
	
	public List<CsCfiInfo> getDataSurrenderReport(Map<String, Object> inputParams) throws BaseException;
	
	public Long countDataCsCfi(Map<String, Object> inputParams) throws BaseException;
	
	public Long countDataDrCfi(Map<String, Object> inputParams) throws BaseException;
	
	public Long countDataCsNoBank(Map<String, Object> inputParams) throws BaseException;
	
	public Long countDataSurrender(Map<String, Object> inputParams) throws BaseException;
	
	public boolean update(Map<String, Object> inputParams) throws BaseException, JSONException;
	

}
