/**
 * 
 */
package com.shinhan.creditshield.common;

import java.io.File;
import java.lang.reflect.Field;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.function.UnaryOperator;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.shinhan.creditshield.core.constant.APIConstant;
import com.shinhan.creditshield.core.util.DateUtils;
import com.shinhan.creditshield.core.util.WriteToExcelTemplate;

/**
 * @author shds01
 *
 */
public abstract class AbstractServiceClass extends AbstractRepositoryClass{

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	public Environment env;
	
	
	@Autowired
	private ProcessManagerService processManagerService;
	
	@Autowired
	private ValidationManagerService validationManagerService;

	/**
	 * @return the processManagerService
	 */
	public ProcessManagerService getProcessManagerService() {
		return processManagerService;
	}


	public ValidationManagerService getValidationManagerService() {
		return validationManagerService;
	}


	public void setValidationManagerService(ValidationManagerService validationManagerService) {
		this.validationManagerService = validationManagerService;
	}


	protected Map<String, Entry<String, UnaryOperator<String>>> buildBankStatementMapping(List<String> excelColumn, Field[] bankStatementProperty){
		/**bankStatementMapping : {excel column name} {[property in Statement],[function to parse value on excel to value in property]}**/
		Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping = new HashMap<>();
		
		/*all parser to map value from excel, must map exactly with the index of excel column*/
		Map<Integer, UnaryOperator<String>> parser = new HashMap<>();
		
		/*excelColumn, clientCoporateProperty MUST have same size*/
		for (int columnIndex = 0; columnIndex < excelColumn.size(); columnIndex++) {
			String key = excelColumn.get(columnIndex).trim();
			UnaryOperator<String> parserToConsume = Optional.ofNullable(parser.get(columnIndex)).orElse(UnaryOperator.identity());
			bankStatementMapping.put(key, new SimpleEntry<String, UnaryOperator<String>>(bankStatementProperty[columnIndex].getName(), parserToConsume));
		}
		
		return bankStatementMapping;
	}

	
	private Workbook loadTemplateAndFillDataReport(String fileSource, List<Object[]> datas, int fromRow) {
		int shiftRow = fromRow + 1;// 1 = (blank row)
		String sheetName = "Data";
		return WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, null, sheetName, fromRow, shiftRow, datas, false);
	}
	private Workbook loadTemplateAndFillDataReport(String fileSource, List<Object[]> datas, int fromRow, String sheetName) {
		int shiftRow = fromRow + 1;// 1 = (blank row)
		return WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, null, sheetName, fromRow, shiftRow, datas, false);
	}
	
	private Workbook fillDataForSectionReport(Workbook wb, List<Object[]> datas, int fromRow) {
		if(CollectionUtils.isEmpty(datas)) {
			return wb;
		}
		int shiftRow = fromRow + 1;// 1 = (blank row)
		String sheetName = "Data";
		return WriteToExcelTemplate.fillDataToSheetTemplate(wb, null, sheetName, fromRow, shiftRow, datas, false);
	}
	
	private Workbook fillDataForSectionPendingReport(Workbook wb, List<Object[]> datas, int fromRow, String sheetName) {
		if(CollectionUtils.isEmpty(datas)) {
			return wb;
		}
		int shiftRow = fromRow;// 1 = (blank row)
		return WriteToExcelTemplate.fillDataToSheetTemplate(wb, null, sheetName, fromRow, shiftRow, datas, false);
	}
	
	
	private void fillDataLabelReport(Workbook wb, Object[] obj, int startrow) {
		String sheetName = "Data";
		//Fill date in second row
		List<Object[]> datas = new ArrayList<>();
		Object[] object = obj;
		datas.add(object);
		WriteToExcelTemplate.fillDataToSheetTemplate(wb, sheetName, startrow, datas);
		
	}
	
	
	
	
	
	private Workbook loadTemplateAndFillDataReport(String fileSource, List<Object[]> datas, String sheetName, int fromRow) {
		int shiftRow = fromRow + 1;// 1 = (blank row)
		return WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, null, sheetName, fromRow, shiftRow, datas, false);
	}
	
	public File exportCreditLifePaymentReport(List<Object[]> datas) {
		String fileSource = env.getProperty(APIConstant.FOLDER_TEMPLATE_REPORT)
				+ APIConstant.CREDIT_SHIELD_REPORT_NEW_LIFE_PAYMENT + APIConstant.FILE_TYPE_EXCEL_OLD;
		String fileDestinationExport = env.getProperty(APIConstant.FOLDER_TEMPLATE_REPORT)
				+ DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss) + APIConstant.FILE_TYPE_EXCEL_OLD;

		Workbook wb = WriteToExcelTemplate.loadTemplateAndFillDataReport(fileSource, datas, "DATA", 4);
		
		/** Start Write Excel file */
		return WriteToExcelTemplate.writeToExcelFile(wb, fileDestinationExport);
		/** End Write Excel file */
	}
	
	public File exportCreditLifePreterReport(List<Object[]> datas) {
		String fileSource = env.getProperty(APIConstant.FOLDER_TEMPLATE_REPORT)
				+ APIConstant.CREDIT_SHIELD_REPORT_NEW_LIFE_PRETER_SVFC + APIConstant.FILE_TYPE_EXCEL_OLD;
		String fileDestinationExport = env.getProperty(APIConstant.FOLDER_TEMPLATE_REPORT)
				+ DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss) + APIConstant.FILE_TYPE_EXCEL_OLD;

		Workbook wb = WriteToExcelTemplate.loadTemplateAndFillDataReport(fileSource, datas, "DATA", 5);
		
		/** Start Write Excel file */
		return WriteToExcelTemplate.writeToExcelFile(wb, fileDestinationExport);
		/** End Write Excel file */
	}
	
}







