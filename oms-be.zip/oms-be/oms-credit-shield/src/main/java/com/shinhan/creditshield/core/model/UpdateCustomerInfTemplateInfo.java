package com.shinhan.creditshield.core.model;

import org.apache.commons.lang3.StringUtils;

public class UpdateCustomerInfTemplateInfo {
	
	private String loanNo;
	private String benName;
	private String benBank;
	private String benAccountNo;
	private String errorMessage;

	
	public String getLoanNo() {
		return loanNo;
	}
	
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	
	public String getBenName() {
		return benName;
	}
	public void setBenName(String benName) {
		this.benName = benName;
	}
	public String getBenBank() {
		return benBank;
	}
	public void setBenBank(String benBank) {
		this.benBank = benBank;
	}
	public String getBenAccountNo() {
		return benAccountNo;
	}
	public void setBenAccountNo(String benAccountNo) {
		this.benAccountNo = benAccountNo;
	}

	public String getError() {
		return errorMessage;
	}

	public void setError(String error) {
		this.errorMessage = error;
	}
	
	public boolean getValid() {
		if (StringUtils.isNotBlank(errorMessage)) {
			return false;
		}
		return true;
	}
	
}
