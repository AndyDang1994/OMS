/**
 * 
 */
package com.shinhan.creditshield.repository.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.shinhan.creditshield.common.AbstractServiceClass;
import com.shinhan.creditshield.core.constant.APIConstant;
import com.shinhan.creditshield.core.exception.BaseException;
import com.shinhan.creditshield.core.exception.ServiceRuntimeException;
import com.shinhan.creditshield.core.util.DateUtils;
import com.shinhan.creditshield.repository.entity.TMetadata;
import com.shinhan.creditshield.repository.service.UtilityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("utilityManagerRepositoryService")
public class UtilityManagerRepositoryServiceImpl extends AbstractServiceClass
		implements UtilityManagerRepositoryService {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.shinhan.recon.repository.service.UtilityManagerRepositoryService#
	 * getAllMetadata(java.util.Map)
	 */
	@Override
	public List<TMetadata> getAllMetadata(Map<String, Object> inputParams) throws BaseException {
		String sql = oracleOMSNamedQueries.get("getAllMetadata");
		Query query = entityManager.createNativeQuery(sql, TMetadata.class);

		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();

		return list;
	}
	
	
	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.UtilityManagerRepositoryService#getOpenBalanceOfBankCodeByDate(java.util.Map)
	 */
	@Override
	public BigDecimal getOpenBalanceOfBankCodeByDate(Map<String, Object> inputParams) throws BaseException {
		String sql = "select sub.OPEN_BLC from (select mas.BANK_CODE, mas.UPLOAD_DT, mas.OPEN_BLC from "
				+ "OMS_STMT_FILE_MAS mas where mas.BANK_CODE = :bankCode and mas.FILE_STATUS = 10 and mas.PROCESS_STATUS = 10 "
				+ "and mas.UPLOAD_DT between :fromDt and :endDt order by mas.UPLOAD_DT ASC, mas.OPEN_BLC desc) sub "
				+ "where rownum = 1";
		
		Query query = entityManager.createNativeQuery(sql);
		
		query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
		query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
		query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
		List<BigDecimal> rsList = query.getResultList();
		BigDecimal openBlc = (rsList.isEmpty() ? APIConstant.DEC_ZERO : rsList.get(0));
		
		return openBlc;
	}


	@Override
	public TMetadata getMetadataByLookupCodeAndId(String lookupCode, String lookupId) throws BaseException {
		String sql = oracleOMSNamedQueries.get("getMetadataByLookupCodeAndId");

		Query query = entityManager.createNativeQuery(sql, TMetadata.class);
		query.setParameter("SERVICENAME", APIConstant.SERVICENAME_REFUND);
		query.setParameter("LOOKUPCODE", lookupCode);
		query.setParameter("LOOKUPCODEID", lookupId);

		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();
		if(CollectionUtils.isEmpty(list)) {
			throw new ServiceRuntimeException(String.format(env.getProperty("MSG_022"), lookupId));
		}
		
		return (TMetadata) list.get(0);
	}


}
