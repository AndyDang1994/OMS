/**
 * 
 */
package com.shinhan.auth.core.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author shds01
 *
 */
public class UserRoleInfo {

	private String roleCode;
	private String roleName;
	private String isShow;
	private List<UserFeatureInfo> features;

	/**
	 * 
	 */
	public UserRoleInfo() {
		super();
		this.features = new ArrayList<UserFeatureInfo>();
	}

	/**
	 * @param roleCode
	 * @param roleName
	 */
	public UserRoleInfo(String roleCode, String roleName) {
		super();
		this.roleCode = roleCode;
		this.roleName = roleName;
	}

	/**
	 * @param roleCode
	 * @param roleName
	 * @param isShow
	 */
	public UserRoleInfo(String roleCode, String roleName, String isShow) {
		super();
		this.roleCode = roleCode;
		this.roleName = roleName;
		this.isShow = isShow;
	}

	/**
	 * @param roleCode
	 * @param roleName
	 * @param features
	 */
	public UserRoleInfo(String roleCode, String roleName, List<UserFeatureInfo> features) {
		super();
		this.roleCode = roleCode;
		this.roleName = roleName;
		this.features = features;
	}

	/**
	 * @return the roleCode
	 */
	public String getRoleCode() {
		return roleCode;
	}

	/**
	 * @param roleCode the roleCode to set
	 */
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	/**
	 * @return the roleName
	 */
	public String getRoleName() {
		return roleName;
	}

	/**
	 * @param roleName the roleName to set
	 */
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	/**
	 * @return the isShow
	 */
	public String getIsShow() {
		return isShow;
	}

	/**
	 * @param isShow the isShow to set
	 */
	public void setIsShow(String isShow) {
		this.isShow = isShow;
	}

	/**
	 * @return the features
	 */
	public List<UserFeatureInfo> getFeatures() {
		return features;
	}

	/**
	 * @param features the features to set
	 */
	public void setFeatures(List<UserFeatureInfo> features) {
		this.features = features;
	}

}
