/**
 * 
 */
package com.shinhan.auth.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.shinhan.auth.repository.entity.TMetadata;

/**
 * @author shds01
 *
 */
@Repository
public interface TMetadataDAO extends JpaRepository<TMetadata, Long> {

}
