/**
 * 
 */
package com.shinhan.auth.repository.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author shds01
 *
 */
@Entity
@Table(name = "OMS_DATAMODEL")
public class TDataModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5988804665611585304L;

	private Long id;
	private String documentType;
	private String dataModel;

	/**
	 * 
	 */
	public TDataModel() {
		super();
	}

	/**
	 * @return the id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "OMS_DATAMODEL_SEQ_GEN")
	@SequenceGenerator(name = "OMS_DATAMODEL_SEQ_GEN", sequenceName = "OMS_DATAMODEL_SEQ", allocationSize = 1)
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the documentType
	 */
	@Column(name = "DOCUMENTTYPE")
	public String getDocumentType() {
		return documentType;
	}

	/**
	 * @param documentType the documentType to set
	 */
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	/**
	 * @return the dataModel
	 */
	@Lob
	@Column(name = "DATAMODEL")
	public String getDataModel() {
		return dataModel;
	}

	/**
	 * @param dataModel the dataModel to set
	 */
	public void setDataModel(String dataModel) {
		this.dataModel = dataModel;
	}

}
