/**
 * 
 */
package com.shinhan.auth.common;

import java.math.BigDecimal;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.auth.core.constant.APIConstant;
import com.shinhan.auth.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.auth.core.exception.ServiceRuntimeException;
import com.shinhan.auth.core.model.UserRoleInfo;
import com.shinhan.auth.core.util.CommonUtil;
import com.shinhan.auth.repository.entity.AuthUser;
import com.shinhan.auth.repository.entity.TDataModel;
import com.shinhan.auth.repository.entity.TMetadata;
import com.shinhan.auth.repository.service.AuthManagerRepositoryService;
import com.shinhan.auth.repository.service.UtilityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("repositoryManagerService")
public class RepositoryManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	public Environment env;
	
	@Autowired
	private UtilityManagerRepositoryService utilityManagerRepositoryService;
	
	@Autowired
	private AuthManagerRepositoryService authManagerRepositoryService;

	/**
	 * @return the utilityManagerRepositoryService
	 */
	public UtilityManagerRepositoryService getUtilityManagerRepositoryService() {
		return utilityManagerRepositoryService;
	}

	/**
	 * @param utilityManagerRepositoryService the utilityManagerRepositoryService to set
	 */
	public void setUtilityManagerRepositoryService(
			@Qualifier("utilityManagerRepositoryService") UtilityManagerRepositoryService utilityManagerRepositoryService) {
		this.utilityManagerRepositoryService = utilityManagerRepositoryService;
	}

	/**
	 * @return the authManagerRepositoryService
	 */
	public AuthManagerRepositoryService getAuthManagerRepositoryService() {
		return authManagerRepositoryService;
	}

	/**
	 * @param authManagerRepositoryService the authManagerRepositoryService to set
	 */
	public void setAuthManagerRepositoryService(@Qualifier("authManagerRepositoryService") AuthManagerRepositoryService authManagerRepositoryService) {
		this.authManagerRepositoryService = authManagerRepositoryService;
	}
	
	public boolean isUserAdmin(AuthUser authUser) throws ServiceRuntimeException {
		if(authUser == null) {
			return false;
		}
		
		List<UserRoleInfo> roles = CommonUtil.toListPojo(authUser.getConfiguration(), UserRoleInfo.class);
		for(UserRoleInfo role : roles) {
			if(APIConstant.LOOKUP_CODE_OMS_USER_ROLE_ADMIN.equals(role.getRoleCode())) {
				return true;
			}
		}
		return false;
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void createNewMultietadataToDB(List<TMetadata> metadatas) throws ServiceRuntimeException{
		getUtilityManagerRepositoryService().createAllMetadata(metadatas);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void createNewMetadataToDB(TMetadata metadata) throws ServiceRuntimeException{
		getUtilityManagerRepositoryService().createMetadata(metadata);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void updateMetadataToDB(TMetadata metadata) throws ServiceRuntimeException, ServiceInvalidAgurmentException{
		getUtilityManagerRepositoryService().updateMetadata(metadata);
		BigDecimal count = utilityManagerRepositoryService.countMetadataByLookupCodeAndId(metadata.getLookupCode(), metadata.getLookupCodeId());
		if(count.compareTo(APIConstant.UNIT_ONE) > 0) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_006"), metadata.getLookupCodeId()));
		}
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void deleteMetadataToDB(TMetadata metadata) throws ServiceRuntimeException{
		metadata.setIsShow(APIConstant.NO_KEY);
		getUtilityManagerRepositoryService().updateMetadata(metadata);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void executeDeleteDB(TMetadata metadata) throws ServiceRuntimeException{
		getUtilityManagerRepositoryService().deleteMetadata(metadata);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void createNewFeatureToDB(TMetadata metadata) throws ServiceRuntimeException{
		getUtilityManagerRepositoryService().createMetadata(metadata);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void updateFeatureToDB(TMetadata metadata) throws ServiceRuntimeException, ServiceInvalidAgurmentException{
		boolean isShow = APIConstant.YES_KEY.equalsIgnoreCase(metadata.getIsShow()) || APIConstant.YES_VALUE.equalsIgnoreCase(metadata.getIsShow()) ? true : false;
		if(isShow) {
			metadata.setIsShow(APIConstant.YES_KEY);
		} else {
			metadata.setIsShow(APIConstant.NO_KEY);
		}
		getUtilityManagerRepositoryService().updateMetadata(metadata);
		BigDecimal count = utilityManagerRepositoryService.countMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_OMS_USER_FEATURE, metadata.getLookupCodeId());
		if(count.compareTo(APIConstant.UNIT_ONE) > 0) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_006"), metadata.getLookupCodeId()));
		}
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void deleteFeatureToDB(TMetadata metadata) throws ServiceRuntimeException{
		metadata.setIsShow(APIConstant.NO_KEY);
		getUtilityManagerRepositoryService().updateMetadata(metadata);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void createNewFeatureForRoleToDB(TDataModel model) throws ServiceRuntimeException{
		getUtilityManagerRepositoryService().updateDataModel(model);
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void updateFeatureForRoleToDB(TDataModel model) throws ServiceRuntimeException{
		getUtilityManagerRepositoryService().updateDataModel(model);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void createNewRoleToDB(TMetadata metadata, TDataModel model) throws ServiceRuntimeException{
		getUtilityManagerRepositoryService().createMetadata(metadata);
		
		getUtilityManagerRepositoryService().createDataModel(model);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void updateRoleToDB(TMetadata metadata) throws ServiceRuntimeException, ServiceInvalidAgurmentException{
		boolean isShow = APIConstant.YES_KEY.equalsIgnoreCase(metadata.getIsShow()) || APIConstant.YES_VALUE.equalsIgnoreCase(metadata.getIsShow()) ? true : false;
		if(isShow) {
			metadata.setIsShow(APIConstant.YES_KEY);
		} else {
			metadata.setIsShow(APIConstant.NO_KEY);
		}
		getUtilityManagerRepositoryService().updateMetadata(metadata);
		BigDecimal count = utilityManagerRepositoryService.countMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_OMS_USER_ROLE, metadata.getLookupCodeId());
		if(count.compareTo(APIConstant.UNIT_ONE) > 0) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_006"), metadata.getLookupCodeId()));
		}
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void deleteRoleToDB(TMetadata metadata) throws ServiceRuntimeException{
		metadata.setIsShow(APIConstant.NO_KEY);
		getUtilityManagerRepositoryService().updateMetadata(metadata);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void createNewAuthUserToDB(AuthUser authUser) throws ServiceRuntimeException{
		getAuthManagerRepositoryService().createAuthUser(authUser);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void updateAuthUserToDB(AuthUser authUser) throws ServiceRuntimeException{
		getAuthManagerRepositoryService().updateAuthUser(authUser);
	}
}
