/**
 * 
 */
package com.shinhan.auth.service;

import java.util.List;
import java.util.Map;

import com.shinhan.auth.core.exception.BaseException;
import com.shinhan.auth.core.model.UserFeatureInfo;
import com.shinhan.auth.repository.entity.TMetadata;

/**
 * @author shds01
 *
 */
public interface ConfigurationApiService {

	public List<TMetadata> getListRole(Map<String, Object> inputParams) throws BaseException;
	
	public TMetadata getRoleDetailSummary(Map<String, Object> inputParams) throws BaseException;
	
	public Object getRoleDetail(Map<String, Object> inputParams) throws BaseException;
	
	public TMetadata createRole(Map<String, Object> inputParams) throws BaseException;
	
	public TMetadata updateRoleSummary(Map<String, Object> inputParams) throws BaseException;
	
	public Object updateRole(Map<String, Object> inputParams) throws BaseException;
	
	public TMetadata deleteRole(Map<String, Object> inputParams) throws BaseException;
	
	public List<UserFeatureInfo> getListFeatureByRole(Map<String, Object> inputParams) throws BaseException;
	
	public UserFeatureInfo createFeatureForRole(Map<String, Object> inputParams) throws BaseException;
	
	public List<TMetadata> getListFeature(Map<String, Object> inputParams) throws BaseException;
	
	public TMetadata createFeature(Map<String, Object> inputParams) throws BaseException;
	
	public TMetadata updateFeature(Map<String, Object> inputParams) throws BaseException;
	
	public TMetadata deleteFeature(Map<String, Object> inputParams) throws BaseException;
}
