/**
 * 
 */
package com.shinhan.auth.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.auth.common.AbstractBasicCommonClass;
import com.shinhan.auth.core.constant.APIConstant;
import com.shinhan.auth.core.exception.BaseException;
import com.shinhan.auth.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.auth.core.model.UserFeatureInfo;
import com.shinhan.auth.core.model.UserRoleInfo;
import com.shinhan.auth.core.util.CommonUtil;
import com.shinhan.auth.core.util.DTOConverter;
import com.shinhan.auth.repository.entity.TDataModel;
import com.shinhan.auth.repository.entity.TMetadata;
import com.shinhan.auth.service.ConfigurationApiService;

/**
 * @author shds01
 *
 */

@Service("configurationApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class ConfigurationApiServiceImpl extends AbstractBasicCommonClass implements ConfigurationApiService {
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.ConfigurationApiService#getListRole(java.util.Map)
	 */
	@Override
	public List<TMetadata> getListRole(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant.LOOKUP_CODE_OMS_USER_ROLE);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.ConfigurationApiService#getRoleDetailSummary(java.util.Map)
	 */
	@Override
	public TMetadata getRoleDetailSummary(Map<String, Object> inputParams) throws BaseException {
		String roleId = inputParams.get(APIConstant.OMSID).toString();
		
		TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataById(Long.valueOf(roleId));
		if(item == null || APIConstant.LOOKUP_CODE_OMS_USER_ROLE.equalsIgnoreCase(item.getLookupCode()) == false || APIConstant.NO_KEY.equalsIgnoreCase(item.getIsShow())) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), roleId));
		}
		
		return item;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.ConfigurationApiService#getRoleDetail(java.util.Map)
	 */
	@Override
	public Object getRoleDetail(Map<String, Object> inputParams) throws BaseException {
		String roleId = inputParams.get(APIConstant.OMSID).toString();
		
		TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataById(Long.valueOf(roleId));
		if(item == null || APIConstant.LOOKUP_CODE_OMS_USER_ROLE.equalsIgnoreCase(item.getLookupCode()) == false || APIConstant.NO_KEY.equalsIgnoreCase(item.getIsShow())) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), roleId));
		}
		
		TDataModel model = getRepositoryManagerService().getUtilityManagerRepositoryService().getDataModelByDocType(item.getLookupCodeId());
		return CommonUtil.toPojo(model.getDataModel(), UserRoleInfo.class);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.ConfigurationApiService#createRole(java.util.Map)
	 */
	@Override
	public TMetadata createRole(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		
		TMetadata item = (TMetadata) CommonUtil.toPojo(document, TMetadata.class);
		DTOConverter.setUtilityTMetadataForRole(item);
		getValidationManagerService().checkValidationCreateNewRole(item);
		
		TDataModel model = DTOConverter.setUtilityTDataModelForCreationRole(item, getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant.LOOKUP_CODE_OMS_USER_FEATURE));
		getRepositoryManagerService().createNewRoleToDB(item, model);
		
		return item;
	
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.ConfigurationApiService#updateRoleSummary(java.util.Map)
	 */
	@Override
	public TMetadata updateRoleSummary(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String roleId = inputParams.get(APIConstant.OMSID).toString();
		
		TMetadata itemUpdate = (TMetadata) CommonUtil.toPojo(document, TMetadata.class);
		TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataById(Long.valueOf(roleId));
		if(item == null || APIConstant.LOOKUP_CODE_OMS_USER_ROLE.equalsIgnoreCase(item.getLookupCode()) == false) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), roleId));
		}
		if(itemUpdate.getId().equals(item.getId()) == false || APIConstant.LOOKUP_CODE_OMS_USER_ROLE.equalsIgnoreCase(itemUpdate.getLookupCode()) == false 
				|| APIConstant.SERVICENAME_ADMIN.equalsIgnoreCase(itemUpdate.getServiceName()) == false) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_008"));
		}
		
		getRepositoryManagerService().updateRoleToDB(itemUpdate);
		
		return itemUpdate;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.ConfigurationApiService#updateRole(java.util.Map)
	 */
	@Override
	public Object updateRole(Map<String, Object> inputParams) throws BaseException {
		String roleId = inputParams.get(APIConstant.OMSID).toString();
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		List<UserFeatureInfo> lstFeatureInfo = CommonUtil.toListPojo(document, UserFeatureInfo.class);
		
		TMetadata itemRole = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataById(Long.valueOf(roleId));
		if(itemRole == null || APIConstant.LOOKUP_CODE_OMS_USER_ROLE.equalsIgnoreCase(itemRole.getLookupCode()) == false || APIConstant.NO_KEY.equalsIgnoreCase(itemRole.getIsShow())) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), roleId));
		}
		
		getValidationManagerService().checkValidationUpdateFeatureByRole(lstFeatureInfo);
		
		TDataModel model = getRepositoryManagerService().getUtilityManagerRepositoryService().getDataModelByDocType(itemRole.getLookupCodeId());
		model = DTOConverter.setUtilityTDataModelForUpdateRole(model, itemRole, lstFeatureInfo);
		getRepositoryManagerService().updateFeatureForRoleToDB(model);
		
		return CommonUtil.toPojo(model.getDataModel(), UserRoleInfo.class);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.ConfigurationApiService#deleteRole(java.util.Map)
	 */
	@Override
	public TMetadata deleteRole(Map<String, Object> inputParams) throws BaseException {
		String roleId = inputParams.get(APIConstant.OMSID).toString();
		
		TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataById(Long.valueOf(roleId));
		if(item == null || APIConstant.LOOKUP_CODE_OMS_USER_ROLE.equalsIgnoreCase(item.getLookupCode()) == false) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), roleId));
		}
		
		if(APIConstant.YES_KEY.equalsIgnoreCase(item.getIsShow())) {
			getRepositoryManagerService().deleteRoleToDB(item);
		}
		return item;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.ConfigurationApiService#getListFeatureByRole(java.util.Map)
	 */
	@Override
	public List<UserFeatureInfo> getListFeatureByRole(Map<String, Object> inputParams) throws BaseException {
		UserRoleInfo userInfo = (UserRoleInfo) getRoleDetail(inputParams);
		return userInfo.getFeatures();
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.ConfigurationApiService#createFeatureForRole(java.util.Map)
	 */
	@Override
	public UserFeatureInfo createFeatureForRole(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		TMetadata feature = (TMetadata) CommonUtil.toPojo(document, TMetadata.class);
		TMetadata itemFeature = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataById(Long.valueOf(feature.getId()));
		if(itemFeature == null) {
			itemFeature = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_OMS_USER_FEATURE, feature.getLookupCodeId());
		}
		if(itemFeature == null || APIConstant.LOOKUP_CODE_OMS_USER_FEATURE.equalsIgnoreCase(itemFeature.getLookupCode()) == false || APIConstant.NO_KEY.equalsIgnoreCase(itemFeature.getIsShow())) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), feature.getId()));
		}
		UserFeatureInfo userFeature = DTOConverter.setUtilityUserFeatureInfoForCreation(itemFeature);
		TMetadata itemRole = getRoleDetailSummary(inputParams);
		
		TDataModel model = getRepositoryManagerService().getUtilityManagerRepositoryService().getDataModelByDocType(itemRole.getLookupCodeId());
		if(model != null) {
			UserRoleInfo userInfo = (UserRoleInfo) CommonUtil.toPojo(model.getDataModel(), UserRoleInfo.class);
			getValidationManagerService().checkValidationCreateFeatureByRole(userInfo.getFeatures(), userFeature);
			DTOConverter.setUtilityTDataModelForCreationFeatureForRole(model, userFeature);
			
			getRepositoryManagerService().createNewFeatureForRoleToDB(model);
			return userFeature;
		}
		
		return null;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.ConfigurationApiService#getListFeature(java.util.Map)
	 */
	@Override
	public List<TMetadata> getListFeature(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant.LOOKUP_CODE_OMS_USER_FEATURE);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.ConfigurationApiService#createFeature(java.util.Map)
	 */
	@Override
	public TMetadata createFeature(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		
		TMetadata item = (TMetadata) CommonUtil.toPojo(document, TMetadata.class);
		DTOConverter.setUtilityTMetadataForFeature(item);
		getValidationManagerService().checkValidationCreateNewFeature(item);
		
		getRepositoryManagerService().createNewFeatureToDB(item);
		
		return item;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.ConfigurationApiService#updateFeature(java.util.Map)
	 */
	@Override
	public TMetadata updateFeature(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String featureId = inputParams.get(APIConstant.OMSID).toString();
		
		TMetadata itemUpdate = (TMetadata) CommonUtil.toPojo(document, TMetadata.class);
		getValidationManagerService().checkValidationUpdateFeature(itemUpdate, featureId);
		
		getRepositoryManagerService().updateFeatureToDB(itemUpdate);
		
		return itemUpdate;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.ConfigurationApiService#deleteFeature(java.util.Map)
	 */
	@Override
	public TMetadata deleteFeature(Map<String, Object> inputParams) throws BaseException {
		String featureId = inputParams.get(APIConstant.OMSID).toString();
		
		TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataById(Long.valueOf(featureId));
		if(item == null || APIConstant.LOOKUP_CODE_OMS_USER_FEATURE.equalsIgnoreCase(item.getLookupCode()) == false) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), featureId));
		}
		
		if(APIConstant.YES_KEY.equalsIgnoreCase(item.getIsShow())) {
			getRepositoryManagerService().deleteFeatureToDB(item);
		}
		return item;
	}

}
