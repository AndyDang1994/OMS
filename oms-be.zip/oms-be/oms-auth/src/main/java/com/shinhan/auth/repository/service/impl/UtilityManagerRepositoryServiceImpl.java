/**
 * 
 */
package com.shinhan.auth.repository.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.auth.common.AbstractServiceClass;
import com.shinhan.auth.core.constant.APIConstant;
import com.shinhan.auth.core.exception.ServiceRuntimeException;
import com.shinhan.auth.repository.dao.TDataModelDAO;
import com.shinhan.auth.repository.dao.TMetadataDAO;
import com.shinhan.auth.repository.entity.TDataModel;
import com.shinhan.auth.repository.entity.TMetadata;
import com.shinhan.auth.repository.service.UtilityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("utilityManagerRepositoryService")
public class UtilityManagerRepositoryServiceImpl extends AbstractServiceClass
		implements UtilityManagerRepositoryService {

	private TMetadataDAO objectMetaDao;
	
	private TDataModelDAO objectDataModelDao;

	@Autowired
	public UtilityManagerRepositoryServiceImpl(TMetadataDAO objectMetaDao, TDataModelDAO objectDataModelDao) {
		this.objectMetaDao = objectMetaDao;
		this.objectDataModelDao = objectDataModelDao;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.auth.repository.service.UtilityManagerRepositoryService#
	 * getAllMetadata(java.util.Map)
	 */
	@Override
	public List<TMetadata> getAllMetadata(Map<String, Object> inputParams) throws ServiceRuntimeException {
		String sql = oracleOMSNamedQueries.get("getAllMetadata");
		Query query = entityManager.createNativeQuery(sql, TMetadata.class);
		query.setParameter("SERVICENAME", APIConstant.SERVICENAME_ADMIN);
		
		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();

		return list;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.repository.service.UtilityManagerRepositoryService#getAllMetadataByAdmin(java.util.Map)
	 */
	@Override
	public List<TMetadata> getAllMetadataByAdmin(Map<String, Object> inputParams) throws ServiceRuntimeException {
		String sql = oracleOMSNamedQueries.get("getAllMetadataByAdmin");
		Query query = entityManager.createNativeQuery(sql, TMetadata.class);
		
		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();

		return list;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.repository.service.UtilityManagerRepositoryService#getMetadataById(java.lang.Long)
	 */
	@Override
	public TMetadata getMetadataById(Long id) throws ServiceRuntimeException {
		return objectMetaDao.findById(id).get(); 
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.auth.repository.service.UtilityManagerRepositoryService#
	 * getMetadataByLookupCode(java.lang.String)
	 */
	@Override
	public List<TMetadata> getMetadataByLookupCode(String lookupCode) throws ServiceRuntimeException {
		String sql = oracleOMSNamedQueries.get("getMetadataByLookupCode");
		Query query = entityManager.createNativeQuery(sql, TMetadata.class);
		query.setParameter("LOOKUPCODE", lookupCode);
		
		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();

		return list;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.repository.service.UtilityManagerRepositoryService#getMetadataByLookupCodeAndId(java.lang.String, java.lang.String)
	 */
	@Override
	public TMetadata getMetadataByLookupCodeAndId(String lookupCode, String lookupId) throws ServiceRuntimeException {
		String sql = oracleOMSNamedQueries.get("getMetadataByLookupCodeAndId");

		Query query = entityManager.createNativeQuery(sql, TMetadata.class);
		query.setParameter("LOOKUPCODE", lookupCode);
		query.setParameter("LOOKUPCODEID", lookupId);

		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();
		if(CollectionUtils.isEmpty(list)) {
			return null;
		}
		return (TMetadata) list.get(0);
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.repository.service.UtilityManagerRepositoryService#countMetadataByLookupCodeAndId(java.lang.String, java.lang.String)
	 */
	@Override
	public BigDecimal countMetadataByLookupCodeAndId(String lookupCode, String lookupId)
			throws ServiceRuntimeException {
		try {
			String sql = "select count(*) from oms_metadata mas "
					+ "where mas.LOOKUPCODE = :LOOKUPCODE and mas.LOOKUPCODEID = :LOOKUPCODEID"
					;
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("LOOKUPCODE", lookupCode);
			query.setParameter("LOOKUPCODEID", lookupId);
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.repository.service.UtilityManagerRepositoryService#createAllMetadata(java.util.List)
	 */
	@Override
	public boolean createAllMetadata(List<TMetadata> metadatas) throws ServiceRuntimeException {
		try {
			if (CollectionUtils.isNotEmpty(metadatas)) {
				objectMetaDao.saveAll(metadatas);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.repository.service.UtilityManagerRepositoryService#createMetadata(com.shinhan.auth.repository.entity.TMetadata)
	 */
	@Override
	public boolean createMetadata(TMetadata metadata) throws ServiceRuntimeException {
		try {
			if (metadata != null) {
				objectMetaDao.save(metadata);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.repository.service.UtilityManagerRepositoryService#updateMetadata(com.shinhan.auth.repository.entity.TMetadata)
	 */
	@Override
	public boolean updateMetadata(TMetadata metadata) throws ServiceRuntimeException {
		try {
			if (metadata != null) {
				objectMetaDao.save(metadata);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.repository.service.UtilityManagerRepositoryService#deleteMetadata(com.shinhan.auth.repository.entity.TMetadata)
	 */
	@Override
	public boolean deleteMetadata(TMetadata metadata) throws ServiceRuntimeException {
		try {
			if (metadata != null) {
				objectMetaDao.delete(metadata);
				logger.info(" Delete :" + metadata.toString());
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.repository.service.UtilityManagerRepositoryService#getDataModelById(java.lang.Long)
	 */
	@Override
	public TDataModel getDataModelById(Long id) throws ServiceRuntimeException {
		try {
			return objectDataModelDao.findById(id).get();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.repository.service.UtilityManagerRepositoryService#getDataModelByDocType(java.lang.String)
	 */
	@Override
	public TDataModel getDataModelByDocType(String docType) throws ServiceRuntimeException {
		try {
			if(StringUtils.isBlank(docType)) {
				return null;
			}
			return objectDataModelDao.getModelByDocType(docType);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.repository.service.UtilityManagerRepositoryService#createDataModel(com.shinhan.auth.repository.entity.TDataModel)
	 */
	@Override
	public boolean createDataModel(TDataModel model) throws ServiceRuntimeException {
		try {
			if (model != null) {
				objectDataModelDao.save(model);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.repository.service.UtilityManagerRepositoryService#updateDataModel(com.shinhan.auth.repository.entity.TDataModel)
	 */
	@Override
	public boolean updateDataModel(TDataModel model) throws ServiceRuntimeException {
		try {
			if (model != null) {
				objectDataModelDao.save(model);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

}
