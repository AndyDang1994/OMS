/**
 * 
 */
package com.shinhan.auth.common;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.shinhan.auth.core.constant.APIConstant;
import com.shinhan.auth.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.auth.core.exception.ServiceRuntimeException;
import com.shinhan.auth.core.model.UserFeatureInfo;
import com.shinhan.auth.core.model.UserRoleInfo;
import com.shinhan.auth.core.util.CommonUtil;
import com.shinhan.auth.repository.entity.AuthUser;
import com.shinhan.auth.repository.entity.TMetadata;


/**
 * @author shds01
 *
 */
@Service("validationManagerService")
public class ValidationManagerService extends AbstractRepositoryClass {

	public void checkValidationCreateNewMetadata(TMetadata metadata) throws ServiceInvalidAgurmentException, ServiceRuntimeException{
		if(StringUtils.isBlank(metadata.getLookupCode()) || StringUtils.isBlank(metadata.getLanguage())
				|| StringUtils.isBlank(metadata.getLookupCodeId()) || StringUtils.isBlank(metadata.getValue())) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_001"));
		} else {
			if(StringUtils.isBlank(metadata.getIsShow())) {
				metadata.setIsShow(APIConstant.YES_KEY);
			}
		}
		
		TMetadata dummy = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCodeAndId(metadata.getLookupCode(), metadata.getLookupCodeId());
		if(dummy != null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_006"), metadata.getLookupCodeId()));
		}
	}
	
	public void checkValidationCreateNewRole(TMetadata metadata) throws ServiceInvalidAgurmentException, ServiceRuntimeException{
		if(StringUtils.isBlank(metadata.getLookupCode()) || StringUtils.isBlank(metadata.getLanguage())
				|| StringUtils.isBlank(metadata.getLookupCodeId()) || StringUtils.isBlank(metadata.getValue())) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_001"));
		}
		
		TMetadata dummy = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_OMS_USER_ROLE, metadata.getLookupCodeId());
		if(dummy != null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_006"), metadata.getLookupCodeId()));
		}
	}
	
	public void checkValidationUpdateFeatureByRole(List<UserFeatureInfo> lstFeatureInfo) throws ServiceInvalidAgurmentException, ServiceRuntimeException{
		if(CollectionUtils.isEmpty(lstFeatureInfo)) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_001"));
		}
		for(UserFeatureInfo feature : lstFeatureInfo) {
			if(StringUtils.isBlank(feature.getFeatureCode())) {
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_001"));
			}
			TMetadata itemFeature = getRepositoryManagerService().getUtilityManagerRepositoryService()
					.getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_OMS_USER_FEATURE, feature.getFeatureCode());
			if(itemFeature == null || APIConstant.LOOKUP_CODE_OMS_USER_FEATURE.equalsIgnoreCase(itemFeature.getLookupCode()) == false) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), feature.getFeatureCode()));
			}
			feature.setFeatureName(itemFeature.getValue());
		}
	}
	
	public void checkValidationCreateFeatureByRole(List<UserFeatureInfo> lstFeatureInfo, UserFeatureInfo userFeature) throws ServiceInvalidAgurmentException, ServiceRuntimeException{
		if(CollectionUtils.isEmpty(lstFeatureInfo) || userFeature == null || StringUtils.isBlank(userFeature.getFeatureCode())) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_001"));
		}
		for(UserFeatureInfo feature : lstFeatureInfo) {
			if(StringUtils.isBlank(feature.getFeatureCode())) {
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_001"));
			}
			if(feature.getFeatureCode().equalsIgnoreCase(userFeature.getFeatureCode())) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_006"), feature.getFeatureCode()));
			}
		}
	}
	
	public void checkValidationCreateNewFeature(TMetadata metadata) throws ServiceInvalidAgurmentException, ServiceRuntimeException{
		if(StringUtils.isBlank(metadata.getLookupCode()) || StringUtils.isBlank(metadata.getLanguage())
				|| StringUtils.isBlank(metadata.getLookupCodeId()) || StringUtils.isBlank(metadata.getValue())) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_001"));
		}
		
		TMetadata dummy = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_OMS_USER_FEATURE, metadata.getLookupCodeId());
		if(dummy != null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_006"), metadata.getLookupCodeId()));
		}
	}
	
	public void checkValidationUpdateFeature(TMetadata itemUpdate, String featureId) throws ServiceInvalidAgurmentException, ServiceRuntimeException{
		if(StringUtils.isBlank(itemUpdate.getLookupCode()) || StringUtils.isBlank(itemUpdate.getLanguage())
				|| StringUtils.isBlank(itemUpdate.getLookupCodeId()) || StringUtils.isBlank(itemUpdate.getValue())) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_001"));
		}
		
		TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataById(Long.valueOf(featureId));
		if(item == null || APIConstant.LOOKUP_CODE_OMS_USER_FEATURE.equalsIgnoreCase(item.getLookupCode()) == false) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), featureId));
		}
		if(itemUpdate.getId().equals(item.getId()) == false || APIConstant.LOOKUP_CODE_OMS_USER_FEATURE.equalsIgnoreCase(itemUpdate.getLookupCode()) == false
				|| APIConstant.SERVICENAME_ADMIN.equalsIgnoreCase(itemUpdate.getServiceName()) == false) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_008"));
		}
		
	}
	
	private boolean checkUserRoleInMetadata(UserRoleInfo role, List<TMetadata> listUserRoles) {
		for(TMetadata item : listUserRoles) {
			if(item.getLookupCodeId().equalsIgnoreCase(role.getRoleCode()) && APIConstant.YES_KEY.equalsIgnoreCase(item.getIsShow())) {
				role.setRoleName(item.getValue());
				return true;
			}
		}
		return false;
	}
	
	public AuthUser checkValidationCreationNewAuthUser(AuthUser authUser) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(authUser.getUsername()) || StringUtils.isBlank(authUser.getPassword()) 
				|| StringUtils.isBlank(authUser.getFullname()) || StringUtils.isBlank(authUser.getConfiguration())) {
			error = env.getProperty("MSG_001");
			authUser.setErrorMessage(error);
			return authUser;
		}
		
		//Check Roles
		checkValidationRoleAuthUser(authUser);
		//Check in DB
		if(StringUtils.isBlank(error) && authUser.getValid()) {
			AuthUser auth = getRepositoryManagerService().getAuthManagerRepositoryService().getAuthenUserProfile(authUser.getUsername());
			if(auth != null) {
				error = String.format(env.getProperty("MSG_006"), authUser.getUsername());
			}
		}
		
		if(authUser.getValid()) {
			authUser.setErrorMessage(error);
		}
		return authUser;
	}
	
	public AuthUser checkValidationRoleAuthUser(AuthUser authUser) throws ServiceRuntimeException {
		String error = "";
		
		//Check Roles
		List<UserRoleInfo> roles = CommonUtil.toListPojo(authUser.getConfiguration(), UserRoleInfo.class);
		if(CollectionUtils.isEmpty(roles)) {
			error = env.getProperty("MSG_001");
			authUser.setErrorMessage(error);
			return authUser;
		}
		List<TMetadata> listUserRoles = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant.LOOKUP_CODE_OMS_USER_ROLE);
		for(UserRoleInfo role : roles) {
			if(APIConstant.LOOKUP_CODE_OMS_USER_ROLE_ADMIN.equalsIgnoreCase(role.getRoleCode())) {
				error = env.getProperty("MSG_991");
				authUser.setErrorMessage(error);
				return authUser;
			}
			boolean flag = checkUserRoleInMetadata(role, listUserRoles);
			if(!flag) {
				error = String.format(env.getProperty("MSG_990"), role.getRoleCode());
				authUser.setErrorMessage(error);
				return authUser;
			}
		}

		authUser.setErrorMessage(error);
		return authUser;
	}
}
