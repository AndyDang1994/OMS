/**
 * 
 */
package com.shinhan.auth.core.model;

import com.shinhan.auth.core.constant.APIConstant;

/**
 * @author shds01
 *
 */
public class UserFeatureInfo {

	private String featureCode;
	private String featureName;
	private String isRead;
	private String isWrite;
	private String url;
	private String endpoint;
	private String remarks;
	private String isShow;
	/**
	 * 
	 */
	public UserFeatureInfo() {
		super();
		this.isRead = APIConstant.NO_KEY;
		this.isWrite = APIConstant.NO_KEY;
	}

	/**
	 * @param featureCode
	 * @param featureName
	 */
	public UserFeatureInfo(String featureCode, String featureName) {
		super();
		this.featureCode = featureCode;
		this.featureName = featureName;
		this.isRead = APIConstant.NO_KEY;
		this.isWrite = APIConstant.NO_KEY;
	}

	/**
	 * @param featureCode
	 * @param featureName
	 * @param isRead
	 * @param isWrite
	 * @param endpoint
	 * @param remarks
	 */
	public UserFeatureInfo(String featureCode, String featureName, String isRead, String isWrite, String endpoint,
			String remarks) {
		super();
		this.featureCode = featureCode;
		this.featureName = featureName;
		this.isRead = isRead;
		this.isWrite = isWrite;
		this.endpoint = endpoint;
		this.remarks = remarks;
	}

	/**
	 * @return the featureCode
	 */
	public String getFeatureCode() {
		return featureCode;
	}

	/**
	 * @param featureCode the featureCode to set
	 */
	public void setFeatureCode(String featureCode) {
		this.featureCode = featureCode;
	}

	/**
	 * @return the featureName
	 */
	public String getFeatureName() {
		return featureName;
	}

	/**
	 * @param featureName the featureName to set
	 */
	public void setFeatureName(String featureName) {
		this.featureName = featureName;
	}

	/**
	 * @return the isRead
	 */
	public String getIsRead() {
		return isRead;
	}

	/**
	 * @param isRead the isRead to set
	 */
	public void setIsRead(String isRead) {
		this.isRead = isRead;
	}

	/**
	 * @return the isWrite
	 */
	public String getIsWrite() {
		return isWrite;
	}

	/**
	 * @param isWrite the isWrite to set
	 */
	public void setIsWrite(String isWrite) {
		this.isWrite = isWrite;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the endpoint
	 */
	public String getEndpoint() {
		return endpoint;
	}

	/**
	 * @param endpoint the endpoint to set
	 */
	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the isShow
	 */
	public String getIsShow() {
		return isShow;
	}

	/**
	 * @param isShow the isShow to set
	 */
	public void setIsShow(String isShow) {
		this.isShow = isShow;
	}

}
