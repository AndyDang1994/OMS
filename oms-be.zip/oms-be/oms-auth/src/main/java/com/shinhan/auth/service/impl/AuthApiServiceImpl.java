/**
 * 
 */
package com.shinhan.auth.service.impl;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.auth.common.AbstractBasicCommonClass;
import com.shinhan.auth.core.constant.APIConstant;
import com.shinhan.auth.core.exception.BaseException;
import com.shinhan.auth.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.auth.core.exception.UnauthorizedException;
import com.shinhan.auth.core.model.UserInfo;
import com.shinhan.auth.core.model.UserPermission;
import com.shinhan.auth.core.util.CommonUtil;
import com.shinhan.auth.core.util.DTOConverter;
import com.shinhan.auth.repository.entity.AuthUser;
import com.shinhan.auth.service.AuthApiService;

/**
 * @author shds01
 *
 */

@Service("authApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class AuthApiServiceImpl extends AbstractBasicCommonClass implements AuthApiService {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.auth.service.AuthApiService#generateUserToken(java.util.
	 * Map)
	 */
	@Override
	public UserInfo generateUserToken(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		UserInfo userInfo = (UserInfo) CommonUtil.toPojo(document, UserInfo.class);

		if(StringUtils.isBlank(userInfo.getUserName()) || StringUtils.isBlank(userInfo.getPassword())){
			throw new UnauthorizedException(env.getProperty("MSG_999"));
		}
		
		AuthUser authUser = getRepositoryManagerService().getAuthManagerRepositoryService().getAuthenUserProfile(userInfo.getUserName());
		if(authUser == null || APIConstant.USER_STATUS_ACTIVE.equalsIgnoreCase(authUser.getStatus()) == false ){
			throw new UnauthorizedException(env.getProperty("MSG_999"));
		}
		
		if(!CommonUtil.decrytePassword(userInfo.getPassword(), authUser.getPassword())){
			throw new UnauthorizedException(env.getProperty("MSG_999"));
		}
		
		// Generate token
		String token = CommonUtil.getCryptUser(env, userInfo.getUserName());
		return new UserInfo(token);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.AuthApiService#getUserProfile(java.util.Map)
	 */
	@Override
	public UserInfo getUserProfile(Map<String, Object> inputParams) throws BaseException {
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		AuthUser authUser = getRepositoryManagerService().getAuthManagerRepositoryService().getAuthenUserProfile(userName);
		if(authUser == null || APIConstant.USER_STATUS_ACTIVE.equalsIgnoreCase(authUser.getStatus()) == false ){
			throw new UnauthorizedException(env.getProperty("MSG_999"));
		}
		
		return getUserProfileByUserName(authUser);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.AuthApiService#updateUserProfilePasswordByToken(java.util.Map)
	 */
	@Override
	public UserInfo updateUserProfilePasswordByToken(Map<String, Object> inputParams) throws BaseException {
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		UserInfo userInfo = (UserInfo) CommonUtil.toPojo(document, UserInfo.class);
		
		if(StringUtils.isBlank(userInfo.getUserName()) || StringUtils.isBlank(userInfo.getPassword()) || userName.equalsIgnoreCase(userInfo.getUserName()) == false){
			throw new UnauthorizedException(env.getProperty("MSG_999"));
		}
		
		AuthUser authUser = getRepositoryManagerService().getAuthManagerRepositoryService().getAuthenUserProfile(userName);
		if(authUser == null || APIConstant.USER_STATUS_DEACTIVE.equalsIgnoreCase(authUser.getStatus())) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), userInfo.getUserName()));
		}
		
		if(APIConstant.USER_STATUS_ACTIVE.equalsIgnoreCase(authUser.getStatus())) {
			DTOConverter.populateForUpdatePasswordAuthUser(authUser, userInfo, userName);
			getRepositoryManagerService().updateAuthUserToDB(authUser);
		}
		return new UserInfo(userInfo.getUserName(), APIConstant.USER_STATUS_ACTIVE, null);
	
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.AuthApiService#checkPermissionURL(java.util.Map)
	 */
	@Override
	public UserInfo checkPermissionURL(Map<String, Object> inputParams) throws BaseException {
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		UserPermission userPer = (UserPermission) CommonUtil.toPojo(document, UserPermission.class);
		
		AuthUser authUser = getRepositoryManagerService().getAuthManagerRepositoryService().getAuthenUserProfile(userName);
		if(authUser == null || APIConstant.USER_STATUS_ACTIVE.equalsIgnoreCase(authUser.getStatus()) == false ){
			throw new UnauthorizedException(env.getProperty("MSG_999"));
		}
		
		//Check permisson by url for user.
		if(!checkPermissionUserNameByURL(authUser, userPer)) {
			throw new UnauthorizedException(String.format(env.getProperty("MSG_992"), userName));
		}
		
		return new UserInfo(userName, APIConstant.USER_STATUS_ACTIVE, null);
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.AuthApiService#getUserProfileByUserName(java.util.Map)
	 */
	@Override
	public UserInfo getUserProfileByUserName(Map<String, Object> inputParams) throws BaseException {
		String userNameSearching = inputParams.get(APIConstant.USERNAME_TXT).toString();
		
		AuthUser authUserProfile = getRepositoryManagerService().getAuthManagerRepositoryService().getAuthenUserProfile(userNameSearching);
		if(authUserProfile == null) {
			return null;
		}
		
		return getUserProfileByUserName(authUserProfile);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.AuthApiService#createUserProfile(java.util.Map)
	 */
	@Override
	public UserInfo createUserProfile(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		UserInfo userInfo = (UserInfo) CommonUtil.toPojo(document, UserInfo.class);
		
		AuthUser authUserNew = DTOConverter.populateForCreateNewAuthUser(userInfo, userName);
		getValidationManagerService().checkValidationCreationNewAuthUser(authUserNew);
		
		if(authUserNew.getValid()) {
			getRepositoryManagerService().createNewAuthUserToDB(authUserNew);
		} else {
			throw new ServiceInvalidAgurmentException(authUserNew.getErrorMessage());
		}
		
		return new UserInfo(userInfo.getUserName(), userInfo.getFullname(), APIConstant.USER_STATUS_ACTIVE, userInfo.getRoles());
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.AuthApiService#activeUserProfile(java.util.Map)
	 */
	@Override
	public UserInfo activeUserProfile(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		UserInfo userInfo = (UserInfo) CommonUtil.toPojo(document, UserInfo.class);
		
		AuthUser authUserProfile = getRepositoryManagerService().getAuthManagerRepositoryService().getAuthenUserProfile(userInfo.getUserName());
		if(authUserProfile == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), userInfo.getUserName()));
		}
		
		if(APIConstant.USER_STATUS_DEACTIVE.equalsIgnoreCase(authUserProfile.getStatus())) {
			DTOConverter.populateForActiveAuthUser(authUserProfile, userName);
			getRepositoryManagerService().updateAuthUserToDB(authUserProfile);
		}
		return new UserInfo(userInfo.getUserName(), APIConstant.USER_STATUS_ACTIVE, null);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.AuthApiService#deactiveUserProfile(java.util.Map)
	 */
	@Override
	public UserInfo deactiveUserProfile(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		UserInfo userInfo = (UserInfo) CommonUtil.toPojo(document, UserInfo.class);
		
		AuthUser authUserProfile = getRepositoryManagerService().getAuthManagerRepositoryService().getAuthenUserProfile(userInfo.getUserName());
		if(authUserProfile == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), userInfo.getUserName()));
		} else if (getRepositoryManagerService().isUserAdmin(authUserProfile)) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_005"), userInfo.getUserName()));
		}
		
		if(APIConstant.USER_STATUS_ACTIVE.equalsIgnoreCase(authUserProfile.getStatus())) {
			DTOConverter.populateForDeactiveAuthUser(authUserProfile, userName);
			getRepositoryManagerService().updateAuthUserToDB(authUserProfile);
		}
		return new UserInfo(userInfo.getUserName(), APIConstant.USER_STATUS_DEACTIVE, null);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.AuthApiService#updateUserProfilePassword(java.util.Map)
	 */
	@Override
	public UserInfo updateUserProfilePassword(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		UserInfo userInfo = (UserInfo) CommonUtil.toPojo(document, UserInfo.class);
		
		if(StringUtils.isBlank(userInfo.getUserName()) || StringUtils.isBlank(userInfo.getPassword())){
			throw new UnauthorizedException(env.getProperty("MSG_999"));
		}
		
		AuthUser authUserProfile = getRepositoryManagerService().getAuthManagerRepositoryService().getAuthenUserProfile(userInfo.getUserName());
		if(authUserProfile == null || APIConstant.USER_STATUS_DEACTIVE.equalsIgnoreCase(authUserProfile.getStatus())) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), userInfo.getUserName()));
		}
		
		if(APIConstant.USER_STATUS_ACTIVE.equalsIgnoreCase(authUserProfile.getStatus())) {
			DTOConverter.populateForUpdatePasswordAuthUser(authUserProfile, userInfo, userName);
			getRepositoryManagerService().updateAuthUserToDB(authUserProfile);
		}
		return new UserInfo(userInfo.getUserName(), APIConstant.USER_STATUS_ACTIVE, null);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.AuthApiService#updateUserProfileRole(java.util.Map)
	 */
	@Override
	public UserInfo updateUserProfileRole(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		UserInfo userInfo = (UserInfo) CommonUtil.toPojo(document, UserInfo.class);
		
		AuthUser authUserProfile = getRepositoryManagerService().getAuthManagerRepositoryService().getAuthenUserProfile(userInfo.getUserName());
		if(authUserProfile == null || APIConstant.USER_STATUS_DEACTIVE.equalsIgnoreCase(authUserProfile.getStatus())) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), userInfo.getUserName()));
		} else if (getRepositoryManagerService().isUserAdmin(authUserProfile)) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_005"), userInfo.getUserName()));
		}
		
		DTOConverter.populateForUpdateRoleAuthUser(authUserProfile, userInfo);
		getValidationManagerService().checkValidationRoleAuthUser(authUserProfile);
		
		if(authUserProfile.getValid()) {
			getRepositoryManagerService().updateAuthUserToDB(authUserProfile);
		} else {
			throw new ServiceInvalidAgurmentException(authUserProfile.getErrorMessage());
		}
		
		return new UserInfo(userInfo.getUserName(), APIConstant.USER_STATUS_ACTIVE, userInfo.getRoles());
	
	}
	
}
