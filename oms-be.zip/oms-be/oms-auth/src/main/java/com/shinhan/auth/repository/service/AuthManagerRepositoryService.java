/**
 * 
 */
package com.shinhan.auth.repository.service;

import com.shinhan.auth.core.exception.ServiceRuntimeException;
import com.shinhan.auth.repository.entity.AuthUser;

/**
 * @author shds01
 *
 */
public interface AuthManagerRepositoryService {
	
	public AuthUser getAuthenUserProfile(String userName)throws ServiceRuntimeException;
	
	public boolean createAuthUser(AuthUser user) throws ServiceRuntimeException;
	
	public boolean updateAuthUser(AuthUser user) throws ServiceRuntimeException;
}
