/**
 * 
 */
package com.shinhan.auth.core.constant;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

/**
 * @author shds01
 *
 */

public class APIConstant {

	/** Common Constant */
	public static final String ALL = "all";
	public static final String DOCUMENT = "document";
	public static final String DOCTYPE = "docType";
	
	public static final String DATA = "data";
	public static final String COUNT = "count";
		
	public static final String USERNAME_KEY = "userName";
	public static final String USERNAME_TXT = "userNameTxt";
	public static final String EXPIRY_DATE = "expiryDate";

	public static final String FILE = "file";
	public static final String LANGUAGE_VN = "VN";
	public static final String FILE_UPLOAD = "fileUpload";
	
	/** Common Document Constant */

	public static final String FILE_TYPE_IMAGE_JPG = ".jpg";
	public static final String FILE_TYPE_IMAGE_PNG = ".png";
	public static final String FILE_TYPE_PDF = ".pdf";
	public static final String FILE_TYPE_JASPER = ".jasper";
	public static final String FILE_TYPE_TXT = ".txt";
	
	public static final String FILE_TYPE_JSON = ".json";
	public static final String FILE_TYPE_XML = ".xml";
	public static final String FILE_TYPE_EXCEL_OLD = ".xls";
	public static final String FILE_TYPE_EXCEL_NEW = ".xlsx";
	
	/** HTTP Description **/
	public static final String HTTP_REQUEST_BODY_STR = "HttpRequestBody";
	public static final String METHOD_NOT_ALLOWED = "Method is not allowed";
	public static final String UNSUPPORTED_MEDIA_TYPE = "Media type is unsupported";
	public static final String NOT_ACCEPTABLE = "Not Acceptable";

	public static final String GET_METHOD_STR = "GET";
	public static final String POST_METHOD_STR = "POST";
	public static final String PATCH_METHOD_STR = "PATCH";
	public static final String DELETE_METHOD_STR = "DELETE";
	public static final String OPTIONS_METHOD_STR = "OPTIONS";
	public static final String ANONYMOUS_USER = "Anonymous";

	public static final String TEXT_HTML_CHARSET_UTF8_CHARSET_TYPE = "text/html;charset=UTF-8";
	public static final String UTF_8_CHARSET_TYPE = "UTF-8";
	public static final String CONTENT_TYPE_REQUEST_HEADER = "Content-Type";

	public static final String CONTENT_TYPE_IMAGE_PNG = "image/png";
	public static final String CONTENT_TYPE_IMAGE_JPG = "image/jpeg";

	public static final String CONTENT_TYPE_JSON = "application/json";
	public static final String CONTENT_TYPE_XML = "application/xml";
	public static final String CONTENT_TYPE_APPLICATION_PDF = "application/pdf";
	public static final String CONTENT_TYPE_APPLICATION_OCTET_STREAM = "application/octet-stream";
	
	
	public static final String CONTEXT_FILTER_PATH = "shinhan/service/";
	public static final String CONTEXT_FILTER_ADMIN_PATH = "shinhan/service/configuration";
	
	public static final String REQUEST_URI_STR = "requestURI";
	
	public static final String SUCCESS_RESPONSE_KEY = "200";
	public static final String ERROR_CLIENT_RESPONSE_KEY = "400";
	public static final String ERROR_SERVER_RESPONSE_KEY = "500";
	
	public static final String MODE_IMPORT_KEY = "import";
	
	/** Exception Constant **/
	public static final String SERVICE_RUNTIME_EXCEPTION_ERROR = "Some error is happened";
	public static final String THE_TOKEN_IS_INVALID_ERROR = "The Token is invalid";
	public static final String THE_TOKEN_IS_INCORRECT_FORMAT_ERROR = "The Token is incorrect format";
	public static final String THE_TOKEN_IS_BLANK_ERROR = "The Token is blank";
	public static final String THE_TOKEN_UNPERMISSION_ERROR = "The Token can not execute this operation";
	public static final String NO_RECORD_FOUND_KEY = "No record found";
	public static final String THE_TOKEN_IS_EXPIRED_ERROR = "The Token is expired";

	/** SECURE Constant **/
	public static final String OMS_JOB = "OMS_JOB";
	public static final String SYSADMIN_STR = "SYSADMIN";
	public static final String ACCESS_TOKEN_KEY = "access-token";
	
	public static final String PUBLIC_KEY = "public_key";
	public static final String ACCESS_TIME = "access-time";
	public static final String EXECUTION_TIME_KEY = "executionTime";
	public static final String TOKEN_EXPIRY_MINUTES = "Token_expiry_minutes";

	/** Other Constant **/
	public static final String REASON_VALUE = "Reason";
	public static final String TOTAL_VALUE = "Total";
	public static final String YES_VALUE = "YES";
	public static final String YES_KEY = "Y";
	public static final String NO_KEY = "N";
	public static final String NULL_KEY = "NULL";
	public static final String BLANK_KEY = "";
	public static final String SPACE_KEY = " ";
	public static final String EMPTY_KEY = "EMPTY";
	public static final String SUCCESS_KEY = "SUCCESS";

	public static final String ERROR_100_RESPONSE_KEY = "100";
	public static final String ERROR_KEY = "ERROR";
	public static final String COMMA = ",";
	public static final String OMSID = "ID";
	
	public static final int ZERO_INT = 0;
	public static final int FORMAT_FACTOR = 0;
	public static final int FORMAT_FACTOR_PERCENT = 9;
	public static final BigDecimal DEC_ZERO = new BigDecimal("0");
	public static final BigDecimal UNIT_ONE = new BigDecimal("1");
	public static final BigDecimal UNIT_HUNDRED = new BigDecimal("100");
	
	public static final int ROUND = -3;
	public static final int DIVIDE_SCALE = 24;
	public static final MathContext MC = new MathContext(APIConstant.DIVIDE_SCALE, RoundingMode.HALF_UP);
	
	/** Metadata Service Name Constant */
	public static final String SERVICENAME_ADMIN = "SYSTEM_ADMIN";
	
	/** Metadata Constant */
	public static final String _LOOKUP_CODE_KEY = "lookupCode";
	public static final String LOOKUP_CODE_OMS_USER_ROLE = "OMS_USER_ROLE";
	public static final String LOOKUP_CODE_OMS_USER_FEATURE = "OMS_USER_FEATURE";
	
	/** Metadata Key Constant */
	public static final String LOOKUP_CODE_OMS_USER_ROLE_ADMIN = "OMS_USER_ROLE_ADMIN";
	public static final String LOOKUP_CODE_OMS_USER_ROLE_DR = "OMS_USER_ROLE_DR";
	public static final String LOOKUP_CODE_OMS_USER_ROLE_RECON = "OMS_USER_ROLE_RECON";
	public static final String LOOKUP_CODE_OMS_USER_ROLE_CO = "OMS_USER_ROLE_CO";
	public static final String LOOKUP_CODE_OMS_USER_ROLE_CS = "OMS_USER_ROLE_CS";
	
	/** Metadata Value Constant */

	
	/** Common Constant */
	public static final String _BIZCODE_KEY = "biz_code";
	public static final String USER_STATUS_ACTIVE = "ACTIVE";
	public static final String USER_STATUS_DEACTIVE = "DE-ACTIVE";
	
}
