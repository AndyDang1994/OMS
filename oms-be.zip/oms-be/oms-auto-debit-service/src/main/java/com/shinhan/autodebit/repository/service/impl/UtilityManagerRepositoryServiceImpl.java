/**
 * 
 */
package com.shinhan.autodebit.repository.service.impl;

import java.util.List;

import javax.persistence.Query;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.autodebit.common.AbstractServiceClass;
import com.shinhan.autodebit.core.constant.APIConstant;
import com.shinhan.autodebit.core.exception.ServiceRuntimeException;
import com.shinhan.autodebit.repository.dao.TOmsCSTrackingDAO;
import com.shinhan.autodebit.repository.entity.TBankCommon;
import com.shinhan.autodebit.repository.entity.TMetadata;
import com.shinhan.autodebit.repository.entity.TOmsCSTracking;
import com.shinhan.autodebit.repository.service.UtilityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("utilityManagerRepositoryService")
public class UtilityManagerRepositoryServiceImpl extends AbstractServiceClass
		implements UtilityManagerRepositoryService {

	private TOmsCSTrackingDAO objectTrackingDao;

	@Autowired
	public UtilityManagerRepositoryServiceImpl(TOmsCSTrackingDAO objectTrackingDao) {
		this.objectTrackingDao = objectTrackingDao;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.autodebit.repository.service.UtilityManagerRepositoryService#
	 * getMetadataByLookupCode(java.lang.String)
	 */
	@Override
	public List<TMetadata> getMetadataByLookupCode(String lookupCode) throws ServiceRuntimeException {
		String sql = oracleOMSNamedQueries.get("getMetadataByLookupCode");
		Query query = entityManager.createNativeQuery(sql, TMetadata.class);
		
		query.setParameter("SERVICENAME", APIConstant.SERVICENAME_AUTODEBIT);
		query.setParameter("LOOKUPCODE", lookupCode);
		
		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();

		return list;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.UtilityManagerRepositoryService#getMetadataByLookupCodeAndId(java.lang.String, java.lang.String)
	 */
	@Override
	public TMetadata getMetadataByLookupCodeAndId(String lookupCode, String lookupId) throws ServiceRuntimeException {
		String sql = oracleOMSNamedQueries.get("getMetadataByLookupCodeAndId");

		Query query = entityManager.createNativeQuery(sql, TMetadata.class);
		query.setParameter("SERVICENAME", APIConstant.SERVICENAME_AUTODEBIT);
		query.setParameter("LOOKUPCODE", lookupCode);
		query.setParameter("LOOKUPCODEID", lookupId);

		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();
		if(CollectionUtils.isEmpty(list)) {
			throw new ServiceRuntimeException(String.format(env.getProperty("MSG_022"), lookupId));
		}
		
		return (TMetadata) list.get(0);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.UtilityManagerRepositoryService#getTrackingByTrackingId(java.lang.String)
	 */
	@Override
	public TOmsCSTracking getTrackingByTrackingId(String trackingNo) throws ServiceRuntimeException {
		if (StringUtils.isBlank(trackingNo)) {
			return null;
		}
		try {
			TOmsCSTracking item = objectTrackingDao.getItemByTrackingNo(trackingNo);
			return item;
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + trackingNo + "");
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.UtilityManagerRepositoryService#create(com.shinhan.autodebit.repository.entity.TOmsCSTracking)
	 */
	@Override
	public boolean create(TOmsCSTracking tracking) throws ServiceRuntimeException {
		try {
			if (tracking != null) {
				objectTrackingDao.save(tracking);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	
	}

	@Override
	public TBankCommon getBankCommonByBankCodeAndBizVal(String bankCode, String bizVal) throws ServiceRuntimeException {
		String sql = oracleOMSNamedQueries.get("getBankCommonByBankCodeAndBizVal");
		
		Query query = entityManager.createNativeQuery(sql, TBankCommon.class);
		query.setParameter("BANK_CODE", bankCode);
		query.setParameter("BIZ_VALUE", bizVal);
		
		TBankCommon bankCommon = (TBankCommon) query.getSingleResult();

		return bankCommon;
	}

}
