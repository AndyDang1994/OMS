/**
 * 
 */
package com.shinhan.autodebit.common;

import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.shinhan.autodebit.core.constant.APIConstant;
import com.shinhan.autodebit.core.exception.ServiceRuntimeException;
import com.shinhan.autodebit.core.model.AutoDebitRegisBankResultTrxInfo;
import com.shinhan.autodebit.core.model.AutoDebitRegisTrxInfo;
import com.shinhan.autodebit.core.model.AutoDebitTrxInfo;
import com.shinhan.autodebit.repository.entity.TMetadata;
import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsInf;
import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsMas;

/**
 * @author shds01
 *
 */
@Service("validationManagerService")
public class ValidationManagerService extends AbstractRepositoryClass{

	public TOmsAutoDebitLmsInf checkValidationImportRegisDA(AutoDebitRegisTrxInfo trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoanNo()) || StringUtils.isBlank(trx.getLocation()) 
				|| trx.getEffectiveDt() == null) {
			error = env.getProperty("MSG_001");
		}
		//Check format Date
//		if(StringUtils.isBlank(error)) {
//			if(DateUtils.compareDate(DateUtils.getCurrentDate(DateUtils.DATE_FORMAT), trx.getEffectiveDt())) {
//				error = String.format(env.getProperty("MSG_019")
//						, DateUtils.formatDate(trx.getEffectiveDt(), DateUtils.DATE_FORMAT)
//						, DateUtils.formatDate(DateUtils.getCurrentDate(DateUtils.DATE_FORMAT), DateUtils.DATE_FORMAT));
//			}
//		}
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsAutoDebitLmsMas mas = getRepositoryManagerService().getAdMasManagerRepositoryService().getByLoanNo(trx.getLoanNo());
			if(mas == null) {
				error = env.getProperty("MSG_005");
			} else if (APIConstant.DOC36_NO_VALUE.equalsIgnoreCase(mas.getDoc36())) {
				error = String.format(env.getProperty("MSG_008"), trx.getLoanNo());
			} else if((APIConstant.SACOMBANK_TEMPLATE_BANK_REGISTRATION.equalsIgnoreCase(mas.getBankName()) || APIConstant.BIDV_TEMPLATE_BANK_REGISTRATION.equalsIgnoreCase(mas.getBankName()))) {
				error = String.format(env.getProperty("MSG_012"), mas.getBankName());
			}
		}
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsAutoDebitLmsInf inf = getRepositoryManagerService().getAdInfManagerRepositoryService().getOneByLoanNo(trx.getLoanNo());
			if(inf != null && APIConstant.AUTO_DEBIT_STATUS_MAPPING_AD_SEND_SMS_DUE_DATE.equals(inf.getStatusCode()) == false) {
				error = env.getProperty("MSG_006");
			}
			trx.setErrorMessage(error);
			return inf;
		}

		trx.setErrorMessage(error);
		return null;
	}
	
	public void checkValidationUpdateBankResultSuccessByUpload(AutoDebitRegisBankResultTrxInfo trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoanNo()) || StringUtils.isBlank(trx.getResult())) {
			error = env.getProperty("MSG_001");
		}
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsAutoDebitLmsMas mas = getRepositoryManagerService().getAdMasManagerRepositoryService().getByLoanNo(trx.getLoanNo());
			if(mas == null) {
				error = env.getProperty("MSG_005");
			} else {
				String bankName = mas.getBankName();
				if(!(APIConstant.SACOMBANK_TEMPLATE_BANK_REGISTRATION.equalsIgnoreCase(bankName) || APIConstant.BIDV_TEMPLATE_BANK_REGISTRATION.equalsIgnoreCase(bankName))) {
					error = String.format(env.getProperty("MSG_012"), bankName);
				}
			}
		}
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsAutoDebitLmsInf inf = getRepositoryManagerService().getAdInfManagerRepositoryService().getOneByLoanNo(trx.getLoanNo());
			if(inf != null) {
				error = env.getProperty("MSG_006");
			}
		}
		trx.setErrorMessage(error);
	}
	
	public void checkValidationUpdateBankResultSuccess(AutoDebitTrxInfo trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoanNo())) {
			error = env.getProperty("MSG_001");
		}
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsAutoDebitLmsMas mas = getRepositoryManagerService().getAdMasManagerRepositoryService().getByLoanNo(trx.getLoanNo());
			if(mas == null) {
				error = env.getProperty("MSG_005");
			}
		}
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsAutoDebitLmsInf inf = getRepositoryManagerService().getAdInfManagerRepositoryService().getOneByLoanNo(trx.getLoanNo());
			if(inf != null) {
				error = env.getProperty("MSG_006");
			}
		}

		trx.setErrorMessage(error);
	}
	
	public TOmsAutoDebitLmsInf checkValidationImportHardCopy(AutoDebitTrxInfo trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoanNo()) ) {
			error = env.getProperty("MSG_001");
			trx.setErrorMessage(error);
			return null;
		}
		//Check in DB
		return getRepositoryManagerService().getAdInfManagerRepositoryService().getOneByLoanNoAndStatusCode(trx.getLoanNo(), APIConstant.AUTO_DEBIT_STATUS_MAPPING_BN_SEND_HARD_COPY);
		
	}
	
	public TOmsAutoDebitLmsInf checkValidationExportAutoDebitByBank(AutoDebitTrxInfo trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoanNo()) ) {
			error = env.getProperty("MSG_001");
			trx.setErrorMessage(error);
			return null;
		}
		//Check in DB
		return getRepositoryManagerService().getAdInfManagerRepositoryService().getOneByLoanNoAndStatusCode(trx.getLoanNo(), APIConstant.AUTO_DEBIT_STATUS_MAPPING_DR_RECEIVED_HARD_COPY);
		
	}
	
	public TOmsAutoDebitLmsInf checkValidationImportRegisBankResultDA(AutoDebitRegisBankResultTrxInfo trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoanNo()) || StringUtils.isBlank(trx.getResult())) {
			error = env.getProperty("MSG_001");
		}
		
		if(!StringUtils.isBlank(error)) {
			trx.setErrorMessage(error);
			return null;
		}
		//Check in DB
		TOmsAutoDebitLmsInf inf = getRepositoryManagerService().getAdInfManagerRepositoryService().getOneByLoanNoAndStatusCode(trx.getLoanNo(), APIConstant.AUTO_DEBIT_STATUS_MAPPING_WAITING_BANK_REGISTRATION);
		if(inf == null) {
			trx.setErrorMessage(env.getProperty("MSG_005"));
			return null;
		}
		//Populate Metadata
		Hashtable<String, TMetadata> hashResult = hashItembyName(getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant.LOOKUP_CODE_AD_IMPORT_BANK_RESULT));
		if(hashResult.get(APIConstant.AD_IMPORT_BANK_RESULT_SUCCESS).getValue().equalsIgnoreCase(trx.getResult())) {
			inf.setRegistrationResult(APIConstant.AD_IMPORT_BANK_RESULT_SUCCESS);
		} else {
			inf.setRegistrationResult(APIConstant.AD_IMPORT_BANK_RESULT_FAIL);
			if (StringUtils.isBlank(trx.getReason())) {
				inf.setReason(APIConstant.AD_IMPORT_BANK_RESULT_FAIL_TYPE_SEVEN);
			} else {
				List<TMetadata> listFail = getRepositoryManagerService().getUtilityManagerRepositoryService()
						.getMetadataByLookupCode(APIConstant.LOOKUP_CODE_AD_IMPORT_BANK_RESULT_FAIL);
				String reasonTrx = trx.getReason().trim();
				inf.setReason(APIConstant.AD_IMPORT_BANK_RESULT_FAIL_TYPE_SEVEN); //Set Default
				boolean isFound = false;
				for(TMetadata failItem : listFail) {
					List<TMetadata> listFailType = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(failItem.getLookupCodeId());
					for(TMetadata typeItem : listFailType) {
						if(reasonTrx.equalsIgnoreCase(typeItem.getValue().trim())) {
							inf.setReason(failItem.getLookupCodeId());
							isFound = true;
							break;
						}
					}
					if(isFound) {
						break;
					}
				}
				
			}
		}
		
		
		return inf;
	}
	
	public TOmsAutoDebitLmsInf checkValidationUpdateFailReasonADTransaction(AutoDebitTrxInfo trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoanNo()) || StringUtils.isBlank(trx.getReason())) {
			error = env.getProperty("MSG_001");
			trx.setErrorMessage(error);
			return null;
		}
		//Check in DB
		TOmsAutoDebitLmsInf inf = getRepositoryManagerService().getAdInfManagerRepositoryService().getOneByLoanNoAndStatusCode(trx.getLoanNo(), APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION);
		if(inf == null) {
			trx.setErrorMessage(env.getProperty("MSG_005"));
			return null;
		}
		
		if(getRepositoryManagerService().getUtilityManagerRepositoryService()
				.getMetadataByLookupCodeAndId(APIConstant.AD_IMPORT_BANK_RESULT_FAIL, trx.getReason()) != null) {
			//Populate Metadata
			inf.setReason(trx.getReason());
			return inf;
		}
		
		error = env.getProperty("MSG_001");
		trx.setErrorMessage(error);
		return null;
	}
	
	public void checkValidationSendSMSForUnRegisADTransaction(AutoDebitTrxInfo trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoanNo())) {
			error = env.getProperty("MSG_001");
			trx.setErrorMessage(error);
		}
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsAutoDebitLmsMas mas = getRepositoryManagerService().getAdMasManagerRepositoryService().getByLoanNo(trx.getLoanNo());
			if(mas == null) {
				error = env.getProperty("MSG_005");
				trx.setErrorMessage(error);
			}
		}
		
		if(StringUtils.isBlank(error)) {
			TOmsAutoDebitLmsInf inf = getRepositoryManagerService().getAdInfManagerRepositoryService().getOneByLoanNo(trx.getLoanNo());
			if(inf != null) {
				trx.setErrorMessage(env.getProperty("MSG_014"));
			}
		}
		
	}
	
	public TOmsAutoDebitLmsInf checkValidationSendSMSForRegisADTransaction(AutoDebitTrxInfo trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoanNo())) {
			error = env.getProperty("MSG_001");
			trx.setErrorMessage(error);
			return null;
		}
		//Check in DB
		TOmsAutoDebitLmsInf inf = getRepositoryManagerService().getAdInfManagerRepositoryService().getOneByLoanNo(trx.getLoanNo());
		if(inf == null) {
			trx.setErrorMessage(env.getProperty("MSG_005"));
			return null;
		} else {
			//Check send already or not
			if(APIConstant.AUTO_DEBIT_STATUS_MAPPING_AD_SEND_SMS_DUE_DATE.equalsIgnoreCase(inf.getStatusCode()) || inf.getSmsDueDt() != null) {
				trx.setErrorMessage(String.format(env.getProperty("MSG_015"), trx.getLoanNo()));
				return null;
			}
		}
		
		return inf;
		
	}
	
	public TOmsAutoDebitLmsInf checkValidationSendSMSForBankRegisFailADTransactionn(AutoDebitTrxInfo trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoanNo())) {
			error = env.getProperty("MSG_001");
			trx.setErrorMessage(error);
			return null;
		}
		//Check in DB
		TOmsAutoDebitLmsInf inf = getRepositoryManagerService().getAdInfManagerRepositoryService().getOneByLoanNoAndStatusCode(trx.getLoanNo(), APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION);
		if(inf == null) {
			trx.setErrorMessage(env.getProperty("MSG_005"));
			return null;
		}else {
			//Check send already or not
			if(inf.getSmsADDt() != null) {
				trx.setErrorMessage(String.format(env.getProperty("MSG_015"), trx.getLoanNo()));
				return null;
			}
		}
		
		return inf;
		
	}
}
