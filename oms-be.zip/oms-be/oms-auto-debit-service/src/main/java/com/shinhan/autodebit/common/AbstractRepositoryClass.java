/**
 * 
 */
package com.shinhan.autodebit.common;

import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;

import com.shinhan.autodebit.core.constant.APIConstant;
import com.shinhan.autodebit.core.exception.ServiceRuntimeException;
import com.shinhan.autodebit.core.util.DateUtils;
import com.shinhan.autodebit.repository.entity.TMetadata;


/**
 * @author shds01
 *
 */

public abstract class AbstractRepositoryClass {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	public Environment env;

	@PersistenceContext(unitName = "entityManagerOMS")
	public EntityManager entityManager;

	@Autowired
	private RepositoryManagerService repositoryManagerService;

	@Autowired
	public OracleOMSNamedQueries oracleOMSNamedQueries;

	/**
	 * @return the repositoryManagerService
	 */
	public RepositoryManagerService getRepositoryManagerService() {
		return repositoryManagerService;
	}

	/**
	 * @param repositoryManagerService the repositoryManagerService to set
	 */
	public void setRepositoryManagerService(
			@Qualifier("repositoryManagerService") RepositoryManagerService repositoryManagerService) {
		this.repositoryManagerService = repositoryManagerService;
	}
	
	public static Hashtable<String, TMetadata> hashItembyName(List<TMetadata> items) {
		Hashtable<String, TMetadata> ht = new Hashtable<String, TMetadata>();
		if (items != null && items.size() >= 0) {
			for (TMetadata item : items) {
				ht.put(item.getLookupCodeId(), item);
			}
		}
		return ht;
	}
	
	public Date getFirstDueDatePeriodByDate(String inputDt) throws ServiceRuntimeException {
		Date date = DateUtils.convertDate(inputDt, DateUtils.DATEFORMAT);
		int day = DateUtils.getTheDayOfDate(date);
		List<TMetadata> lst = repositoryManagerService.getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant.LOOKUP_CODE_AD_FIRST_DUE_DT_PERIOD);
		if(CollectionUtils.isEmpty(lst) || day == 0) {
			return null;
		}
		String periodType = APIConstant.AD_FIRST_DUE_DT_PERIOD_FOUR;
		for(TMetadata item : lst) {
			String valueItem = item.getValue();
			if(StringUtils.contains(valueItem, APIConstant.COMMA)) {
				String[] values = StringUtils.split(valueItem, APIConstant.COMMA);
				int from = Integer.valueOf(values[0]);
				int to = Integer.valueOf(values[1]);
				if(day >= from && day <= to) {
					periodType = item.getLookupCodeId();
					break;
				}
			}
		}
		TMetadata dayPeriodMeta = repositoryManagerService.getUtilityManagerRepositoryService().getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_AD_FIRST_DUE_DT_PERIOD_DAY, periodType);
		String dayPeriodStr = dayPeriodMeta.getValue();
		return DateUtils.changeDayOfDate(date, Integer.valueOf(dayPeriodStr));
	}

}
