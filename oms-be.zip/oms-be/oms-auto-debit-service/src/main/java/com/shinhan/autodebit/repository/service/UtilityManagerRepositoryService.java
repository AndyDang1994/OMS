/**
 * 
 */
package com.shinhan.autodebit.repository.service;

import java.util.List;

import com.shinhan.autodebit.core.exception.ServiceRuntimeException;
import com.shinhan.autodebit.repository.entity.TBankCommon;
import com.shinhan.autodebit.repository.entity.TMetadata;
import com.shinhan.autodebit.repository.entity.TOmsCSTracking;

/**
 * @author shds01
 *
 */
public interface UtilityManagerRepositoryService {
	
	public List<TMetadata> getMetadataByLookupCode(String lookupCode) throws ServiceRuntimeException;
	
	public TMetadata getMetadataByLookupCodeAndId(String lookupCode, String lookupId) throws ServiceRuntimeException;
	
	public TOmsCSTracking getTrackingByTrackingId(String trackingNo) throws ServiceRuntimeException;
	
	public boolean create(TOmsCSTracking tracking) throws ServiceRuntimeException;
	
	public TBankCommon getBankCommonByBankCodeAndBizVal(String bankName, String bizVal) throws ServiceRuntimeException;
}
