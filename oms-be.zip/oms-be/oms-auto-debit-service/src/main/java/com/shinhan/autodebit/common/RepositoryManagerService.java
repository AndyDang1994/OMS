/**
 * 
 */
package com.shinhan.autodebit.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.autodebit.core.constant.APIConstant;
import com.shinhan.autodebit.core.exception.ServiceRuntimeException;
import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsInf;
import com.shinhan.autodebit.repository.entity.TOmsCSTracking;
import com.shinhan.autodebit.repository.service.ADInfManagerRepositoryService;
import com.shinhan.autodebit.repository.service.ADMasManagerRepositoryService;
import com.shinhan.autodebit.repository.service.UtilityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("repositoryManagerService")
public class RepositoryManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private ADInfManagerRepositoryService adInfManagerRepositoryService;
	
	@Autowired
	private ADMasManagerRepositoryService adMasManagerRepositoryService;
	
	@Autowired
	private UtilityManagerRepositoryService utilityManagerRepositoryService;

	/**
	 * @return the adInfManagerRepositoryService
	 */
	public ADInfManagerRepositoryService getAdInfManagerRepositoryService() {
		return adInfManagerRepositoryService;
	}

	/**
	 * @param adInfManagerRepositoryService the adInfManagerRepositoryService to set
	 */
	public void setAdInfManagerRepositoryService(@Qualifier("adInfManagerRepositoryService") ADInfManagerRepositoryService adInfManagerRepositoryService) {
		this.adInfManagerRepositoryService = adInfManagerRepositoryService;
	}

	/**
	 * @return the adMasManagerRepositoryService
	 */
	public ADMasManagerRepositoryService getAdMasManagerRepositoryService() {
		return adMasManagerRepositoryService;
	}

	/**
	 * @param adMasManagerRepositoryService the adMasManagerRepositoryService to set
	 */
	public void setAdMasManagerRepositoryService(@Qualifier("adMasManagerRepositoryService") ADMasManagerRepositoryService adMasManagerRepositoryService) {
		this.adMasManagerRepositoryService = adMasManagerRepositoryService;
	}

	/**
	 * @return the utilityManagerRepositoryService
	 */
	public UtilityManagerRepositoryService getUtilityManagerRepositoryService() {
		return utilityManagerRepositoryService;
	}

	/**
	 * @param utilityManagerRepositoryService the utilityManagerRepositoryService to set
	 */
	public void setUtilityManagerRepositoryService(
			@Qualifier("utilityManagerRepositoryService") UtilityManagerRepositoryService utilityManagerRepositoryService) {
		this.utilityManagerRepositoryService = utilityManagerRepositoryService;
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void importAutoDebitTrxToDB(ArrayList<TOmsAutoDebitLmsInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getAdInfManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void importAutoDebitHardCopyToDB(List<TOmsAutoDebitLmsInf> listUp) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listUp);
		getAdInfManagerRepositoryService().updateAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void importAutoDebitBankResultToDB(ArrayList<TOmsAutoDebitLmsInf> listUp) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listUp);
		getAdInfManagerRepositoryService().updateAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void updateAutoDebitFailReasonToDB(ArrayList<TOmsAutoDebitLmsInf> listUp) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listUp);
		getAdInfManagerRepositoryService().updateAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void sendSmsForUnRegisADTrxToDB(ArrayList<TOmsAutoDebitLmsInf> listReg) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listReg);
		getAdInfManagerRepositoryService().createAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void sendSmsForRegisADTrxToDB(ArrayList<TOmsAutoDebitLmsInf> listUp) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listUp);
		getAdInfManagerRepositoryService().updateAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void sendSmsForBankRegisFailADTrxToDB(ArrayList<TOmsAutoDebitLmsInf> listUp) throws ServiceRuntimeException{
		Map<String, Object> inputs = new HashMap<>();
		inputs.put(APIConstant.DOCUMENT, listUp);
		getAdInfManagerRepositoryService().updateAll(inputs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void sendSmsForProcessingFirstDueDateADTrxToDB(TOmsAutoDebitLmsInf infUp, TOmsCSTracking tracking) throws ServiceRuntimeException{
		getAdInfManagerRepositoryService().update(infUp);
		getUtilityManagerRepositoryService().create(tracking);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void sendSmsForProcessingBankRegisFailADTrxToDB(TOmsAutoDebitLmsInf infUp, TOmsCSTracking tracking) throws ServiceRuntimeException{
		getAdInfManagerRepositoryService().update(infUp);
		getUtilityManagerRepositoryService().create(tracking);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void sendSmsForCompleteADTrxToDB(TOmsAutoDebitLmsInf infUp) throws ServiceRuntimeException{
		getAdInfManagerRepositoryService().update(infUp);
	}
	
}
