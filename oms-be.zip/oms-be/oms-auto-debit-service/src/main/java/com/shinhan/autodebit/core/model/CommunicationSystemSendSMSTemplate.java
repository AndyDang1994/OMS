/**
 * 
 */
package com.shinhan.autodebit.core.model;

/**
 * @author shds01
 *
 */
public class CommunicationSystemSendSMSTemplate {

	private String phone;
	private String template_name;
	private String source;
	private String callback_url;
	private String channel_code;
	private CommunicationSystemSendSMSTemplateData template_data;

	/**
	 * 
	 */
	public CommunicationSystemSendSMSTemplate() {
		super();
	}

	/**
	 * @param phone
	 * @param template_name
	 * @param source
	 * @param callback_url
	 * @param channel_code
	 */
	public CommunicationSystemSendSMSTemplate(String phone, String template_name, String source, String callback_url,
			String channel_code) {
		super();
		this.phone = phone;
		this.template_name = template_name;
		this.source = source;
		this.callback_url = callback_url;
		this.channel_code = channel_code;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * @return the template_name
	 */
	public String getTemplate_name() {
		return template_name;
	}

	/**
	 * @param template_name the template_name to set
	 */
	public void setTemplate_name(String template_name) {
		this.template_name = template_name;
	}

	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}

	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		this.source = source;
	}

	/**
	 * @return the callback_url
	 */
	public String getCallback_url() {
		return callback_url;
	}

	/**
	 * @param callback_url the callback_url to set
	 */
	public void setCallback_url(String callback_url) {
		this.callback_url = callback_url;
	}

	/**
	 * @return the channel_code
	 */
	public String getChannel_code() {
		return channel_code;
	}

	/**
	 * @param channel_code the channel_code to set
	 */
	public void setChannel_code(String channel_code) {
		this.channel_code = channel_code;
	}

	/**
	 * @return the template_data
	 */
	public CommunicationSystemSendSMSTemplateData getTemplate_data() {
		return template_data;
	}

	/**
	 * @param template_data the template_data to set
	 */
	public void setTemplate_data(CommunicationSystemSendSMSTemplateData template_data) {
		this.template_data = template_data;
	}

}
