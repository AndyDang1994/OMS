/**
 * 
 */
package com.shinhan.autodebit.core.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;

import com.shinhan.autodebit.core.constant.APIConstant;
import com.shinhan.autodebit.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.autodebit.core.exception.ServiceRuntimeException;
import com.shinhan.autodebit.core.model.AutoDebitRegisBankResultTrxInfo;
import com.shinhan.autodebit.core.model.AutoDebitRegisTrxInfo;
import com.shinhan.autodebit.core.model.AutoDebitTrxInfo;
import com.shinhan.autodebit.core.model.BankTemplateFormat;
import com.shinhan.autodebit.core.model.CommunicationSystemReponseSendSMS;
import com.shinhan.autodebit.core.model.CommunicationSystemSendSMSTemplate;
import com.shinhan.autodebit.core.model.CommunicationSystemSendSMSTemplateData;
import com.shinhan.autodebit.repository.entity.TBankCommon;
import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsInf;
import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsMas;
import com.shinhan.autodebit.repository.entity.TOmsCSTracking;

/**
 * @author shds01
 *
 */
public class DTOConverter {

	public static List<?> convertSettoList(Set<?> sets) throws ServiceRuntimeException {
		List<?> list = new ArrayList<>(sets);
		return list;
	}

	public static AutoDebitRegisTrxInfo convertToAutoDebitRegisTrxInfoFromImportRegisAD(Map mapObject, Environment env) throws ServiceInvalidAgurmentException{
		AutoDebitRegisTrxInfo item = new AutoDebitRegisTrxInfo();
		
		item.setLoanNo(
				mapObject.get(env.getProperty("import.autodebit.regis.loanNo")) != null ? 
						mapObject.get(env.getProperty("import.autodebit.regis.loanNo")).toString() : 
							APIConstant.BLANK_KEY);
		
		if(mapObject.get(env.getProperty("import.autodebit.regis.effectiveDt")) == null) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_001"));
		} else if (DateUtils.isValidate(mapObject.get(env.getProperty("import.autodebit.regis.effectiveDt")).toString())) {
			item.setEffectiveDt(DateUtils.converToDate(mapObject.get(env.getProperty("import.autodebit.regis.effectiveDt")).toString()));
		} else {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_023"), mapObject.get(env.getProperty("import.autodebit.regis.effectiveDt")).toString()));
		}
		
		item.setLocation(
				mapObject.get(env.getProperty("import.autodebit.regis.location")) != null ? 
						mapObject.get(env.getProperty("import.autodebit.regis.location")).toString() : 
							APIConstant.BLANK_KEY);
		
		return item;
	}
	
	public static AutoDebitRegisBankResultTrxInfo convertToAutoDebitRegisBankResultTrxInfoFromImportRegisBankResultAD(Map mapObject, Environment env) throws ServiceRuntimeException{
		AutoDebitRegisBankResultTrxInfo item = new AutoDebitRegisBankResultTrxInfo();
		
		item.setLoanNo(
				mapObject.get(env.getProperty("import.autodebit.regis.bankresult.loanNo")) != null ? 
						mapObject.get(env.getProperty("import.autodebit.regis.bankresult.loanNo")).toString() : 
							APIConstant.BLANK_KEY);
		item.setResult(
				mapObject.get(env.getProperty("import.autodebit.regis.bankresult.result")) != null ? 
						mapObject.get(env.getProperty("import.autodebit.regis.bankresult.result")).toString() : 
							APIConstant.BLANK_KEY);
		item.setReason(
				mapObject.get(env.getProperty("import.autodebit.regis.bankresult.reason")) != null ? 
						mapObject.get(env.getProperty("import.autodebit.regis.bankresult.reason")).toString().trim() : 
							APIConstant.BLANK_KEY);
		
		return item;
	}
	
	public static TOmsAutoDebitLmsInf populateDataFromAutoDebitRegisTrxInfoToTOmsAutoDebitLmsInfNew(AutoDebitRegisTrxInfo trx, String userName) {
		TOmsAutoDebitLmsInf inf = new TOmsAutoDebitLmsInf();
		
		inf.setLoanNo(trx.getLoanNo());
		inf.setSendDt(trx.getEffectiveDt());
		inf.setSendUser(userName);
		inf.setSignedLocation(trx.getLocation());
		inf.setStatusCode(APIConstant.AUTO_DEBIT_STATUS_MAPPING_BN_SEND_HARD_COPY);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsAutoDebitLmsInf populateDataFromAutoDebitRegisTrxInfoToTOmsAutoDebitLmsInfUpdate(AutoDebitRegisTrxInfo trx, TOmsAutoDebitLmsInf inf, String userName) {
		
		inf.setSendDt(trx.getEffectiveDt());
		inf.setSendUser(userName);
		inf.setSignedLocation(trx.getLocation());
		inf.setStatusCode(APIConstant.AUTO_DEBIT_STATUS_MAPPING_BN_SEND_HARD_COPY);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsAutoDebitLmsInf populateDataUpdateBankResultSuccessByUpload(String loanNo, String userName) {
		TOmsAutoDebitLmsInf inf = new TOmsAutoDebitLmsInf();
		
		inf.setLoanNo(loanNo);
		inf.setBankResultDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setStatusCode(APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION);
		inf.setRegistrationResult(APIConstant.AD_IMPORT_BANK_RESULT_SUCCESS);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsAutoDebitLmsInf populateDataUpdateBankResultSuccess(AutoDebitTrxInfo trx, String userName) {
		TOmsAutoDebitLmsInf inf = new TOmsAutoDebitLmsInf();
		
		inf.setLoanNo(trx.getLoanNo());
		inf.setBankResultDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setStatusCode(APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION);
		inf.setRegistrationResult(APIConstant.AD_IMPORT_BANK_RESULT_SUCCESS);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsAutoDebitLmsInf populateDataImportHardCopy(TOmsAutoDebitLmsInf inf, String userName) {
		inf.setReceiveDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setReceiveUser(userName);
		inf.setStatusCode(APIConstant.AUTO_DEBIT_STATUS_MAPPING_DR_RECEIVED_HARD_COPY);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		return inf;
	}
	
	public static TOmsAutoDebitLmsInf populateDataExportAutoDebitByBank(TOmsAutoDebitLmsInf inf, String userName) {
		inf.setSendBankDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setStatusCode(APIConstant.AUTO_DEBIT_STATUS_MAPPING_WAITING_BANK_REGISTRATION);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		return inf;
	}
	
	public static TOmsAutoDebitLmsInf populateDataImportBankResult(TOmsAutoDebitLmsInf inf, String userName) {
		inf.setBankResultDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setStatusCode(APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		return inf;
	}
	
	public static TOmsAutoDebitLmsInf populateDataUpdateFailReason(TOmsAutoDebitLmsInf inf, String userName) {
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		return inf;
	}
	
	public static TOmsAutoDebitLmsInf populateDataForProcessingSmsUnRegisTrx(AutoDebitTrxInfo trx, String userName) {
		TOmsAutoDebitLmsInf inf = new TOmsAutoDebitLmsInf();
		
		inf.setLoanNo(trx.getLoanNo());
		inf.setStatusCode(APIConstant.AUTO_DEBIT_STATUS_MAPPING_AD_SEND_SMS_DUE_DATE);
		//inf.setSmsDueDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setSmsDueDtStatus(APIConstant.AD_SEND_SMS_STATUS_PROCESSING);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsAutoDebitLmsInf populateDataForProcessingSmsRegisTrx(TOmsAutoDebitLmsInf inf, String userName) {
		inf.setSmsDueDtStatus(APIConstant.AD_SEND_SMS_STATUS_PROCESSING);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsAutoDebitLmsInf populateDataForSendingSmsRegisTrx(TOmsAutoDebitLmsInf inf, String userName) {
		inf.setSmsDueDtStatus(APIConstant.AD_SEND_SMS_STATUS_SENDING);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsAutoDebitLmsInf populateDataForCompleteSmsRegisTrx(TOmsAutoDebitLmsInf inf, String userName) {
		inf.setSmsDueDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setSmsDueDtStatus(APIConstant.AD_SEND_SMS_STATUS_DONE);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsCSTracking populateDataForSendingSmsRegisTrxTracking(CommunicationSystemReponseSendSMS response, String loanNo) {
		TOmsCSTracking tracking = new TOmsCSTracking();
		
		tracking.setLoanNo(loanNo);
		tracking.setTrackingNo(response.getData().getTracking_id());
		tracking.setTrackingType(APIConstant.FAIL_AUTO_DEBIT_FIRST_DUE);
		if(StringUtils.isBlank(tracking.getTrackingNo())) {
			return null;
		}
		return tracking;
	}
	
	public static TOmsAutoDebitLmsInf populateDataForProcessingSmsBankRegisFailTrx(TOmsAutoDebitLmsInf inf, String userName) {
		inf.setSmsADDtStatus(APIConstant.AD_SEND_SMS_STATUS_PROCESSING);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		return inf;
	}
	
	public static TOmsAutoDebitLmsInf populateDataForSendingSmsBankRegisFailTrx(TOmsAutoDebitLmsInf inf, String userName) {
		inf.setSmsADDtStatus(APIConstant.AD_SEND_SMS_STATUS_SENDING);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		return inf;
	}
	
	public static TOmsAutoDebitLmsInf populateDataForCompleteSmsBankRegisFailTrx(TOmsAutoDebitLmsInf inf, String userName) {
		inf.setSmsADDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setSmsADDtStatus(APIConstant.AD_SEND_SMS_STATUS_DONE);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.ddMMyyyy_HH_mm_ss));
		inf.setUpdatedUser(userName);
		return inf;
	}
	
	public static TOmsCSTracking populateDataForSendingSmsBankRegisFailTrxTracking(CommunicationSystemReponseSendSMS response, String loanNo) {
		TOmsCSTracking tracking = new TOmsCSTracking();
		
		tracking.setLoanNo(loanNo);
		tracking.setTrackingNo(response.getData().getTracking_id());
		tracking.setTrackingType(APIConstant.FAIL_AUTO_DEBIT_BANK);
		if(StringUtils.isBlank(tracking.getTrackingNo())) {
			return null;
		}
		return tracking;
	}
	
	public static List<Object[]> transferDataToFillHeaderForReport(List<TOmsAutoDebitLmsMas> masLst, String bankName){
		List<Object[]> datas = new ArrayList<>();
		int count = 1;
		for(TOmsAutoDebitLmsMas mas : masLst) {
			switch (bankName) {
			case APIConstant.ACB_TEMPLATE_BANK_REGISTRATION:
				Object[] objectBankACB = {count, mas.getLoanNo(), mas.getCustomerName(), mas.getCustomerBankAccount()};
				datas.add(objectBankACB);
				break;
			case APIConstant.AGRIBANK_TEMPLATE_BANK_REGISTRATION:
				Object[] objectBankAri = {count, mas.getLoanNo(), mas.getCustomerName(), mas.getCustomerBankAccount()};
				datas.add(objectBankAri);
				break;
			case APIConstant.SACOMBANK_TEMPLATE_BANK_REGISTRATION:
				Object[] objectBankSacom = {count, mas.getLoanNo(), mas.getCustomerName(), mas.getCustomerBankAccount()};
				datas.add(objectBankSacom);
				break;
			case APIConstant.TECHCOMBANK_TEMPLATE_BANK_REGISTRATION:
				Object[] objectBankTech = {count, mas.getCustomerIdNo(), mas.getCustomerName(), mas.getCustomerBankAccount(), mas.getLoanNo(), mas.getAuthorizeDt()};
				datas.add(objectBankTech);
				break;
			case APIConstant.VCB_TEMPLATE_BANK_REGISTRATION:
				Object[] objectBankVCB = {count, mas.getCustomerName(), mas.getCustomerIdNo(), mas.getCustomerIssuedDt(), mas.getCustomerBankAccount() , mas.getLoanNo(), ""};
				datas.add(objectBankVCB);
				break;
			case APIConstant.VIETTINBANK_TEMPLATE_BANK_REGISTRATION:
				Object[] objectBankViettin = {count, mas.getLoanNo(), mas.getCustomerName(), mas.getCustomerBankAccount()};
				datas.add(objectBankViettin);
				break;
			default:
				return null;
			}
			
			count++;
		}
		return datas;
	}
	
	public static List<Object[]> replaceNullValueToNumber(List<Object[]> datas) throws ServiceRuntimeException{
		List<Object[]> rs = new ArrayList<>();
		for(Object[] data : datas) {
			Object[] dataDummy = new Object[data.length];
			for(int i = 0; i < data.length; i++) {
				dataDummy[i] = data[i] == null || StringUtils.isEmpty(String.valueOf(data[i])) ? APIConstant.DEC_ZERO : data[i];
			}
			rs.add(dataDummy);
		}
		return rs;
	}
	
	public static List<Object[]> replaceNullValueToString(List<Object[]> datas) throws ServiceRuntimeException{
		List<Object[]> rs = new ArrayList<>();
		for(Object[] data : datas) {
			Object[] dataDummy = new Object[data.length];
			for(int i = 0; i < data.length; i++) {
				dataDummy[i] = data[i] == null || StringUtils.isEmpty(String.valueOf(data[i])) ? APIConstant.SPACE_KEY : data[i];
			}
			rs.add(dataDummy);
		}
		return rs;
	}
	
	
	public static List<Object[]> convertDataForExportTATReport(List<Object[]> datas) throws ServiceRuntimeException{
		List<Object[]> rs = new ArrayList<>();
		for(Object[] data : datas) {
			BigDecimal cnt = new BigDecimal(String.valueOf(data[0]));
			BigDecimal dayDiff = new BigDecimal(String.valueOf(data[1]));
			BigDecimal raito;
			if(APIConstant.DEC_ZERO.equals(dayDiff) || APIConstant.DEC_ZERO.equals(cnt)) {
				raito = APIConstant.DEC_ZERO;
			} else {
				raito = dayDiff.divide(cnt, APIConstant.MC);
			}
			Object[] objectRS = {CommonUtil.writeDecimal(raito.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT), data[0]};
			rs.add(objectRS);
		}
		return rs;
	}
	
	public static List<Object[]> convertDataForExportBankTrxReport(List<Object[]> datas) throws ServiceRuntimeException{
		List<Object[]> rs = new ArrayList<>();
		BigDecimal totalBankTrx = APIConstant.DEC_ZERO;
		BigDecimal totalBankRegisTrx = APIConstant.DEC_ZERO;
		BigDecimal totalGrandBankRegisTrxPer = APIConstant.DEC_ZERO;
		
		//Calculate the total trx
		for(Object[] data : datas) {
			BigDecimal bankCnt = new BigDecimal(String.valueOf(data[1]));
			BigDecimal bankRegisCnt = new BigDecimal(String.valueOf(data[2]));
			if(bankCnt != null && bankCnt.compareTo(APIConstant.DEC_ZERO) != 0) {
				totalBankTrx = totalBankTrx.add(bankCnt);
			}
			if(bankRegisCnt != null && bankRegisCnt.compareTo(APIConstant.DEC_ZERO) != 0) {
				totalBankRegisTrx = totalBankRegisTrx.add(bankRegisCnt);
			}
		}
		//Convert data for report
		for(Object[] data : datas) {
			String bankName = String.valueOf(data[0]);
			BigDecimal bankCnt = new BigDecimal(String.valueOf(data[1]));
			BigDecimal bankRegisCnt = new BigDecimal(String.valueOf(data[2]));
			BigDecimal raitoBankCnt = APIConstant.DEC_ZERO;
			BigDecimal raitoBankRegisCnt = APIConstant.DEC_ZERO;
			
			if(APIConstant.DEC_ZERO.equals(bankCnt) || APIConstant.DEC_ZERO.equals(totalBankTrx)) {
				raitoBankCnt = APIConstant.DEC_ZERO;
			} else {
				raitoBankCnt = bankCnt.divide(totalBankTrx, APIConstant.MC);
			}
			
			if(APIConstant.DEC_ZERO.equals(bankRegisCnt) || APIConstant.DEC_ZERO.equals(totalBankRegisTrx)) {
				raitoBankRegisCnt = APIConstant.DEC_ZERO;
			} else {
				raitoBankRegisCnt = bankRegisCnt.divide(totalBankRegisTrx, APIConstant.MC);
			}
			
			Object[] objectRS = {bankName
								, bankCnt, 
								CommonUtil.forPercentages(raitoBankCnt.doubleValue(), new Locale("en", "US"))
								, bankRegisCnt,
								CommonUtil.forPercentages(raitoBankRegisCnt.doubleValue(), new Locale("en", "US"))};
			rs.add(objectRS);
		}
		//Set total Trx
		if(APIConstant.DEC_ZERO.equals(totalBankTrx) || APIConstant.DEC_ZERO.equals(totalBankRegisTrx)) {
			totalGrandBankRegisTrxPer = APIConstant.DEC_ZERO;
		} else {
			totalGrandBankRegisTrxPer = totalBankRegisTrx.divide(totalBankTrx, APIConstant.MC);
		}
		Object[] objectTotal = {APIConstant.TOTAL_VALUE
				, totalBankTrx, 
				CommonUtil.forPercentages(APIConstant.UNIT_ONE.doubleValue(), new Locale("en", "US"))
				, totalBankRegisTrx,
				CommonUtil.forPercentages(totalGrandBankRegisTrxPer.doubleValue(), new Locale("en", "US"))};
		
		rs.add(objectTotal);
		return rs;
	}
	
	public static List<Object[]> convertDataForExportTATBankTrxReport(List<Object[]> dataTATLst, List<Object[]> dataBankTrxLst) throws ServiceRuntimeException{
		List<Object[]> rs = new ArrayList<>();
		BigDecimal totalBankTrx = APIConstant.DEC_ZERO;
		BigDecimal totalBankRegisSuccessTrx = APIConstant.DEC_ZERO;
		BigDecimal totalBankRegisFailTrx = APIConstant.DEC_ZERO;

		BigDecimal raitoTotalBankSuccessCnt = APIConstant.DEC_ZERO;
		BigDecimal raitoTotalBankFailCnt = APIConstant.DEC_ZERO;
		
		//Calculate the total Bank trx
		for(Object[] data : dataBankTrxLst) {
			BigDecimal bankCnt = new BigDecimal(String.valueOf(data[1]));
			BigDecimal bankRegisSuccessCnt = new BigDecimal(String.valueOf(data[2]));
			BigDecimal bankRegisFailCnt = new BigDecimal(String.valueOf(data[3]));
			if(bankCnt != null && bankCnt.compareTo(APIConstant.DEC_ZERO) != 0) {
				totalBankTrx = totalBankTrx.add(bankCnt);
			}
			if(bankRegisSuccessCnt != null && bankRegisSuccessCnt.compareTo(APIConstant.DEC_ZERO) != 0) {
				totalBankRegisSuccessTrx = totalBankRegisSuccessTrx.add(bankRegisSuccessCnt);
			}
			if(bankRegisFailCnt != null && bankRegisFailCnt.compareTo(APIConstant.DEC_ZERO) != 0) {
				totalBankRegisFailTrx = totalBankRegisFailTrx.add(bankRegisFailCnt);
			}
		}
		
		//Convert data for report
		for(Object[] data : dataBankTrxLst) {
			String bankName = String.valueOf(data[0]);
			boolean bankNameIsFound = false;
			BigDecimal bankCnt = new BigDecimal(String.valueOf(data[1]));
			BigDecimal bankRegisSuccessCnt = new BigDecimal(String.valueOf(data[2]));
			BigDecimal bankRegisFailCnt = new BigDecimal(String.valueOf(data[3]));
			BigDecimal cntTAT = APIConstant.DEC_ZERO;
			BigDecimal dayDiffTAT = APIConstant.DEC_ZERO;
			
			BigDecimal raitoTAT = APIConstant.DEC_ZERO;
			BigDecimal raitoBankCnt = APIConstant.DEC_ZERO;
			BigDecimal raitoBankSuccessCnt = APIConstant.DEC_ZERO;
			BigDecimal raitoBankFailCnt = APIConstant.DEC_ZERO;
			
			if(APIConstant.DEC_ZERO.equals(bankCnt) || APIConstant.DEC_ZERO.equals(totalBankTrx)) {
				raitoBankCnt = APIConstant.DEC_ZERO;
			} else {
				raitoBankCnt = bankCnt.divide(totalBankTrx, APIConstant.MC);
			}
			
			if(APIConstant.DEC_ZERO.equals(bankRegisSuccessCnt) || APIConstant.DEC_ZERO.equals(totalBankRegisSuccessTrx)) {
				raitoBankSuccessCnt = APIConstant.DEC_ZERO;
			} else {
				raitoBankSuccessCnt = bankRegisSuccessCnt.divide(totalBankRegisSuccessTrx, APIConstant.MC);
			}
			
			if(APIConstant.DEC_ZERO.equals(bankRegisFailCnt) || APIConstant.DEC_ZERO.equals(totalBankRegisFailTrx)) {
				raitoBankFailCnt = APIConstant.DEC_ZERO;
			} else {
				raitoBankFailCnt = bankRegisFailCnt.divide(totalBankRegisFailTrx, APIConstant.MC);
			}
			
			if(CollectionUtils.isNotEmpty(dataTATLst)) {
				for(Object[] tat : dataTATLst) {
					if(String.valueOf(tat[0]).equals(String.valueOf(data[0]))) {
						String bankNameTAT = String.valueOf(data[0]);
						if(StringUtils.isNotEmpty(bankName) && bankName.equalsIgnoreCase(bankNameTAT)) {
							bankNameIsFound = true;
							cntTAT = new BigDecimal(String.valueOf(tat[1]));
							dayDiffTAT = new BigDecimal(String.valueOf(tat[2]));
							break;
						}
					}
				}
			}
			if(!bankNameIsFound || bankName.equals(APIConstant.BIDV_TEMPLATE_BANK_REGISTRATION) || bankName.equals(APIConstant.SACOMBANK_TEMPLATE_BANK_REGISTRATION)) {
				raitoTAT = APIConstant.DEC_ZERO;
			}else {
				if(bankName != null) {
					if(APIConstant.DEC_ZERO.equals(cntTAT) || APIConstant.DEC_ZERO.equals(dayDiffTAT)) {
						raitoTAT = APIConstant.DEC_ZERO;
					} else {
						raitoTAT = dayDiffTAT.divide(cntTAT, APIConstant.MC);
					}
				}
			}
			
			Object[] objectRS = {bankName, CommonUtil.writeDecimal(raitoTAT.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT)
					, bankCnt, 
					CommonUtil.forPercentages(raitoBankCnt.doubleValue(), new Locale("en", "US"))
					, bankRegisSuccessCnt,
					CommonUtil.forPercentages(raitoBankSuccessCnt.doubleValue(), new Locale("en", "US"))
					, bankRegisFailCnt,
					CommonUtil.forPercentages(raitoBankFailCnt.doubleValue(), new Locale("en", "US"))
					};
			rs.add(objectRS);
			
		}
		//Set total Trx
		if(APIConstant.DEC_ZERO.equals(totalBankTrx) || APIConstant.DEC_ZERO.equals(totalBankRegisSuccessTrx)) {
			raitoTotalBankSuccessCnt = APIConstant.DEC_ZERO;
		} else {
			raitoTotalBankSuccessCnt = totalBankRegisSuccessTrx.divide(totalBankTrx, APIConstant.MC);
		}
		
		if(APIConstant.DEC_ZERO.equals(totalBankTrx) || APIConstant.DEC_ZERO.equals(totalBankRegisFailTrx)) {
			raitoTotalBankFailCnt = APIConstant.DEC_ZERO;
		} else {
			raitoTotalBankFailCnt = totalBankRegisFailTrx.divide(totalBankTrx, APIConstant.MC);
		}
		Object[] objectTotal = {APIConstant.TOTAL_VALUE, APIConstant.SPACE_KEY
				, totalBankTrx, 
				CommonUtil.forPercentages(APIConstant.UNIT_ONE.doubleValue(), new Locale("en", "US"))
				, totalBankRegisSuccessTrx,
				CommonUtil.forPercentages(raitoTotalBankSuccessCnt.doubleValue(), new Locale("en", "US"))
				, totalBankRegisFailTrx,
				CommonUtil.forPercentages(raitoTotalBankFailCnt.doubleValue(), new Locale("en", "US"))
				};
		
		rs.add(objectTotal);
		
		return rs;
	}
	
	public static CommunicationSystemSendSMSTemplate buildDataForSendSMS(TOmsAutoDebitLmsMas mas, String templateName, String url, Environment env) {
		CommunicationSystemSendSMSTemplate template = new CommunicationSystemSendSMSTemplate();
		
		template.setSource(env.getProperty(APIConstant.PREFIX_COMMUNICATION_SYSTEM_SOURCE_DEFAULT_VALUE));
		template.setChannel_code(env.getProperty(APIConstant.PREFIX_COMMUNICATION_SYSTEM_SOURCE_CHANNEL_VALUE));
		
		template.setTemplate_name(templateName);
		template.setCallback_url(url);
		
		template.setPhone(mas.getCustomerPhone());
		
		if(APIConstant.FAIL_AUTO_DEBIT_FIRST_DUE.equalsIgnoreCase(templateName)) {
			CommunicationSystemSendSMSTemplateData data = new CommunicationSystemSendSMSTemplateData(mas.getLoanNo(), DateUtils.formatDate(mas.getFirstDt(), DateUtils.MMyyyy));
			template.setTemplate_data(data);
		} else if(APIConstant.FAIL_AUTO_DEBIT_BANK.equalsIgnoreCase(templateName)) {
			CommunicationSystemSendSMSTemplateData data = new CommunicationSystemSendSMSTemplateData(mas.getLoanNo());
			template.setTemplate_data(data);
		} else {
			return null;
		}
		
		return template;
	}
	
	public static BankTemplateFormat getBankTemplateFormat(TBankCommon tBankCommon, Environment env) throws ServiceRuntimeException {
		BankTemplateFormat bankTemplateInfo = (BankTemplateFormat) CommonUtil.toPojo(tBankCommon.getAddInf(), BankTemplateFormat.class);
		
		if(bankTemplateInfo == null) {
			bankTemplateInfo = new BankTemplateFormat();
		}else {
			if( bankTemplateInfo.getPrefix() != null) {
				if(tBankCommon.getBankCode().equals(APIConstant.TECHCOMBANK_TEMPLATE_BANK_REGISTRATION)) {
					Object[] object = { env.getProperty(APIConstant.PREFIX_REPORT_CITI_VN) + env.getProperty(APIConstant.PREFIX_REPORT_DATE_VN)
					+ DateUtils.getValueOfCurrentDate().getDayOfMonth() + StringUtils.SPACE + env.getProperty(APIConstant.PREFIX_REPORT_MONTH_VN)
					+ DateUtils.getValueOfCurrentDate().getMonthValue() + StringUtils.SPACE + env.getProperty(APIConstant.PREFIX_REPORT_YEARS_VN)
							+ DateUtils.getValueOfCurrentDate().getYear() };
					bankTemplateInfo.setDateExportReport(object);	
				}else {
					Object[] object = { bankTemplateInfo.getPrefix() + " : "
							+ DateUtils.formatDate(DateUtils.getCurrentDate(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT) };
					bankTemplateInfo.setDateExportReport(object);	
				}
				
			}
		}
		return bankTemplateInfo;
	}
}
