/**
 * 
 */
package com.shinhan.autodebit.service.impl;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.autodebit.common.AbstractBasicCommonClass;
import com.shinhan.autodebit.core.constant.APIConstant;
import com.shinhan.autodebit.core.exception.BaseException;
import com.shinhan.autodebit.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.autodebit.core.model.CommunicationSystemCallBackRequest;
import com.shinhan.autodebit.core.model.CommunicationSystemReponseSendSMS;
import com.shinhan.autodebit.core.model.CommunicationSystemSendSMSTemplate;
import com.shinhan.autodebit.core.util.CommonUtil;
import com.shinhan.autodebit.core.util.DTOConverter;
import com.shinhan.autodebit.repository.entity.TMetadata;
import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsInf;
import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsMas;
import com.shinhan.autodebit.repository.entity.TOmsCSTracking;
import com.shinhan.autodebit.service.UtilityApiService;

/**
 * @author shds01
 *
 */

@Service("utilityApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class UtilityApiServiceImpl extends AbstractBasicCommonClass implements UtilityApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.UtilityApiService#getTemplateNameToImport(java.util.Map)
	 */
	@Override
	public File getTemplateNameToImport(Map<String, Object> inputParams) throws BaseException {
		String templateName = inputParams.get(APIConstant._TEMPLATE_NAME_KEY).toString();
		String folderDir = env.getProperty(APIConstant.PATH_TEMPLATE_BANK_AUTODEBIT);
		if(StringUtils.isBlank(templateName)) {
			return null;
		}
		
		TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService()
				.getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_AD_TEMPLATE_IMPORT_DATA, templateName);
		if(item == null) {
			return null;
		}
		
		return new File(folderDir + item.getValue());
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.UtilityApiService#scanADTrxToSendSMSFirstDueDt(java.util.Map)
	 */
	@Override
	public String scanADTrxToSendSMSFirstDueDt(Map<String, Object> inputParams) throws BaseException {
		List<TOmsAutoDebitLmsInf> lst = getRepositoryManagerService().getAdInfManagerRepositoryService().getListAutoDebitTrxForSendSMSFirstDueDt();
		if(CollectionUtils.isEmpty(lst)) {
			logger.info("***** No records to sending First Due Date *****");
			return APIConstant.EMPTY_KEY;
		}
		
		for(TOmsAutoDebitLmsInf inf : lst){
			Object rs = null;
			CommunicationSystemReponseSendSMS responseRs = null;
			try {
				logger.info("***** Start process call Communication System to send SMS *****");
				logger.info("***** loan no ***** " + inf.getLoanNo() + " *****");
				TOmsAutoDebitLmsMas mas = getRepositoryManagerService().getAdMasManagerRepositoryService().getByLoanNo(inf.getLoanNo());
				CommunicationSystemSendSMSTemplate body = DTOConverter.buildDataForSendSMS(mas, APIConstant.FAIL_AUTO_DEBIT_FIRST_DUE
						, env.getProperty(APIConstant.COMMUNICATION_SYSTEM_CALLBACK_URL_REQUEST), env);
				rs = CommonUtil.invokeRestTemplateService(env.getProperty(APIConstant.COMMUNICATION_SYSTEM_SEND_SMS)
						, APIConstant.POST_METHOD_STR, null, body, Object.class);
				if(rs == null) {
					logger.info("***** Fail *****");
					continue;
				}
				responseRs = (CommunicationSystemReponseSendSMS) CommonUtil.toPojo(rs, CommunicationSystemReponseSendSMS.class);
				logger.info("***** End process call Communication System to send SMS *****");
			} catch (Exception ex) {
				logger.info("***** Fail *****");
				logger.info(CommonUtil.getLogMessenge(ex));
				continue;
			}
			
			if(responseRs != null && responseRs.getStatus() == 0) {
				//Success then update status to DB
				DTOConverter.populateDataForSendingSmsRegisTrx(inf, APIConstant.OMS_JOB);
				TOmsCSTracking tracking = DTOConverter.populateDataForSendingSmsRegisTrxTracking(responseRs, inf.getLoanNo());
				if(tracking == null) {
					logger.info("***** Fail ***** Status ***** " + responseRs.getStatus() + " Tracking " + responseRs.getData().getTracking_id() + " *****" );
					continue;
				}
				getRepositoryManagerService().sendSmsForProcessingFirstDueDateADTrxToDB(inf, tracking);
				logger.info("***** Success *****");
			} else {
				logger.info("***** Fail *****");
			}
		}
		
		return APIConstant.SUCCESS_KEY;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.UtilityApiService#scanADTrxToSendSMSBankFail(java.util.Map)
	 */
	@Override
	public String scanADTrxToSendSMSBankFail(Map<String, Object> inputParams) throws BaseException {
		List<TOmsAutoDebitLmsInf> lst = getRepositoryManagerService().getAdInfManagerRepositoryService().getListAutoDebitTrxForSendSMSFailBank();
		if(CollectionUtils.isEmpty(lst)) {
			logger.info("***** No records to sending Bank Fail *****");
			return APIConstant.EMPTY_KEY;
		}
		
		for(TOmsAutoDebitLmsInf inf : lst){
			Object rs = null;
			CommunicationSystemReponseSendSMS responseRs = null;
			try {
				logger.info("***** Start process call Communication System to send SMS *****");
				logger.info("***** loan no ***** " + inf.getLoanNo() + " *****");
				TOmsAutoDebitLmsMas mas = getRepositoryManagerService().getAdMasManagerRepositoryService().getByLoanNo(inf.getLoanNo());
				CommunicationSystemSendSMSTemplate body = DTOConverter.buildDataForSendSMS(mas, APIConstant.FAIL_AUTO_DEBIT_BANK
						, env.getProperty(APIConstant.COMMUNICATION_SYSTEM_CALLBACK_URL_REQUEST), env);
				rs = CommonUtil.invokeRestTemplateService(env.getProperty(APIConstant.COMMUNICATION_SYSTEM_SEND_SMS)
						, APIConstant.POST_METHOD_STR, null, body, Object.class);
				if(rs == null) {
					logger.info("***** Fail *****");
					continue;
				}
				responseRs = (CommunicationSystemReponseSendSMS) CommonUtil.toPojo(rs, CommunicationSystemReponseSendSMS.class);
				logger.info("***** End process call Communication System to send SMS *****");
			} catch (Exception ex) {
				logger.info("***** Fail *****");
				logger.info(CommonUtil.getLogMessenge(ex));
				continue;
			}
			
			if(responseRs != null && responseRs.getStatus() == 0) {
				//Success then update status to DB
				DTOConverter.populateDataForSendingSmsBankRegisFailTrx(inf, APIConstant.OMS_JOB);
				TOmsCSTracking tracking = DTOConverter.populateDataForSendingSmsBankRegisFailTrxTracking(responseRs, inf.getLoanNo());
				if(tracking == null) {
					logger.info("***** Fail ***** Status ***** " + responseRs.getStatus() + " Tracking " + responseRs.getData().getTracking_id() + " *****" );
					continue;
				}
				getRepositoryManagerService().sendSmsForProcessingBankRegisFailADTrxToDB(inf, tracking);
				logger.info("***** Success *****");
			} else {
				logger.info("***** Fail *****");
			}
		}
		
		return APIConstant.SUCCESS_KEY;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.UtilityApiService#callBackURLForCommunicationSystem(java.util.Map)
	 */
	@Override
	public CommunicationSystemCallBackRequest callBackURLForCommunicationSystem(Map<String, Object> inputParams)
			throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		CommunicationSystemCallBackRequest body = (CommunicationSystemCallBackRequest) CommonUtil.toPojo(document, CommunicationSystemCallBackRequest.class);
		
		String trackingId = body.getMessage().getTracking_id();
		TOmsCSTracking tracking = getRepositoryManagerService().getUtilityManagerRepositoryService().getTrackingByTrackingId(trackingId);
		if(StringUtils.isBlank(trackingId) || tracking == null) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_001"));
		}
		
		TOmsAutoDebitLmsInf inf = getRepositoryManagerService().getAdInfManagerRepositoryService().getOneByLoanNo(tracking.getLoanNo());
		boolean isUpdate = true;
		if(APIConstant.FAIL_AUTO_DEBIT_BANK.equalsIgnoreCase(tracking.getTrackingType()) 
				&& APIConstant.AD_SEND_SMS_STATUS_SENDING.equalsIgnoreCase(inf.getSmsADDtStatus())){
			DTOConverter.populateDataForCompleteSmsBankRegisFailTrx(inf, APIConstant.OMS_JOB);
		} else if(APIConstant.FAIL_AUTO_DEBIT_FIRST_DUE.equalsIgnoreCase(tracking.getTrackingType()) 
				&& APIConstant.AD_SEND_SMS_STATUS_SENDING.equalsIgnoreCase(inf.getSmsDueDtStatus())){
			DTOConverter.populateDataForCompleteSmsRegisTrx(inf, APIConstant.OMS_JOB);
		} else {
			isUpdate = false;
			logger.info("Skipped Update : " + trackingId);
		}
		
		if(isUpdate) {
			getRepositoryManagerService().sendSmsForCompleteADTrxToDB(inf);
		}
		
		return body;
	}

}
