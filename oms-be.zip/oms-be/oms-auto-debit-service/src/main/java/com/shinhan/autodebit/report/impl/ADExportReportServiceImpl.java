/**
 * 
 */
package com.shinhan.autodebit.report.impl;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import com.shinhan.autodebit.common.AbstractBasicCommonClass;
import com.shinhan.autodebit.core.constant.APIConstant;
import com.shinhan.autodebit.core.exception.BaseException;
import com.shinhan.autodebit.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.autodebit.core.exception.ServiceRuntimeException;
import com.shinhan.autodebit.core.util.DTOConverter;
import com.shinhan.autodebit.core.util.DateUtils;
import com.shinhan.autodebit.core.util.WriteToExcelTemplate;
import com.shinhan.autodebit.report.ADExportReportService;
import com.shinhan.autodebit.repository.entity.TMetadata;

/**
 * @author shds01
 *
 */
@Service("adExportReportService")
public class ADExportReportServiceImpl extends AbstractBasicCommonClass implements ADExportReportService{

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.report.ADExportReportService#exportADReportForBankByTemplate(java.util.Map)
	 */
	@Override
	public File exportADReportForBankByTemplate(Map<String, Object> inputParams) throws BaseException {
		String bankName = inputParams.get(APIConstant._BANK).toString();
		List<Object[]> templateData = buildDataADTrxReportByBank(bankName);
		if(CollectionUtils.isEmpty(templateData)) {
			if(templateData == null) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), bankName));
			}
			
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_013"), bankName));
		}
		switch (bankName) {
		case APIConstant.ACB_TEMPLATE_BANK_REGISTRATION:
			//Build pojo
			return exportADTrxReportForBank(templateData, bankName);
		case APIConstant.AGRIBANK_TEMPLATE_BANK_REGISTRATION:
			//Build pojo
			return exportADTrxReportForBank(templateData, bankName);
		case APIConstant.TECHCOMBANK_TEMPLATE_BANK_REGISTRATION:
			//Build pojo
			return exportADTrxReportForBank(templateData, bankName);
		case APIConstant.VCB_TEMPLATE_BANK_REGISTRATION:
			//Build pojo
			return exportADTrxReportForBank(templateData, bankName);
		case APIConstant.VIETTINBANK_TEMPLATE_BANK_REGISTRATION:
			//Build pojo
			return exportADTrxReportForBank(templateData, bankName);
		default:
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_012"), bankName));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.report.ADExportReportService#exportUnRegisterAutoDebitTrx(java.util.List)
	 */
	@Override
	public File exportUnRegisterAutoDebitTrx(List<Object[]> data) throws ServiceRuntimeException {
		TMetadata templateFileName = getRepositoryManagerService()
				.getUtilityManagerRepositoryService()
				.getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_AD_TEMPLATE_EXPORT_DATA, APIConstant.AD_TEMPLATE_EXPORT_DATA_REGISTRATION);
		String fileSource = env.getProperty(APIConstant.PATH_TEMPLATE_AUTODEBIT_FOR_EXPORT_DATA) + templateFileName.getValue();
		String fileDestinationExport = env.getProperty(APIConstant.PATH_TEMPLATE_EXPORT_BANK_REGISTRATION_AUTODEBIT) 
				+ APIConstant.AD_TEMPLATE_EXPORT_DATA_REGISTRATION
				+ DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss) + APIConstant.FILE_TYPE_EXCEL_OLD;
		/** Start Process fill data */
		int fromRow = 1; // initial row
		Workbook wb = WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, "Data", fromRow, data);
		/** End Process fill data */
		
		/** Start Write Excel file */
		WriteToExcelTemplate.writeWorkbook(wb, fileDestinationExport);
		File file = new File(fileDestinationExport);
		if(!file.exists()) {
			throw new ServiceRuntimeException(env.getProperty("MSG_004"));
		}
		/** End Write Excel file */
		return file;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.report.ADExportReportService#exportRegisterAutoDebitTrx(java.util.List, java.util.String)
	 */
	@Override
	public File exportRegisterAutoDebitTrx(List<Object[]> data, String statusCode) throws BaseException {
		String templateName = "";
		switch (statusCode) {
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_BN_SEND_HARD_COPY:
			templateName = APIConstant.AD_TEMPLATE_EXPORT_DATA_BN_SEND_HARD;
			break;
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DR_RECEIVED_HARD_COPY:
			templateName = APIConstant.AD_TEMPLATE_EXPORT_DATA_DR_RECEIVED_HARD;
			break;
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_WAITING_BANK_REGISTRATION:
			templateName = APIConstant.AD_TEMPLATE_EXPORT_DATA_WAITING_BANK_REGISTRATION;
			break;
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION:
			templateName = APIConstant.AD_TEMPLATE_EXPORT_DATA_BANK_REGISTRATION_FAIL;
			break;
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_AD_SMS_SEND_UN_REGISTRATION:
			templateName = APIConstant.AD_TEMPLATE_EXPORT_DATA_AD_SMS_SEND_UN_REGISTRATION;
			break;
		default :
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_010"), statusCode));
		}
		TMetadata templateFileName = getRepositoryManagerService()
				.getUtilityManagerRepositoryService()
				.getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_AD_TEMPLATE_EXPORT_DATA, templateName);
		String fileSource = env.getProperty(APIConstant.PATH_TEMPLATE_AUTODEBIT_FOR_EXPORT_DATA) + templateFileName.getValue();
		String fileDestinationExport = env.getProperty(APIConstant.PATH_TEMPLATE_EXPORT_BANK_REGISTRATION_AUTODEBIT) 
				+ templateName
				+ DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss) + APIConstant.FILE_TYPE_EXCEL_OLD;
		/** Start Process fill data */
		int fromRow = 1; // initial row
		Workbook wb = WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, "Data", fromRow, data);
		/** End Process fill data */
		
		/** Start Write Excel file */
		WriteToExcelTemplate.writeWorkbook(wb, fileDestinationExport);
		File file = new File(fileDestinationExport);
		if(!file.exists()) {
			throw new ServiceRuntimeException(env.getProperty("MSG_004"));
		}
		/** End Write Excel file */
		return file;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.report.ADExportReportService#exportReportByTemplate(java.util.Map)
	 */
	@Override
	public File exportReportByTemplate(Map<String, Object> inputParams) throws BaseException {
		String templateName = inputParams.get(APIConstant._TEMPLATE_NAME).toString();
		String startDt = inputParams.get(APIConstant._START_DATE_KEY).toString();
		String endDt = inputParams.get(APIConstant._END_DATE_KEY).toString();
		
		TMetadata templateFileName = getRepositoryManagerService()
				.getUtilityManagerRepositoryService()
				.getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_EXPORT_AD_REPORT_TEMPLATE_NAME, templateName);
		String fileSource = env.getProperty(APIConstant.PATH_TEMPLATE_AUTODEBIT_FOR_EXPORT_DATA) + templateFileName.getValue();
		String fileDestinationExport = env.getProperty(APIConstant.PATH_EXPORT_AUTODEBIT) 
				+ templateName
				+ DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss) + APIConstant.FILE_TYPE_EXCEL_OLD;
		
		Workbook wb;
		int fromRow;
		int fromColumn;
		List<Object[]> data;
		switch (templateName) {
		case APIConstant.EXPORT_AD_REPORT_TEMPLATE_NAME_ALL:
			data = getRepositoryManagerService().getAdInfManagerRepositoryService().exportReportSummaryAutoDebitTrx(startDt, endDt);
			/** Start Process fill data */
			fromRow = 1; // initial row
			wb = WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, "Data", fromRow, data);
			/** End Process fill data */
			break;
		case APIConstant.EXPORT_AD_REPORT_TEMPLATE_NAME_TAT_ALL:
			data = getRepositoryManagerService().getAdInfManagerRepositoryService().exportReportTATSummaryAutoDebitTrx(startDt, endDt);
			data = DTOConverter.convertDataForExportTATReport(data);
			/** Start Process fill data */
			fromRow = 1; // initial row
			fromColumn = 4; // Skipped Column
			wb = WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, "Data", fromRow, fromColumn, data);
			/** End Process fill data */
			break;
		case APIConstant.EXPORT_AD_REPORT_TEMPLATE_NAME_BANK_RESULT:
			data = getRepositoryManagerService().getAdInfManagerRepositoryService().exportReportBankResultAutoDebitTrx(startDt, endDt);
			data = DTOConverter.replaceNullValueToNumber(data);
			/** Start Process fill data */
			fromRow = 0; // initial row
			fromColumn = 1; // Skipped Column
			wb = WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, "Data", fromRow, fromColumn, data);
			WriteToExcelTemplate.setStyleForRowByCell(wb, "Data", 0, 5);
			/** End Process fill data */
			break;
		case APIConstant.EXPORT_AD_REPORT_TEMPLATE_NAME_BANK_RESULT_FAIL:
			data = getRepositoryManagerService().getAdInfManagerRepositoryService().exportReportBankResultFailAutoDebitTrx(startDt, endDt);
			data = DTOConverter.replaceNullValueToNumber(data);
			/** Start Process fill data */
			fromRow = 0; // initial row
			fromColumn = 0; // Skipped Column
			wb = WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, "Data", fromRow, fromColumn, data);
			WriteToExcelTemplate.setStyleForRowByCell(wb, "Data", 0, 0);
			WriteToExcelTemplate.setBoderForRow(wb, "Data", 1, 8);
			/** End Process fill data */
			break;
		case APIConstant.EXPORT_AD_REPORT_TEMPLATE_NAME_BANK_TRX:
			data = getRepositoryManagerService().getAdInfManagerRepositoryService().exportReportBankTransactionAutoDebitTrx(startDt, endDt);
			data = DTOConverter.convertDataForExportBankTrxReport(data);
			/** Start Process fill data */
			fromRow = 1; // initial row
			wb = WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, "Data", fromRow, data);
			/** End Process fill data */
			break;
		case APIConstant.EXPORT_AD_REPORT_TEMPLATE_NAME_TAT_BANK:
			List<Object[]> dataTATBank = DTOConverter.convertDataForExportTATBankTrxReport(
					getRepositoryManagerService().getAdInfManagerRepositoryService().exportReportTATBankAutoDebitTrx(startDt, endDt), 
					getRepositoryManagerService().getAdInfManagerRepositoryService().exportReportTATBankTransactionAutoDebitTrx(startDt, endDt));
			/** Start Process fill data */
			fromRow = 1; // initial row
			wb = WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, "Data", fromRow, dataTATBank);
			/** End Process fill data */
			break;
		default :
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_010"), templateName));
		}
		
		/** Start Write Excel file */
		WriteToExcelTemplate.writeWorkbook(wb, fileDestinationExport);
		File file = new File(fileDestinationExport);
		if(!file.exists()) {
			throw new ServiceRuntimeException(env.getProperty("MSG_004"));
		}
		/** End Write Excel file */
		return file;
	}

}
