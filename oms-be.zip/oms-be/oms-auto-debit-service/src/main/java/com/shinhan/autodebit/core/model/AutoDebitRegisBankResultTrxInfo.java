/**
 * 
 */
package com.shinhan.autodebit.core.model;

import org.apache.commons.lang3.StringUtils;

/**
 * @author shds01
 *
 */
public class AutoDebitRegisBankResultTrxInfo {

	private String loanNo;
	private String result;
	private String reason;
	private String errorMessage;

	/**
	 * 
	 */
	public AutoDebitRegisBankResultTrxInfo() {
		super();
	}

	/**
	 * @param loanNo
	 * @param result
	 * @param reason
	 */
	public AutoDebitRegisBankResultTrxInfo(String loanNo, String result, String reason) {
		super();
		this.loanNo = loanNo;
		this.result = result;
		this.reason = reason;
	}

	/**
	 * @return the loanNo
	 */
	public String getLoanNo() {
		return loanNo;
	}

	/**
	 * @param loanNo the loanNo to set
	 */
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	/**
	 * @return the result
	 */
	public String getResult() {
		return result;
	}

	/**
	 * @param result the result to set
	 */
	public void setResult(String result) {
		this.result = result;
	}

	/**
	 * @return the reason
	 */
	public String getReason() {
		return reason;
	}

	/**
	 * @param reason the reason to set
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public boolean getValid() {
		if (StringUtils.isNotBlank(errorMessage)) {
			return false;
		}
		return true;
	}
}
