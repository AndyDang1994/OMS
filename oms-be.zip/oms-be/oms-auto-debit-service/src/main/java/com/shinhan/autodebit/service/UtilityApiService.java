/**
 * 
 */
package com.shinhan.autodebit.service;

import java.io.File;
import java.util.Map;

import com.shinhan.autodebit.core.exception.BaseException;
import com.shinhan.autodebit.core.model.CommunicationSystemCallBackRequest;

/**
 * @author shds01
 *
 */
public interface UtilityApiService {
	
	public File getTemplateNameToImport (Map<String, Object> inputParams) throws BaseException;
	
	public String scanADTrxToSendSMSFirstDueDt (Map<String, Object> inputParams) throws BaseException;
	
	public String scanADTrxToSendSMSBankFail (Map<String, Object> inputParams) throws BaseException;
	
	public CommunicationSystemCallBackRequest callBackURLForCommunicationSystem (Map<String, Object> inputParams) throws BaseException;
}
