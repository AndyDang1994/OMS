/**
 * 
 */
package com.shinhan.autodebit.service.impl;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.shinhan.autodebit.common.AbstractBasicCommonClass;
import com.shinhan.autodebit.core.constant.APIConstant;
import com.shinhan.autodebit.core.exception.BaseException;
import com.shinhan.autodebit.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.autodebit.core.exception.ServiceRuntimeException;
import com.shinhan.autodebit.core.model.AutoDebitRegisBankResultTrxInfo;
import com.shinhan.autodebit.core.model.AutoDebitRegisTrxInfo;
import com.shinhan.autodebit.core.model.AutoDebitTrxInfo;
import com.shinhan.autodebit.core.util.CommonUtil;
import com.shinhan.autodebit.core.util.DTOConverter;
import com.shinhan.autodebit.core.util.ReadFromExcel;
import com.shinhan.autodebit.repository.entity.TMetadata;
import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsInf;
import com.shinhan.autodebit.service.ADApiService;

/**
 * @author shds01
 *
 */

@Service("adApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class ADApiServiceImpl extends AbstractBasicCommonClass implements ADApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#getListUnRegisterAutoDebitTrx(java.util.Map)
	 */
	@Override
	public List<AutoDebitTrxInfo> getListUnRegisterAutoDebitTrx(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		String firstDueDtStr = inputParams.get(APIConstant._FIRST_DUEDT).toString();
		if(StringUtils.isNotBlank(firstDueDtStr)){
			Date periodDt = getFirstDueDatePeriodByDate(firstDueDtStr);
			inputParams.put(APIConstant.PERIOD_DT, periodDt);
		}
		
		return getRepositoryManagerService().getAdMasManagerRepositoryService().getListUnRegisterAutoDebitTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#countTotalUnRegisterAutoDebitTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countTotalUnRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		String firstDueDtStr = inputParams.get(APIConstant._FIRST_DUEDT).toString();
		if(StringUtils.isNotBlank(firstDueDtStr)){
			Date periodDt = getFirstDueDatePeriodByDate(firstDueDtStr);
			inputParams.put(APIConstant.PERIOD_DT, periodDt);
		}
		return getRepositoryManagerService().getAdMasManagerRepositoryService().countUnRegisterAutoDebitTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#exportUnRegisterAutoDebitTrx(java.util.Map)
	 */
	@Override
	public File exportUnRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		String firstDueDtStr = inputParams.get(APIConstant._FIRST_DUEDT).toString();
		if(StringUtils.isNotBlank(firstDueDtStr)){
			Date periodDt = getFirstDueDatePeriodByDate(firstDueDtStr);
			inputParams.put(APIConstant.PERIOD_DT, periodDt);
		}
		return getProcessManagerService().getAdExportReportService().exportUnRegisterAutoDebitTrx(getRepositoryManagerService().getAdMasManagerRepositoryService().exportUnRegisterAutoDebitTrx(inputParams));
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#getListRegisterAutoDebitTrx(java.util.Map)
	 */
	@Override
	public List<AutoDebitTrxInfo> getListRegisterAutoDebitTrx(Map<String, Object> inputParams)
			throws BaseException {
		String statusCode = inputParams.get(APIConstant._STATUS_AD_MAP).toString();
		switch (statusCode) {
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_BN_SEND_HARD_COPY:
			if(StringUtils.isBlank(inputParams.get(APIConstant._START_SEND_DT).toString()) 
					|| StringUtils.isBlank(inputParams.get(APIConstant._END_SEND_DT).toString())) {
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_009"));
			}
			break;
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DR_RECEIVED_HARD_COPY:
			if(StringUtils.isBlank(inputParams.get(APIConstant._START_RECEIVE_DT).toString()) 
			|| StringUtils.isBlank(inputParams.get(APIConstant._END_RECEIVE_DT).toString())) {
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_009"));
			}
			break;
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_WAITING_BANK_REGISTRATION:
			if(StringUtils.isBlank(inputParams.get(APIConstant._START_SEND_BANK_DT).toString()) 
			|| StringUtils.isBlank(inputParams.get(APIConstant._END_SEND_BANK_DT).toString())) {
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_009"));
			}
			break;
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION:
			if(StringUtils.isBlank(inputParams.get(APIConstant._START_BANK_RESULT_DT).toString()) 
					|| StringUtils.isBlank(inputParams.get(APIConstant._END_BANK_RESULT_DT).toString())) {
						throw new ServiceInvalidAgurmentException(env.getProperty("MSG_009"));
					}
			break;
		default :
			break;
		}
		return getRepositoryManagerService().getAdInfManagerRepositoryService().getListRegisterAutoDebitTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#countTotalRegisterAutoDebitTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countTotalRegisterAutoDebitTrx(Map<String, Object> inputParams) throws BaseException {
		String statusCode = inputParams.get(APIConstant._STATUS_AD_MAP).toString();
		switch (statusCode) {
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_BN_SEND_HARD_COPY:
			if(StringUtils.isBlank(inputParams.get(APIConstant._START_SEND_DT).toString()) 
					|| StringUtils.isBlank(inputParams.get(APIConstant._END_SEND_DT).toString())) {
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_009"));
			}
			break;
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DR_RECEIVED_HARD_COPY:
			if(StringUtils.isBlank(inputParams.get(APIConstant._START_RECEIVE_DT).toString()) 
			|| StringUtils.isBlank(inputParams.get(APIConstant._END_RECEIVE_DT).toString())) {
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_009"));
			}
			break;
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_WAITING_BANK_REGISTRATION:
			if(StringUtils.isBlank(inputParams.get(APIConstant._START_SEND_BANK_DT).toString()) 
			|| StringUtils.isBlank(inputParams.get(APIConstant._END_SEND_BANK_DT).toString())) {
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_009"));
			}
			break;
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION:
			if(StringUtils.isBlank(inputParams.get(APIConstant._START_BANK_RESULT_DT).toString()) 
					|| StringUtils.isBlank(inputParams.get(APIConstant._END_BANK_RESULT_DT).toString())) {
						throw new ServiceInvalidAgurmentException(env.getProperty("MSG_009"));
					}
			break;
		default :
			break;
		}
		return getRepositoryManagerService().getAdInfManagerRepositoryService().countRegisterAutoDebitTrx(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#exportRegisterAutoDebitTrx(java.util.Map)
	 */
	@Override
	public File exportRegisterAutoDebitTrx(Map<String, Object> inputParams) throws BaseException {
		String statusCode = inputParams.get(APIConstant._STATUS_AD_MAP).toString();
		switch (statusCode) {
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_BN_SEND_HARD_COPY:
			if(StringUtils.isBlank(inputParams.get(APIConstant._START_SEND_DT).toString()) 
					|| StringUtils.isBlank(inputParams.get(APIConstant._END_SEND_DT).toString())) {
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_009"));
			}
			break;
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DR_RECEIVED_HARD_COPY:
			if(StringUtils.isBlank(inputParams.get(APIConstant._START_RECEIVE_DT).toString()) 
			|| StringUtils.isBlank(inputParams.get(APIConstant._END_RECEIVE_DT).toString())) {
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_009"));
			}
			break;
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_WAITING_BANK_REGISTRATION:
			if(StringUtils.isBlank(inputParams.get(APIConstant._START_SEND_BANK_DT).toString()) 
			|| inputParams.get(APIConstant._END_SEND_BANK_DT) == null && StringUtils.isBlank(inputParams.get(APIConstant._END_SEND_BANK_DT).toString())) {
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_009"));
			}
			break;
		case APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION:
			if(StringUtils.isBlank(inputParams.get(APIConstant._START_BANK_RESULT_DT).toString()) 
					|| StringUtils.isBlank(inputParams.get(APIConstant._END_BANK_RESULT_DT).toString())) {
						throw new ServiceInvalidAgurmentException(env.getProperty("MSG_009"));
					}
			break;
		default :
			break;
		}
		return getProcessManagerService().getAdExportReportService().exportRegisterAutoDebitTrx(
				getRepositoryManagerService().getAdInfManagerRepositoryService().exportRegisterAutoDebitTrx(inputParams), statusCode);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#getListRegisterAutoDebitTrxBySMS(java.util.Map)
	 */
	@Override
	public List<AutoDebitTrxInfo> getListRegisterAutoDebitTrxBySMS(Map<String, Object> inputParams)
			throws BaseException {
		String firstDueDtStr = inputParams.get(APIConstant._FIRST_DUEDT).toString();
		Date periodDt = getFirstDueDatePeriodByDate(firstDueDtStr);
		inputParams.put(APIConstant.PERIOD_DT, periodDt);
		return getRepositoryManagerService().getAdInfManagerRepositoryService().getListRegisterAutoDebitTrxByPeriodDate(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#countTotalRegisterAutoDebitTrxBySMS(java.util.Map)
	 */
	@Override
	public BigDecimal countTotalRegisterAutoDebitTrxBySMS(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		String firstDueDtStr = inputParams.get(APIConstant._FIRST_DUEDT).toString();
		Date periodDt = getFirstDueDatePeriodByDate(firstDueDtStr);
		inputParams.put(APIConstant.PERIOD_DT, periodDt);
		return getRepositoryManagerService().getAdInfManagerRepositoryService().countRegisterAutoDebitTrxByPeriodDate(inputParams);
	}


	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#exportRegisterAutoDebitTrxBySMS(java.util.Map)
	 */
	@Override
	public File exportRegisterAutoDebitTrxBySMS(Map<String, Object> inputParams) throws BaseException {
		String firstDueDtStr = inputParams.get(APIConstant._FIRST_DUEDT).toString();
		Date periodDt = getFirstDueDatePeriodByDate(firstDueDtStr);
		inputParams.put(APIConstant.PERIOD_DT, periodDt);
		return getProcessManagerService().getAdExportReportService().exportRegisterAutoDebitTrx(
				getRepositoryManagerService().getAdInfManagerRepositoryService().exportRegisterAutoDebitTrxByPeriodDate(inputParams), APIConstant.AUTO_DEBIT_STATUS_MAPPING_AD_SMS_SEND_UN_REGISTRATION);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#importAutoDebitTrx(java.util.Map)
	 */
	@Override
	public List<AutoDebitRegisTrxInfo> importAutoDebitTrx(Map<String, Object> inputParams)
			throws BaseException {
		ReadFromExcel rw;
		List<AutoDebitRegisTrxInfo> lstTrx = new ArrayList<>();
		MultipartFile fileUpload = (MultipartFile) inputParams.get(APIConstant.FILE_UPLOAD);
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		boolean flagTemplate = false;
		ArrayList<TOmsAutoDebitLmsInf> listReg = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.UPLOAD_LIMIT_TRX));
		long startTime = System.currentTimeMillis();
		try {
			if(fileUpload == null){
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_011"));
			}
			rw = new ReadFromExcel(fileUpload.getInputStream(), fileUpload.getOriginalFilename(),
					env.getProperty(APIConstant.PATH_IMPORT_REGIS_AUTODEBIT));
			TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService()
					.getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_AD_TEMPLATE_IMPORT_DATA, APIConstant.REGIS_AUTO_DEBIT_TEMPLATE);
			flagTemplate = rw.isCorrectTemplateHeader(item.getValue(), env.getProperty(APIConstant.PATH_TEMPLATE_BANK_AUTODEBIT), 0);
			
		} catch (IOException ex) {
			logger.info(ex.getMessage());
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_011"));
		}
		if(!flagTemplate) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_003"));
		}
		
		List<Map> mapObjectLst = rw.readDataFromExcel(0, 1, 0);
		if(CollectionUtils.isNotEmpty(mapObjectLst)) {
			if(mapObjectLst.size() > limitTrx) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
			}
			for (Map mapData : mapObjectLst){
				AutoDebitRegisTrxInfo data = DTOConverter.convertToAutoDebitRegisTrxInfoFromImportRegisAD(mapData, env);
				TOmsAutoDebitLmsInf inf = getValidationManagerService().checkValidationImportRegisDA(data);
				if(data.getValid()){
					if (inf == null) {
						inf = DTOConverter.populateDataFromAutoDebitRegisTrxInfoToTOmsAutoDebitLmsInfNew(data,
								userName);
					} else {
						inf = DTOConverter.populateDataFromAutoDebitRegisTrxInfoToTOmsAutoDebitLmsInfUpdate(data, inf,
								userName);
					}
					//Set Send Date index
					inf.setSendDtIndex(startTime);
					listReg.add(inf);
					count++;
					startTime++;
				}
				
				lstTrx.add(data);
				countTotal++;
			}
		}
		
		if(countTotal == count){
			getRepositoryManagerService().importAutoDebitTrxToDB(listReg);
		}
		
		return lstTrx;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#updateToBankResultSuccessByUpload(java.util.Map)
	 */
	@Override
	public List<AutoDebitRegisBankResultTrxInfo> updateToBankResultSuccessByUpload(Map<String, Object> inputParams)
			throws BaseException {
		ReadFromExcel rw;
		List<AutoDebitRegisBankResultTrxInfo> lstTrx = new ArrayList<>();
		MultipartFile fileUpload = (MultipartFile) inputParams.get(APIConstant.FILE_UPLOAD);
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		boolean flagTemplate = false;
		try {
			if(fileUpload == null){
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_011"));
			}
			rw = new ReadFromExcel(fileUpload.getInputStream(), fileUpload.getOriginalFilename(),
					env.getProperty(APIConstant.PATH_IMPORT_REGIS_AUTODEBIT));
			TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService()
					.getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_AD_TEMPLATE_IMPORT_DATA, APIConstant.REGIS_AUTO_DEBIT_BANK_RESULT_TEMPLATE);
			flagTemplate = rw.isCorrectTemplateHeader(item.getValue(), env.getProperty(APIConstant.PATH_TEMPLATE_BANK_AUTODEBIT), 0);
			
		} catch (IOException ex) {
			logger.info(ex.getMessage());
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_011"));
		}
		
		if(!flagTemplate) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_003"));
		}
		ArrayList<TOmsAutoDebitLmsInf> listReg = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.UPLOAD_LIMIT_TRX));
		List<Map> mapObjectLst = rw.readDataFromExcel(0, 1, 0);
		if(CollectionUtils.isNotEmpty(mapObjectLst)) {
			if(mapObjectLst.size() > limitTrx) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
			}
			for (Map mapData : mapObjectLst){
				AutoDebitRegisBankResultTrxInfo data = DTOConverter.convertToAutoDebitRegisBankResultTrxInfoFromImportRegisBankResultAD(mapData, env);
				getValidationManagerService().checkValidationUpdateBankResultSuccessByUpload(data);
				if(data.getValid()){
					listReg.add(DTOConverter.populateDataUpdateBankResultSuccessByUpload(data.getLoanNo(), userName));
					count++;
				}
				
				lstTrx.add(data);
				countTotal++;
			}
		}
		
		if(countTotal == count){
			getRepositoryManagerService().importAutoDebitBankResultToDB(listReg);
		}
		
		return lstTrx;
	
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#updateToBankResultSuccess(java.util.Map)
	 */
	@Override
	public List<AutoDebitTrxInfo> updateToBankResultSuccess(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<AutoDebitTrxInfo> lst = CommonUtil.toListPojo(document, AutoDebitTrxInfo.class);
		
		ArrayList<TOmsAutoDebitLmsInf> listReg = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.UPLOAD_LIMIT_TRX));
		for(AutoDebitTrxInfo trx : lst) {
			getValidationManagerService().checkValidationUpdateBankResultSuccess(trx);
			if(trx.getValid()){
				listReg.add(DTOConverter.populateDataUpdateBankResultSuccess(trx, userName));
				count++;
			}
			countTotal++;
			if(countTotal > limitTrx) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
			}
		}
		
		if(countTotal == count){
			getRepositoryManagerService().
			importAutoDebitTrxToDB(listReg);
		}
		
		return lst;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#importHardCopyTransaction(java.util.Map)
	 */
	@Override
	public List<AutoDebitTrxInfo> importHardCopyTransaction(Map<String, Object> inputParams)
			throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		List<AutoDebitTrxInfo> lst = CommonUtil.toListPojo(document, AutoDebitTrxInfo.class);
		
		ArrayList<TOmsAutoDebitLmsInf> listUp = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.UPLOAD_LIMIT_TRX));
		long startTime = System.currentTimeMillis();
		
		for(AutoDebitTrxInfo trx : lst) {
			TOmsAutoDebitLmsInf inf = getValidationManagerService().checkValidationImportHardCopy(trx);
			if(trx.getValid() && inf != null){
				DTOConverter.populateDataImportHardCopy(inf, userName);
				listUp.add(inf);
				count++;
				
				//Set Receive Date index
				inf.setReceiveDtIndex(startTime);
				startTime++;
			}
			countTotal++;
			if(countTotal > limitTrx) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
			}
		}
		if(countTotal == count){
			getRepositoryManagerService().importAutoDebitHardCopyToDB(listUp);
		}
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#exportAutoDebitByBank(java.util.Map)
	 */
	@Override
	public File exportAutoDebitByBank(Map<String, Object> inputParams) throws BaseException {
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		String bankName = inputParams.get(APIConstant._BANK).toString();
		List<TOmsAutoDebitLmsInf> listUp = getRepositoryManagerService().getAdInfManagerRepositoryService().getListAutoDebitTrxForExport(bankName);
		
		if(CollectionUtils.isEmpty(listUp)) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_013"), bankName));
		}
		File fileExport = getProcessManagerService().getAdExportReportService().exportADReportForBankByTemplate(inputParams);
		
		if(fileExport != null && fileExport.exists()) {
			for(TOmsAutoDebitLmsInf inf : listUp) {
				DTOConverter.populateDataExportAutoDebitByBank(inf, userName);
			}
			
			getRepositoryManagerService().importAutoDebitHardCopyToDB(listUp);
		}
		return fileExport;
		
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#importAutoDebitBankResultTrx(java.util.Map)
	 */
	@Override
	public List<AutoDebitRegisBankResultTrxInfo> importAutoDebitBankResultTrx(Map<String, Object> inputParams)
			throws BaseException {
		ReadFromExcel rw;
		List<AutoDebitRegisBankResultTrxInfo> lstTrx = new ArrayList<>();
		MultipartFile fileUpload = (MultipartFile) inputParams.get(APIConstant.FILE_UPLOAD);
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		boolean flagTemplate = false;
		try {
			if(fileUpload == null){
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_011"));
			}
			rw = new ReadFromExcel(fileUpload.getInputStream(), fileUpload.getOriginalFilename(),
					env.getProperty(APIConstant.PATH_IMPORT_REGIS_AUTODEBIT));
			TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService()
					.getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_AD_TEMPLATE_IMPORT_DATA, APIConstant.REGIS_AUTO_DEBIT_BANK_RESULT_TEMPLATE);
			flagTemplate = rw.isCorrectTemplateHeader(item.getValue(), env.getProperty(APIConstant.PATH_TEMPLATE_BANK_AUTODEBIT), 0);
			
		} catch (IOException ex) {
			logger.info(ex.getMessage());
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_011"));
		}
		
		if(!flagTemplate) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_003"));
		}
		ArrayList<TOmsAutoDebitLmsInf> listUp = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.UPLOAD_LIMIT_TRX));
		List<Map> mapObjectLst = rw.readDataFromExcel(0, 1, 0);
		if(CollectionUtils.isNotEmpty(mapObjectLst)) {
			if(mapObjectLst.size() > limitTrx) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
			}
			for (Map mapData : mapObjectLst){
				AutoDebitRegisBankResultTrxInfo data = DTOConverter.convertToAutoDebitRegisBankResultTrxInfoFromImportRegisBankResultAD(mapData, env);
				TOmsAutoDebitLmsInf inf = getValidationManagerService().checkValidationImportRegisBankResultDA(data);
				if(data.getValid() && inf != null){
					DTOConverter.populateDataImportBankResult(inf, userName);
					listUp.add(inf);
					count++;
				}
				
				lstTrx.add(data);
				countTotal++;
			}
		}
		
		if(countTotal == count){
			getRepositoryManagerService().importAutoDebitBankResultToDB(listUp);
		}
		
		return lstTrx;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#updateFailReasonADTransaction(java.util.Map)
	 */
	@Override
	public List<AutoDebitTrxInfo> updateFailReasonADTransaction(Map<String, Object> inputParams)
			throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		List<AutoDebitTrxInfo> lst = CommonUtil.toListPojo(document, AutoDebitTrxInfo.class);
		ArrayList<TOmsAutoDebitLmsInf> listUp = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.UPLOAD_LIMIT_TRX));
		for(AutoDebitTrxInfo trx : lst) {
			TOmsAutoDebitLmsInf inf = getValidationManagerService().checkValidationUpdateFailReasonADTransaction(trx);
			if(trx.getValid() && inf != null){
				DTOConverter.populateDataUpdateFailReason(inf, userName);
				listUp.add(inf);
				count++;
			}
			countTotal++;
			if(countTotal > limitTrx) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
			}
		}
		if(countTotal == count){
			getRepositoryManagerService().updateAutoDebitFailReasonToDB(listUp);
		}
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#sendSmsForUnRegisADTrx(java.util.Map)
	 */
	@Override
	public List<AutoDebitTrxInfo> sendSmsForUnRegisADTrx(Map<String, Object> inputParams)
			throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		List<AutoDebitTrxInfo> lst = CommonUtil.toListPojo(document, AutoDebitTrxInfo.class);
		
		ArrayList<TOmsAutoDebitLmsInf> listReg = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.UPLOAD_LIMIT_TRX));
		
		for(AutoDebitTrxInfo trx : lst) {
			getValidationManagerService().checkValidationSendSMSForUnRegisADTransaction(trx);
			if(trx.getValid()){
				listReg.add(DTOConverter.populateDataForProcessingSmsUnRegisTrx(trx, userName));
				count++;
			}
			countTotal++;
			if(countTotal > limitTrx) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
			}
		}
		
		if(countTotal == count){
			getRepositoryManagerService().sendSmsForUnRegisADTrxToDB(listReg);
		}
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#sendSmsForRegisADTrx(java.util.Map)
	 */
	@Override
	public List<AutoDebitTrxInfo> sendSmsForRegisADTrx(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		String statusCode = inputParams.get(APIConstant._STATUS_AD_MAP).toString();
		
		List<AutoDebitTrxInfo> lst = CommonUtil.toListPojo(document, AutoDebitTrxInfo.class);
		ArrayList<TOmsAutoDebitLmsInf> listUp = new ArrayList<>();
		int count = 0;
		int countTotal = 0;
		int limitTrx = Integer.valueOf(env.getProperty(APIConstant.UPLOAD_LIMIT_TRX));
		
		if(StringUtils.isBlank(statusCode)) {
			//Sending SMS for AD Regis Trx
			for(AutoDebitTrxInfo trx : lst) {
				TOmsAutoDebitLmsInf inf = getValidationManagerService().checkValidationSendSMSForRegisADTransaction(trx);
				if(trx.getValid() && inf != null){
					DTOConverter.populateDataForProcessingSmsRegisTrx(inf, userName);
					listUp.add(inf);
					count++;
				}
				countTotal++;
				if(countTotal > limitTrx) {
					throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
				}
			}
			if(countTotal == count){
				getRepositoryManagerService().sendSmsForRegisADTrxToDB(listUp);
			}
		} else if(APIConstant.AUTO_DEBIT_STATUS_MAPPING_DONE_BANK_REGISTRATION.equalsIgnoreCase(statusCode)) {
			//Sending SMS for bank registration fail
			for(AutoDebitTrxInfo trx : lst) {
				TOmsAutoDebitLmsInf inf = getValidationManagerService().checkValidationSendSMSForBankRegisFailADTransactionn(trx);
				if(trx.getValid() && inf != null){
					DTOConverter.populateDataForProcessingSmsBankRegisFailTrx(inf, userName);
					listUp.add(inf);
					count++;
				}
				countTotal++;
				if(countTotal > limitTrx) {
					throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), env.getProperty(APIConstant.UPLOAD_LIMIT_TRX)));
				}
			}
			if(countTotal == count){
				getRepositoryManagerService().sendSmsForBankRegisFailADTrxToDB(listUp);
			}
		}
		
		
		return lst;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.service.ADApiService#exportReportByTemplate(java.util.Map)
	 */
	@Override
	public File exportReportByTemplate(Map<String, Object> inputParams) throws BaseException {
		File fileExport = getProcessManagerService().getAdExportReportService().exportReportByTemplate(inputParams);
		if(fileExport == null || !fileExport.exists()) {
			return null;
		}
		return fileExport;
	}

}
