/**
 * 
 */
package com.shinhan.recon.api.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.recon.core.model.BankDailyReportInf;
import com.shinhan.recon.core.model.BankStatemenTrxInfo;
import com.shinhan.recon.core.model.BankStatementFile;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.core.model.LmsTrxInfo;
import com.shinhan.recon.core.model.ReconcileCommonStatementInfo;
import com.shinhan.recon.core.model.SuspenseTrxInf;
import com.shinhan.recon.core.util.DateUtils;

/**
 * @author shds01
 *
 */
@RestController
public class ReconcileController extends BaseController{
	
	/** Begin For Statement File **/
	@RequestMapping(value = "shinhan/service/reconcile/statementFileMas", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public ResponseEntity<Object> getStatementFileMasList(@RequestParam(required = false, defaultValue = "" ) String _uploadDt, Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.UPLOAD_DATE_KEY, StringUtils.isBlank(_uploadDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _uploadDt);
		
		List<BankStatementFile> list = getProcessManagerService()
				.getReconcileApiService().getListStmtFileMasByDate(inputParams);
		
		return triggerSuccessOutPut(list, list.size());
		
	}
	
	@RequestMapping(value = "shinhan/service/reconcile/retry", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.POST)
	public ResponseEntity<Object> retryReconcile(
			@RequestParam(required = true) String _bankCode,
			@RequestBody String document, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.UPLOAD_BANKCODE_KEY, _bankCode);
		boolean flag = getProcessManagerService().getReconcileApiService().retryReconcileByBankcode(inputParams);
		if(!flag){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		return triggerSuccessOutPut(APIConstant.SUCCESS_KEY, JsonObject.class, null);
	}
	
	/** End For Statement File **/

	/** Begin Reconcile Common **/
	
	@RequestMapping(value = "shinhan/service/reconcile/common", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public ResponseEntity<Object> getReconcileCommonInfor(
			@RequestParam(required = true) String _startDt,
			@RequestParam(required = true) String _endDt,
			@RequestParam(required = true) String _bankCode,
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, _bankCode);
		
		ReconcileCommonStatementInfo item = getProcessManagerService().getReconcileApiService().getBankStatementCommonInforByDate(inputParams);
		
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		
		return triggerSuccessOutPut(item, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/reconcile/report", produces = {"application/pdf"}, method = RequestMethod.POST)
	public ResponseEntity<Object> exportReconcileReport(
			@RequestParam(required = true) String _startDt,
			@RequestParam(required = true) String _endDt,
			@RequestParam(required = true) String _bankCode,
			@RequestBody String document, Locale locale) throws BaseException, FileNotFoundException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, _bankCode);
		
		File item = getProcessManagerService().getReconcileApiService().exportReconcileReport(inputParams);
		
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		
		return triggerSuccessResponseFile(item);
	}
	@RequestMapping(value = "shinhan/service/reconcile/pendingreport", produces = {"application/pdf"}, method = RequestMethod.POST)
	public ResponseEntity<Object> exportPendingReport(
			@RequestParam(required = true) String _startDt,
			@RequestParam(required = true) String _endDt,
			@RequestParam(required = false, defaultValue = "") String _bankCode,
			@RequestBody String document, Locale locale) throws BaseException, FileNotFoundException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, _bankCode);
		
		File item = getProcessManagerService().getReconcileApiService().exportPendingReport(inputParams);
		
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		
		return triggerSuccessResponseFile(item);
	}
	@RequestMapping(value = "shinhan/service/reconcile/dailyreport", produces = {"application/pdf"}, method = RequestMethod.POST)
	public ResponseEntity<Object> exportDailyReport(
			@RequestParam(required = true) String _trxDt,
			@RequestBody String document, Locale locale) throws Exception, FileNotFoundException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		inputParams.put(APIConstant.TRX_DATE_KEY, StringUtils.isBlank(_trxDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _trxDt);
		
		File item = getProcessManagerService().getReconcileApiService().exportDailyReport(inputParams);
		
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		
		return triggerSuccessResponseFile(item);
	}
	@RequestMapping(value = "shinhan/service/reconcile/suspensereport", produces = {"application/pdf"}, method = RequestMethod.POST)
	public ResponseEntity<Object> exportSuspenseReport(
			@RequestParam(required = true) String _startDt,
			@RequestParam(required = true) String _type,
			@RequestParam(required = true) String _endDt,
			@RequestParam(required = false, defaultValue = "") String _bankCode,
			@RequestBody String document, Locale locale) throws Exception, FileNotFoundException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, _bankCode);
		inputParams.put(APIConstant._TYPE_KEY, _type);
		
		File item = getProcessManagerService().getReconcileApiService().exportSuspenseReport(inputParams);
		
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		
		return triggerSuccessResponseFile(item);
	}
	
	/** End Reconcile Common **/
	
	/** Begin Statement Transaction **/
	
	@RequestMapping(value = "shinhan/service/reconcile/matchingtrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public ResponseEntity<Object> getStatementTrxList(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			
			@RequestParam(required = false, defaultValue = "") String _ref,
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _cif,
			@RequestParam(required = false, defaultValue = "") String _payMode,
			
			@RequestParam(required = true) String _startDt,
			@RequestParam(required = true) String _endDt,
			@RequestParam(required = true) String _bankCode,
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant.REF_KEY, _ref);
		inputParams.put(APIConstant.LOAN_NO_KEY, _loanNo);
		inputParams.put(APIConstant.PAY_MODE_KEY, _payMode);
		inputParams.put(APIConstant.CIF_KEY, _cif);
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, _bankCode);
		
		List<BankStatementLmsTrxInfo> lst = getProcessManagerService().getReconcileApiService().getListBankStatementTrxByDate(inputParams);
		BigDecimal countTotal = getProcessManagerService().getReconcileApiService().countTotalBankStatementTrxByDate(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
	@RequestMapping(value = "shinhan/service/reconcile/suspensetrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public ResponseEntity<Object> getSuspenseTrxList(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			@RequestParam(required = false, defaultValue = "") String _status,
			@RequestParam(required = false, defaultValue = "") String _bankCode,
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _confirm_yn,
			@RequestParam(required = false, defaultValue = "") String _ref,
			
			@RequestParam(required = true) String _startDt,
			@RequestParam(required = true) String _type,
			@RequestParam(required = true) String _endDt,
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		inputParams.put(APIConstant._STATUS_KEY, _status);
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, _bankCode);
		inputParams.put(APIConstant.LOAN_NO_KEY, _loanNo);
		inputParams.put(APIConstant.FLAG, _confirm_yn);
		inputParams.put(APIConstant._TYPE_KEY, StringUtils.isBlank(_type) ? "0" : _type);
		inputParams.put(APIConstant._REF_NO_KEY, _ref);
		
		List<SuspenseTrxInf> lst = getProcessManagerService().getReconcileApiService().getListSuspenseInf(inputParams);
		BigDecimal countTotal = getProcessManagerService().getReconcileApiService().countTotalSuspenseTrxByDate(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
	@RequestMapping(value = "shinhan/service/reconcile/suspensetrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.PATCH)
	public ResponseEntity<Object> updateSuspenseTrxList(@RequestBody String document, @RequestParam(required = true) boolean _isConfirm, Locale locale) throws BaseException{
		//document = CommonUtil.checkSecureTheToken(env, document);
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.FLAG, _isConfirm);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		List<SuspenseTrxInf> lst = getProcessManagerService().getReconcileApiService().updateListSuspenseTrxByDate(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	@RequestMapping(value = "shinhan/service/reconcile/matchingdisbtrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public ResponseEntity<Object> getMatchingDisbursTrxList(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			
			@RequestParam(required = false, defaultValue = "") String _ref,
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _cif,
			
			@RequestParam(required = true) String _startDt,
			@RequestParam(required = true) String _endDt,
			@RequestParam(required = true) String _bankCode,
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant.REF_KEY, _ref);
		inputParams.put(APIConstant.LOAN_NO_KEY, _loanNo);
		inputParams.put(APIConstant.CIF_KEY, _cif);
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, _bankCode);
		
		List<BankStatementLmsTrxInfo> lst = getProcessManagerService().getReconcileApiService().getMatchingDisburTrxByDate(inputParams);
		BigDecimal countTotal = getProcessManagerService().getReconcileApiService().countTotalDisbursTrxByDate(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
	
	@RequestMapping(value = "shinhan/service/reconcile/matchingtrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.PATCH)
	@ResponseBody
	public ResponseEntity<Object> updateReconcileTrx(@RequestBody String document, @RequestParam(required = true) boolean _isUnmatch, Locale locale) throws BaseException{
		//document = CommonUtil.checkSecureTheToken(env, document);
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.FLAG, _isUnmatch);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		List<BankStatementLmsTrxInfo> lst = getProcessManagerService().getReconcileApiService().updateListBankStatementTrxByDate(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	@RequestMapping(value = "shinhan/service/reconcile/matchingdisbtrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.PATCH)
	@ResponseBody
	public ResponseEntity<Object> updateDisbursReconcileTrx(@RequestBody String document, @RequestParam(required = true) boolean _isUnmatch, Locale locale) throws BaseException{
		//document = CommonUtil.checkSecureTheToken(env, document);
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.FLAG, _isUnmatch);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		List<BankStatementLmsTrxInfo> lst = getProcessManagerService().getReconcileApiService().updateListDisburByDate(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	@RequestMapping(value = "shinhan/service/reconcile/remarkaddinf", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.PATCH)
	@ResponseBody
	public ResponseEntity<Object> updateRemarkReconcileTrx(@RequestBody String document, Locale locale) throws BaseException{
		//document = CommonUtil.checkSecureTheToken(env, document);
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		boolean lst = getProcessManagerService().getReconcileApiService().updateRemarkReconcileTrx(inputParams);
		
		return triggerSuccessOutPut(lst == true ? APIConstant.SUCCESS_KEY : APIConstant.ERROR_KEY, JsonObject.class, null);
	}
	
	
	@RequestMapping(value = "shinhan/service/reconcile/unmatchingtrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public ResponseEntity<Object> getUnMatchStatementTrxList(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			
			@RequestParam(required = false, defaultValue = "") String _ref,
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _statusCode,
			
			@RequestParam(required = true) String _startDt,
			@RequestParam(required = true) String _endDt,
			@RequestParam(required = true) String _bankCode,
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant.REF_KEY, _ref);
		inputParams.put(APIConstant.LOAN_NO_KEY, _loanNo);
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, _bankCode);
		inputParams.put(APIConstant._STATUS_KEY, _statusCode);
		
		List<BankStatemenTrxInfo> lst = getProcessManagerService().getReconcileApiService().getUnmatchListBankStatementTrxByDate(inputParams);
		BigDecimal countTotal = getProcessManagerService().getReconcileApiService().countTotalUnMatchBankStatementTrxByDate(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
	@RequestMapping(value = "shinhan/service/reconcile/unmatchingdisbtrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public ResponseEntity<Object> getUnMatchDisburList(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			
			@RequestParam(required = false, defaultValue = "") String _ref,
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _statusCode,
			
			@RequestParam(required = true) String _startDt,
			@RequestParam(required = true) String _endDt,
			@RequestParam(required = true) String _bankCode,
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant.REF_KEY, _ref);
		inputParams.put(APIConstant.LOAN_NO_KEY, _loanNo);
		inputParams.put(APIConstant._STATUS_KEY, _statusCode);
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, _bankCode);
		
		List<BankStatemenTrxInfo> lst = getProcessManagerService().getReconcileApiService().getUnmatchListDisbByDate(inputParams);
		BigDecimal countTotal = getProcessManagerService().getReconcileApiService().countTotalUnMatchDisbByDate(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
	
	@RequestMapping(value = "shinhan/service/reconcile/unmatchingtrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.PATCH)
	public ResponseEntity<Object> updateUnMatchStatementTrxList(@RequestBody String document,
			Locale locale) throws BaseException {
		//document = CommonUtil.checkSecureTheToken(env, document);
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		List<BankStatemenTrxInfo> lst = getProcessManagerService().getReconcileApiService().setStatusUnmatchListBankStatement(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	@RequestMapping(value = "shinhan/service/reconcile/unmatchingdisbtrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.PATCH)
	public ResponseEntity<Object> updateUnMatchDisbList(@RequestBody String document,
			Locale locale) throws BaseException {
		//document = CommonUtil.checkSecureTheToken(env, document);
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		List<BankStatemenTrxInfo> lst = getProcessManagerService().getReconcileApiService().setStatusUnmatchListDisb(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	
	@RequestMapping(value = "shinhan/service/reconcile/unmatchinglmstrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public ResponseEntity<Object> getUnMatchLMSTrxList(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			
			@RequestParam(required = false, defaultValue = "") String _ref,
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _statusCode,
			@RequestParam(required = false, defaultValue = "") String _cif,
			@RequestParam(required = false, defaultValue = "") String _payMode,
			
			@RequestParam(required = true) String _startDt,
			@RequestParam(required = true) String _endDt,
			@RequestParam(required = true) String _bankCode,
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant.REF_KEY, _ref);
		inputParams.put(APIConstant.LOAN_NO_KEY, _loanNo);
		inputParams.put(APIConstant.PAY_MODE_KEY, _payMode);
		inputParams.put(APIConstant.CIF_KEY, _cif);
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, _bankCode);
		inputParams.put(APIConstant._STATUS_KEY, _statusCode);
		
		List<LmsTrxInfo> lst = getProcessManagerService().getReconcileApiService().getUnmatchListLMSTrxByDate(inputParams);
		BigDecimal countTotal = getProcessManagerService().getReconcileApiService().countTotalUnMatchLMSTrxByDate(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
	@RequestMapping(value = "shinhan/service/reconcile/repmtopsreport", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public ResponseEntity<Object> getRepaymentOpsReport(
			@RequestParam(required = true) String _trxDt,
			@RequestParam(required = true) String _type,
			Locale locale) throws Exception {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		inputParams.put(APIConstant.TRX_DATE_KEY, StringUtils.isBlank(_trxDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _trxDt);
		inputParams.put(APIConstant._TYPE_KEY,_type) ;
		
		BankDailyReportInf lst = getProcessManagerService().getReconcileApiService().getAllBankDailyReport(inputParams);
		
		return triggerSuccessOutPut(lst.getData(),0);
	}
	
	@RequestMapping(value = "shinhan/service/reconcile/unmatchinglmstrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.PATCH)
	public ResponseEntity<Object> updateUnMatchLMSTrxList(@RequestBody String document,
			Locale locale) throws BaseException {
		//document = CommonUtil.checkSecureTheToken(env, document);
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		List<LmsTrxInfo> lst = getProcessManagerService().getReconcileApiService().setStatusUnmatchListLMS(inputParams);
		
		return triggerSuccessOutPut(lst, lst.size());
	}
	/** End Statement Transaction **/
}
