/**
 * 
 */
package com.shinhan.recon.common;

import java.io.File;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.core.model.statement.BankStatementCommonTemplate;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.core.util.WriteToExcelTemplate;
import com.shinhan.recon.report.model.DailyReportHeader;
import com.shinhan.recon.report.model.RepaymentForHeaderReport;
import com.shinhan.recon.report.model.SuspenseReportHeader;
import com.shinhan.recon.report.model.bank.DailyReportData;
import com.shinhan.recon.report.model.bank.RepaymentForBankFooterReport;
import com.shinhan.recon.report.model.bank.RepaymentForBankHeaderReport;
import com.shinhan.recon.report.model.bank.RepaymentForBankMatchingDataReport;
import com.shinhan.recon.report.model.bank.RepaymentForBankReport;
import com.shinhan.recon.report.model.bank.RepaymentForBankUnMatchingDataReport;
import com.shinhan.recon.report.model.bank.SuspenseReportData;
import com.shinhan.recon.report.model.disburs.DisbursalFooterReport;
import com.shinhan.recon.report.model.disburs.DisbursalForBankReport;
import com.shinhan.recon.report.model.disburs.DisbursalHeaderReport;
import com.shinhan.recon.report.model.disburs.DisbursalMatchingDataReport;
import com.shinhan.recon.report.model.disburs.DisbursalUnMatchingDataReport;
import com.shinhan.recon.report.model.nonbank.RepaymentForNonBankFooterReport;
import com.shinhan.recon.report.model.nonbank.RepaymentForNonBankHeaderReport;
import com.shinhan.recon.report.model.nonbank.RepaymentForNonBankMatchingDataReport;
import com.shinhan.recon.report.model.nonbank.RepaymentForNonBankReport;
import com.shinhan.recon.report.model.nonbank.RepaymentForNonBankUnMatchingDataReport;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TMetadata;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;

/**
 * @author shds01
 *
 */
public abstract class AbstractServiceClass extends AbstractRepositoryClass{

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	public Environment env;
	
	@Autowired
	private ProcessManagerService processManagerService;

	@Autowired
	private ValidationManagerService validationManagerService;
	
	/**
	 * @return the processManagerService
	 */
	public ProcessManagerService getProcessManagerService() {
		return processManagerService;
	}

	/**
	 * @param processManagerService the processManagerService to set
	 */
	public void setProcessManagerService(@Qualifier("processManagerService") ProcessManagerService processManagerService) {
		this.processManagerService = processManagerService;
	}
	
	/**
	 * @return the validationManagerService
	 */
	public ValidationManagerService getValidationManagerService() {
		return validationManagerService;
	}

	/**
	 * @param validationManagerService the validationManagerService to set
	 */
	public void setValidationManagerService(@Qualifier("validationManagerService")
		ValidationManagerService validationManagerService) {
		this.validationManagerService = validationManagerService;
	}

	protected Map<String, Entry<String, UnaryOperator<String>>> buildBankStatementMapping(List<String> excelColumn, Field[] bankStatementProperty){
		/**bankStatementMapping : {excel column name} {[property in Statement],[function to parse value on excel to value in property]}**/
		Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping = new HashMap<>();
		
		/*all parser to map value from excel, must map exactly with the index of excel column*/
		Map<Integer, UnaryOperator<String>> parser = new HashMap<>();
		
		/*excelColumn, clientCoporateProperty MUST have same size*/
		for (int columnIndex = 0; columnIndex < excelColumn.size(); columnIndex++) {
			String key = excelColumn.get(columnIndex).trim();
			UnaryOperator<String> parserToConsume = Optional.ofNullable(parser.get(columnIndex)).orElse(UnaryOperator.identity());
			bankStatementMapping.put(key, new SimpleEntry<String, UnaryOperator<String>>(bankStatementProperty[columnIndex].getName(), parserToConsume));
		}
		
		return bankStatementMapping;
	}

	public <T extends BankStatementCommonTemplate> List<T> mapListExcelDataToListBankStatement
					(JsonArray jsonArrayDocument, Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping, Supplier<T> supplier){
		List<T> statements = new ArrayList<>();
		for(JsonElement element: jsonArrayDocument) {
			boolean isContinue = mapOneExcelDataToOneBankStatement(statements, element, bankStatementMapping, supplier);
			//stop scanning excel file if one item don't add into List
			if(!isContinue) {
				break;
			}
		}
		return statements;
	}
	
	private <T extends BankStatementCommonTemplate> Boolean mapOneExcelDataToOneBankStatement
				(List<T> statements, JsonElement element, Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping, Supplier<T> supplier) {
		T statement = supplier.get();
		for(Map.Entry<String, JsonElement> entry : element.getAsJsonObject().entrySet()){
			String excelColumnName = entry.getKey().trim();
			String excelColumnValue = entry.getValue().getAsString();
			if(!bankStatementMapping.containsKey(excelColumnName)) {
				continue;
			}
			
			Entry<String, UnaryOperator<String>> mapper = bankStatementMapping.get(excelColumnName);
			//get value to add into property, and call parser to parse that value
			String valueToAdd = mapper.getValue().apply(excelColumnValue);
			
			//get property of BankStatement
			String field = mapper.getKey();
			if(valueToAdd != null && !CommonUtil.setPropertyIntoObject(statement, valueToAdd, field)) {
				//statement.setError("Configuration error"); TODO
			}
		}
		
		if(StringUtils.isNotBlank(statement.getRef())) {
			statements.add(statement);
			return true;
		}
		return false;
	}
	
	private Workbook loadTemplateAndFillDataReport(String fileSource, List<Object[]> datas, int fromRow) {
		int shiftRow = fromRow + 1;// 1 = (blank row)
		String sheetName = "Data";
		return WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, null, sheetName, fromRow, shiftRow, datas, false);
	}
	private Workbook loadTemplateAndFillDataReport(String fileSource, List<Object[]> datas, int fromRow, String sheetName) {
		int shiftRow = fromRow + 1;// 1 = (blank row)
		return WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, null, sheetName, fromRow, shiftRow, datas, false);
	}
	
	private Workbook fillDataForSectionReport(Workbook wb, List<Object[]> datas, int fromRow) {
		if(CollectionUtils.isEmpty(datas)) {
			return wb;
		}
		int shiftRow = fromRow + 1;// 1 = (blank row)
		String sheetName = "Data";
		return WriteToExcelTemplate.fillDataToSheetTemplate(wb, null, sheetName, fromRow, shiftRow, datas, false);
	}
	
	private Workbook fillDataForSectionPendingReport(Workbook wb, List<Object[]> datas, int fromRow, String sheetName) {
		if(CollectionUtils.isEmpty(datas)) {
			return wb;
		}
		int shiftRow = fromRow + 1;// 1 = (blank row)
		return WriteToExcelTemplate.fillDataToSheetTemplate(wb, null, sheetName, fromRow, shiftRow, datas, false);
	}
	
	private void fillDataTotalRecordForMatchingReport(Workbook wb, BankStatementLmsTrxInfo item, int fromRow) {
		int startRow = fromRow + 1; // 1 = (blank row)
		String sheetName = "Data";
		WriteToExcelTemplate.fillDataToSheetTemplate(wb, sheetName, startRow, DTOConverter.transferDataTotalRecordForReport(item));
	}
	private void fillDataTotalDisbRecordForMatchingReport(Workbook wb, BankStatementLmsTrxInfo item, int fromRow) {
		int startRow = fromRow + 1; // 1 = (blank row)
		String sheetName = "Data";
		WriteToExcelTemplate.fillDataToSheetTemplate(wb, sheetName, startRow, DTOConverter.transferDataTotalRecordDisbForReport(item));
	}
	
	private void fillDataTotalRecordForUnMatchingReport(Workbook wb, BankStatementLmsTrxInfo totalUnmatch, BankStatementLmsTrxInfo grandTotal, int fromRow) {
		int startRow = fromRow + 1; // 1 = (blank row)
		String sheetName = "Data";
		
		List<Object[]> datas = DTOConverter.transferDataTotalRecordForReport(totalUnmatch);
		datas.add(DTOConverter.transferDataGrandTotalRecordForReport(grandTotal));
		
		WriteToExcelTemplate.fillDataToSheetTemplate(wb, sheetName, startRow, datas);
	}
	private void fillDataTotalDisbRecordForUnMatchingReport(Workbook wb, BankStatementLmsTrxInfo totalUnmatch, BankStatementLmsTrxInfo grandTotal, int fromRow) {
		int startRow = fromRow + 1; // 1 = (blank row)
		String sheetName = "Data";
		
		List<Object[]> datas = DTOConverter.transferDataTotalRecordDisbForReport(totalUnmatch);
		datas.add(DTOConverter.transferDataGrandTotalDisbRecordForReport(grandTotal));
		
		WriteToExcelTemplate.fillDataToSheetTemplate(wb, sheetName, startRow, datas);
	}
	
	private void fillDataForHeaderReport(Workbook wb, RepaymentForHeaderReport headerReport) {
		int startRow = 1; // 1 = (blank row)
		String sheetName = "Data";
		//Fill date in second row
		List<Object[]> datas = new ArrayList<>();
		Object[] object = {"From " + headerReport.getFromDt() + " To " + headerReport.getToDt()};
		datas.add(object);
		WriteToExcelTemplate.fillDataToSheetTemplate(wb, sheetName, startRow, datas);
		
		//Fill Bank information
		startRow = 3;
		WriteToExcelTemplate.fillDataToSheetTemplate(wb, sheetName, startRow, DTOConverter.transferDataToFillHeaderForReport(headerReport));
	}
	private void fillDataForHeaderPendingReport(Workbook wb, String srtDate, String endDate, String shtName) {
		int startRow = 2; // 1 = (blank row)
		String sheetName = shtName;
		//Fill date in second row
		List<Object[]> datas = new ArrayList<>();
		Object[] object = {"From " + srtDate + " To " + endDate};
		datas.add(object);
		WriteToExcelTemplate.fillDataToSheetTemplate(wb, sheetName, startRow, datas);
	}
	private void fillDataForHeaderSuspenseReport(Workbook wb, SuspenseReportHeader headerReport) {
		int startRow = 1; // 1 = (blank row)
		String sheetName = "Data";
		//Fill date in second row
		List<Object[]> datas = new ArrayList<>();
		Object[] objectTitle = {"","","","","","",headerReport.getTitle()};
		Object[] objectDate = {"","","","","","",headerReport.getStartDt() + " - " + headerReport.getEndDt()};
		datas.add(objectTitle);
		datas.add(objectDate);
		WriteToExcelTemplate.fillDataToSheetTemplate(wb, sheetName, startRow, datas);
		
	}
	
	private void fillDataLabelReport(Workbook wb, Object[] obj, int startrow) {
		String sheetName = "Data";
		//Fill date in second row
		List<Object[]> datas = new ArrayList<>();
		Object[] object = obj;
		datas.add(object);
		WriteToExcelTemplate.fillDataToSheetTemplate(wb, sheetName, startrow, datas);
		
	}
	
	/** 
	 * Build data to binding report reconcile for Bank Statement
	 * @param bankCode
	 * @param bankName
	 * @param startDt
	 * @param endDt
	 * */
	public RepaymentForBankReport buildDataForRepaymentBankReport(String bankCode, String bankName, String startDt, String endDt) throws BaseException {
		
		RepaymentForBankReport reportData = new RepaymentForBankReport(new RepaymentForBankHeaderReport(startDt, endDt, bankCode, bankName));
		Map<String, Object> inputParams = new HashMap<String, Object>();
		
		/** Start Process build data for matching report */
		RepaymentForBankMatchingDataReport dataMatchingReport = new RepaymentForBankMatchingDataReport();
		inputParams.put(APIConstant._START_DATE_KEY, startDt);
		inputParams.put(APIConstant._END_DATE_KEY, endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, bankCode);
		inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		
		dataMatchingReport.setSumRecord(getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().sumDrAndCrMatchListBankStatementTrxByDateAndBankCode(inputParams));

		reportData.setDataMatchingReport(dataMatchingReport);
		
		
		/** Start Process build data for unmatching report */
		RepaymentForBankUnMatchingDataReport dataUnMatchingReport = new RepaymentForBankUnMatchingDataReport();

		//Sum the debit amount and credit amount of un-matching trx bank statement
		BankStatementLmsTrxInfo sumRecordBank = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().sumDrAndCrUnMatchListBankStatementTrxByDateAndBankCode(inputParams);
		//Sum the debit amount and credit amount of un-matching trx LMS
		BankStatementLmsTrxInfo sumRecordLMS = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().sumDrAndCrUnMatchListLMSTrxByDateAndBankCode(inputParams);
		
		dataUnMatchingReport.setSumRecord(new BankStatementLmsTrxInfo(sumRecordBank.getBankStatemenTrxInfo().getDrAmt(), sumRecordBank.getBankStatemenTrxInfo().getCrAmt()
				, sumRecordLMS.getLmsTrxInfo().getDrAmt(), sumRecordLMS.getLmsTrxInfo().getCrAmt()));
		
		
		reportData.setDataUnMatchingReport(dataUnMatchingReport);
		
		/** End Process build data for unmatching report */
		
		/** Start Process build footer data report */
		
		RepaymentForBankFooterReport footerReport = new RepaymentForBankFooterReport(
				DTOConverter.getGrandBalanceReconcileOfLMSAndBankStatement(
						dataMatchingReport.getSumRecord().getLmsTrxInfo().getDrAmt(), dataMatchingReport.getSumRecord().getLmsTrxInfo().getCrAmt(), 
						dataMatchingReport.getSumRecord().getBankStatemenTrxInfo().getDrAmt(), dataMatchingReport.getSumRecord().getBankStatemenTrxInfo().getCrAmt(), 
						dataUnMatchingReport.getSumRecord().getLmsTrxInfo().getDrAmt(), dataUnMatchingReport.getSumRecord().getLmsTrxInfo().getCrAmt(), 
						dataUnMatchingReport.getSumRecord().getBankStatemenTrxInfo().getDrAmt(), dataUnMatchingReport.getSumRecord().getBankStatemenTrxInfo().getCrAmt()));
		reportData.setFooterReport(footerReport);
		/** End Process build footer data report */
		
		/** Start Process build header data report */
		BigDecimal openBal = getRepositoryManagerService().getUtilityManagerRepositoryService().getOpenBalanceOfBankCodeByDate(inputParams);
		BigDecimal closeBal = openBal.add(
				reportData.getFooterReport().getSumRecord().getBankStatemenTrxInfo().getCrAmt()
					.subtract(reportData.getFooterReport().getSumRecord().getBankStatemenTrxInfo().getDrAmt()));
		reportData.getHeaderReport().setFromDt(startDt);
		reportData.getHeaderReport().setToDt(endDt);
		reportData.getHeaderReport().setOpenBal(openBal);
		reportData.getHeaderReport().setCloseBal(closeBal);
//		reportData.getHeaderReport().setGlCloseBal(closeBal); 
//		reportData.getHeaderReport().setGlOpenBal(openBal); 
		
		/** End Process build header data report */
		return reportData;
	}
	
	/** 
	 * process export the reconcile report for bank statement
	 * @param dataReport
	 * */
	public File exportReconcileRepaymentReportForBank(RepaymentForBankReport dataReport,String bankCode, String bankName, String startDt, String endDt) throws BaseException {
		//Get template file
		TMetadata tMetadata = getMetaByLookupCodeId(getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant._LOOKUP_CODE_BANK_REPORT_VALUE_), bankCode); 
		String endDate =   DateUtils.formatToDate(dataReport.getHeaderReport().getToDt(), DateUtils.dd_MM_YYYY);
		String fileSource = env.getProperty(APIConstant.FOLDER_TEMPLATE_REPORT) + "/" + APIConstant.FILE_BANK_TEMPLATE_REPORT_IN;
		String fileDestinationExport = env.getProperty(APIConstant.FOLDER_EXPORT_REPORT) + "/"+ APIConstant.FILE_BANK_TEMPLATE_REPORT_EXPORT + " " + tMetadata.getValue() 
				+ "_"+ endDate + APIConstant.FILE_TYPE_EXCEL_NEW;
		Map<String, Object> inputParams = new HashMap<String, Object>();
		inputParams.put(APIConstant._START_DATE_KEY, startDt);
		inputParams.put(APIConstant._END_DATE_KEY, endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, bankCode);
		inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		/** Start Process fill data for matching report */
		int blankRow = 1;
		int fromRow = 10; // initial row
		int shiftRow = 0;
		int rowIndexFromMatchingToUnmatchingOMSOtherCase = 5;
		int rowIndexFromOtherCaseBankToOtherCaseLMS = 2;
		int rowIndexFromMatchingToUnmatchingPendingCase = 2;
		int rowIndexFromUnmatchingPendingToCancel = 2;
		int rowIndexFromUnmatchingCancelToFinance = 2;
		int rowIndexFromUnmatchingFinanceToRefund = 2;
		int rowIndexFromUnmatchingRefundToRevert = 2;
		int rowIndexFromUnmatchingRevertToPending = 2;
		List<Object[]> lstMatching = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getMatchListBankStatementTrxByDateAndBankCode(inputParams);
		Workbook wb = loadTemplateAndFillDataReport(fileSource, lstMatching, fromRow);
		
		shiftRow = lstMatching.size(); //array size of last data which import
		fromRow = fromRow + shiftRow; //
		fillDataTotalRecordForMatchingReport(wb, dataReport.getDataMatchingReport().getSumRecord(), fromRow);
		lstMatching = null;
		/** End Process fill data for matching report */
		
		/** Start Process fill data for un-matching report */
			/** Start Un-matching LMS */
			/* OMS Other cases */
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_OTHER_CASE_STATUS);
			List<Object[]> bankLmsOtherCase = getRepositoryManagerService().
												getTomsReconStmtInfManagerRepositoryService().
												getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + rowIndexFromMatchingToUnmatchingOMSOtherCase + blankRow; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankLmsOtherCase, fromRow);
			
			/* Other Case LMS */
			shiftRow = bankLmsOtherCase.size();
			bankLmsOtherCase = null;
			inputParams.put(APIConstant._STATUS_KEY, APIConstant.LMS_OTHER_CASE_STATUS);
			List<Object[]> lmsOtherCaseLst = getRepositoryManagerService().
					getTomsReconLmsInfManagerRepositoryService().
					getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromOtherCaseBankToOtherCaseLMS; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, lmsOtherCaseLst, fromRow);
			/* Pending Trx */
			shiftRow = lmsOtherCaseLst.size();
			bankLmsOtherCase = null;
			inputParams.put(APIConstant._STATUS_KEY, APIConstant.LMS_UPLOADED_PENDING);
			List<Object[]> lmsUploadPendingLst = getRepositoryManagerService().
													getTomsReconLmsInfManagerRepositoryService().
														getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromMatchingToUnmatchingPendingCase; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, lmsUploadPendingLst, fromRow);
			
			/* Cancel Trx */
			shiftRow = lmsUploadPendingLst.size(); //array size of last data which import
			lmsUploadPendingLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			List<Long> stList = new ArrayList<>();
			stList.add(APIConstant.LMS_UPLOAD_PENDING);
			stList.add(APIConstant.LMS_CANCEL_TRX);
			//stList.add(APIConstant.LMS_DUP_TRX);
			inputParams.put(APIConstant._STATUS_KEY, stList);
			List<Object[]> lmsCancelLst = getRepositoryManagerService().
											getTomsReconLmsInfManagerRepositoryService().
												getListTrxByDateAndBankCodeAndStatuses(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingPendingToCancel; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, lmsCancelLst, fromRow);
			/** End Un-matching LMS */
		
			/** Start Un-matching BankStatement */
			/* Finance Trx */
			shiftRow = lmsCancelLst.size(); //array size of last data which import
			lmsCancelLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_FINANCE_STATUS);
			List<Object[]> bankFinanceLst = getRepositoryManagerService().
												getTomsReconStmtInfManagerRepositoryService().
													getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingCancelToFinance; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankFinanceLst, fromRow);
			/* Refund Trx */
			shiftRow = bankFinanceLst.size(); //array size of last data which import
			bankFinanceLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_REFUND_STATUS);
			List<Object[]> bankRefundLst = getRepositoryManagerService().
												getTomsReconStmtInfManagerRepositoryService().
													getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingFinanceToRefund; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankRefundLst, fromRow);
			/* Revert Trx */
			shiftRow = bankRefundLst.size(); //array size of last data which import
			bankRefundLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_REVERT_STATUS);
			List<Object[]> bankRevertLst = getRepositoryManagerService().
												getTomsReconStmtInfManagerRepositoryService().
													getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingRefundToRevert; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankRevertLst, fromRow);
			/* Pending Trx */
			shiftRow = bankRevertLst.size(); //array size of last data which import
			bankRevertLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_PENDING_STATUS);
			List<Object[]> bankPendingLst = getRepositoryManagerService().
												getTomsReconStmtInfManagerRepositoryService().
													getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingRevertToPending; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankPendingLst, fromRow);
			/* Fill Total sum for record */
			shiftRow = bankPendingLst.size(); //array size of last data which import
			bankPendingLst = null;
			fromRow = fromRow + shiftRow; // last data row + last list . size() + (number of between record)
			fillDataTotalRecordForUnMatchingReport(wb, dataReport.getDataUnMatchingReport().getSumRecord(), dataReport.getFooterReport().getSumRecord(), fromRow);
			/** End Un-matching BankStatement */
		
		/** End Process fill data for un-matching report */
		
		/** Start Process fill data for header report */
			fillDataForHeaderReport(wb, dataReport.getHeaderReport());
		/** End Process fill data for header report */
			
		WriteToExcelTemplate.writeWorkbook(wb, fileDestinationExport);
		File file = new File(fileDestinationExport);
		if(!file.exists()) {
			throw new ServiceRuntimeException(env.getProperty("MSG_004"));
		}
		return file;
	}
	
	/** 
	 * Build data to binding report reconcile for Non-Bank Statement
	 * @param bankCode
	 * @param bankName
	 * @param startDt
	 * @param endDt
	 * */
	
	public RepaymentForNonBankReport buildDataForRepaymentNonBankReport(String bankCode, String bankName, String startDt, String endDt) throws BaseException {
		
		RepaymentForNonBankReport reportData = new RepaymentForNonBankReport(new RepaymentForNonBankHeaderReport(startDt, endDt, bankCode, bankName));
		Map<String, Object> inputParams = new HashMap<String, Object>();
		
		/** Start Process build data for matching report */
		RepaymentForNonBankMatchingDataReport dataMatchingReport = new RepaymentForNonBankMatchingDataReport();
		inputParams.put(APIConstant._START_DATE_KEY, startDt);
		inputParams.put(APIConstant._END_DATE_KEY, endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, bankCode);
		inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		//Sum the debit amount and credit amount of matching trx
		dataMatchingReport.setSumRecord(getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().sumDrAndCrMatchListBankStatementTrxByDateAndBankCode(inputParams));
		
		reportData.setDataMatchingReport(dataMatchingReport);
		/** End Process build data for matching report */
		
		/** Start Process build data for unmatching report */
		RepaymentForNonBankUnMatchingDataReport dataUnMatchingReport = new RepaymentForNonBankUnMatchingDataReport();
		
		//Sum the debit amount and credit amount of un-matching trx bank statement
		BankStatementLmsTrxInfo sumRecordBank = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().sumDrAndCrUnMatchListBankStatementTrxByDateAndBankCode(inputParams);
		//Sum the debit amount and credit amount of un-matching trx LMS
		BankStatementLmsTrxInfo sumRecordLMS = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().sumDrAndCrUnMatchListLMSTrxByDateAndBankCode(inputParams);
		
		dataUnMatchingReport.setSumRecord(new BankStatementLmsTrxInfo(sumRecordBank.getBankStatemenTrxInfo().getDrAmt(), sumRecordBank.getBankStatemenTrxInfo().getCrAmt()
				, sumRecordLMS.getLmsTrxInfo().getDrAmt(), sumRecordLMS.getLmsTrxInfo().getCrAmt()));
		
		
		reportData.setDataUnMatchingReport(dataUnMatchingReport);
		
		/** End Process build data for unmatching report */
		
		/** Start Process build footer data report */
		
		RepaymentForNonBankFooterReport footerReport = new RepaymentForNonBankFooterReport(
				DTOConverter.getGrandBalanceReconcileOfLMSAndBankStatement(
						dataMatchingReport.getSumRecord().getLmsTrxInfo().getDrAmt(), dataMatchingReport.getSumRecord().getLmsTrxInfo().getCrAmt(), 
						dataMatchingReport.getSumRecord().getBankStatemenTrxInfo().getDrAmt(), dataMatchingReport.getSumRecord().getBankStatemenTrxInfo().getCrAmt(), 
						dataUnMatchingReport.getSumRecord().getLmsTrxInfo().getDrAmt(), dataUnMatchingReport.getSumRecord().getLmsTrxInfo().getCrAmt(), 
						dataUnMatchingReport.getSumRecord().getBankStatemenTrxInfo().getDrAmt(), dataUnMatchingReport.getSumRecord().getBankStatemenTrxInfo().getCrAmt()));
		reportData.setFooterReport(footerReport);
		/** End Process build footer data report */
		
		/** Start Process build header data report */
		BigDecimal openBal = getRepositoryManagerService().getUtilityManagerRepositoryService().getOpenBalanceOfBankCodeByDate(inputParams);
		BigDecimal closeBal = openBal.add(
				reportData.getFooterReport().getSumRecord().getBankStatemenTrxInfo().getCrAmt()
					.subtract(reportData.getFooterReport().getSumRecord().getBankStatemenTrxInfo().getDrAmt()));
		reportData.getHeaderReport().setFromDt(startDt);
		reportData.getHeaderReport().setToDt(endDt);
		reportData.getHeaderReport().setOpenBal(openBal);
		reportData.getHeaderReport().setCloseBal(closeBal);
		
		/** End Process build header data report */
		return reportData;
	}
	public SuspenseReportData buildDataForSuspenseReport(String bankCode, String startDt, String endDt, long type) throws BaseException {
		Map<String, Object> inputParam = new HashMap<>();
		List<Object[]> pending = new ArrayList<>();
		List<Object[]> done = new ArrayList<>();
		List<Object[]> income = new ArrayList<>();
		
		inputParam.put(APIConstant._BANK_CODE_KEY, bankCode);
		inputParam.put(APIConstant._START_DATE_KEY, startDt);
		inputParam.put(APIConstant._END_DATE_KEY, endDt);
		List<Object[]> List =  getRepositoryManagerService().gettOmsReconSuspInfManagerRepositoryService().getSuspenseListForReport(inputParam);
		SuspenseReportData reportData = new SuspenseReportData();
		SuspenseReportHeader reportHeader = new SuspenseReportHeader();
		if( type == APIConstant._SUSPENSE_RPT ) {
			reportHeader.setTitle("SUSPENSE REPORT");
			reportHeader.setEndDt(endDt);
			reportHeader.setStartDt(startDt);
			List<String> headers = new ArrayList<>();
			headers.add("Suspense Pending");
			headers.add("Suspense Done");
			headers.add("Book Income");
			
			for (Object[] objs : List) {
				if( (long)objs[10] <= 365 ) {
					BigDecimal status = (objs[12] == null ? APIConstant.DEC_ZERO : new BigDecimal(objs[12].toString())); /// the native sql return bigdecimal 
					if(status.compareTo( new BigDecimal(APIConstant._SUSPENSE_DONE_STATUS)) == 0) {
						done.add(objs);
					}else if(status.compareTo(new BigDecimal(APIConstant._SUSPENSE_INCOME_STATUS)) == 0) {
						income.add(objs);
					}else {
						pending.add(objs);
					}
					
				}
				objs[12] = "";
			}
		}else if( type == APIConstant._WRITEOFF_RPT ) {
			reportHeader.setTitle("WRITE OFF REPORT");
			reportHeader.setEndDt(endDt);
			reportHeader.setStartDt(startDt);
			List<String> headers = new ArrayList<>();
			headers.add("Write Off Pending");
			headers.add("Write Off Done ( refunded/reverted/uploaded )");
			headers.add("Book Income");
			for (Object[] objs : List) {
				if( (long)objs[10] > 365 ) {
					BigDecimal status = (objs[12] == null ? APIConstant.DEC_ZERO : new BigDecimal(objs[12].toString())); /// the native sql return bigdecimal 
					if(status.compareTo( new BigDecimal(APIConstant._SUSPENSE_DONE_STATUS)) == 0) {
						done.add(objs);
					}else if(status.compareTo(new BigDecimal(APIConstant._SUSPENSE_INCOME_STATUS)) == 0) {
						income.add(objs);
					}else {
						pending.add(objs);
					}
					
				}
				objs[12] = "";
			}
		}
		reportData.setSuspenseReportHeader(reportHeader);
		reportData.setDone(done);
		reportData.setIncome(income);
		reportData.setPending(pending);
		/** End Process build header data report */
		return reportData;
	}
	public DisbursalForBankReport buildDataForDisbursalReport(String bankCode, String bankName, String startDt, String endDt) throws BaseException {
		
		
		DisbursalForBankReport reportData = new DisbursalForBankReport(new DisbursalHeaderReport(startDt, endDt, bankCode, bankName));
		Map<String, Object> inputParams = new HashMap<String, Object>();
		
		/** Start Process build data for matching report */
		DisbursalMatchingDataReport dataMatchingReport = new DisbursalMatchingDataReport();
		inputParams.put(APIConstant._START_DATE_KEY, startDt);
		inputParams.put(APIConstant._END_DATE_KEY, endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, bankCode);
		inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
		
		dataMatchingReport.setSumRecord(getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().sumDrAndCrMatchListDisbursalTrxByDateAndBankCode(inputParams));
		
		reportData.setDataMatchingReport(dataMatchingReport);
		
		DisbursalUnMatchingDataReport dataUnMatchingReport = new DisbursalUnMatchingDataReport();
		
		//Sum the debit amount and credit amount of un-matching trx bank statement
		BankStatementLmsTrxInfo sumRecordBank = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().sumDrAndCrUnMatchListDisbursalTrxByDateAndBankCode(inputParams);
		//Sum the debit amount and credit amount of un-matching trx LMS
		BankStatementLmsTrxInfo sumRecordLMS = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().sumDrAndCrUnMatchListLMSTrxByDateAndBankCode(inputParams);
		
		dataUnMatchingReport.setSumRecord(new BankStatementLmsTrxInfo(sumRecordBank.getBankStatemenTrxInfo().getDrAmt(), sumRecordBank.getBankStatemenTrxInfo().getCrAmt()
				, sumRecordLMS.getLmsTrxInfo().getDrAmt(), sumRecordLMS.getLmsTrxInfo().getCrAmt()));
		
		
		reportData.setDataUnMatchingReport(dataUnMatchingReport);
		
		/** End Process build data for unmatching report */
		
		/** Start Process build footer data report */
		
		DisbursalFooterReport footerReport = new DisbursalFooterReport(
				DTOConverter.getGrandBalanceReconcileOfLMSAndBankStatement(
						dataMatchingReport.getSumRecord().getLmsTrxInfo().getDrAmt(), dataMatchingReport.getSumRecord().getLmsTrxInfo().getCrAmt(), 
						dataMatchingReport.getSumRecord().getBankStatemenTrxInfo().getDrAmt(), dataMatchingReport.getSumRecord().getBankStatemenTrxInfo().getCrAmt(), 
						dataUnMatchingReport.getSumRecord().getLmsTrxInfo().getDrAmt(), dataUnMatchingReport.getSumRecord().getLmsTrxInfo().getCrAmt(), 
						dataUnMatchingReport.getSumRecord().getBankStatemenTrxInfo().getDrAmt(), dataUnMatchingReport.getSumRecord().getBankStatemenTrxInfo().getCrAmt()));
		reportData.setFooterReport(footerReport);
		/** End Process build footer data report */
		
		/** Start Process build header data report */
		BigDecimal openBal = getRepositoryManagerService().getUtilityManagerRepositoryService().getOpenBalanceOfBankCodeByDate(inputParams);
		BigDecimal closeBal = openBal.add(
				reportData.getFooterReport().getSumRecord().getBankStatemenTrxInfo().getCrAmt()
				.subtract(reportData.getFooterReport().getSumRecord().getBankStatemenTrxInfo().getDrAmt()));
		
		reportData.getHeaderReport().setOpenBal(openBal);
		reportData.getHeaderReport().setCloseBal(closeBal);
//		reportData.getHeaderReport().setGlOpenBal(openBal);
//		reportData.getHeaderReport().setGlCloseBal(closeBal);
		reportData.getHeaderReport().setFromDt(startDt);
		reportData.getHeaderReport().setToDt(endDt);
		/** End Process build header data report */
		return reportData;
	}
	
	/** 
	 * process build data for daily report
	 * @param dataReport
	 * */
	public DailyReportData buildDataForDailyReport( String startDt, String endDt, String trxDt) throws BaseException {
		DailyReportHeader reportHeaderData = new DailyReportHeader();
		DailyReportData dataReport = new DailyReportData();
		Map<String, Object> inputParams = new HashMap<String, Object>();
		/** start load data summary report **/
		inputParams.put(APIConstant.TRX_DATE_KEY, trxDt);
		dataReport.setReconSummaryData(getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getSummaryStatisticInf(inputParams).getData());
		/** end load data summary report **/
		List<String> listHeader = new ArrayList<>();
		listHeader.addAll(DateUtils.getListStringDate(DateUtils.convertDate(startDt, DateUtils.DATEFORMAT ), DateUtils.convertDate(endDt, DateUtils.DATEFORMAT )));
		reportHeaderData.setOpsCollectionHeader(listHeader);
		String str = "";
		for (String string : listHeader) {
			if(!StringUtils.isBlank(string)) {
				str += "'" + string + "'";
				if(!string.equals(endDt)) {
					str += ",";
				}
			}
			
		}
		
		
		/** Start Process build data for matching report */
		
		inputParams.put(APIConstant._START_DATE_KEY, startDt);
		inputParams.put(APIConstant._END_DATE_KEY, endDt);
		inputParams.put(APIConstant.REF_KEY, str);
		List<Object[]> opsDataReport = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getStatisticInf(inputParams).getData();
		dataReport.setDisbursalDailyData(getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getStatisticDisbInf(inputParams).getData());
		dataReport.setDisbursalCollData(getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getDailyCollDisbInf(inputParams).getData());
		dataReport.setStmtCollData(getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getDailyCollStmtInf(inputParams).getData());
		dataReport.setDailyReportHeader(reportHeaderData);
		dataReport.setOpsData(opsDataReport);
		/** End Process build header data report */
		return dataReport;
	}
	
	/** 
	 * process export the daily report
	 * @param dataReport
	 * */
	public File exportDailyReport(DailyReportData dataReport) throws BaseException {
		//Get template file
		String fileSource = env.getProperty(APIConstant.FOLDER_TEMPLATE_REPORT) + "/" + APIConstant.FILE_DAILY_REPORT_IN;
		String fileDestinationExport = env.getProperty(APIConstant.FOLDER_EXPORT_REPORT) + "/" + APIConstant.FILE_DAILY_REPORT_EXPORT
				+ DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss) + APIConstant.FILE_TYPE_EXCEL_NEW;
		/** Start Process fill data for Summary report */
		int blankRow = 1;
		int fromRow = 4; // initial row
		int shiftRow = 0;
		int rowIndexFromSummaryToOpsDataRowHeader = 6;
		int rowIndexFromRowHeaderToOpsDataDisbursal = 2;
		int rowIndexFromOpsDataDisbursalToOpsDataRepayment = 2;
		int rowIndexFromDailyToCollDataRowHeader = 6;
		int rowIndexFromCollDataRowHeaderToCollDisb = 1;
		int rowIndexFromCollDisbToCollStmt = 1;
		Workbook wb = loadTemplateAndFillDataReport(fileSource, dataReport.getReconSummaryData(), fromRow);
		shiftRow = dataReport.getReconSummaryData().size(); //array size of last data which import
		fromRow = fromRow + shiftRow + rowIndexFromSummaryToOpsDataRowHeader; //
		List<String> listHeader = new ArrayList<>();
		listHeader.addAll(dataReport.getDailyReportHeader().getOpsCollectionHeader());
		listHeader.add(0,"");
		listHeader.add(0,"");
		fillDataLabelReport(wb,listHeader.toArray(),fromRow);
		/** start process fill data for disbursal **/
		fromRow = fromRow + rowIndexFromRowHeaderToOpsDataDisbursal; //
		List<Object[]> dataList = dataReport.getDisbursalDailyData();
		List<TMetadata> metadatas = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant._LOOKUP_CODE_BANK_DISB_VALUE_);
		List<Object[]> fillDataDisb = new ArrayList<>();
		for (TMetadata tMetadata : metadatas) {
			
			for (Object[] datas : dataList) {
				if(datas[0].toString().equals(tMetadata.getValue())) {
					fillDataDisb.add(datas);
				}
			}
			Object[] blank = new Object[dataList.get(0).length];
			Arrays.fill(blank, ""); 
			fillDataDisb.add(blank);
			/** blank row **/
		}
		fillDataForSectionReport(wb, fillDataDisb, fromRow);
		/** end process fill data for disbursal **/
		
		/** Start Process fill data for Ops Daily report */
		shiftRow = fillDataDisb.size(); //array size of last data which import
		fromRow = fromRow + shiftRow + rowIndexFromOpsDataDisbursalToOpsDataRepayment; //
		
		dataList = dataReport.getOpsData();
		metadatas = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant._LOOKUP_CODE_BANK_VALUE_);
		List<Object[]> fillData = new ArrayList<>();
		for (TMetadata tMetadata : metadatas) {
			
			for (Object[] datas : dataList) {
				if(datas[0].toString().equals(tMetadata.getValue())) {
					fillData.add(datas);
				}
			}
			Object[] blank = new Object[dataList.get(0).length];
			Arrays.fill(blank, ""); 
			fillData.add(blank);
			/** blank row **/
		}
		fillDataForSectionReport(wb, fillData, fromRow );
		/** end Process fill data for Ops Daily report */	
		shiftRow = fillData.size(); //array size of last data which import
		fromRow = fromRow + shiftRow + rowIndexFromDailyToCollDataRowHeader; //
		List<String> listHeaderCol = new ArrayList<>();
		listHeaderCol.addAll(dataReport.getDailyReportHeader().getOpsCollectionHeader());
		listHeaderCol.add(0,"");
		fillDataLabelReport(wb,listHeaderCol.toArray(),fromRow);
		
		shiftRow = 1; //label list size
		fromRow = fromRow + shiftRow + rowIndexFromCollDataRowHeaderToCollDisb;
		fillDataForSectionReport(wb, dataReport.getDisbursalCollData(), fromRow );
		
		shiftRow = dataReport.getDisbursalCollData().size(); //array size of last data which import
		fromRow = fromRow + shiftRow + rowIndexFromCollDisbToCollStmt;
		fillDataForSectionReport(wb, dataReport.getStmtCollData(), fromRow );
		
		WriteToExcelTemplate.writeWorkbook(wb, fileDestinationExport);
		File file = new File(fileDestinationExport);
		if(!file.exists()) {
			throw new ServiceRuntimeException(env.getProperty("MSG_004"));
		}
		return file;
	}
	/** 
	 * process export the reconcile report for Non-bank statement
	 * @param dataReport
	 * */
	public File exportReconcileRepaymentReportForNonBank(RepaymentForNonBankReport dataReport,String bankCode, String bankName, String startDt, String endDt) throws BaseException {
		//Get template file
		TMetadata tMetadata = getMetaByLookupCodeId(getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant._LOOKUP_CODE_BANK_REPORT_VALUE_), bankCode);
		String endDate =   DateUtils.formatToDate(dataReport.getHeaderReport().getToDt(), DateUtils.dd_MM_YYYY);
		String fileSource = env.getProperty(APIConstant.FOLDER_TEMPLATE_REPORT) + "/" + APIConstant.FILE_NONBANK_TEMPLATE_REPORT_IN;
		String fileDestinationExport = env.getProperty(APIConstant.FOLDER_EXPORT_REPORT) + "/"+ APIConstant.FILE_BANK_TEMPLATE_REPORT_EXPORT + " " +  tMetadata.getValue()
				+"_"+ endDate + APIConstant.FILE_TYPE_EXCEL_NEW;
		Map<String, Object> inputParams = new HashMap<String, Object>();
		inputParams.put(APIConstant._START_DATE_KEY, startDt);
		inputParams.put(APIConstant._END_DATE_KEY, endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, bankCode);
		inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		/** Start Process fill data for matching report */
		int blankRow = 1;
		int fromRow = 10; // initial row
		int shiftRow = 0;
		int rowIndexFromMatchingToUnmatchingOMSotherCase = 5;
		int rowIndexFromUnmatchingLMSotherCaseToMoneyTransit = 2;
		int rowIndexFromUnmatchingMoneyTransitToUploadedPending= 2;
		int rowIndexFromUnmatchingUploadedPendingToCancel = 2;
		int rowIndexFromUnmatchingCancelToCaseHandle = 2;
		int rowIndexFromUnmatchingCaseHandleToFinance = 2;
		int rowIndexFromUnmatchingFinanceToRevert = 2;
		int rowIndexFromUnmatchingRevertToRefund = 2;
		int rowIndexFromUnmatchingRevertToPending = 2;
		List<Object[]> lstMatching = getRepositoryManagerService().
										getTomsReconStmtInfManagerRepositoryService().
											getMatchListBankStatementTrxByDateAndBankCode(inputParams);
		Workbook wb = loadTemplateAndFillDataReport(fileSource, lstMatching, fromRow);
		
		shiftRow = lstMatching.size(); //array size of last data which import
		lstMatching = null;
		fromRow = fromRow + shiftRow; //
		fillDataTotalRecordForMatchingReport(wb, dataReport.getDataMatchingReport().getSumRecord(), fromRow);
		/** End Process fill data for matching report */
		
		/** Start Process fill data for un-matching report */
			/** Start Un-matching LMS */
			/* OMS Other cases */
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_OTHER_CASE_STATUS);
			List<Object[]> bankLmsOtherCase = getRepositoryManagerService().
													getTomsReconStmtInfManagerRepositoryService().
													getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + rowIndexFromMatchingToUnmatchingOMSotherCase + blankRow; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankLmsOtherCase, fromRow);
			
			/* LMS other cases */
			
			shiftRow = bankLmsOtherCase.size(); //array size of last data which import
			bankLmsOtherCase = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant.LMS_OTHER_CASE_STATUS);
			List<Object[]> lmsOthercase = getRepositoryManagerService().
					getTomsReconLmsInfManagerRepositoryService().
					getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingLMSotherCaseToMoneyTransit; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, lmsOthercase, fromRow);
			
			/* Money in transit Trx */
			shiftRow = lmsOthercase.size(); //array size of last data which import
			lmsOthercase = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant.LMS_MONEY_IN_TRANSIT);
			List<Object[]> lmsMoneyTransitLst = getRepositoryManagerService().
													getTomsReconLmsInfManagerRepositoryService().
														getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow+ shiftRow + rowIndexFromUnmatchingLMSotherCaseToMoneyTransit; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, lmsMoneyTransitLst, fromRow);
			/* upload pending Trx */
			shiftRow = lmsMoneyTransitLst.size(); //array size of last data which import
			lmsMoneyTransitLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant.LMS_UPLOADED_PENDING);
			List<Object[]> lmsUploadPendingLst = getRepositoryManagerService().
												 	getTomsReconLmsInfManagerRepositoryService().
												 		getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingMoneyTransitToUploadedPending; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, lmsUploadPendingLst, fromRow);
			/* Cancel Trx */
			shiftRow = lmsUploadPendingLst.size(); //array size of last data which import
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingUploadedPendingToCancel; // last data row + last list . size() + (number of between record)
			lmsUploadPendingLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			List<Long> stList = new ArrayList<>();
			stList.add(APIConstant.LMS_UPLOAD_PENDING);
			stList.add(APIConstant.LMS_CANCEL_TRX);
			//stList.add(APIConstant.LMS_DUP_TRX);
			inputParams.put(APIConstant._STATUS_KEY, stList);
			List<Object[]> lmsCancelLst = getRepositoryManagerService().
												getTomsReconLmsInfManagerRepositoryService().
													getListTrxByDateAndBankCodeAndStatuses(inputParams);
			fillDataForSectionReport(wb, lmsCancelLst, fromRow);
			
			/* Bank Cases Handle */
			shiftRow = lmsCancelLst.size(); //array size of last data which import
			lmsCancelLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_CASE_HANDLED_STATUS);
			List<Object[]> bankCaseHandle = getRepositoryManagerService().
													getTomsReconStmtInfManagerRepositoryService().
													getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingCancelToCaseHandle; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankCaseHandle, fromRow);
			
			/* LMS Cases Handle */
			shiftRow = bankCaseHandle.size(); //array size of last data which import
			bankCaseHandle = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant.LMS_CASE_HANDLED_TRX);
			List<Object[]> lmsCaseHandleLst = getRepositoryManagerService().
												 	getTomsReconLmsInfManagerRepositoryService().
												 		getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingMoneyTransitToUploadedPending; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, lmsCaseHandleLst, fromRow);
			/** End Un-matching LMS */
		
			/** Start Un-matching BankStatement */
			/* Finance Trx */
			shiftRow = lmsCaseHandleLst.size(); //array size of last data which import
			lmsCaseHandleLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_FINANCE_STATUS);
			List<Object[]> bankFinanceLst = getRepositoryManagerService().
												getTomsReconStmtInfManagerRepositoryService().
													getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingCaseHandleToFinance; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankFinanceLst, fromRow);
			/* Revert Trx */
			shiftRow = bankFinanceLst.size(); //array size of last data which import
			bankFinanceLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_REVERT_STATUS);
			List<Object[]> bankRevertLst = getRepositoryManagerService().
												getTomsReconStmtInfManagerRepositoryService().
													getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingFinanceToRevert; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankRevertLst, fromRow);
			/* Refund Trx */
			shiftRow = bankRevertLst.size(); //array size of last data which import
			bankRevertLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_REFUND_STATUS);
			List<Object[]> bankRefundLst = getRepositoryManagerService().
												getTomsReconStmtInfManagerRepositoryService().
													getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingRevertToRefund; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankRefundLst, fromRow);
			/* Pending Trx */
			shiftRow = bankRefundLst.size(); //array size of last data which import
			bankRefundLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_PENDING_STATUS);
			List<Object[]> bankPendingLst = getRepositoryManagerService().
												getTomsReconStmtInfManagerRepositoryService().
													getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingRevertToPending; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankPendingLst, fromRow);
			/* Fill Total sum for record */
			shiftRow = bankPendingLst.size(); //array size of last data which import
			bankPendingLst = null;
			fromRow = fromRow + shiftRow; // last data row + last list . size() + (number of between record)
			fillDataTotalRecordForUnMatchingReport(wb, dataReport.getDataUnMatchingReport().getSumRecord(), dataReport.getFooterReport().getSumRecord(), fromRow);
			/** End Un-matching BankStatement */
		
		/** End Process fill data for un-matching report */
		
		/** Start Process fill data for header report */
			fillDataForHeaderReport(wb, dataReport.getHeaderReport());
		/** End Process fill data for header report */
			
		WriteToExcelTemplate.writeWorkbook(wb, fileDestinationExport);
		File file = new File(fileDestinationExport);
		if(!file.exists()) {
			throw new ServiceRuntimeException(env.getProperty("MSG_004"));
		}
		return file;
	}
	public File exportDisbursalReport(DisbursalForBankReport dataReport,String bankCode, String bankName, String startDt, String endDt) throws BaseException {
		//Get template file
		TMetadata tMetadata = getMetaByLookupCodeId(getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant._LOOKUP_CODE_BANK_DISB_VALUE_), bankCode);
		String endDate =   DateUtils.formatToDate(dataReport.getHeaderReport().getToDt(), DateUtils.dd_MM_YYYY);
		String fileSource = env.getProperty(APIConstant.FOLDER_TEMPLATE_REPORT) + "/" + APIConstant.FILE_DISBURSAL_REPORT_IN;
		String fileDestinationExport = env.getProperty(APIConstant.FOLDER_EXPORT_REPORT) + "/" + APIConstant.FILE_DISBURSAL_REPORT_EXPORT + " " + tMetadata.getValue()
				+"_"+ endDate + APIConstant.FILE_TYPE_EXCEL_NEW;
		Map<String, Object> inputParams = new HashMap<String, Object>();
		inputParams.put(APIConstant._START_DATE_KEY, startDt);
		inputParams.put(APIConstant._END_DATE_KEY, endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, bankCode);
		inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
		/** Start Process fill data for matching report */
		int blankRow = 1;
		int fromRow = 10; // initial row
		int shiftRow = 0;
		int rowIndexFromMatchingToUnmatchingPendingCase = 5;
		int rowIndexFromUnmatchingPendingToExcess = 2;
		int rowIndexFromUnmatchingPendingToFinance = 2;
		int rowIndexFromUnmatchingRefundToReDisburs = 2;
		int rowIndexFromUnmatchingReDisbursToCrShield = 2;
		int rowIndexFromUnmatchingCrShieldToRevert = 2;
		List<Object[]> lstMatching = getRepositoryManagerService().
										gettOmsReconDisbursalInfManagerRepositoryService().
											getMatchListDisbursalByDateAndBankCode(inputParams);
		Workbook wb = loadTemplateAndFillDataReport(fileSource, lstMatching, fromRow);
		
		shiftRow = lstMatching.size(); //array size of last data which import
		lstMatching = null;
		fromRow = fromRow + shiftRow; //
		fillDataTotalDisbRecordForMatchingReport(wb, dataReport.getDataMatchingReport().getSumRecord(), fromRow);
		/** End Process fill data for matching report */
		
		/** Start Process fill data for un-matching report */
			/** Start Un-matching LMS */
			/* Pending Trx */
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			List<Long> stList = new ArrayList<>();
			stList.add(APIConstant.LMS_UPLOAD_PENDING);
			//stList.add(APIConstant.LMS_DUP_TRX);
			inputParams.put(APIConstant._STATUS_KEY, stList);
			List<Object[]> lmsUploadPendingLst = getRepositoryManagerService().
													getTomsReconLmsInfManagerRepositoryService().
													getListTrxByDateAndBankCodeAndStatuses(inputParams);
			fromRow = fromRow + rowIndexFromMatchingToUnmatchingPendingCase + blankRow; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, lmsUploadPendingLst, fromRow);
			/* Excess Money Trx */
			shiftRow = lmsUploadPendingLst.size(); //array size of last data which import
			lmsUploadPendingLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant.LMS_EXCESS_MONEY_STATUS);
			List<Object[]> lmsMoneyExcessLst = getRepositoryManagerService().
													getTomsReconLmsInfManagerRepositoryService().
														getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingPendingToExcess; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, lmsMoneyExcessLst, fromRow);

			/** End Un-matching LMS */
		
			/** Start Un-matching BankStatement */
			/* Pending Trx */
			shiftRow = lmsMoneyExcessLst.size(); //array size of last data which import
			lmsMoneyExcessLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_DISBURSAL_STATUS_PENDING);
			List<Object[]> bankPendingLst = getRepositoryManagerService().
												gettOmsReconDisbursalInfManagerRepositoryService().
													getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingPendingToFinance; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankPendingLst, fromRow);
			
			/* Finance Trx */
			shiftRow = bankPendingLst.size(); //array size of last data which import
			bankPendingLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_FINANCE_STATUS);
			List<Object[]> bankFinanceLst = getRepositoryManagerService().
												gettOmsReconDisbursalInfManagerRepositoryService().
													getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingPendingToFinance; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankFinanceLst, fromRow);
			/* re-disburs Trx */
			shiftRow = bankFinanceLst.size(); //array size of last data which import
			bankFinanceLst = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_DISBURSAL_STATUS_RE_DISB);
			List<Object[]> bankReDisb = getRepositoryManagerService().
											gettOmsReconDisbursalInfManagerRepositoryService().
												getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingRefundToReDisburs; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankReDisb, fromRow);
			/* credit Shield Trx */
			shiftRow = bankReDisb.size(); //array size of last data which import
			bankReDisb = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_DISBURSAL_STATUS_CRSHIELD);
			List<Object[]> bankCrShield = getRepositoryManagerService().
												gettOmsReconDisbursalInfManagerRepositoryService().
													getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingReDisbursToCrShield; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankCrShield, fromRow);
			
			/* revert Trx */
			shiftRow = bankCrShield.size(); //array size of last data which import
			bankCrShield = null;
			if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
				inputParams.remove(APIConstant._STATUS_KEY);
			}
			inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_REVERT_STATUS);
			List<Object[]> bankRevertLst = getRepositoryManagerService().
												gettOmsReconDisbursalInfManagerRepositoryService().
													getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingCrShieldToRevert; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, bankRevertLst, fromRow);
			
			/* Fill Total sum for record */
			shiftRow = bankRevertLst.size(); //array size of last data which import
			bankRevertLst = null;
			fromRow = fromRow + shiftRow; // last data row + last list . size() + (number of between record)
			fillDataTotalDisbRecordForUnMatchingReport(wb, dataReport.getDataUnMatchingReport().getSumRecord(), dataReport.getFooterReport().getSumRecord(), fromRow);
			/** End Un-matching BankStatement */
		
		/** End Process fill data for un-matching report */
		
		/** Start Process fill data for header report */
			fillDataForHeaderReport(wb, dataReport.getHeaderReport());
		/** End Process fill data for header report */
			
		WriteToExcelTemplate.writeWorkbook(wb, fileDestinationExport);
		File file = new File(fileDestinationExport);
		if(!file.exists()) {
			throw new ServiceRuntimeException(env.getProperty("MSG_004"));
		}
		return file;
	}
	public File exportPendingReport(String bankCode, String startDt, String endDt) throws BaseException {
		//Get template file
		List<TMetadata> tMetadataBankReps = new ArrayList<>();  
		List<TMetadata> tMetadataBankDisbs = new ArrayList<>();  
		if(StringUtils.isBlank(bankCode)) {
			tMetadataBankReps.addAll(getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant._LOOKUP_CODE_BANK_VALUE_));
			tMetadataBankDisbs.addAll(getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant._LOOKUP_CODE_BANK_DISB_VALUE_));
		}else {
			TMetadata tMetadata = new TMetadata(null, null, bankCode, null, null, null, null,null);
			tMetadataBankReps.add(tMetadata);
			tMetadataBankDisbs.add(tMetadata);
		}
		String stDate =   DateUtils.formatToDate(startDt, DateUtils.dd_MM_YYYY);
		String endDate =   DateUtils.formatToDate(endDt, DateUtils.dd_MM_YYYY);
		String fileSource = env.getProperty(APIConstant.FOLDER_TEMPLATE_REPORT) + "/" + APIConstant.FILE_PENDING_REPORT_IN;
		String fileDestinationExport = env.getProperty(APIConstant.FOLDER_EXPORT_REPORT) + "/" + APIConstant.FILE_PENDING_REPORT_EXPORT + " " + stDate
		+"_"+ endDate + APIConstant.FILE_TYPE_EXCEL_NEW;
		
		int fromRowRep = 6; // initial row
		int shiftRowRep = 0;
		int blankRow = 1;
		Workbook wbRep = loadTemplateAndFillDataReport(fileSource, null, fromRowRep,APIConstant._REPMT_SHEET_NM);
		for (TMetadata tMetadata : tMetadataBankReps) {
			Map<String, Object> inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant._START_DATE_KEY, startDt);
			inputParams.put(APIConstant._END_DATE_KEY, endDt);
			inputParams.put(APIConstant._BANK_CODE_KEY, tMetadata.getLookupCodeId());
			
			List<Object[]> rs = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getPendingListBankStatementTrxForReport(inputParams);
			shiftRowRep = rs.size();
			fillDataForSectionPendingReport(wbRep, rs, fromRowRep,APIConstant._REPMT_SHEET_NM);
			fromRowRep+= shiftRowRep+blankRow;
		}
		
		int fromRowDisb = 7; // initial row
		int shiftRowDisb = 0;
		//Workbook wbDisb = loadTemplateAndFillDataReport(fileSource, null, fromRowDisb,APIConstant._DISB_SHEET_NM);
		for (TMetadata tMetadata : tMetadataBankDisbs) {
			Map<String, Object> inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant._START_DATE_KEY, startDt);
			inputParams.put(APIConstant._END_DATE_KEY, endDt);
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
			inputParams.put(APIConstant._BANK_CODE_KEY, tMetadata.getLookupCodeId());
			List<Object[]> rsDisb = DTOConverter.getPendingDisbReportList(getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getPendingListDisbursalForReport(inputParams),
																		   getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getPendingListTrxForReport(inputParams));
//			List<Object[]> rsDisb = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getPendingListDisbursalForReport(inputParams);
//			List<Object[]> rsLms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getPendingListTrxForReport(inputParams);
			//shiftRowDisb = (rsDisb.size() > rsLms.size() ? rsDisb.size(): rsLms.size());
			shiftRowDisb = rsDisb.size();
			fillDataForSectionPendingReport(wbRep, rsDisb, fromRowDisb,APIConstant._DISB_SHEET_NM);
			//fillDataForSectionPendingReport(wbRep, rsLms, fromRowDisb,APIConstant._DISB_SHEET_NM);
			fromRowDisb+= shiftRowDisb +blankRow;
		}
		fillDataForHeaderPendingReport(wbRep,startDt,endDt,APIConstant._DISB_SHEET_NM);
		fillDataForHeaderPendingReport(wbRep,startDt,endDt,APIConstant._REPMT_SHEET_NM);
		WriteToExcelTemplate.writeWorkbook(wbRep, fileDestinationExport);
		File file = new File(fileDestinationExport);
		if(!file.exists()) {
			throw new ServiceRuntimeException(env.getProperty("MSG_004"));
		}
		return file;
	}
	public File exportSuspenseReport(String bankCode, String startDt, String endDt, SuspenseReportData suspenseReportData) throws BaseException {
		Map<String, Object> inputParam = new HashMap<>();
		inputParam.put(APIConstant._BANK_CODE_KEY, bankCode);
		inputParam.put(APIConstant._START_DATE_KEY, startDt);
		inputParam.put(APIConstant._END_DATE_KEY, endDt);
		String stDate =   DateUtils.formatToDate(startDt, DateUtils.dd_MM_YYYY);
		String endDate =   DateUtils.formatToDate(endDt, DateUtils.dd_MM_YYYY);
		String fileSource = env.getProperty(APIConstant.FOLDER_TEMPLATE_REPORT) + "/" + APIConstant.FILE_SUSPENSE_REPORT_IN;
		String fileDestinationExport = env.getProperty(APIConstant.FOLDER_EXPORT_REPORT) + "/" + APIConstant.FILE_SUSPENSE_REPORT_EXPORT + " " + stDate
				+"_"+ endDate + APIConstant.FILE_TYPE_EXCEL_NEW;
		
		int fromRow = 6; // initial row
		int shiftRow = 0;
		int rowIndexFromPendingToDone = 3;
		int rowIndexFromDoneToIncome = 3;
		Workbook wb = loadTemplateAndFillDataReport(fileSource, suspenseReportData.getPending(), fromRow);
		
		shiftRow = suspenseReportData.getPending().size();
		fromRow += shiftRow + rowIndexFromPendingToDone;
		fillDataForSectionReport(wb, suspenseReportData.getDone(), fromRow);

		shiftRow = suspenseReportData.getDone().size();
		fromRow += shiftRow + rowIndexFromDoneToIncome;
		fillDataForSectionReport(wb, suspenseReportData.getIncome(), fromRow);
		
		fillDataForHeaderSuspenseReport(wb, suspenseReportData.getSuspenseReportHeader());
		WriteToExcelTemplate.writeWorkbook(wb, fileDestinationExport);
		File file = new File(fileDestinationExport);
		if(!file.exists()) {
			throw new ServiceRuntimeException(env.getProperty("MSG_004"));
		}
		return file;
	}
	
	public  TMetadata getMetaByLookupCodeId(List<TMetadata> list, String bankCode) {
		
		for (TMetadata tMetadata : list) {
			if(tMetadata.getLookupCodeId().equals(bankCode)) {
				return tMetadata;
			}
		}
		return new TMetadata();
	}
	
	/**
	 * @param fileName, return true if the given filename in List
	 */
	public  TBankCommon getBankCommonValByBankCode(String fileName, List<TBankCommon> metadatas) {
		TBankCommon tm = new TBankCommon();
		for (TBankCommon tMetadata : metadatas) {
			if(fileName.startsWith(tMetadata.getBankCode())) {
				tm = tMetadata;
			}
		}
		return tm;
	}
	/**
	 * @param fileName, return true if the given filename in List
	 */
	public  int getBankUploadedFileCount(Collection<File> files, List<TBankCommon> metadatas) {
		int count = 0;
		for (File file : files) {
			for (TBankCommon tBankCommon : metadatas) {
				if(file.getName().startsWith(tBankCommon.getBankCode())) {
					count++;
				}
			}
			
		}
		return count;
	}
	public  Collection<File> getListFileOfBank(Collection<File> files, List<TBankCommon> tBankCommons, String bankCode){
		Collection<File> rs = new ArrayList<>();
		for (File file : files) {
			for (TBankCommon tBankCommon : tBankCommons) {
				if(tBankCommon.getBankAccNuber().equals(bankCode) && file.getName().startsWith(tBankCommon.getBankCode())) {
					rs.add(file);
				}
			}
		}
		return rs;
	}
	/**
	 * @param fileName, return true if the given filename in List
	 */
	public  boolean isFileScanSuccess(String fileName, List<TOmsStmtFileMas> list) {
		for (TOmsStmtFileMas tOmsStmtFileMas : list) {
			if(tOmsStmtFileMas.getFileName().equals(fileName)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * @param fileName, return true if the given filename in List and file status = 10( uploaded successfully )
	 */
	public  boolean isFileUploadSuccess(String fileName, List<TOmsStmtFileMas> list) {
		for (TOmsStmtFileMas tOmsStmtFileMas : list) {
			if(tOmsStmtFileMas.getFileName().equals(fileName) && 
			  ( tOmsStmtFileMas.getFileStatus() == Long.valueOf(APIConstant._UPLOAD_FILE_NORMAL_STATUS) || 
				tOmsStmtFileMas.getFileStatus() == Long.valueOf(APIConstant._UPLOAD_FILE_PENDING_DELETE_STATUS))) {
				return true;
			}
		}
		return false;
	}
	/**
	 * @param Bank code, return list of fileMas if list contains bankcode
	 */
	public  List<TOmsStmtFileMas> getListByBankCode(String bankcode, List<TOmsStmtFileMas> list){
		List<TOmsStmtFileMas> tOmsStmtFileMasList = new ArrayList<>();
		tOmsStmtFileMasList = list.stream().filter(e->e.getBankCode().equals(bankcode)).collect(Collectors.toList());
		return tOmsStmtFileMasList;
	}
	/**
	 * @param Bank code, return list of fileMas if list contains bankcode
	 */
	public  TOmsStmtFileMas getFileMasByFileName(String fileName, List<TOmsStmtFileMas> list){
		TOmsStmtFileMas tOmsStmtFileMasList = new TOmsStmtFileMas();
		for (TOmsStmtFileMas tOmsStmtFileMas : list) {
			if(tOmsStmtFileMas.getFileName().equals(fileName))
				return tOmsStmtFileMas;
		}
		return tOmsStmtFileMasList;
	}
	
	/**
	 * @param bankId, return total bank file
	 */
	public  List<TBankCommon> getBankCommonByBankId(String bankId, List<TBankCommon> OmsCommonValEntitys) {
		List<TBankCommon> commonValEntity = new ArrayList<>();
		for (TBankCommon omsCommonValEntity : OmsCommonValEntitys) {
			if(omsCommonValEntity.getBankAccNuber().equals(bankId)) {
				commonValEntity.add(omsCommonValEntity);
			}
		}
		return commonValEntity;
	}
}







