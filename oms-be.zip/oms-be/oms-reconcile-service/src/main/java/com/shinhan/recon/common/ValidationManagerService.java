/**
 * 
 */
package com.shinhan.recon.common;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.model.BankStatemenTrxInfo;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.core.model.LmsTrxInfo;
import com.shinhan.recon.core.model.ReconcileCommonInf;
import com.shinhan.recon.core.model.SuspenseTrxInf;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.entity.TOmsReconDisburInf;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;

/**
 * @author shds01
 *
 */
@Service("validationManagerService")
public class ValidationManagerService extends AbstractRepositoryClass{

	public HashMap<String, Object> checkValidationUpdateToUnmatch(List<BankStatementLmsTrxInfo> lst, String userName) throws BaseException{
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		Map<String, Object> inputParams;
		ArrayList<TOmsReconStmtInf> smts = new ArrayList<>();
		ArrayList<TOmsStmtFileMas> fileList = new ArrayList<>();
		ArrayList<TOmsReconLmsInf> lmss = new ArrayList<>();
		ArrayList<TOmsReconSuspenseInf> susp = new ArrayList<>();
		for(BankStatementLmsTrxInfo item : lst) {
			
			BankStatemenTrxInfo bankStatemenTrxInfo = item.getBankStatemenTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, bankStatemenTrxInfo.getId());
			TOmsReconStmtInf stmt = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getOne(inputParams);
			inputParams.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
			TOmsStmtFileMas fileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getNewestFileMas(inputParams);
			fileList.add(DTOConverter.setAddInfModForFileMas(bankStatemenTrxInfo.getStatusCode(),stmt,fileMas));
			LmsTrxInfo lmsTrxInfo = item.getLmsTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, lmsTrxInfo.getId());
			TOmsReconLmsInf lms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
			
			Map<String, Object> stmtMap = new HashedMap<>();
			stmtMap.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, stmt.getRefNo());
			stmtMap.put(APIConstant._CR_AMT_KEY, stmt.getCrAmt());
			stmtMap.put(APIConstant._DR_AMT_KEY, stmt.getDrAmt());
			
			List<TOmsReconSuspenseInf> lmsInfs  = getRepositoryManagerService()
					.gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRef(stmtMap);
			for (TOmsReconSuspenseInf tOmsReconSuspenseInf : lmsInfs) {
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_PENDING_STATUS);
				if( bankStatemenTrxInfo.getStatusCode() == APIConstant.LMS_DELETE_TRX ) {
					tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_DELETE_STATUS);
				}
				susp.add(tOmsReconSuspenseInf);
			}
			DTOConverter.setUtilityTOmsReconStmtInfForUnmatch(stmt, bankStatemenTrxInfo.getStatusCode(), userName, new Date(), bankStatemenTrxInfo.getRemarkNote());
			smts.add(stmt);
			DTOConverter.setUtilityTOmsReconLmsInfForUnmatch(lms, lmsTrxInfo.getStatusCode(), userName, new Date(),lmsTrxInfo.getRemarkNote());
			lmss.add(lms);
//			if(APIConstant.LMS_TRX_MATCHED == lms.getStatusCode() && APIConstant._BANK_STATEMENT_MATCH_STATUS == stmt.getStatusCode() 
//					&& stmt.getRefID().equals(lms.getRefID())) {
//				DTOConverter.setUtilityTOmsReconStmtInfForUnmatch(stmt, bankStatemenTrxInfo.getStatusCode(), userName, new Date(), bankStatemenTrxInfo.getRemarkNote());
//				smts.add(stmt);
//				DTOConverter.setUtilityTOmsReconLmsInfForUnmatch(lms, lmsTrxInfo.getStatusCode(), userName, new Date(),lmsTrxInfo.getRemarkNote());
//				lmss.add(lms);
//			}else {
//				rs.put(APIConstant.RESULT_MSG, "Input information is not valid ref_no :" + lms.getRefNo() + " status :" + bankStatemenTrxInfo.getStatusCode());
//				rs.put(APIConstant.RESULT, false);
//				return rs;
//			}
			
		}
		rs.put(APIConstant._BANK_STATEMENT_MATCHING, smts);
		rs.put(APIConstant._BANK_FILE_LIST, fileList);
		rs.put(APIConstant._BANK_LMS_MATCHING, lmss);
		rs.put(APIConstant._BANK_SUSPEND_LIST, susp);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	public HashMap<String, Object> checkValidationUpdateSuspenseTrx(List<SuspenseTrxInf> lst, String userName, boolean isConfirm) throws BaseException{
		HashMap<String, Object> rs = new HashMap<String, Object>();
		HashMap<String, Object> stmtMap = new HashMap<String, Object>();
		List<TOmsReconSuspenseInf> rsLst = new ArrayList<>();
		List<TOmsReconLmsInf> lmsList = new ArrayList<>();
		List<TOmsReconStmtInf> stmtList = new ArrayList<>();
		List<TOmsReconDisburInf> disbList = new ArrayList<>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		Map<String, Object> inputParams = new HashMap<String, Object>();
		for(SuspenseTrxInf item : lst) {
			
			inputParams.put(APIConstant.OMSID, item.getId());
			TOmsReconSuspenseInf stmt = getRepositoryManagerService().gettOmsReconSuspInfManagerRepositoryService().getOne(inputParams);
			stmtMap.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, stmt.getRefNo());
			stmtMap.put(APIConstant._CR_AMT_KEY, stmt.getCrAmt());
			stmtMap.put(APIConstant._DR_AMT_KEY, stmt.getDrAmt());
			stmtMap.put(APIConstant.UPLOAD_TRXTYPE_KEY,APIConstant.LMS_TRX_TYPE_REPAYMENT);
			if( isConfirm ) {
				DTOConverter.setUtilityTOmsReconSuspenseInfForConfirm(stmt, userName,  new Date(), item.getRemarkNote());
			}else {
				DTOConverter.setUtilityTOmsReconSuspenseInfForUpdate(stmt,item.getStatus(), userName,  new Date(), item.getRemarkNote());
			}
			if( !StringUtils.isBlank(item.getSuspenseType())) {
				stmt.setSuspenseType(item.getSuspenseType());
			}
			lmsList.addAll(getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getListLmsTrxMatchAmount(stmtMap));
			for (TOmsReconLmsInf lms : lmsList) {
				lms.setRemarkNote(item.getRemarkNote());
			}
			stmtList.addAll(getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getStatementByRevertRef(stmtMap));
			for (TOmsReconStmtInf tOmsReconStmtInf : stmtList) {
				tOmsReconStmtInf.setRemarkNote(item.getRemarkNote());
			}
			disbList.addAll(getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getDisburByRefNo(stmtMap));
			for (TOmsReconDisburInf tOmsReconStmtInf : disbList) {
				tOmsReconStmtInf.setRemarkNote(item.getRemarkNote());
			}
			rsLst.add(stmt);
			
		}
		rs.put(APIConstant._BANK_DISBURS_MATCHED, disbList);
		rs.put(APIConstant._BANK_SUSPEND_LIST, rsLst);
		rs.put(APIConstant._BANK_STATEMENT_MATCHING, stmtList);
		rs.put(APIConstant._BANK_LMS_MATCHING, lmsList);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	public HashMap<String, Object> checkValidationUpdateDisbToUnmatch(List<BankStatementLmsTrxInfo> lst, String userName) throws BaseException{
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		Map<String, Object> inputParams;
		ArrayList<TOmsReconDisburInf> smts = new ArrayList<>();
		ArrayList<TOmsReconLmsInf> lmss = new ArrayList<>();
		ArrayList<TOmsStmtFileMas> fileList = new ArrayList<>();
		
		for(BankStatementLmsTrxInfo item : lst) {
			
			BankStatemenTrxInfo bankStatemenTrxInfo = item.getBankStatemenTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, bankStatemenTrxInfo.getId());
			TOmsReconDisburInf stmt = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getOne(inputParams);
			inputParams.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
			TOmsStmtFileMas fileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getNewestFileMas(inputParams);
			LmsTrxInfo lmsTrxInfo = item.getLmsTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, lmsTrxInfo.getId());
			TOmsReconLmsInf lms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
			DTOConverter.setAddDisbInfModForFileMas(bankStatemenTrxInfo.getStatusCode(),stmt,fileMas);
			DTOConverter.setAddDisbLMSInfModForFileMas(bankStatemenTrxInfo.getStatusCode(),stmt.getStatusCode(),lms,fileMas);
			fileList.add(fileMas);
			
			DTOConverter.setUtilityTDisburForUnmatch(stmt, bankStatemenTrxInfo.getStatusCode(), userName, new Date(), bankStatemenTrxInfo.getRemarkNote());
			smts.add(stmt);
			DTOConverter.setUtilityTOmsReconLmsInfForUnmatch(lms, lmsTrxInfo.getStatusCode(), userName, new Date(),lmsTrxInfo.getRemarkNote());
			lmss.add(lms);
			
//			if(APIConstant.LMS_TRX_MATCHED == lms.getStatusCode() && APIConstant._BANK_STATEMENT_MATCH_STATUS == stmt.getStatusCode() 
//					&& stmt.getRefID().equals(lms.getRefID())) {
//				DTOConverter.setUtilityTDisburForUnmatch(stmt, bankStatemenTrxInfo.getStatusCode(), userName, new Date(), bankStatemenTrxInfo.getRemarkNote());
//				smts.add(stmt);
//				DTOConverter.setUtilityTOmsReconLmsInfForUnmatch(lms, lmsTrxInfo.getStatusCode(), userName, new Date(),lmsTrxInfo.getRemarkNote());
//				lmss.add(lms);
//				continue;
//			}else {
//				rs.put(APIConstant.RESULT_MSG, "Input information is not valid ref_no :" + lms.getRefNo() + " status :" + bankStatemenTrxInfo.getStatusCode());
//				rs.put(APIConstant.RESULT, false);
//				return rs;
//			}
		}
		rs.put(APIConstant._BANK_STATEMENT_MATCHING, smts);
		rs.put(APIConstant._BANK_FILE_LIST, fileList);
		rs.put(APIConstant._BANK_LMS_MATCHING, lmss);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	
	public HashMap<String, Object> checkValidationUpdateToMatch(List<BankStatementLmsTrxInfo> lst, String userName) throws BaseException{
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		BigDecimal lmsAmt = APIConstant.DEC_ZERO;
		BigDecimal stmtAmt = APIConstant.DEC_ZERO;
		Map<String, Object> inputParams;
		List<Long> tmplms = new ArrayList<>();
		List<Long> tmpstmt = new ArrayList<>();
		ArrayList<TOmsReconStmtInf> smts = new ArrayList<>();
		ArrayList<TOmsReconLmsInf> lmss = new ArrayList<>();
		ArrayList<TOmsStmtFileMas> fileList = new ArrayList<>();
		ArrayList<TOmsReconSuspenseInf> susp = new ArrayList<>();
		String refId = userName + DateUtils.getSystemDateStr(DateUtils.ddMMyyyyhhmmssSSSSSS);
		for(BankStatementLmsTrxInfo item : lst) {
			
			BankStatemenTrxInfo bankStatemenTrxInfo = item.getBankStatemenTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, bankStatemenTrxInfo.getId());
			TOmsReconStmtInf stmt = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getOne(inputParams);
			inputParams.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
			TOmsStmtFileMas fileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getNewestFileMas(inputParams);
			fileList.add(DTOConverter.setAddInfModForFileMas(bankStatemenTrxInfo.getStatusCode(),stmt,fileMas));
			if(!tmpstmt.contains(stmt.getId())) {
				stmtAmt =stmtAmt.add(stmt.getCrAmt());
				tmpstmt.add(stmt.getId());
			}
			LmsTrxInfo lmsTrxInfo = item.getLmsTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, lmsTrxInfo.getId());
			TOmsReconLmsInf lms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
			if(!tmplms.contains(lms.getId())) {
				lmsAmt= lmsAmt.add(lms.getDrAmt());
				tmplms.add(lms.getId());
			}
			if(bankStatemenTrxInfo.getStatusCode() != lmsTrxInfo.getStatusCode() || 
			   bankStatemenTrxInfo.getStatusCode() != lmsTrxInfo.getStatusCode() || 
			   ( bankStatemenTrxInfo.getStatusCode() != APIConstant._BANK_STATEMENT_MATCH_STATUS  )){
				rs.put(APIConstant.RESULT, false);
				rs.put(APIConstant.RESULT_MSG, "Input information is not valid ref_no :" + lms.getRefNo() + " status :" + bankStatemenTrxInfo.getStatusCode());
				return rs;
			}
			Map<String, Object> stmtMap = new HashedMap<>();
			stmtMap.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, stmt.getRefNo());
			stmtMap.put(APIConstant._CR_AMT_KEY, stmt.getCrAmt());
			stmtMap.put(APIConstant._DR_AMT_KEY, stmt.getDrAmt());
			
			List<TOmsReconSuspenseInf> lmsInfs  = getRepositoryManagerService()
					.gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRef(stmtMap);
			stmtMap.put(APIConstant._REF_NO_KEY, lms.getRefNo());
			stmtMap.put(APIConstant._DR_AMT_KEY, lms.getDrAmt());
			stmtMap.put(APIConstant._CR_AMT_KEY, lms.getCrAmt());
			lmsInfs.addAll(getRepositoryManagerService().gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRevertRef(stmtMap));
			for (TOmsReconSuspenseInf tOmsReconSuspenseInf : lmsInfs) {
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_DONE_STATUS);
				susp.add(tOmsReconSuspenseInf);
			}
			
			DTOConverter.setUtilityTOmsReconStmtInfForMatch(stmt,bankStatemenTrxInfo.getStatusCode(), refId, userName, new Date(),bankStatemenTrxInfo.getRemarkNote());
			smts.add(stmt);
			DTOConverter.setUtilityTOmsReconLmsInfForMatch(lms,bankStatemenTrxInfo.getStatusCode(), refId, userName, new Date(),lmsTrxInfo.getRemarkNote());
			lmss.add(lms);
		}
		if(lmsAmt.compareTo(stmtAmt) != 0) {
			rs.put(APIConstant.RESULT_MSG, "Input information is not valid, please check reconciliation amount ");
			rs.put(APIConstant.RESULT, false);
			return rs;
		}
		rs.put(APIConstant._BANK_STATEMENT_MATCHING, smts);
		rs.put(APIConstant._BANK_FILE_LIST, fileList);
		rs.put(APIConstant._BANK_LMS_MATCHING, lmss);
		rs.put(APIConstant._BANK_SUSPEND_LIST, susp);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	public HashMap<String, Object> checkValidationUpdateDisbToMatch(List<BankStatementLmsTrxInfo> lst, String userName) throws BaseException{
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		BigDecimal lmsAmt = APIConstant.DEC_ZERO;
		BigDecimal stmtAmt = APIConstant.DEC_ZERO;
		Map<String, Object> inputParams;
		ArrayList<TOmsReconDisburInf> smts = new ArrayList<>();
		ArrayList<TOmsReconLmsInf> lmss = new ArrayList<>();
		List<Long> tmplms = new ArrayList<>();
		List<Long> tmpstmt = new ArrayList<>();
		ArrayList<TOmsStmtFileMas> fileList = new ArrayList<>();
		ArrayList<TOmsReconSuspenseInf> susp = new ArrayList<>();
		String refID = userName + DateUtils.getSystemDateStr(DateUtils.ddMMyyyyhhmmssSSSSSS);
		for(BankStatementLmsTrxInfo item : lst) {
			
			BankStatemenTrxInfo bankStatemenTrxInfo = item.getBankStatemenTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, bankStatemenTrxInfo.getId());
			TOmsReconDisburInf stmt = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getOne(inputParams);
			inputParams.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
			TOmsStmtFileMas fileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getNewestFileMas(inputParams);
			LmsTrxInfo lmsTrxInfo = item.getLmsTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, lmsTrxInfo.getId());
			TOmsReconLmsInf lms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
			DTOConverter.setAddDisbInfModForFileMas(bankStatemenTrxInfo.getStatusCode(),stmt,fileMas);
			DTOConverter.setAddDisbLMSInfModForFileMas(bankStatemenTrxInfo.getStatusCode(),stmt.getStatusCode(),lms,fileMas);
			fileList.add(fileMas);
			if(!tmpstmt.contains(stmt.getId())) {
				stmtAmt= stmtAmt.add(stmt.getDrAmt());
				tmpstmt.add(stmt.getId());
			}
			if(!tmplms.contains(lms.getId())) {
				lmsAmt = lms.getCrAmt();
				tmplms.add(lms.getId());
			}
			
			
			if(bankStatemenTrxInfo.getStatusCode() != lmsTrxInfo.getStatusCode() || 
			   bankStatemenTrxInfo.getStatusCode() != lmsTrxInfo.getStatusCode() || 
			   ( bankStatemenTrxInfo.getStatusCode() != APIConstant._BANK_STATEMENT_MATCH_STATUS  )){
				rs.put(APIConstant.RESULT, false);
				rs.put(APIConstant.RESULT_MSG, "Input information is not valid ref_no :" + lms.getRefNo() + " status :" + lms.getStatusCode());
				return rs;
			}
			Map<String, Object> stmtMap = new HashedMap<>();
			stmtMap.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, stmt.getRefNo());
			stmtMap.put(APIConstant._CR_AMT_KEY, stmt.getCrAmt());
			stmtMap.put(APIConstant._DR_AMT_KEY, stmt.getDrAmt());
			
			List<TOmsReconSuspenseInf> lmsInfs  = getRepositoryManagerService()
					.gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRef(stmtMap);
			stmtMap.put(APIConstant._REF_NO_KEY, lms.getRefNo());
			stmtMap.put(APIConstant._DR_AMT_KEY, lms.getDrAmt());
			stmtMap.put(APIConstant._CR_AMT_KEY, lms.getCrAmt());
			lmsInfs.addAll(getRepositoryManagerService().gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRevertRef(stmtMap));
			for (TOmsReconSuspenseInf tOmsReconSuspenseInf : lmsInfs) {
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_DONE_STATUS);
				susp.add(tOmsReconSuspenseInf);
			}
			DTOConverter.setUtilityDisburForMatch(stmt,refID, userName, new Date(),bankStatemenTrxInfo.getRemarkNote());
			smts.add(stmt);
			DTOConverter.setUtilityTOmsReconLmsInfForMatch(lms, refID, userName, new Date(),lmsTrxInfo.getRemarkNote());
			lmss.add(lms);
		}
		if(lmsAmt.compareTo(stmtAmt) != 0) {
			rs.put(APIConstant.RESULT_MSG, "Input information is not valid, please check reconciliation amount ");
			rs.put(APIConstant.RESULT, false);
			return rs;
		}
		rs.put(APIConstant._BANK_STATEMENT_MATCHING, smts);
		rs.put(APIConstant._BANK_SUSPEND_LIST, susp);
		rs.put(APIConstant._BANK_FILE_LIST, fileList);
		rs.put(APIConstant._BANK_LMS_MATCHING, lmss);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	
	public HashMap<String, Object> checkValidationUpdateStatusBankStatement(List<BankStatemenTrxInfo> lst, String userName) throws BaseException {
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		Map<String, Object> inputParams;
		ArrayList<TOmsReconStmtInf> smts = new ArrayList<>();
		ArrayList<TOmsReconSuspenseInf> susp = new ArrayList<>();
		ArrayList<TOmsStmtFileMas> fileList = new ArrayList<>();
		for(BankStatemenTrxInfo info : lst) {
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, info.getId());
			TOmsReconStmtInf stmt = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getOne(inputParams);
			
			inputParams.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
			TOmsStmtFileMas fileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getNewestFileMas(inputParams);
			fileList.add(DTOConverter.setAddInfModForFileMas(info.getStatusCode(),stmt ,fileMas));
			
			if(APIConstant._BANK_STATEMENT_MATCH_STATUS == stmt.getStatusCode() || APIConstant._BANK_STATEMENT_MATCH_STATUS == info.getStatusCode() ) {
				rs.put(APIConstant.RESULT_MSG, "Input information is not valid, please check status["+ stmt.getStatusCode() + "]");
				rs.put(APIConstant.RESULT, false);
				return rs;
			}
			Map<String, Object> stmtMap = new HashedMap<>();
			stmtMap.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, stmt.getRefNo());
			stmtMap.put(APIConstant._CR_AMT_KEY, stmt.getCrAmt());
			stmtMap.put(APIConstant._DR_AMT_KEY, stmt.getDrAmt());
			List<TOmsReconSuspenseInf> lmsInfs  = getRepositoryManagerService()
					.gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRef(stmtMap);
			for (TOmsReconSuspenseInf tOmsReconSuspenseInf : lmsInfs) {
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_DONE_STATUS);
				if( APIConstant.LMS_DELETE_TRX == info.getStatusCode()  ) {
					tOmsReconSuspenseInf.setStatusCode(APIConstant.LMS_DELETE_TRX);
				}
				susp.add(tOmsReconSuspenseInf);
			}
			DTOConverter.setUtilityTOmsReconStmtInfForChangingStatus(stmt, info, userName, new Date());
			smts.add(stmt);
		}
		rs.put(APIConstant._BANK_STATEMENT_UNMATCHING, smts);
		rs.put(APIConstant._BANK_FILE_LIST, fileList);
		rs.put(APIConstant._BANK_SUSPEND_LIST, susp);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	public HashMap<String, Object> checkValidationUpdateStatusDisb(List<BankStatemenTrxInfo> lst, String userName) throws BaseException {
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		Map<String, Object> inputParams;
		ArrayList<TOmsReconDisburInf> smts = new ArrayList<>();
		ArrayList<TOmsReconSuspenseInf> susp = new ArrayList<>();
		ArrayList<TOmsStmtFileMas> fileList = new ArrayList<>();
		for(BankStatemenTrxInfo info : lst) {
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, info.getId());
			TOmsReconDisburInf stmt = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getOne(inputParams);
			
			inputParams.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
			TOmsStmtFileMas fileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getNewestFileMas(inputParams);
			DTOConverter.setAddDisbInfModForFileMas(info.getStatusCode(),stmt,fileMas);
			fileList.add(fileMas);
			if(APIConstant._BANK_STATEMENT_MATCH_STATUS == stmt.getStatusCode() || APIConstant._BANK_STATEMENT_MATCH_STATUS == info.getStatusCode() ) {
				rs.put(APIConstant.RESULT_MSG, "Input information is not valid, please check status["+ stmt.getStatusCode() + "]");
				rs.put(APIConstant.RESULT, false);
				return rs;
			}
			Map<String, Object> stmtMap = new HashedMap<>();
			stmtMap.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, stmt.getRefNo());
			stmtMap.put(APIConstant._CR_AMT_KEY, stmt.getCrAmt());
			stmtMap.put(APIConstant._DR_AMT_KEY, stmt.getDrAmt());
			List<TOmsReconSuspenseInf> lmsInfs  = getRepositoryManagerService()
					.gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRef(stmtMap);
			for (TOmsReconSuspenseInf tOmsReconSuspenseInf : lmsInfs) {
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_DONE_STATUS);
				if( APIConstant.LMS_DELETE_TRX == info.getStatusCode()  ) {
					tOmsReconSuspenseInf.setStatusCode(APIConstant.LMS_DELETE_TRX);
				}
				susp.add(tOmsReconSuspenseInf);
			}
			DTOConverter.setUtilityDisbForChangingStatus(stmt, info, userName, new Date());
			smts.add(stmt);
		}
		rs.put(APIConstant._BANK_SUSPEND_LIST, susp);
		rs.put(APIConstant._BANK_STATEMENT_UNMATCHING, smts);
		rs.put(APIConstant._BANK_FILE_LIST, fileList);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	
	public HashMap<String, Object> checkValidationUpdateStatusLMS(List<LmsTrxInfo> lst, String userName) throws BaseException {
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		Map<String, Object> inputParams;
		ArrayList<TOmsReconLmsInf> lmss = new ArrayList<>();
		ArrayList<TOmsReconSuspenseInf> susp = new ArrayList<>();
		for(LmsTrxInfo info : lst) {
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, info.getId());
			TOmsReconLmsInf lms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
			if(APIConstant.LMS_TRX_MATCHED == lms.getStatusCode() || APIConstant.LMS_TRX_MATCHED == info.getStatusCode() ) {
				rs.put(APIConstant.RESULT_MSG, "Input information is not valid, please check status["+ lms.getStatusCode() + "]" + " ref_no["+ lms.getRefNo() + "]");
				rs.put(APIConstant.RESULT, false);
				return rs;
			}
			
			DTOConverter.setUtilityTOmsReconLmsInfForChangingStatus(lms, info, userName, new Date());
			lmss.add(lms);
			Map<String, Object> stmtMap = new HashedMap<>();
			stmtMap.put(APIConstant._BANK_CODE_KEY, lms.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, lms.getRefNo());
			stmtMap.put(APIConstant._DR_AMT_KEY, lms.getDrAmt());
			stmtMap.put(APIConstant._CR_AMT_KEY, lms.getCrAmt());
			
			List<TOmsReconSuspenseInf> lmsInfs  = getRepositoryManagerService()
					.gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRevertRef(stmtMap);
			for (TOmsReconSuspenseInf tOmsReconSuspenseInf : lmsInfs) {
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_DONE_STATUS);
				susp.add(tOmsReconSuspenseInf);
			}
			
		}
		rs.put(APIConstant._BANK_SUSPEND_LIST, susp);
		rs.put(APIConstant._BANK_LMS_UNMATCHING, lmss);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	public HashMap<String, Object> checkUpdateRemark(List<ReconcileCommonInf> lst, String userName) throws BaseException {
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			rs.put(APIConstant.RESULT_MSG, "Input information is empty");
			return rs;
		}
		Map<String, Object> inputParams;
		Map<String, Object> stmtMap =  new HashedMap<>();
		ArrayList<TOmsReconLmsInf> lmss = new ArrayList<>();
		List<TOmsReconStmtInf> stmts = new ArrayList<>();
		List<TOmsReconSuspenseInf> lmsInfs = new ArrayList<>();
		List<TOmsReconDisburInf> disbs = new ArrayList<>();
		
		for(ReconcileCommonInf info : lst) {
			switch (info.getType()) {
				case APIConstant._STMT_:
					inputParams = new HashMap<String, Object>();
					inputParams.put(APIConstant.OMSID, info.getId());
					TOmsReconStmtInf stmt = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getOne(inputParams);
					stmtMap.put(APIConstant._BANK_CODE_KEY, stmt.getBankCode());
					stmtMap.put(APIConstant._REF_NO_KEY, stmt.getRefNo());
					stmtMap.put(APIConstant._CR_AMT_KEY, stmt.getCrAmt());
					stmtMap.put(APIConstant._DR_AMT_KEY, stmt.getDrAmt());
					lmsInfs  = getRepositoryManagerService()
							.gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRef(stmtMap);
					for (TOmsReconSuspenseInf sus : lmsInfs) {
						sus.setRemarkNote(info.getRemarkNote());
					}
					stmt.setRemarkNote(info.getRemarkNote());
					stmts.add(stmt);
					break;
				case APIConstant._LMS_:
					inputParams = new HashMap<String, Object>();
					inputParams.put(APIConstant.OMSID, info.getId());
					TOmsReconLmsInf lms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
					stmtMap.remove(APIConstant._REF_NO_KEY);
					stmtMap.put(APIConstant._BANK_CODE_KEY, lms.getBankCode());
					stmtMap.put(APIConstant._REF_NO_KEY, lms.getRefNo());
					stmtMap.put(APIConstant._DR_AMT_KEY, lms.getDrAmt());
					stmtMap.put(APIConstant._CR_AMT_KEY, lms.getCrAmt());
					lmsInfs = getRepositoryManagerService().gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRevertRef(stmtMap);
					for (TOmsReconSuspenseInf sus : lmsInfs) {
						sus.setRemarkNote(info.getRemarkNote());
					}
					lms.setRemarkNote(info.getRemarkNote());
					lmss.add(lms);
					break;
				case APIConstant._DISB_:
					inputParams = new HashMap<String, Object>();
					inputParams.put(APIConstant.OMSID, info.getId());
					TOmsReconDisburInf disb = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getOne(inputParams);
					disb.setRemarkNote(info.getRemarkNote());
					stmtMap.remove(APIConstant._REF_NO_KEY);
					stmtMap.put(APIConstant._BANK_CODE_KEY, disb.getBankCode());
					stmtMap.put(APIConstant._REF_NO_KEY, disb.getRefNo());
					stmtMap.put(APIConstant._DR_AMT_KEY, disb.getDrAmt());
					stmtMap.put(APIConstant._CR_AMT_KEY, disb.getCrAmt());
					lmsInfs = getRepositoryManagerService().gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRevertRef(stmtMap);
					for (TOmsReconSuspenseInf sus : lmsInfs) {
						sus.setRemarkNote(info.getRemarkNote());
					}
					disbs.add(disb);
					break;
			}
			
		}
		rs.put(APIConstant._BANK_SUSPEND_LIST, lmsInfs);
		rs.put(APIConstant._BANK_LMS_MATCHING, lmss);
		rs.put(APIConstant._BANK_STATEMENT_MATCHING, stmts);
		rs.put(APIConstant._BANK_DISBURS_MATCHED, disbs);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
}
