package com.shinhan.recon.core.model.statement;

public class NonBankReconViettelTemplate {
	
	private String STT;
	private String channelId;
	private String viettelBankCode;
	private String viettelBankName;
	private String ref;
	private String exntRef;
	private String loanNo;
	private String credit;
	private String trxDt;
	public NonBankReconViettelTemplate() {
		super();
		// TODO Auto-generated constructor stub
	}
	public NonBankReconViettelTemplate(String sTT, String channelId, String viettelBankCode, String viettelBankName,
			String ref, String exntRef, String loanNo, String credit, String trxDt) {
		super();
		STT = sTT;
		this.channelId = channelId;
		this.viettelBankCode = viettelBankCode;
		this.viettelBankName = viettelBankName;
		this.ref = ref;
		this.exntRef = exntRef;
		this.loanNo = loanNo;
		this.credit = credit;
		this.trxDt = trxDt;
	}
	public String getSTT() {
		return STT;
	}
	public void setSTT(String sTT) {
		STT = sTT;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getViettelBankCode() {
		return viettelBankCode;
	}
	public void setViettelBankCode(String viettelBankCode) {
		this.viettelBankCode = viettelBankCode;
	}
	public String getViettelBankName() {
		return viettelBankName;
	}
	public void setViettelBankName(String viettelBankName) {
		this.viettelBankName = viettelBankName;
	}
	public String getRef() {
		return ref;
	}
	public void setRef(String ref) {
		this.ref = ref;
	}
	public String getExntRef() {
		return exntRef;
	}
	public void setExntRef(String exntRef) {
		this.exntRef = exntRef;
	}
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	public String getTrxDt() {
		return trxDt;
	}
	public void setTrxDt(String trxDt) {
		this.trxDt = trxDt;
	}
	
}
