package com.shinhan.recon.configure;

import java.util.Locale;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * @author shds06
 *
 */
@Configuration
public class SpringFoxConfig {
	
	@Bean
	public Docket omsServiceAPI() {
		return new Docket(DocumentationType.OAS_30)
				.ignoredParameterTypes(Locale.class).select()
				.apis(RequestHandlerSelectors.basePackage("com.shinhan.recon.api.controller"))
				.paths(PathSelectors.any()).build().apiInfo(metaData());
	}

	private ApiInfo metaData() {
		return new ApiInfoBuilder().title("Spring Boot Swagger").description("An Document API Of Shinhan.").build();
	}
}
