/**
 * 
 */
package com.shinhan.recon.core.model.statement;

/**
 * @author shds04
 *
 */
public class NonBankStatementViettelTemplate {

	private String trxDt;
	private String refDes;
	private String loanNo;
	private String valueDt;
	private String description;
	private String debit;
	private String credit;
	private String ref;
	public NonBankStatementViettelTemplate() {
		super();
		// TODO Auto-generated constructor stub
	}
	public NonBankStatementViettelTemplate(String trxDt, String refDes, String loanNo, String valueDt,
			String description, String debit, String credit, String ref) {
		super();
		this.trxDt = trxDt;
		this.refDes = refDes;
		this.loanNo = loanNo;
		this.valueDt = valueDt;
		this.description = description;
		this.debit = debit;
		this.credit = credit;
		this.ref = ref;
	}
	public String getTrxDt() {
		return trxDt;
	}
	public void setTrxDt(String trxDt) {
		this.trxDt = trxDt;
	}
	public String getRefDes() {
		return refDes;
	}
	public void setRefDes(String refDes) {
		this.refDes = refDes;
	}
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	public String getValueDt() {
		return valueDt;
	}
	public void setValueDt(String valueDt) {
		this.valueDt = valueDt;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDebit() {
		return debit;
	}
	public void setDebit(String debit) {
		this.debit = debit;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	public String getRef() {
		return ref;
	}
	public void setRef(String ref) {
		this.ref = ref;
	}
	
	
	
}
