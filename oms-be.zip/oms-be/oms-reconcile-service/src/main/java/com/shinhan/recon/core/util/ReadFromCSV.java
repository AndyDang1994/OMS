package com.shinhan.recon.core.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;


public class ReadFromCSV {
	private String filePath;

	public  ReadFromCSV(String filePath) {
		this.filePath = filePath;
	}
	
	public List<Map> readDataFromCsv(String bankTemplateColumn, int fromRow ){
		List<String> excelColumn = Arrays.asList(bankTemplateColumn.split(","));
		ArrayList<Map> mapArray = new ArrayList<Map>();
		try{
			FileReader fileReader =  new FileReader(this.filePath);
			String line = "";  
			int idx = 0 ;
			String splitBy = ",";  
			Map<String, Object> rowMap = null;
			BufferedReader br = new BufferedReader(fileReader);  
			while ((line = br.readLine()) != null)   //returns a Boolean value  
			{  
				idx++;
				if(idx > fromRow && !StringUtils.isBlank(line.trim())) {
					rowMap = new HashMap<String, Object>(excelColumn.size());
					String[] result = line.split(splitBy);    // use comma as separator    
					for (int i = 0; i< excelColumn.size(); i++ ) {
						rowMap.put(excelColumn.get(i),result[i].trim());
					}
					mapArray.add(rowMap);
				}
				
			}  
			fileReader.close();
		} catch (Exception e) {
			
		}
		return mapArray;
	}
	
	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
}
