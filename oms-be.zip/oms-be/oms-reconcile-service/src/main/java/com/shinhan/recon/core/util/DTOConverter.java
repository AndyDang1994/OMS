/**
 * 
 */
package com.shinhan.recon.core.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.BankFileReconResult;
import com.shinhan.recon.core.model.BankStatemenTrxInfo;
import com.shinhan.recon.core.model.BankStatementFile;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.core.model.BankTemplateInfo;
import com.shinhan.recon.core.model.LmsTrxInfo;
import com.shinhan.recon.core.model.statement.BankStatementCommonTemplate;
import com.shinhan.recon.report.model.RepaymentForHeaderReport;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsReconDisburInf;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;

/**
 * @author shds01
 *
 */
public class DTOConverter {

	public static List<?> convertSettoList(Set<?> sets) throws ServiceRuntimeException {
		List<?> list = new ArrayList<>(sets);
		return list;
	}

	public static void setUtilityTOmsStmtFileMas(TOmsStmtFileMas item, String createdBy, Date createdDt, String updatedBy, Date updatedDt) {
		
	}

	public static void setUtilityTOmsReconLmsInf(TOmsReconLmsInf item, String createdBy, Date createdDt, String updatedBy, Date updatedDt) {

	}
	
	public static void setUtilityTOmsReconLmsInfForChangingStatus(TOmsReconLmsInf item, LmsTrxInfo info, String updatedBy, Date updatedDt) {
		item.setStatusCode(info.getStatusCode());
		item.setRemarkNote(info.getRemarkNote());
		item.setRefID(APIConstant.BLANK_VALUE);
		item.setUpdatedDt(updatedDt);
		item.setUpdatedUser(updatedBy);
		item.setRemarkNote(info.getRemarkNote());
	}
	
	public static void setUtilityTOmsReconLmsInfForUnmatch(TOmsReconLmsInf item, long statusCode, String updatedBy, Date updatedDt,String remakeNote) {
		item.setStatusCode(statusCode);
		item.setRefID(APIConstant.BLANK_VALUE);
		item.setUpdatedDt(updatedDt);
		item.setUpdatedUser(updatedBy);
		item.setRemarkNote(remakeNote);
	}
	
	public static void setUtilityTOmsReconLmsInfForMatch(TOmsReconLmsInf item,long statusCode, String refId, String updatedBy, Date updatedDt,String remakeNote) {
		item.setStatusCode(statusCode);
		item.setRefID(refId);
		item.setUpdatedDt(updatedDt);
		item.setUpdatedUser(updatedBy);
		item.setRemarkNote(remakeNote);
	}
	public static void setUtilityTOmsReconLmsInfForMatch(TOmsReconLmsInf item, String refId, String updatedBy, Date updatedDt,String remakeNote) {
		item.setStatusCode(APIConstant.LMS_TRX_MATCHED);
		item.setRefID(refId);
		item.setUpdatedDt(updatedDt);
		item.setUpdatedUser(updatedBy);
		item.setRemarkNote(remakeNote);
	}

	public static void setUtilityTOmsReconStmtInf(TOmsReconStmtInf item, String createdBy, Date createdDt, String updatedBy, Date updatedDt) {
		if(updatedBy != null) {
			item.setUpdatedUser(updatedBy);
		}
		if(updatedDt != null) {
			item.setUpdatedDt(updatedDt);
		}
		if(createdBy != null) {
			item.setCreatedDt(createdDt);
		}
		if(createdDt != null) {
			item.setCreatedUser(createdBy);
		}
	}
	public static void setUtilityTOmsDisbStmtInf(TOmsReconDisburInf item, String createdBy, Date createdDt, String updatedBy, Date updatedDt) {
		if(updatedBy != null) {
			item.setUpdatedUser(updatedBy);
		}
		if(updatedDt != null) {
			item.setUpdatedDt(updatedDt);
		}
		if(createdBy != null) {
			item.setCreatedDt(createdDt);
		}
		if(createdDt != null) {
			item.setCreatedUser(createdBy);
		}
	}
	
	public static void setUtilityTOmsReconStmtInfForChangingStatus(TOmsReconStmtInf item, BankStatemenTrxInfo info, String updatedBy, Date updatedDt) {
		item.setStatusCode(info.getStatusCode());
		item.setRemarkNote(info.getRemarkNote());
		item.setRefID(APIConstant.BLANK_VALUE);
		item.setUpdatedDt(updatedDt);
		item.setUpdatedUser(updatedBy);
		item.setRemarkNote(info.getRemarkNote());
	}
	public static void setUtilityDisbForChangingStatus(TOmsReconDisburInf item, BankStatemenTrxInfo info, String updatedBy, Date updatedDt) {
		item.setStatusCode(info.getStatusCode());
		item.setRemarkNote(info.getRemarkNote());
		item.setRefID(APIConstant.BLANK_VALUE);
		item.setUpdatedDt(updatedDt);
		item.setUpdatedUser(updatedBy);
		item.setRemarkNote(info.getRemarkNote());
	}
	
	public static void setUtilityTOmsReconStmtInfForUnmatch(TOmsReconStmtInf item, long statusCode, String updatedBy, Date updatedDt, String remakeNote) {
		item.setStatusCode(statusCode);
		item.setRefID(APIConstant.BLANK_VALUE);
		item.setUpdatedDt(updatedDt);
		item.setUpdatedUser(updatedBy);
		item.setRemarkNote(remakeNote);
	}
	public static void setUtilityTDisburForUnmatch(TOmsReconDisburInf item, long statusCode, String updatedBy, Date updatedDt, String remakeNote) {
		item.setStatusCode(statusCode);
		item.setRefID(APIConstant.BLANK_VALUE);
		item.setUpdatedDt(updatedDt);
		item.setUpdatedUser(updatedBy);
		item.setRemarkNote(remakeNote);
	}
	
	public static void setUtilityTOmsReconStmtInfForMatch(TOmsReconStmtInf item,Long statusCode, String refId, String updatedBy, Date updatedDt, String remakeNote) {
		item.setStatusCode(statusCode);
		item.setRefID(refId);
		item.setUpdatedDt(updatedDt);
		item.setUpdatedUser(updatedBy);
		item.setRemarkNote(remakeNote);
	}
	public static void setUtilityTOmsReconSuspenseInfForConfirm(TOmsReconSuspenseInf item, String updatedBy, Date updatedDt, String remakeNote) {
		item.setConfirmYn(APIConstant.YES_KEY);
		item.setConfirmDt(updatedDt);
		item.setUpdatedDt(updatedDt);
		item.setUpdatedUser(updatedBy);
		item.setRemarkNote(remakeNote);
	}
	public static void setUtilityTOmsReconSuspenseInfForUpdate(TOmsReconSuspenseInf item,Long statusCode, String updatedBy, Date updatedDt, String remakeNote) {
		item.setStatusCode(statusCode);
		item.setUpdatedDt(updatedDt);
		item.setUpdatedUser(updatedBy);
		item.setRemarkNote(remakeNote);
	}
	public static void setUtilityTOmsReconStmtInfForMatch(TOmsReconStmtInf item, String refId, String updatedBy, Date updatedDt, String remakeNote) {
		item.setStatusCode(APIConstant._BANK_STATEMENT_MATCH_STATUS);
		item.setRefID(refId);
		item.setUpdatedDt(updatedDt);
		item.setUpdatedUser(updatedBy);
		item.setRemarkNote(remakeNote);
	}
	public static void setUtilityDisburForMatch(TOmsReconDisburInf item, String refId, String updatedBy, Date updatedDt, String remakeNote) {
		item.setStatusCode(APIConstant._BANK_STATEMENT_MATCH_STATUS);
		item.setRefID(refId);
		item.setUpdatedDt(updatedDt);
		item.setUpdatedUser(updatedBy);
		item.setRemarkNote(remakeNote);
	}

	public static void setUtilityTOmsReconSuspenseInf(TOmsReconSuspenseInf item, String createdBy, Date createdDt, String updatedBy, Date updatedDt) {
		if(updatedBy != null) {
			item.setUpdatedUser(updatedBy);
		}
		if(updatedDt != null) {
			item.setUpdatedDt(updatedDt);
		}
		if(createdBy != null) {
			item.setCreatedDt(createdDt);
		}
		if(createdDt != null) {
			item.setCreateUser(createdBy);
		}
	}
	
	public static List<TOmsReconStmtInf> setCommonTemplateToOmsReconStmtInf(List<BankStatementCommonTemplate> commonTemplates, String bankCode,String createdBy, Date createdDt, String updatedBy, Date updatedDt, long fileMasId){
		List<TOmsReconStmtInf> rs = new ArrayList<>();
		for (BankStatementCommonTemplate commonTemplate : commonTemplates) {
			TOmsReconStmtInf reconStmtInf = new TOmsReconStmtInf();
			reconStmtInf.setBankCode(bankCode);
			if( !StringUtils.isBlank(commonTemplate.getCredit()) && CommonUtil.isCurrencyAmt(commonTemplate.getCredit())) {
				BigDecimal bigDecimal = new BigDecimal( commonTemplate.getCredit().replaceAll(",", "") );
				if(bigDecimal.compareTo(APIConstant.DEC_ZERO) < 0) {
					bigDecimal = bigDecimal.multiply(new BigDecimal("-1"));
				}
				reconStmtInf.setCrAmt( bigDecimal );
			}else {
				reconStmtInf.setCrAmt( BigDecimal.ZERO );
			}
			
			if( !StringUtils.isBlank(commonTemplate.getDebit()) && CommonUtil.isCurrencyAmt(commonTemplate.getDebit())) {
				BigDecimal bigDecimal = new BigDecimal( commonTemplate.getDebit().replaceAll(",", "") );
				if(bigDecimal.compareTo(APIConstant.DEC_ZERO) < 0) {
					bigDecimal = bigDecimal.multiply(new BigDecimal("-1"));
				}
				reconStmtInf.setDrAmt( bigDecimal );
			}else {
				reconStmtInf.setDrAmt( BigDecimal.ZERO );
			}
				
			reconStmtInf.setCreatedUser(createdBy);
			reconStmtInf.setCreatedDt(createdDt);
			reconStmtInf.setUpdatedDt(updatedDt);
			reconStmtInf.setUpdatedUser(updatedBy);
			if( CommonUtil.isNumber(commonTemplate.getLoanNo()) ) {
				reconStmtInf.setLoanNo(commonTemplate.getLoanNo());
			}
			reconStmtInf.setRefNo(commonTemplate.getRef());
			//reconStmtInf.setRefIdFileMas(fileMasId);
			reconStmtInf.setSeqNo(0);
			String trxDt = commonTemplate.getTrxDt().replaceAll("\\s.*", "");
			String format = DateUtils.getValidFormat(trxDt);
			if(DateUtils.isValidate(trxDt)) {
				reconStmtInf.setRemark( StringUtils.isBlank(commonTemplate.getDescription()) ? " " :commonTemplate.getDescription());
				if(format.equals(DateUtils.DATEFORMAT)) {
					reconStmtInf.setTrxDt(DateUtils.formatStringToDate(trxDt, DateUtils.DATEFORMAT));
				}else {
					reconStmtInf.setTrxDt(DateUtils.convertDate(trxDt,format, DateUtils.DATEFORMAT));
				}
			}else {
				reconStmtInf.setRemark( APIConstant.THE_DATA_INCORRECT_FORMAT_ERROR );
				reconStmtInf.setTrxDt(createdDt);
			}
			String valueDt = (commonTemplate.getValueDt() == null ? "" : commonTemplate.getValueDt().replaceAll("\\s.*", ""));
			String formatValueDt = DateUtils.getValidFormat(valueDt);
			if(DateUtils.isValidate(valueDt)) {
				if(formatValueDt.equals(DateUtils.DATEFORMAT)) {
					reconStmtInf.setValueDt(DateUtils.formatStringToDate(valueDt, DateUtils.DATEFORMAT));
				}else {
					reconStmtInf.setValueDt(DateUtils.convertDate(valueDt, formatValueDt, DateUtils.DATEFORMAT));
				}
			}else {
				reconStmtInf.setValueDt(reconStmtInf.getTrxDt());
			}
			rs.add(reconStmtInf);
		}
		return rs;
	}
	public static List<TOmsReconStmtInf> setCommonTemplateToOmsReconStmtInfForCiti(List<BankStatementCommonTemplate> commonTemplates, String bankCode,String createdBy, Date createdDt, String updatedBy, Date updatedDt, long fileMasId){
		List<TOmsReconStmtInf> rs = new ArrayList<>();
		for (BankStatementCommonTemplate commonTemplate : commonTemplates) {
			TOmsReconStmtInf reconStmtInf = new TOmsReconStmtInf();
			reconStmtInf.setBankCode(bankCode);
			if( !StringUtils.isBlank(commonTemplate.getCredit()) && CommonUtil.isCurrencyAmt(commonTemplate.getCredit())) {
				BigDecimal bigDecimal = new BigDecimal( commonTemplate.getCredit().replaceAll(",", "") );
				if(bigDecimal.compareTo(APIConstant.DEC_ZERO) < 0) {
					bigDecimal = bigDecimal.multiply(new BigDecimal("-1"));
				}
				reconStmtInf.setCrAmt( bigDecimal );
			}else {
				reconStmtInf.setCrAmt( BigDecimal.ZERO );
			}
			
			if( !StringUtils.isBlank(commonTemplate.getDebit()) && CommonUtil.isCurrencyAmt(commonTemplate.getDebit())) {
				BigDecimal bigDecimal = new BigDecimal( commonTemplate.getDebit().replaceAll(",", "") );
				if(bigDecimal.compareTo(APIConstant.DEC_ZERO) < 0) {
					bigDecimal = bigDecimal.multiply(new BigDecimal("-1"));
				}
				reconStmtInf.setDrAmt( bigDecimal );
			}else {
				reconStmtInf.setDrAmt( BigDecimal.ZERO );
			}
			
			reconStmtInf.setCreatedUser(createdBy);
			reconStmtInf.setCreatedDt(createdDt);
			reconStmtInf.setUpdatedDt(updatedDt);
			reconStmtInf.setUpdatedUser(updatedBy);
			if( CommonUtil.isNumber(commonTemplate.getLoanNo()) ) {
				reconStmtInf.setLoanNo(commonTemplate.getLoanNo());
			}
			reconStmtInf.setRefNo(commonTemplate.getRef());
			//reconStmtInf.setRefIdFileMas(fileMasId);
			reconStmtInf.setSeqNo(0);
			String trxDt = commonTemplate.getTrxDt().replaceAll("\\s.*", "");
			if(DateUtils.isValidate(trxDt)) {
				reconStmtInf.setRemark( StringUtils.isBlank(commonTemplate.getDescription()) ? " " :commonTemplate.getDescription());
				reconStmtInf.setTrxDt(DateUtils.convertDate(trxDt, DateUtils.MM_dd_yyyy, DateUtils.DATEFORMAT));
			}else {
				reconStmtInf.setRemark( APIConstant.THE_DATA_INCORRECT_FORMAT_ERROR );
				reconStmtInf.setTrxDt(createdDt);
			}
			String valueDt = (commonTemplate.getValueDt() == null ? "" : commonTemplate.getValueDt().replaceAll("\\s.*", ""));
			if(DateUtils.isValidate(valueDt)) {
				reconStmtInf.setValueDt(DateUtils.convertDate(valueDt, DateUtils.MM_dd_yyyy, DateUtils.DATEFORMAT));
			}else {
				reconStmtInf.setValueDt(reconStmtInf.getTrxDt());
			}
			rs.add(reconStmtInf);
		}
		return rs;
	}
	public static List<TOmsReconStmtInf> setCommonTemplateToOmsReconStmtInfForACB(List<BankStatementCommonTemplate> commonTemplates, String bankCode,String createdBy, Date createdDt, String updatedBy, Date updatedDt, long fileMasId){
		List<TOmsReconStmtInf> rs = new ArrayList<>();
		for (BankStatementCommonTemplate commonTemplate : commonTemplates) {
			TOmsReconStmtInf reconStmtInf = new TOmsReconStmtInf();
			reconStmtInf.setBankCode(bankCode);
			if( !StringUtils.isBlank(commonTemplate.getCredit()) && CommonUtil.isCurrencyAmt(commonTemplate.getCredit())) {
				BigDecimal bigDecimal = new BigDecimal( commonTemplate.getCredit().replaceAll(",", "") );
				if(bigDecimal.compareTo(APIConstant.DEC_ZERO) < 0) {
					bigDecimal = bigDecimal.multiply(new BigDecimal("-1"));
				}
				reconStmtInf.setCrAmt( bigDecimal );
			}else {
				reconStmtInf.setCrAmt( BigDecimal.ZERO );
			}
			
			if( !StringUtils.isBlank(commonTemplate.getDebit()) && CommonUtil.isCurrencyAmt(commonTemplate.getDebit())) {
				BigDecimal bigDecimal = new BigDecimal( commonTemplate.getDebit().replaceAll(",", "") );
				if(bigDecimal.compareTo(APIConstant.DEC_ZERO) < 0) {
					bigDecimal = bigDecimal.multiply(new BigDecimal("-1"));
				}
				reconStmtInf.setDrAmt( bigDecimal );
			}else {
				reconStmtInf.setDrAmt( BigDecimal.ZERO );
			}
			
			reconStmtInf.setCreatedUser(createdBy);
			reconStmtInf.setCreatedDt(createdDt);
			reconStmtInf.setUpdatedDt(updatedDt);
			reconStmtInf.setUpdatedUser(updatedBy);
			if( CommonUtil.isNumber(commonTemplate.getLoanNo()) ) {
				reconStmtInf.setLoanNo(commonTemplate.getLoanNo());
			}
			reconStmtInf.setRefNo(commonTemplate.getRef());
			//reconStmtInf.setRefIdFileMas(fileMasId);
			reconStmtInf.setSeqNo(0);
			String trxDt = commonTemplate.getTrxDt().replaceAll("\\s.*", "");
			String format = DateUtils.getValidFormat(trxDt);
			if(DateUtils.isValidate(trxDt)) {
				reconStmtInf.setRemark( StringUtils.isBlank(commonTemplate.getDescription()) ? " " :commonTemplate.getDescription());
				if(format.equals(DateUtils.DATEFORMAT)) {
					reconStmtInf.setTrxDt(DateUtils.formatStringToDate(trxDt, DateUtils.DATEFORMAT));
				}else {
					reconStmtInf.setTrxDt(DateUtils.convertDate(trxDt, DateUtils.getValidFormat(trxDt), DateUtils.DATEFORMAT));
				}
			}else {
				reconStmtInf.setRemark( APIConstant.THE_DATA_INCORRECT_FORMAT_ERROR );
				reconStmtInf.setTrxDt(createdDt);
			}
			String valueDt = (commonTemplate.getValueDt() == null ? "" : commonTemplate.getValueDt().replaceAll("\\s.*", ""));
			if(DateUtils.isValidate(valueDt)) {
				reconStmtInf.setValueDt(DateUtils.convertDate(valueDt, DateUtils.MM_dd_yyyy, DateUtils.DATEFORMAT));
			}else {
				reconStmtInf.setValueDt(reconStmtInf.getTrxDt());
			}
			rs.add(reconStmtInf);
		}
		return rs;
	}
	public static TOmsReconStmtInf setCommonTemplateToOmsReconStmtInf(BankStatementCommonTemplate commonTemplate, String bankCode,String createdBy, Date createdDt, String updatedBy, Date updatedDt, long fileMasId){
		
		TOmsReconStmtInf reconStmtInf = new TOmsReconStmtInf();
		reconStmtInf.setBankCode(bankCode);
		if( !StringUtils.isBlank(commonTemplate.getCredit()) && CommonUtil.isCurrencyAmt(commonTemplate.getCredit())) {
			BigDecimal bigDecimal = new BigDecimal( commonTemplate.getCredit().replaceAll(",", "") );
			if(bigDecimal.compareTo(APIConstant.DEC_ZERO) < 0) {
				bigDecimal = bigDecimal.multiply(new BigDecimal("-1"));
			}
			reconStmtInf.setCrAmt( bigDecimal );
		}else {
			reconStmtInf.setCrAmt( BigDecimal.ZERO );
		}
		
		if( !StringUtils.isBlank(commonTemplate.getDebit()) && CommonUtil.isCurrencyAmt(commonTemplate.getDebit())) {
			BigDecimal bigDecimal = new BigDecimal( commonTemplate.getDebit().replaceAll(",", "") );
			if(bigDecimal.compareTo(APIConstant.DEC_ZERO) < 0) {
				bigDecimal = bigDecimal.multiply(new BigDecimal("-1"));
			}
			reconStmtInf.setDrAmt( bigDecimal );
		}else {
			reconStmtInf.setDrAmt( BigDecimal.ZERO );
		}
		
		reconStmtInf.setCreatedUser(createdBy);
		reconStmtInf.setCreatedDt(createdDt);
		reconStmtInf.setUpdatedDt(updatedDt);
		reconStmtInf.setUpdatedUser(updatedBy);
		reconStmtInf.setLoanNo(commonTemplate.getLoanNo());
		reconStmtInf.setRefNo(commonTemplate.getRef());
		reconStmtInf.setRefIdFileMas(fileMasId);
		reconStmtInf.setSeqNo(0);
		String trxDt = commonTemplate.getTrxDt().replaceAll("\\s.*", "");
		String format = DateUtils.getValidFormat(trxDt);
		if(DateUtils.isValidate(trxDt)) {
			reconStmtInf.setRemark( StringUtils.isBlank(commonTemplate.getDescription()) ? " " :commonTemplate.getDescription());
			if(format.equals(DateUtils.DATEFORMAT)) {
				reconStmtInf.setTrxDt(DateUtils.formatStringToDate(trxDt, DateUtils.DATEFORMAT));
			}else {
				reconStmtInf.setTrxDt(DateUtils.convertDate(trxDt, DateUtils.getValidFormat(trxDt), DateUtils.DATEFORMAT));
			}
		}else {
			reconStmtInf.setRemark( APIConstant.THE_DATA_INCORRECT_FORMAT_ERROR );
			reconStmtInf.setTrxDt(createdDt);
		}
		String valueDt = (commonTemplate.getValueDt() == null ? "" : commonTemplate.getValueDt().replaceAll("\\s.*", ""));
		String formatValueDt = DateUtils.getValidFormat(valueDt);
		if(DateUtils.isValidate(valueDt)) {
			if(formatValueDt.equals(DateUtils.DATEFORMAT)) {
				reconStmtInf.setValueDt(DateUtils.formatStringToDate(valueDt, DateUtils.DATEFORMAT));
			}else {
				reconStmtInf.setValueDt(DateUtils.convertDate(valueDt, formatValueDt, DateUtils.DATEFORMAT));
			}
		}else {
			reconStmtInf.setValueDt(reconStmtInf.getTrxDt());
		}
		return reconStmtInf;
	}
	public static List<TOmsReconDisburInf> setCommonTemplateToOmsReconDisbursalInf(List<BankStatementCommonTemplate> commonTemplates, String bankCode,String createdBy, Date createdDt, String updatedBy, Date updatedDt, long fileMasId){
		List<TOmsReconDisburInf> rs = new ArrayList<>();
		for (BankStatementCommonTemplate commonTemplate : commonTemplates) {
			TOmsReconDisburInf reconStmtInf = new TOmsReconDisburInf();
			reconStmtInf.setBankCode(bankCode);
			if( !StringUtils.isBlank(commonTemplate.getCredit()) && CommonUtil.isCurrencyAmt(commonTemplate.getCredit())) {
				BigDecimal bigDecimal = new BigDecimal( commonTemplate.getCredit().replaceAll(",", "") );
				if(bigDecimal.compareTo(APIConstant.DEC_ZERO) < 0) {
					bigDecimal = bigDecimal.multiply(new BigDecimal("-1"));
				}
				reconStmtInf.setCrAmt( bigDecimal );
			}else {
				reconStmtInf.setCrAmt( BigDecimal.ZERO );
			}
			
			if( !StringUtils.isBlank(commonTemplate.getDebit()) && CommonUtil.isCurrencyAmt(commonTemplate.getDebit())) {
				BigDecimal bigDecimal = new BigDecimal( commonTemplate.getDebit().replaceAll(",", "") );
				if(bigDecimal.compareTo(APIConstant.DEC_ZERO) < 0) {
					bigDecimal = bigDecimal.multiply(new BigDecimal("-1"));
				}
				reconStmtInf.setDrAmt( bigDecimal );
			}else {
				reconStmtInf.setDrAmt( BigDecimal.ZERO );
			}
			
			reconStmtInf.setCreatedUser(createdBy);
			reconStmtInf.setCreatedDt(createdDt);
			reconStmtInf.setUpdatedDt(updatedDt);
			reconStmtInf.setUpdatedUser(updatedBy);
			if( CommonUtil.isNumber(commonTemplate.getLoanNo()) ) {
				reconStmtInf.setLoanNo(commonTemplate.getLoanNo());
			}
			reconStmtInf.setRefNo(commonTemplate.getRef());
			//reconStmtInf.setRefIdFileMas(fileMasId);
			String trxDt = commonTemplate.getTrxDt().replaceAll("\\s.*", "");
			String format = DateUtils.getValidFormat(trxDt);
			if(DateUtils.isValidate(trxDt)) {
				reconStmtInf.setRemark( StringUtils.isBlank(commonTemplate.getDescription()) ? " " :commonTemplate.getDescription());
				if(format.equals(DateUtils.DATEFORMAT)) {
					reconStmtInf.setTrxDt(DateUtils.formatStringToDate(trxDt, DateUtils.DATEFORMAT));
				}else {
					reconStmtInf.setTrxDt(DateUtils.convertDate(trxDt, DateUtils.getValidFormat(trxDt), DateUtils.DATEFORMAT));
				}
			}else {
				reconStmtInf.setRemark( APIConstant.THE_DATA_INCORRECT_FORMAT_ERROR );
				reconStmtInf.setTrxDt(createdDt);
			}
			
			rs.add(reconStmtInf);
		}
		return rs;
	}
	public static List<TOmsReconDisburInf> setCommonTemplateToOmsReconDisbursalInfForCiti(List<BankStatementCommonTemplate> commonTemplates, String bankCode,String createdBy, Date createdDt, String updatedBy, Date updatedDt, long fileMasId){
		List<TOmsReconDisburInf> rs = new ArrayList<>();
		for (BankStatementCommonTemplate commonTemplate : commonTemplates) {
			TOmsReconDisburInf reconStmtInf = new TOmsReconDisburInf();
			reconStmtInf.setBankCode(bankCode);
			if( !StringUtils.isBlank(commonTemplate.getCredit()) && CommonUtil.isCurrencyAmt(commonTemplate.getCredit())) {
				BigDecimal bigDecimal = new BigDecimal( commonTemplate.getCredit().replaceAll(",", "") );
				if(bigDecimal.compareTo(APIConstant.DEC_ZERO) < 0) {
					bigDecimal = bigDecimal.multiply(new BigDecimal("-1"));
				}
				reconStmtInf.setCrAmt( bigDecimal );
			}else {
				reconStmtInf.setCrAmt( BigDecimal.ZERO );
			}
			
			if( !StringUtils.isBlank(commonTemplate.getDebit()) && CommonUtil.isCurrencyAmt(commonTemplate.getDebit())) {
				BigDecimal bigDecimal = new BigDecimal( commonTemplate.getDebit().replaceAll(",", "") );
				if(bigDecimal.compareTo(APIConstant.DEC_ZERO) < 0) {
					bigDecimal = bigDecimal.multiply(new BigDecimal("-1"));
				}
				reconStmtInf.setDrAmt( bigDecimal );
			}else {
				reconStmtInf.setDrAmt( BigDecimal.ZERO );
			}
			
			reconStmtInf.setCreatedUser(createdBy);
			reconStmtInf.setCreatedDt(createdDt);
			reconStmtInf.setUpdatedDt(updatedDt);
			reconStmtInf.setUpdatedUser(updatedBy);
			if( CommonUtil.isNumber(commonTemplate.getLoanNo()) ) {
				reconStmtInf.setLoanNo(commonTemplate.getLoanNo());
			}
			reconStmtInf.setRefNo(commonTemplate.getRef());
			//reconStmtInf.setRefIdFileMas(fileMasId);
			String trxDt = commonTemplate.getTrxDt().replaceAll("\\s.*", "");
			if(DateUtils.isValidate(trxDt)) {
				reconStmtInf.setRemark( StringUtils.isBlank(commonTemplate.getDescription()) ? " " :commonTemplate.getDescription());
				reconStmtInf.setTrxDt(DateUtils.convertDate(trxDt, DateUtils.MM_dd_yyyy , DateUtils.DATEFORMAT));
			}else {
				reconStmtInf.setRemark( APIConstant.THE_DATA_INCORRECT_FORMAT_ERROR );
				reconStmtInf.setTrxDt(createdDt);
			}
			
			rs.add(reconStmtInf);
		}
		return rs;
	}
	
	public static List<TOmsReconSuspenseInf> getSuspenseListFromStatement( List<TOmsReconStmtInf> stmtInfs, TOmsStmtFileMas tOmsStmtFileMas ){
		
		List<TOmsReconSuspenseInf> reconSuspenseInfs = new ArrayList<>();
		
		for (TOmsReconStmtInf tOmsReconStmtInf : stmtInfs) {
			if(tOmsReconStmtInf.getRefIdFileMas() == tOmsStmtFileMas.getId()) {
				TOmsReconSuspenseInf tOmsReconSuspenseInf = new TOmsReconSuspenseInf();
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_PENDING_STATUS);
				tOmsReconSuspenseInf.setConfirmYn(APIConstant.NO_KEY);
				tOmsReconSuspenseInf.setRefIdFileMas(tOmsStmtFileMas.getId());
				tOmsReconSuspenseInf.setBankCode(tOmsReconStmtInf.getBankCode());
				tOmsReconSuspenseInf.setCrAmt(tOmsReconStmtInf.getCrAmt());
				tOmsReconSuspenseInf.setDrAmt(tOmsReconStmtInf.getDrAmt());
				tOmsReconSuspenseInf.setLoanNo(tOmsReconStmtInf.getLoanNo());
				tOmsReconSuspenseInf.setRefNo(tOmsReconStmtInf.getRefNo());
				tOmsReconSuspenseInf.setTrxDt(tOmsReconStmtInf.getTrxDt());
				tOmsReconSuspenseInf.setRemark(tOmsReconStmtInf.getRemark());
				tOmsReconSuspenseInf.setRemarkNote(tOmsReconStmtInf.getRemarkNote());
				setUtilityTOmsReconSuspenseInf(tOmsReconSuspenseInf, APIConstant._USERNAME_BATCHJOB,  DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
						DateUtils.DATEFORMAT), APIConstant._USERNAME_BATCHJOB,  DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
						DateUtils.DATEFORMAT));
				reconSuspenseInfs.add(tOmsReconSuspenseInf);
			}
			
		}
		
		return reconSuspenseInfs;
	}
	public static List<TOmsReconSuspenseInf> getSuspenseListFromDisburse( List<TOmsReconDisburInf> stmtInfs, TOmsStmtFileMas tOmsStmtFileMas ){
		
		List<TOmsReconSuspenseInf> reconSuspenseInfs = new ArrayList<>();
		
		for (TOmsReconDisburInf tOmsReconStmtInf : stmtInfs) {
			if(tOmsReconStmtInf.getRefIdFileMas() == tOmsStmtFileMas.getId()) {
				TOmsReconSuspenseInf tOmsReconSuspenseInf = new TOmsReconSuspenseInf();
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_PENDING_STATUS);
				tOmsReconSuspenseInf.setConfirmYn(APIConstant.NO_KEY);
				tOmsReconSuspenseInf.setRefIdFileMas(tOmsStmtFileMas.getId());
				tOmsReconSuspenseInf.setBankCode(tOmsReconStmtInf.getBankCode());
				tOmsReconSuspenseInf.setCrAmt(tOmsReconStmtInf.getCrAmt());
				tOmsReconSuspenseInf.setDrAmt(tOmsReconStmtInf.getDrAmt());
				tOmsReconSuspenseInf.setLoanNo(tOmsReconStmtInf.getLoanNo());
				tOmsReconSuspenseInf.setRefNo(tOmsReconStmtInf.getRefNo());
				tOmsReconSuspenseInf.setTrxDt(tOmsReconStmtInf.getTrxDt());
				tOmsReconSuspenseInf.setRemark(tOmsReconStmtInf.getRemark());
				tOmsReconSuspenseInf.setRemarkNote(tOmsReconStmtInf.getRemarkNote());
				setUtilityTOmsReconSuspenseInf(tOmsReconSuspenseInf, APIConstant._USERNAME_BATCHJOB,  DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
						DateUtils.DATEFORMAT), APIConstant._USERNAME_BATCHJOB,  DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
						DateUtils.DATEFORMAT));
				reconSuspenseInfs.add(tOmsReconSuspenseInf);
			}
			
		}
		
		return reconSuspenseInfs;
	}
	public static List<TOmsReconSuspenseInf> getSuspenseListFromLMS( List<TOmsReconLmsInf> stmtInfs, TOmsStmtFileMas tOmsStmtFileMas ) throws ServiceRuntimeException{
		
		List<TOmsReconSuspenseInf> reconSuspenseInfs = new ArrayList<>();
		BankFileReconResult bankResult = StringUtils.isBlank(tOmsStmtFileMas.getAddInf()) ? new BankFileReconResult() :(BankFileReconResult) CommonUtil.toPojo(tOmsStmtFileMas.getAddInf(), BankFileReconResult.class);
		int rev = 0;
		for (TOmsReconLmsInf tOmsReconStmtInf : stmtInfs) {
			String loanStatus = (tOmsReconStmtInf.getLoanStatus() != null ? tOmsReconStmtInf.getLoanStatus() : "" );
			String cif = (tOmsReconStmtInf.getCif() != null ? tOmsReconStmtInf.getCif() : "" );
			if( loanStatus.equals(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT)) &&
				( (tOmsReconStmtInf.getDrAmt().compareTo(APIConstant.DEC_ZERO) > 0 && tOmsReconStmtInf.getTransactionType() == APIConstant.LMS_TRX_TYPE_REPAYMENT) || 
				  (tOmsReconStmtInf.getCrAmt().compareTo(APIConstant.DEC_ZERO) > 0 && tOmsReconStmtInf.getTransactionType() == APIConstant.LMS_TRX_TYPE_DISBURSAL)
				)
			  ) {
				TOmsReconSuspenseInf tOmsReconSuspenseInf = new TOmsReconSuspenseInf();
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_PENDING_STATUS);
				tOmsReconSuspenseInf.setConfirmYn(APIConstant.NO_KEY);
				tOmsReconSuspenseInf.setRefIdFileMas(tOmsStmtFileMas.getId());
				tOmsReconSuspenseInf.setBankCode(tOmsReconStmtInf.getBankCode());
				tOmsReconSuspenseInf.setCrAmt(tOmsReconStmtInf.getCrAmt());
				tOmsReconSuspenseInf.setDrAmt(tOmsReconStmtInf.getDrAmt());
				tOmsReconSuspenseInf.setLoanNo(tOmsReconStmtInf.getLoanNo());
				tOmsReconSuspenseInf.setRefNo(tOmsReconStmtInf.getRefNo());
				tOmsReconSuspenseInf.setTrxDt(tOmsReconStmtInf.getTrxDt());
				tOmsReconSuspenseInf.setRemark(tOmsReconStmtInf.getRemark());
				tOmsReconSuspenseInf.setRemarkNote(tOmsReconStmtInf.getRemarkNote());
				setUtilityTOmsReconSuspenseInf(tOmsReconSuspenseInf, APIConstant._USERNAME_BATCHJOB,  DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
						DateUtils.DATEFORMAT), APIConstant._USERNAME_BATCHJOB,  DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
						DateUtils.DATEFORMAT));
				reconSuspenseInfs.add(tOmsReconSuspenseInf);
			}
			if( loanStatus.equals(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT)) &&
				(tOmsReconStmtInf.getCrAmt().compareTo(APIConstant.DEC_ZERO) > 0 && tOmsReconStmtInf.getTransactionType() == APIConstant.LMS_TRX_TYPE_REPAYMENT) 
				
			) {
				rev++;
			}
		}
		bankResult.setRevertCnt(rev);
		tOmsStmtFileMas.setAddInf(CommonUtil.toJson(bankResult));
		return reconSuspenseInfs;
	}
	public static List<TOmsReconSuspenseInf> getSuspenseListFromLms( List<TOmsReconLmsInf> stmtInfs ){
		
		List<TOmsReconSuspenseInf> reconSuspenseInfs = new ArrayList<>();
		
		for (TOmsReconLmsInf tOmsReconStmtInf : stmtInfs) {
			TOmsReconSuspenseInf tOmsReconSuspenseInf = new TOmsReconSuspenseInf();
			
			tOmsReconSuspenseInf.setBankCode(tOmsReconStmtInf.getBankCode());
			tOmsReconSuspenseInf.setCrAmt(tOmsReconStmtInf.getCrAmt());
			tOmsReconSuspenseInf.setDrAmt(tOmsReconStmtInf.getDrAmt());
			tOmsReconSuspenseInf.setLoanNo(tOmsReconStmtInf.getLoanNo());
			tOmsReconSuspenseInf.setRefNo(tOmsReconStmtInf.getRefNo());
			tOmsReconSuspenseInf.setTrxDt(tOmsReconStmtInf.getTrxDt());
			tOmsReconSuspenseInf.setRemark(tOmsReconStmtInf.getRemark());
			setUtilityTOmsReconSuspenseInf(tOmsReconSuspenseInf, APIConstant._USERNAME_BATCHJOB,  DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
					DateUtils.DATEFORMAT), APIConstant._USERNAME_BATCHJOB,  DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
							DateUtils.DATEFORMAT));
			reconSuspenseInfs.add(tOmsReconSuspenseInf);
		}
		
		return reconSuspenseInfs;
	}
	
	public static TOmsReconSuspenseInf getSuspenseFromStatement( TOmsReconStmtInf stmtInfs ){
		
		TOmsReconSuspenseInf reconSuspenseInfs = new TOmsReconSuspenseInf();
		reconSuspenseInfs.setBankCode(stmtInfs.getBankCode());
		reconSuspenseInfs.setCrAmt(stmtInfs.getCrAmt());
		reconSuspenseInfs.setDrAmt(stmtInfs.getDrAmt());
		reconSuspenseInfs.setLoanNo(stmtInfs.getLoanNo());
		reconSuspenseInfs.setRefNo(stmtInfs.getRefNo());
		reconSuspenseInfs.setTrxDt(stmtInfs.getTrxDt());
		reconSuspenseInfs.setRemark(stmtInfs.getRemark());
		setUtilityTOmsReconSuspenseInf(reconSuspenseInfs, APIConstant._USERNAME_BATCHJOB,  DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
					DateUtils.DATEFORMAT), APIConstant._USERNAME_BATCHJOB,  DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
					DateUtils.DATEFORMAT));
		
		return reconSuspenseInfs;
	}
	
	public static List<Object[]> transferDataTotalRecordForReport(BankStatementLmsTrxInfo item){
		List<Object[]> datas = new ArrayList<>();
		Object[] object = {
					"Total", "", "", item.getBankStatemenTrxInfo().getDrAmt(), item.getBankStatemenTrxInfo().getCrAmt(), "",
					"Total", "", "", "", "", item.getLmsTrxInfo().getDrAmt(), item.getLmsTrxInfo().getCrAmt(), ""
				};
		datas.add(object);
		return datas;
	}
	
	public static Object[] transferDataGrandTotalRecordForReport(BankStatementLmsTrxInfo item){
		Object[] object = {
					"Grand total", "", "", item.getBankStatemenTrxInfo().getDrAmt(), item.getBankStatemenTrxInfo().getCrAmt(), "",
					"Grand total", "", "", "", "", item.getLmsTrxInfo().getDrAmt(), item.getLmsTrxInfo().getCrAmt(), ""
				};
		return object;
	}
	public static List<Object[]> transferDataTotalRecordDisbForReport(BankStatementLmsTrxInfo item){
		List<Object[]> datas = new ArrayList<>();
		Object[] object = {
				"Total", "", "", item.getBankStatemenTrxInfo().getDrAmt(), item.getBankStatemenTrxInfo().getCrAmt(), "",
				"Total", "", "", "","", item.getLmsTrxInfo().getDrAmt(), item.getLmsTrxInfo().getCrAmt(), ""
		};
		datas.add(object);
		return datas;
	}
	
	public static Object[] transferDataGrandTotalDisbRecordForReport(BankStatementLmsTrxInfo item){
		Object[] object = {
				"Grand total", "", "", item.getBankStatemenTrxInfo().getDrAmt(), item.getBankStatemenTrxInfo().getCrAmt(), "",
				"Grand total", "", "", "","", item.getLmsTrxInfo().getDrAmt(), item.getLmsTrxInfo().getCrAmt(), ""
		};
		return object;
	}
	
	public static List<Object[]> transferDataToFillHeaderForReport(RepaymentForHeaderReport headerReport){
		List<Object[]> datas = new ArrayList<>();
		Object[] objectBankAcc = {
				"Bank A/c", headerReport.getBankAccount(),"","","","","","","","","","", ""
			};
		Object[] objectBankName = {
				"At", headerReport.getBankName(),"","","","","","","","","","", ""
			};
		Object[] objectOpenBal = {
				"Opening Balance", headerReport.getOpenBal()
			};
		Object[] objectCloseBal = {
				"Closing Balance", headerReport.getCloseBal()//,"","","","","","","","","GL Close Balance",headerReport.getGlOpenBal(),headerReport.getGlCloseBal()
			};
		
		datas.add(objectBankAcc);
		datas.add(objectBankName);
		datas.add(objectOpenBal);
		datas.add(objectCloseBal);
		return datas;
	}
	
	public static BankStatementLmsTrxInfo getGrandBalanceReconcileOfLMSAndBankStatement(BigDecimal matchingDrLMS, BigDecimal matchingCrLMS, 
			BigDecimal matchingDrBank, BigDecimal matchingCrBank, 
			BigDecimal unMatchingDrLMS, BigDecimal unMatchingCrLMS, 
			BigDecimal unMatchingDrBank, BigDecimal unMatchingCrBank) {
		
		BigDecimal grandDebitBank = matchingDrBank.add(unMatchingDrBank);
		BigDecimal grandCreditBank = matchingCrBank.add(unMatchingCrBank);
		
		BigDecimal grandDebitLMS = matchingDrLMS
				.add(unMatchingDrLMS);
		BigDecimal grandCreditLMS = matchingCrLMS
				.add(unMatchingCrLMS);
		
		return new BankStatementLmsTrxInfo(grandDebitBank, grandCreditBank, grandDebitLMS, grandCreditLMS);
	}
	
	public static BankStatementFile transferDataTBankCommonToBankStatementFile(TBankCommon data) {
		BankStatementFile item = new BankStatementFile();
		item.setBankCode(data.getBankCode());
		item.setBankName(data.getBankName());
		item.setIsBank(data.getIsBankYn());
		item.setIsRepayment(data.getIsRepaymentYn());
		BankTemplateInfo bankTemplateInfo;
		try {
			bankTemplateInfo = DTOConverter.getBankTemplateInfo(data.getAddInf());
			item.setFileCnt(bankTemplateInfo.getFileCnt());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return item;
	}
	
	public static BankTemplateInfo getBankTemplateInfo(TBankCommon tBankCommon) throws Exception {
		BankTemplateInfo bankTemplateInfo = (BankTemplateInfo) CommonUtil.toPojo(tBankCommon.getAddInf(), BankTemplateInfo.class);
		if(bankTemplateInfo == null) {
			bankTemplateInfo =  new BankTemplateInfo();
		}
		return bankTemplateInfo;
	}
	public static BankFileReconResult getBankFileReconResult(TOmsStmtFileMas tBankCommon) throws BaseException {
		BankFileReconResult bankTemplateInfo = (BankFileReconResult) CommonUtil.toPojo(tBankCommon.getAddInf(), BankFileReconResult.class);
		if(bankTemplateInfo == null) {
			bankTemplateInfo =  new BankFileReconResult();
		}
		return bankTemplateInfo;
	}
	public static BankTemplateInfo getBankTemplateInfo(String objectString) throws Exception {
		BankTemplateInfo bankTemplateInfo = (BankTemplateInfo) CommonUtil.toPojo(objectString, BankTemplateInfo.class);
		if(bankTemplateInfo == null) {
			bankTemplateInfo =  new BankTemplateInfo();
		}
		return bankTemplateInfo;
	}
	public static List<Object[]> getPendingDisbReportList(List<Object[]> disbInf, List<Object[]> lms ){
		int fromDisbIdx = 0;
		int fromLmsIdx = 8;
		List<Object[]> rs = new ArrayList<>();
		int length = disbInf.size() > lms.size() ? disbInf.size() : lms.size();
		for(int idx = 0; idx < length; idx++) {
			Object[] arr = {"","","","","","","","","","","","","","",""};
			if(idx < disbInf.size()) {
				for (int jdx = 0; jdx < disbInf.get(idx).length; jdx++) {
					arr[fromDisbIdx + jdx] = disbInf.get(idx)[jdx];
				}
			}
			if(idx < lms.size()) {
				for (int jdx = 0; jdx < lms.get(idx).length; jdx++) {
					arr[fromLmsIdx + jdx] = lms.get(idx)[jdx];
				}
			}
			rs.add(arr);
		}
		return rs;
	}
	
	public static TOmsStmtFileMas setAddInfModForFileMas( long status, TOmsReconStmtInf preStatus, TOmsStmtFileMas tOmsStmtFileMas) throws BaseException {
		if(tOmsStmtFileMas.getUploadDt().compareTo( DateUtils.removeTimeFromDate(DateUtils.getCurrentDate())) == 0 ) {
			BankFileReconResult bankFileReconResult = DTOConverter.getBankFileReconResult(tOmsStmtFileMas);
			switch ((int)status) {
				case (int)APIConstant._BANK_STATEMENT_MATCH_STATUS:
					bankFileReconResult.setMatchedCnt(bankFileReconResult.getMatchedCnt() + 1);
					break;
				case (int)APIConstant._BANK_STATEMENT_PENDING_STATUS:
					bankFileReconResult.setPendingCnt(bankFileReconResult.getPendingCnt() + 1);
					break;
				case (int)APIConstant._BANK_STATEMENT_FINANCE_STATUS:
					bankFileReconResult.setFinanceCnt(bankFileReconResult.getFinanceCnt() + 1);
					break;
//				case (int)APIConstant._BANK_DISBURSAL_STATUS_REVERTED:
//					bankFileReconResult.setRevertCnt(bankFileReconResult.getRevertCnt() + 1);
//					break;
				case (int)APIConstant._BANK_STATEMENT_REFUND_STATUS:
				case (int)APIConstant._BANK_STATEMENT_REVERT_STATUS:
					if(preStatus.getDrAmt().compareTo(APIConstant.DEC_ZERO) > 0 )
						bankFileReconResult.setRefundCnt(bankFileReconResult.getRefundCnt() + 1);
					break;
				case (int)APIConstant._BANK_STATEMENT_DELETED_STATUS:
					bankFileReconResult.setTotCnt(bankFileReconResult.getTotCnt() - 1);
				break;
				
				default:
					break;
			}
			switch ((int)preStatus.getStatusCode()) {
				case (int)APIConstant._BANK_STATEMENT_MATCH_STATUS:
					bankFileReconResult.setMatchedCnt(bankFileReconResult.getMatchedCnt() - 1);
					break;
				case (int)APIConstant._BANK_STATEMENT_PENDING_STATUS:
					bankFileReconResult.setPendingCnt(bankFileReconResult.getPendingCnt() - 1);
					break;
				case (int)APIConstant._BANK_STATEMENT_FINANCE_STATUS:
					bankFileReconResult.setFinanceCnt(bankFileReconResult.getFinanceCnt() - 1);
					break;
				case (int)APIConstant._BANK_STATEMENT_REFUND_STATUS:
				case (int)APIConstant._BANK_STATEMENT_REVERT_STATUS:
					if(preStatus.getDrAmt().compareTo(APIConstant.DEC_ZERO) > 0 )
						bankFileReconResult.setRefundCnt(bankFileReconResult.getRefundCnt() - 1);
					break;
				
				default:
					break;
			}
			tOmsStmtFileMas.setAddInf(CommonUtil.toJson(bankFileReconResult));
		}
		
		return tOmsStmtFileMas;
	}
	
	public static void setAddDisbInfModForFileMas( long status, TOmsReconDisburInf preStatus, TOmsStmtFileMas tOmsStmtFileMas) throws BaseException {
		if(tOmsStmtFileMas.getUploadDt().compareTo( DateUtils.removeTimeFromDate(DateUtils.getCurrentDate())) == 0 ) {
			BankFileReconResult bankFileReconResult = DTOConverter.getBankFileReconResult(tOmsStmtFileMas);
			switch ((int)status) {
				case (int)APIConstant._BANK_DISBURSAL_STATUS_CRSHIELD:
					bankFileReconResult.setCreditShieldCnt(bankFileReconResult.getCreditShieldCnt() + 1);
					break;
				case (int)APIConstant._BANK_DISBURSAL_STATUS_REVERTED:
					bankFileReconResult.setRevertCnt(bankFileReconResult.getRevertCnt() + 1);
					break;
				case (int)APIConstant._BANK_DISBURSAL_STATUS_RE_DISB:
					if(preStatus.getDrAmt().compareTo(APIConstant.DEC_ZERO) > 0 )
						bankFileReconResult.setRedisbCnt(bankFileReconResult.getRedisbCnt() + 1);
					break;
				default:
					break;
			}
			switch ((int)preStatus.getStatusCode()) {
				case (int)APIConstant._BANK_DISBURSAL_STATUS_CRSHIELD:
					bankFileReconResult.setCreditShieldCnt(bankFileReconResult.getCreditShieldCnt() - 1);
					break;
				case (int)APIConstant._BANK_DISBURSAL_STATUS_REVERTED:
					bankFileReconResult.setRevertCnt(bankFileReconResult.getRevertCnt() - 1);
					break;
				case (int)APIConstant._BANK_DISBURSAL_STATUS_RE_DISB:
					if(preStatus.getDrAmt().compareTo(APIConstant.DEC_ZERO) > 0 )
						bankFileReconResult.setRedisbCnt(bankFileReconResult.getRedisbCnt() - 1);
					break;
				default:
					break;
			}
			tOmsStmtFileMas.setAddInf(CommonUtil.toJson(bankFileReconResult));
		}
		
	}
	public static void setAddDisbLMSInfModForFileMas( long status, long preStatus,TOmsReconLmsInf item, TOmsStmtFileMas tOmsStmtFileMas) throws BaseException {
		if(tOmsStmtFileMas.getUploadDt().compareTo( DateUtils.removeTimeFromDate(DateUtils.getCurrentDate())) == 0 ) {
			BankFileReconResult bankFileReconResult = DTOConverter.getBankFileReconResult(tOmsStmtFileMas);
			switch ((int)status) {
				case (int)APIConstant._BANK_DISBURSAL_STATUS_PENDING:
					if( item.getLoanStatus().equals(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT)) ) {
						bankFileReconResult.setPendingCnt(bankFileReconResult.getPendingCnt() + 1);
					}
					break;
				case (int)APIConstant._BANK_DISBURSAL_STATUS_MATCHED:
					if( item.getRefNo().toLowerCase().contains("refund") ) 
					{
						bankFileReconResult.setRefundCnt(bankFileReconResult.getRefundCnt() + 1);
					}else
					{
						bankFileReconResult.setMatchedCnt(bankFileReconResult.getMatchedCnt() + 1);
					}
					break;
				default:
					break;
			}
			switch ((int)preStatus) {
				case (int)APIConstant._BANK_DISBURSAL_STATUS_PENDING:
					if( item.getLoanStatus().equals(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT)) ) {
						bankFileReconResult.setPendingCnt(bankFileReconResult.getPendingCnt() - 1);
					}
					break;
				case (int)APIConstant._BANK_DISBURSAL_STATUS_MATCHED:
					if( item.getRefNo().toLowerCase().contains("refund") ) 
					{
						bankFileReconResult.setRefundCnt(bankFileReconResult.getRefundCnt() - 1);
					}else
					{
						bankFileReconResult.setMatchedCnt(bankFileReconResult.getMatchedCnt() - 1);
					}
					break;
				default:
					break;
			}
			tOmsStmtFileMas.setAddInf(CommonUtil.toJson(bankFileReconResult));
		}
		
	}
	
}
