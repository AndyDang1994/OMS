package com.shinhan.recon.core.model.statement;

public class NonBankReconMomoTemplate {

	private String channelID;
	private String STT;
	private String ref;
	private String exntRef;
	private String description;
	private String credit;
	private String trxDt;
	private String day;
	private String type;
	private String trxType;
	private String loanNo;
	public NonBankReconMomoTemplate() {
		super();
		// TODO Auto-generated constructor stub
	}
	public NonBankReconMomoTemplate(String channelID, String sTT, String ref, String exntRef, String description,
			String credit, String trxDt, String day, String type, String trxType, String loanNo) {
		super();
		this.channelID = channelID;
		STT = sTT;
		this.ref = ref;
		this.exntRef = exntRef;
		this.description = description;
		this.credit = credit;
		this.trxDt = trxDt;
		this.day = day;
		this.type = type;
		this.trxType = trxType;
		this.loanNo = loanNo;
	}
	public String getChannelID() {
		return channelID;
	}
	public void setChannelID(String channelID) {
		this.channelID = channelID;
	}
	public String getSTT() {
		return STT;
	}
	public void setSTT(String sTT) {
		STT = sTT;
	}
	public String getRef() {
		return ref;
	}
	public void setRef(String ref) {
		this.ref = ref;
	}
	public String getExntRef() {
		return exntRef;
	}
	public void setExntRef(String exntRef) {
		this.exntRef = exntRef;
	}
	public String getAccountNo() {
		return description;
	}
	public void setAccountNo(String accountNo) {
		this.description = accountNo;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	public String getTrxDt() {
		return trxDt;
	}
	public void setTrxDt(String trxDt) {
		this.trxDt = trxDt;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTrxType() {
		return trxType;
	}
	public void setTrxType(String trxType) {
		this.trxType = trxType;
	}
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	
	
}
