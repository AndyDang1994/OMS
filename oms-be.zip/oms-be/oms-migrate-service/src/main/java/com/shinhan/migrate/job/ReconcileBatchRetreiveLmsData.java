package com.shinhan.migrate.job;

import java.time.LocalDateTime;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.shinhan.migrate.common.AbstractBasicCommonClass;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.util.CommonUtil;
@Component
public class ReconcileBatchRetreiveLmsData extends AbstractBasicCommonClass {
	
	@Scheduled(fixedDelayString = "${spring.job.application.fixedDelay.retreiveLMSData}") // 1 minutes
	public void scanBankStatementFile() throws Exception {
		logger.info("***** Start Retreive LMS Data Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		getProcessManagerService().getReconcileRetreiveLmsDataService().retreiveDataLms();
		
		logger.info("***** End Retreive LMS Data Task Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
	}
	@Scheduled(cron = "${spring.job.application.fixedDelay.deleteGarbageFiles}" ) // 15th of month
	public void deleteGarbage()throws Exception{
		logger.info("***** Start Delete garbage files :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_LMS_TEMP_FOLDER));
		logger.info("***** End Delete garbage files :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
}
