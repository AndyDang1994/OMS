package com.shinhan.migrate.service.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.migrate.common.AbstractBasicCommonClass;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.exception.BaseException;
import com.shinhan.migrate.core.model.FCLFollowUpTemplateInfo;
import com.shinhan.migrate.core.model.FCLFormPaymentTemplateInfo;
import com.shinhan.migrate.core.model.FCLMaturityTemplateInfo;
import com.shinhan.migrate.core.util.CommonUtil;
import com.shinhan.migrate.core.util.DTOConvert;
import com.shinhan.migrate.repository.entity.TOmsFCLFollowEmiMas;
import com.shinhan.migrate.repository.entity.TOmsFCLFormPaymentMas;
import com.shinhan.migrate.repository.entity.TOmsFCLMaturityMas;
import com.shinhan.migrate.service.FCLApiService;

@Service("fclApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class FCLApiServiceImpl extends AbstractBasicCommonClass implements FCLApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.migrate.service.FCLApiService#saveDataFollowEMITrx(java.util.Map)
	 */
	@Override
	public boolean saveDataFollowEMITrx(Map<String, Object> inputParams) throws BaseException {
		List<FCLFollowUpTemplateInfo> lstInfo = CommonUtil.toListPojo(inputParams.get(APIConstant.DOCUMENT).toString(), FCLFollowUpTemplateInfo.class);
		
		if(CollectionUtils.isEmpty(lstInfo)) {
			return false;
		}
		
		//populate data for insert new trx
		List<TOmsFCLFollowEmiMas> lstReg = DTOConvert.parsingToFollowUpMas(lstInfo);
		
		if (CollectionUtils.isNotEmpty(lstReg)) {
			getRepositoryManagerService().processInsertEMITrxToDB(lstReg);
			return true;
		}
		
		return false;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.migrate.service.FCLApiService#saveDataMaturityTrx(java.util.Map)
	 */
	@Override
	public boolean saveDataMaturityTrx(Map<String, Object> inputParams) throws BaseException {
		List<FCLMaturityTemplateInfo> lstInfo = CommonUtil.toListPojo(inputParams.get(APIConstant.DOCUMENT).toString(), FCLMaturityTemplateInfo.class);
		
		if(CollectionUtils.isEmpty(lstInfo)) {
			return false;
		}
		
		//populate data for insert new trx
		List<TOmsFCLMaturityMas> lstReg = DTOConvert.parsingToMaturityMas(lstInfo);
		
		if (CollectionUtils.isNotEmpty(lstReg)) {
			getRepositoryManagerService().processInsertMaturityTrxToDB(lstReg);
			return true;
		}
		
		return false;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.migrate.service.FCLApiService#saveDataFormPayment(java.util.Map)
	 */
	@Override
	public boolean saveDataFormPayment(Map<String, Object> inputParams) throws BaseException {
		List<FCLFormPaymentTemplateInfo> lstInfo = CommonUtil.toListPojo(inputParams.get(APIConstant.DOCUMENT).toString(), FCLFormPaymentTemplateInfo.class);
		
		if(CollectionUtils.isEmpty(lstInfo)) {
			return false;
		}
		
		//populate data for insert new trx
		List<TOmsFCLFormPaymentMas> lstReg = DTOConvert.parsingToFormPaymentMas(lstInfo);
		
		if (CollectionUtils.isNotEmpty(lstReg)) {
			getRepositoryManagerService().processInsertFormPaymentTrxToDB(lstReg);
			return true;
		}
		
		return false;
	}

}
