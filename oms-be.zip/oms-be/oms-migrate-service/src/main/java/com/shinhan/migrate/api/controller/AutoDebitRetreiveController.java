package com.shinhan.migrate.api.controller;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.exception.ServiceInvalidAgurmentException;

@RestController
public class AutoDebitRetreiveController extends BaseController {
	
	@RequestMapping(value = "shinhan/service/autodebit/lmsdirect", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.POST)
	public ResponseEntity<Object> retreiveAndInsertLMSData(
			@RequestBody String document, Locale locale) throws Exception {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		boolean flag = getProcessManagerService().getAutoDebitRetreiveApiService().retreiveAndInsertLMSDataAutoDebit(inputParams);
		if(!flag) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		return triggerSuccessOutPut(APIConstant.SUCCESS_KEY, JsonObject.class, null);
		
	}
	
}
