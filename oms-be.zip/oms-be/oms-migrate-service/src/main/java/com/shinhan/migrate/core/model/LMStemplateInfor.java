package com.shinhan.migrate.core.model;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class LMStemplateInfor {

	private String refNo;
	private String bankCode;
	private String bankName;
	private String loanNo;
	private String custNo;
	private String paymentMode;
	private String remark;
	private BigDecimal receiptAmt;
	private Date trxDt;
	private Date valDt;
	public LMStemplateInfor() {
		super();
	}
	public LMStemplateInfor(String refNo, String bankCode, String bankName, String loanNo, String custNo,
			String paymentMode, String remark, BigDecimal receiptAmt, Date trxDt, Date valDt) {
		super();
		this.refNo = refNo;
		this.bankCode = bankCode;
		this.bankName = bankName;
		this.loanNo = loanNo;
		this.custNo = custNo;
		this.paymentMode = paymentMode;
		this.remark = remark;
		this.receiptAmt = receiptAmt;
		this.trxDt = trxDt;
		this.valDt = valDt;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	public String getCustNo() {
		return custNo;
	}
	public void setCustNo(String custNo) {
		this.custNo = custNo;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public BigDecimal getReceiptAmt() {
		return receiptAmt;
	}
	public void setReceiptAmt(BigDecimal receiptAmt) {
		this.receiptAmt = receiptAmt;
	}
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getTrxDt() {
		return trxDt;
	}
	public void setTrxDt(Date trxDt) {
		this.trxDt = trxDt;
	}
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getValDt() {
		return valDt;
	}
	public void setValDt(Date valDt) {
		this.valDt = valDt;
	}
	
}
