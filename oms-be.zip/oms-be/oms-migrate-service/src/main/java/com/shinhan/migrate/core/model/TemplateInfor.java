package com.shinhan.migrate.core.model;

public class TemplateInfor {

	private String refNo;
	private String bankCode;
	private String bankName;
	private String loanNo;
	private String custNo;
	private String paymentMode;
	private String remark;
	private String receiptAmt;
	private String creditAmt;
	private String debitAmt;
	private String trxDt;
	private String valDt;
	public TemplateInfor() {
		super();
	}
	public TemplateInfor(String refNo, String bankCode, String bankName, String loanNo, String custNo,
			String paymentMode, String remark, String receiptAmt, String trxDt, String valDt, String creditAmt, String debitAmt) {
		super();
		this.refNo = refNo;
		this.bankCode = bankCode;
		this.bankName = bankName;
		this.loanNo = loanNo;
		this.custNo = custNo;
		this.paymentMode = paymentMode;
		this.remark = remark;
		this.receiptAmt = receiptAmt;
		this.trxDt = trxDt;
		this.valDt = valDt;
		this.debitAmt = debitAmt;
		this.creditAmt = creditAmt;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	public String getCustNo() {
		return custNo;
	}
	public void setCustNo(String custNo) {
		this.custNo = custNo;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getReceiptAmt() {
		return receiptAmt;
	}
	public void setReceiptAmt(String receiptAmt) {
		this.receiptAmt = receiptAmt;
	}
	public String getTrxDt() {
		return trxDt;
	}
	public void setTrxDt(String trxDt) {
		this.trxDt = trxDt;
	}
	public String getValDt() {
		return valDt;
	}
	public void setValDt(String valDt) {
		this.valDt = valDt;
	}
	public String getCreditAmt() {
		return creditAmt;
	}
	public void setCreditAmt(String creditAmt) {
		this.creditAmt = creditAmt;
	}
	public String getDebitAmt() {
		return debitAmt;
	}
	public void setDebitAmt(String debitAmt) {
		this.debitAmt = debitAmt;
	}
	
}
