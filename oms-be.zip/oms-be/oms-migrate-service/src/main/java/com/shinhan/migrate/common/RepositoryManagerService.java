/**
 * 
 */
package com.shinhan.migrate.common;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.migrate.core.exception.ServiceRuntimeException;
import com.shinhan.migrate.repository.entity.TOmsFCLFollowEmiMas;
import com.shinhan.migrate.repository.entity.TOmsFCLFormPaymentMas;
import com.shinhan.migrate.repository.entity.TOmsFCLMaturityMas;
import com.shinhan.migrate.repository.service.TOmsAutoDebitLmsMasRepositoryService;
import com.shinhan.migrate.repository.service.TOmsCreditShieldLmsMasRepositoryService;
import com.shinhan.migrate.repository.service.TOmsFclFollowEmiMasRepositoryService;
import com.shinhan.migrate.repository.service.TOmsFclFormPaymentMasRepositoryService;
import com.shinhan.migrate.repository.service.TOmsFclMaturityMasRepositoryService;
import com.shinhan.migrate.repository.service.TOmsReconLmsInfManagerRepositoryService;
import com.shinhan.migrate.repository.service.TOmsReconRetreiveLmsDataRepositoryService;
import com.shinhan.migrate.repository.service.TOmsReconSuspInfManagerRepositoryService;
import com.shinhan.migrate.repository.service.UtilityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("repositoryManagerService")
public class RepositoryManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private UtilityManagerRepositoryService utilityManagerRepositoryService;

	@Autowired
	private TOmsReconLmsInfManagerRepositoryService tomsReconLmsInfManagerRepositoryService;

	@Autowired
	private TOmsReconRetreiveLmsDataRepositoryService tOmsReconRetreiveLmsDataRepositoryService;

	@Autowired
	private TOmsReconSuspInfManagerRepositoryService tOmsReconSuspInfManagerRepositoryService;

	@Autowired
	private TOmsAutoDebitLmsMasRepositoryService tOmsAutoDebitLmsMasRepositoryService;

	@Autowired
	private TOmsCreditShieldLmsMasRepositoryService tOmsCreditShieldLmsMasRepositoryService;

	@Autowired
	private TOmsFclFollowEmiMasRepositoryService tomsFclFollowEmiMasRepositoryService;
	
	@Autowired
	private TOmsFclMaturityMasRepositoryService tomsFclMaturityMasRepositoryService;
	
	@Autowired
	private TOmsFclFormPaymentMasRepositoryService tomsFclFormPaymentMasRepositoryService;

	/**
	 * @return the utilityManagerRepositoryService
	 */
	public UtilityManagerRepositoryService getUtilityManagerRepositoryService() {
		return utilityManagerRepositoryService;
	}

	/**
	 * @param utilityManagerRepositoryService the utilityManagerRepositoryService to
	 *                                        set
	 */
	public void setUtilityManagerRepositoryService(
			@Qualifier("utilityManagerRepositoryService") UtilityManagerRepositoryService utilityManagerRepositoryService) {
		this.utilityManagerRepositoryService = utilityManagerRepositoryService;
	}

	/**
	 * @return the tomsReconLmsInfManagerRepositoryService
	 */
	public TOmsReconLmsInfManagerRepositoryService getTomsReconLmsInfManagerRepositoryService() {
		return tomsReconLmsInfManagerRepositoryService;
	}

	/**
	 * @param tomsReconLmsInfManagerRepositoryService the
	 *                                                tomsReconLmsInfManagerRepositoryService
	 *                                                to set
	 */
	public void setTomsReconLmsInfManagerRepositoryService(
			@Qualifier("tomsReconLmsInfManagerRepositoryService") TOmsReconLmsInfManagerRepositoryService tomsReconLmsInfManagerRepositoryService) {
		this.tomsReconLmsInfManagerRepositoryService = tomsReconLmsInfManagerRepositoryService;
	}

	public TOmsReconRetreiveLmsDataRepositoryService gettOmsReconRetreiveLmsDataRepositoryService() {
		return tOmsReconRetreiveLmsDataRepositoryService;
	}

	public void settOmsReconRetreiveLmsDataRepositoryService(
			@Qualifier("tOmsReconRetreiveLmsDataRepositoryService") TOmsReconRetreiveLmsDataRepositoryService tOmsReconRetreiveLmsDataRepositoryService) {
		this.tOmsReconRetreiveLmsDataRepositoryService = tOmsReconRetreiveLmsDataRepositoryService;
	}

	public TOmsReconSuspInfManagerRepositoryService gettOmsReconSuspInfManagerRepositoryService() {
		return tOmsReconSuspInfManagerRepositoryService;
	}

	public void settOmsReconSuspInfManagerRepositoryService(
			@Qualifier("tOmsReconSuspInfManagerRepositoryService") TOmsReconSuspInfManagerRepositoryService tOmsReconSuspInfManagerRepositoryService) {
		this.tOmsReconSuspInfManagerRepositoryService = tOmsReconSuspInfManagerRepositoryService;
	}

	/**
	 * @return the tOmsAutoDebitLmsMasRepositoryService
	 */
	public TOmsAutoDebitLmsMasRepositoryService gettOmsAutoDebitLmsMasRepositoryService() {
		return tOmsAutoDebitLmsMasRepositoryService;
	}

	/**
	 * @param tOmsAutoDebitLmsMasRepositoryService the tOmsAutoDebitLmsMasRepositoryService to set
	 */
	public void settOmsAutoDebitLmsMasRepositoryService(
			@Qualifier("tomsAutoDebitLmsMasRepositoryService") TOmsAutoDebitLmsMasRepositoryService tOmsAutoDebitLmsMasRepositoryService) {
		this.tOmsAutoDebitLmsMasRepositoryService = tOmsAutoDebitLmsMasRepositoryService;
	}

	/**
	 * @return the tOmsCreditShieldLmsMasRepositoryService
	 */
	public TOmsCreditShieldLmsMasRepositoryService gettOmsCreditShieldLmsMasRepositoryService() {
		return tOmsCreditShieldLmsMasRepositoryService;
	}

	/**
	 * @param tOmsCreditShieldLmsMasRepositoryService the tOmsCreditShieldLmsMasRepositoryService to set
	 */
	public void settOmsCreditShieldLmsMasRepositoryService(
			@Qualifier("tomsCreditShieldLmsMasRepositoryService") TOmsCreditShieldLmsMasRepositoryService tOmsCreditShieldLmsMasRepositoryService) {
		this.tOmsCreditShieldLmsMasRepositoryService = tOmsCreditShieldLmsMasRepositoryService;
	}

	/**
	 * @return the tomsFclFollowEmiMasRepositoryService
	 */
	public TOmsFclFollowEmiMasRepositoryService getTomsFclFollowEmiMasRepositoryService() {
		return tomsFclFollowEmiMasRepositoryService;
	}

	/**
	 * @param tomsFclFollowEmiMasRepositoryService the tomsFclFollowEmiMasRepositoryService to set
	 */
	public void setTomsFclFollowEmiMasRepositoryService(
			@Qualifier("tomsFclFollowEmiMasRepositoryService") TOmsFclFollowEmiMasRepositoryService tomsFclFollowEmiMasRepositoryService) {
		this.tomsFclFollowEmiMasRepositoryService = tomsFclFollowEmiMasRepositoryService;
	}
	
	/**
	 * @return the tomsFclMaturityMasRepositoryService
	 */
	public TOmsFclMaturityMasRepositoryService getTomsFclMaturityMasRepositoryService() {
		return tomsFclMaturityMasRepositoryService;
	}

	/**
	 * @param tomsFclMaturityMasRepositoryService the tomsFclMaturityMasRepositoryService to set
	 */
	public void setTomsFclMaturityMasRepositoryService(
			@Qualifier("tomsFclMaturityMasRepositoryService") TOmsFclMaturityMasRepositoryService tomsFclMaturityMasRepositoryService) {
		this.tomsFclMaturityMasRepositoryService = tomsFclMaturityMasRepositoryService;
	}

	
	
	/**
	 * @return the tomsFclFormPaymentMasRepositoryService
	 */
	public TOmsFclFormPaymentMasRepositoryService getTomsFclFormPaymentMasRepositoryService() {
		return tomsFclFormPaymentMasRepositoryService;
	}

	/**
	 * @param tomsFclFormPaymentMasRepositoryService the tomsFclFormPaymentMasRepositoryService to set
	 */
	public void setTomsFclFormPaymentMasRepositoryService(
			@Qualifier("tomsFclFormPaymentMasRepositoryService") TOmsFclFormPaymentMasRepositoryService tomsFclFormPaymentMasRepositoryService) {
		this.tomsFclFormPaymentMasRepositoryService = tomsFclFormPaymentMasRepositoryService;
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void processInsertEMITrxToDB(List<TOmsFCLFollowEmiMas> lstReg) throws ServiceRuntimeException{
		//clear data 
		getTomsFclFollowEmiMasRepositoryService().deleteDataFollowEmi();
		
		//insert new to DB
		getTomsFclFollowEmiMasRepositoryService().createDataFollowEmiAll(lstReg);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void processInsertMaturityTrxToDB(List<TOmsFCLMaturityMas> lstReg) throws ServiceRuntimeException{
		//clear data 
		getTomsFclMaturityMasRepositoryService().deleteData();
		
		//insert new to DB
		getTomsFclMaturityMasRepositoryService().createData(lstReg);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void processInsertFormPaymentTrxToDB(List<TOmsFCLFormPaymentMas> lstReg) throws ServiceRuntimeException{
		//clear data 
		getTomsFclFormPaymentMasRepositoryService().deleteData();
		
		//insert new to DB
		getTomsFclFormPaymentMasRepositoryService().createData(lstReg);
	}
	
}
