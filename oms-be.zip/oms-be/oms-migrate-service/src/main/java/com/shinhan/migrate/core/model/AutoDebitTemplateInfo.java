package com.shinhan.migrate.core.model;

import com.fasterxml.jackson.annotation.JsonFormat;

public class AutoDebitTemplateInfo {
	private String agreementNo;
	private String loanStatus;
	private String loanACH;
	private String customerName;
	private String customerPhone;
	private String nationalId;
	private String natIdIssueDt;
	private String accNo;
	private String authDt;
	private String firstDue;
	private String shortNameBranch;
	private String relationshipOfficer;
	private String bankName;
	private String noteCode;
	private String incomePayDay;
	private String doc36;
	
	public AutoDebitTemplateInfo(String loanNo, String loanStatus, String loanACH, String customerName,
			String customerPhone, String idNo, String idIssuedDt, String customerBankAccount, String authorizeDt,
			String firstDueDt, String branch, String roUser, String bank, String adType, String autosalDay,
			String doc36) {
		super();
		this.agreementNo = loanNo;
		this.loanStatus = loanStatus;
		this.loanACH = loanACH;
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.nationalId = idNo;
		this.natIdIssueDt = idIssuedDt;
		this.accNo = customerBankAccount;
		this.authDt = authorizeDt;
		this.firstDue = firstDueDt;
		this.shortNameBranch = branch;
		this.relationshipOfficer = roUser;
		this.bankName = bank;
		this.noteCode = adType;
		this.incomePayDay = autosalDay;
		this.doc36 = doc36;
	}
	
	public AutoDebitTemplateInfo() {
		// TODO Auto-generated constructor stub
	}

	public String getLoanNo() {
		return agreementNo;
	}
	public void setLoanNo(String loanNo) {
		this.agreementNo = loanNo;
	}
	public String getLoanStatus() {
		return loanStatus;
	}
	public void setLoanStatus(String loanStatus) {
		this.loanStatus = loanStatus;
	}
	public String getLoanACH() {
		return loanACH;
	}
	public void setLoanACH(String loanACH) {
		this.loanACH = loanACH;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerPhone() {
		return customerPhone;
	}
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}
	public String getIdNo() {
		return nationalId;
	}
	public void setIdNo(String idNo) {
		this.nationalId = idNo;
	}
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public String getIdIssuedDt() {
		return natIdIssueDt;
	}
	public void setIdIssuedDt(String idIssuedDt) {
		this.natIdIssueDt = idIssuedDt;
	}
	public String getCustomerBankAccount() {
		return accNo;
	}
	public void setCustomerBankAccount(String customerBankAccount) {
		this.accNo = customerBankAccount;
	}
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public String getAuthorizeDt() {
		return authDt;
	}
	public void setAuthorizeDt(String authorizeDt) {
		this.authDt = authorizeDt;
	}
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public String getFirstDueDt() {
		return firstDue;
	}
	public void setFirstDueDt(String firstDueDt) {
		this.firstDue = firstDueDt;
	}
	public String getBranch() {
		return shortNameBranch;
	}
	public void setBranch(String branch) {
		this.shortNameBranch = branch;
	}
	public String getRoUser() {
		return relationshipOfficer;
	}
	public void setRoUser(String roUser) {
		this.relationshipOfficer = roUser;
	}
	public String getBank() {
		return bankName;
	}
	public void setBank(String bank) {
		this.bankName = bank;
	}
	public String getAdType() {
		return noteCode;
	}
	public void setAdType(String adType) {
		this.noteCode = adType;
	}
	public String getAutosalDay() {
		return incomePayDay;
	}
	public void setAutosalDay(String autosalDay) {
		this.incomePayDay = autosalDay;
	}
	public String getDoc36() {
		return doc36;
	}
	public void setDoc36(String doc36) {
		this.doc36 = doc36;
	}
	
	
}
