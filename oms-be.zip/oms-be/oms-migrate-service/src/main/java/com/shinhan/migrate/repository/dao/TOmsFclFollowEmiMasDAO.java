package com.shinhan.migrate.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shinhan.migrate.repository.entity.TOmsFCLFollowEmiMas;

public interface TOmsFclFollowEmiMasDAO extends JpaRepository<TOmsFCLFollowEmiMas, Long> {

}
