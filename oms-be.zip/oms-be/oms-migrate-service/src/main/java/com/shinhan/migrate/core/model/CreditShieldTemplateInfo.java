package com.shinhan.migrate.core.model;

import com.fasterxml.jackson.annotation.JsonFormat;

public class CreditShieldTemplateInfo {
	private String loanNo;
	private String cif;
	private String disbursalDate;
	private String loanAmount;
	private String creditShieldAmount;
	private String benName;
	private String benBank;
	private String benAccountNo;
	private String closureDate;
	private String phoneNo;
	private String beneficiaryBankBranchName;
	
	public CreditShieldTemplateInfo(String loanNo, String cif, String disbursalDate,
			String loanAmount, String creditShieldAmount, String benName, String benBank,
			String benAccountNo, String closureDate, String phoneNo, String beneficiaryBankBranchName) {
		super();
		this.loanNo = loanNo;
		this.cif = cif;
		this.disbursalDate = disbursalDate;
		this.loanAmount = loanAmount;
		this.creditShieldAmount = creditShieldAmount;
		this.benName = benName;
		this.benBank = benBank;
		this.benAccountNo = benAccountNo;
		this.closureDate = closureDate;
		this.phoneNo = phoneNo;
		this.beneficiaryBankBranchName = beneficiaryBankBranchName;
	}

	public String getLoanNo() {
		return loanNo;
	}

	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public String getDisbursalDate() {
		return disbursalDate;
	}

	public void setDisbursalDate(String disbursalDate) {
		this.disbursalDate = disbursalDate;
	}

	public String getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(String loanAmount) {
		this.loanAmount = loanAmount;
	}

	public String getCreditShieldAmount() {
		return creditShieldAmount;
	}

	public void setCreditShieldAmount(String creditShieldAmount) {
		this.creditShieldAmount = creditShieldAmount;
	}

	public String getBenName() {
		return benName;
	}

	public void setBenName(String benName) {
		this.benName = benName;
	}

	public String getBenBank() {
		return benBank;
	}

	public void setBenBank(String benBank) {
		this.benBank = benBank;
	}

	public String getBenAccountNo() {
		return benAccountNo;
	}

	public void setBenAccountNo(String benAccountNo) {
		this.benAccountNo = benAccountNo;
	}

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public String getClosureDate() {
		return closureDate;
	}

	public void setClosureDate(String closureDate) {
		this.closureDate = closureDate;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getBeneficiaryBankBranchName() {
		return beneficiaryBankBranchName;
	}

	public void setBeneficiaryBankBranchName(String beneficiaryBankBranchName) {
		this.beneficiaryBankBranchName = beneficiaryBankBranchName;
	}
	
}
