package com.shinhan.migrate.repository.service;

import java.util.List;
import java.util.Map;

import com.shinhan.migrate.core.exception.BaseException;
import com.shinhan.migrate.repository.entity.TOmsCreditShieldLmsMas;

public interface TOmsCreditShieldLmsMasRepositoryService {
	public boolean createAll(List<TOmsCreditShieldLmsMas> lstData) throws BaseException;

	public List<TOmsCreditShieldLmsMas> getListOmsCreditShieldLmsMas(List<String> lstLoanNo) throws BaseException;
}
