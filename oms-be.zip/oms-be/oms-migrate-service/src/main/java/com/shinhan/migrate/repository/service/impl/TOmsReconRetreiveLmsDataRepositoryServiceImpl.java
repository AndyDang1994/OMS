package com.shinhan.migrate.repository.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.migrate.common.AbstractServiceClass;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.exception.BaseException;
import com.shinhan.migrate.core.exception.ServiceRuntimeException;
import com.shinhan.migrate.core.util.DateUtils;
import com.shinhan.migrate.repository.dao.TOmsProjPmtInfDAO;
import com.shinhan.migrate.repository.entity.TOmsProjPmtInf;
import com.shinhan.migrate.repository.service.TOmsReconRetreiveLmsDataRepositoryService;


@Service("tOmsReconRetreiveLmsDataRepositoryService")
public class TOmsReconRetreiveLmsDataRepositoryServiceImpl extends AbstractServiceClass implements TOmsReconRetreiveLmsDataRepositoryService {
 
	private TOmsProjPmtInfDAO objectDAO;
	
	@Autowired
	public TOmsReconRetreiveLmsDataRepositoryServiceImpl(TOmsProjPmtInfDAO objectDAO) {
		super();
		this.objectDAO = objectDAO;
	}



	@Override
	public List<TOmsProjPmtInf> getListByTrxDt(Map<String, Object> inputParams) throws BaseException {
		List<TOmsProjPmtInf> list = new ArrayList<>();
		String sql = "select a.id, a.cd,a.regis_dt,a.value, a.hash_value, a.status, a.service_name  from ( "
				+ "select id, cd, value, regis_dt,hash_value, status,service_name, rank() over( partition by cd, regis_dt order by id desc  ) cnt "
				+ "from proj_payment "
				+ "where regis_dt = :trxDt "
				+ "and service_name = :service_name "
				+ "and status = :status )a "
				+ "where a.cnt = 1";
		Query query = entityManager.createNativeQuery(sql, TOmsProjPmtInf.class);
		query.setParameter("trxDt",DateUtils.converToDate(inputParams.get(APIConstant.TRX_DATE_KEY).toString()));
		query.setParameter("status",APIConstant._PROCESS_STATUS_PENDING);
		query.setParameter("service_name",inputParams.get(APIConstant._SERVICE_NM).toString());
		list = query.getResultList();
		return list;
		
	}
	
	@Override
	public boolean createAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsProjPmtInf> items = (List<TOmsProjPmtInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDAO.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	@Override
	public boolean create(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsProjPmtInf item = (TOmsProjPmtInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDAO.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}



	@Override
	public List<TOmsProjPmtInf> getListByTrxDtandCD(Map<String, Object> inputParams) throws BaseException {
		List<TOmsProjPmtInf> list = new ArrayList<>();
		String sql = 	"select id, cd, value, regis_dt,hash_value,status, service_name "
						+ "from proj_payment "
						+ "where regis_dt = :trxDt "
						+ "and service_name = :service_name "
						+ "and cd = :cd";
		Query query = entityManager.createNativeQuery(sql, TOmsProjPmtInf.class);
		query.setParameter("trxDt",DateUtils.converToDate(inputParams.get(APIConstant.TRX_DATE_KEY).toString()));
		query.setParameter("cd",inputParams.get(APIConstant.DATA_TYPE_KEY));
		query.setParameter("service_name",inputParams.get(APIConstant._SERVICE_NM).toString());
		list = query.getResultList();
		return list;
	}
	
	@Override
	public boolean update(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsProjPmtInf item = (TOmsProjPmtInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDAO.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	

	@Override
	public boolean updateAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsProjPmtInf> items = (List<TOmsProjPmtInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDAO.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
}
