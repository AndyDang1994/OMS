package com.shinhan.migrate.service;

import com.shinhan.migrate.core.exception.BaseException;
import com.shinhan.migrate.core.exception.ServiceRuntimeException;

public interface ReconcileRetreiveLmsDataService {
	
	public void retreiveDataLms() throws ServiceRuntimeException , BaseException;
	
}
