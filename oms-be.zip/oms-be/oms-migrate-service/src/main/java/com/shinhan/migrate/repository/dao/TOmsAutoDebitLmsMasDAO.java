package com.shinhan.migrate.repository.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import org.springframework.stereotype.Repository;

import com.shinhan.migrate.repository.entity.TOmsAutoDebitLmsMas;

@Repository
public interface TOmsAutoDebitLmsMasDAO extends JpaRepository<TOmsAutoDebitLmsMas, Long>, JpaSpecificationExecutor<TOmsAutoDebitLmsMas> {

	@Query("SELECT mas FROM TOmsAutoDebitLmsMas mas WHERE mas.loanNo IN :loanNos")
	public List<TOmsAutoDebitLmsMas> findAllByLoanNo(@Param("loanNos") List<String> loanNos);
}
