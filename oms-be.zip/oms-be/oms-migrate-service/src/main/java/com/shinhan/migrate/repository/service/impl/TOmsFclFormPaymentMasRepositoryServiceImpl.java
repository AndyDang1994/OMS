package com.shinhan.migrate.repository.service.impl;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.migrate.common.AbstractServiceClass;
import com.shinhan.migrate.core.exception.ServiceRuntimeException;
import com.shinhan.migrate.repository.dao.TOmsFclFormPaymentMasDAO;
import com.shinhan.migrate.repository.entity.TOmsFCLFormPaymentMas;
import com.shinhan.migrate.repository.service.TOmsFclFormPaymentMasRepositoryService;

@Service("tomsFclFormPaymentMasRepositoryService")
public class TOmsFclFormPaymentMasRepositoryServiceImpl extends AbstractServiceClass
		implements TOmsFclFormPaymentMasRepositoryService {

	@Autowired
	private TOmsFclFormPaymentMasDAO objectDao;

	@Override
	public void deleteData() throws ServiceRuntimeException {
		try {
			objectDao.deleteAll();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean createData(List<TOmsFCLFormPaymentMas> lstData) throws ServiceRuntimeException {
		try {
			if (CollectionUtils.isNotEmpty(lstData)) {
				objectDao.saveAll(lstData);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

}
