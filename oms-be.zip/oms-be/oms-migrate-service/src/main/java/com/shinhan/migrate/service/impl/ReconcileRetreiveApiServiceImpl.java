/**
 * 
 */
package com.shinhan.migrate.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.migrate.common.AbstractBasicCommonClass;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.migrate.core.util.DTOConvert;
import com.shinhan.migrate.core.util.DateUtils;
import com.shinhan.migrate.core.util.WriteToCSV;
import com.shinhan.migrate.repository.entity.TOmsProjPmtInf;
import com.shinhan.migrate.service.ReconcileRetreiveApiService;

/**
 * @author shds01
 *
 */
@Service("reconcileRetreiveApiService")
public class ReconcileRetreiveApiServiceImpl extends AbstractBasicCommonClass implements ReconcileRetreiveApiService {

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED)
	@Override
	public boolean retreiveLMSData(Map<String, Object> inputParams) throws Exception {
		TOmsProjPmtInf proj = new TOmsProjPmtInf();
		DTOConvert.setUtilityTOmsProjInf(proj, inputParams.get(APIConstant.DATA_TYPE_KEY).toString(), inputParams.get(APIConstant.DOCUMENT).toString(), APIConstant._SERVICE_NM_RECON);
		
		if( inputParams.containsKey(APIConstant.TRX_DATE_KEY) ) {
			inputParams.remove(APIConstant.TRX_DATE_KEY);
		}
		inputParams.put(APIConstant.TRX_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		inputParams.put(APIConstant.DATA_TYPE_KEY, inputParams.get(APIConstant.DATA_TYPE_KEY).toString());
		inputParams.put(APIConstant._SERVICE_NM, APIConstant._SERVICE_NM_RECON);
		List<TOmsProjPmtInf> lsit = getRepositoryManagerService().gettOmsReconRetreiveLmsDataRepositoryService().getListByTrxDtandCD(inputParams);
		for (TOmsProjPmtInf tOmsProjPmtInf : lsit) {
			if( tOmsProjPmtInf.getHashValue().equals(proj.getHashValue()) ) {
				logger.info("***** Retrieve Data From LMS Error, " + inputParams.get(APIConstant.DATA_TYPE_KEY).toString() + " was inserted *****" );
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
			}
		}
		Map<String, Object> input = new HashMap<>();
		input.put(APIConstant.DOCUMENT,proj);
		return getRepositoryManagerService().gettOmsReconRetreiveLmsDataRepositoryService().create(input);
	}
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED)
	@Override
	public boolean retreiveLMSDataRep(Map<String, Object> inputParams) throws Exception {
		TOmsProjPmtInf proj = new TOmsProjPmtInf();
		DTOConvert.setUtilityTOmsProjInf(proj, APIConstant._LMS_TRX_TYPE_REP_, inputParams.get(APIConstant.DOCUMENT).toString(),APIConstant._SERVICE_NM_RECON);
		
		if( inputParams.containsKey(APIConstant.TRX_DATE_KEY) ) {
			inputParams.remove(APIConstant.TRX_DATE_KEY);
		}
		inputParams.put(APIConstant.TRX_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		inputParams.put(APIConstant.DATA_TYPE_KEY, APIConstant._LMS_TRX_TYPE_REP_);
		inputParams.put(APIConstant._SERVICE_NM, APIConstant._SERVICE_NM_RECON);
		List<TOmsProjPmtInf> lsit = getRepositoryManagerService().gettOmsReconRetreiveLmsDataRepositoryService().getListByTrxDtandCD(inputParams);
		for (TOmsProjPmtInf tOmsProjPmtInf : lsit) {
			if( tOmsProjPmtInf.getHashValue().equals(proj.getHashValue()) ) {
				logger.info("***** Retrieve Data From LMS Error, " + APIConstant._LMS_TRX_TYPE_REP_ + " was inserted *****" );
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
			}
		}
		Map<String, Object> input = new HashMap<>();
		input.put(APIConstant.DOCUMENT,proj);
		WriteToCSV.WriteToFile(env.getProperty(APIConstant.PATH_LMS_TEMP_FOLDER) + "/" + APIConstant._LMS_TRX_TYPE_REP_ + "_" + DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss) + ".dat",
								inputParams.get(APIConstant.DOCUMENT).toString());
		return getRepositoryManagerService().gettOmsReconRetreiveLmsDataRepositoryService().create(input);
	}
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED)
	@Override
	public boolean retreiveLMSDataRevert(Map<String, Object> inputParams) throws Exception {
		TOmsProjPmtInf proj = new TOmsProjPmtInf();
		DTOConvert.setUtilityTOmsProjInf(proj, APIConstant._LMS_TRX_TYPE_REV_, inputParams.get(APIConstant.DOCUMENT).toString(),APIConstant._SERVICE_NM_RECON);
		
		if( inputParams.containsKey(APIConstant.TRX_DATE_KEY) ) {
			inputParams.remove(APIConstant.TRX_DATE_KEY);
		}
		inputParams.put(APIConstant.TRX_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		inputParams.put(APIConstant.DATA_TYPE_KEY, APIConstant._LMS_TRX_TYPE_REV_);
		inputParams.put(APIConstant._SERVICE_NM, APIConstant._SERVICE_NM_RECON);
		List<TOmsProjPmtInf> lsit = getRepositoryManagerService().gettOmsReconRetreiveLmsDataRepositoryService().getListByTrxDtandCD(inputParams);
		for (TOmsProjPmtInf tOmsProjPmtInf : lsit) {
			if( tOmsProjPmtInf.getHashValue().equals(proj.getHashValue()) ) {
				logger.info("***** Retrieve Data From LMS Error, " + APIConstant._LMS_TRX_TYPE_REV_ + " was inserted *****" );
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
			}
		}
		Map<String, Object> input = new HashMap<>();
		input.put(APIConstant.DOCUMENT,proj);
		WriteToCSV.WriteToFile(env.getProperty(APIConstant.PATH_LMS_TEMP_FOLDER) + "/" + APIConstant._LMS_TRX_TYPE_REV_ + "_" + DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss)+ ".dat",
				inputParams.get(APIConstant.DOCUMENT).toString());
		return getRepositoryManagerService().gettOmsReconRetreiveLmsDataRepositoryService().create(input);
	}
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED)
	@Override
	public boolean retreiveLMSDataDisb(Map<String, Object> inputParams) throws Exception {
		TOmsProjPmtInf proj = new TOmsProjPmtInf();
		DTOConvert.setUtilityTOmsProjInf(proj, APIConstant._LMS_TRX_TYPE_DISB_, inputParams.get(APIConstant.DOCUMENT).toString(),APIConstant._SERVICE_NM_RECON);
		
		if( inputParams.containsKey(APIConstant.TRX_DATE_KEY) ) {
			inputParams.remove(APIConstant.TRX_DATE_KEY);
		}
		inputParams.put(APIConstant.TRX_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		inputParams.put(APIConstant.DATA_TYPE_KEY, APIConstant._LMS_TRX_TYPE_DISB_);
		inputParams.put(APIConstant._SERVICE_NM, APIConstant._SERVICE_NM_RECON);
		List<TOmsProjPmtInf> lsit = getRepositoryManagerService().gettOmsReconRetreiveLmsDataRepositoryService().getListByTrxDtandCD(inputParams);
		for (TOmsProjPmtInf tOmsProjPmtInf : lsit) {
			if( tOmsProjPmtInf.getHashValue().equals(proj.getHashValue()) ) {
				logger.info("***** Retrieve Data From LMS Error, " +  APIConstant._LMS_TRX_TYPE_DISB_ + " was inserted *****" );
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
			}
		}
		Map<String, Object> input = new HashMap<>();
		input.put(APIConstant.DOCUMENT,proj);
		WriteToCSV.WriteToFile(env.getProperty(APIConstant.PATH_LMS_TEMP_FOLDER) + "/" + APIConstant._LMS_TRX_TYPE_DISB_ + "_" + DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss)+ ".dat",
				inputParams.get(APIConstant.DOCUMENT).toString());
		return getRepositoryManagerService().gettOmsReconRetreiveLmsDataRepositoryService().create(input);
	}

	
}
