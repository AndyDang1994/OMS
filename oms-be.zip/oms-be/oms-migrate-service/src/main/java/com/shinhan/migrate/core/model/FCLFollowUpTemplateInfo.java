package com.shinhan.migrate.core.model;

public class FCLFollowUpTemplateInfo {

	private String loanNo;
	private String loanStatus;
	private String phoneNo;
	private String customerName;
	private String collectionAcc;
	private String bankRefNo;
	private String bankNar;
	private String paymentAmount;
	private String emi;
	private String txnDate;
	//pos
	private String outstandingPrinciple;
	private String excessAmount;
	private String etFees;
	private String partner;
	private String maturityDate;

	/**
	 * 
	 */
	public FCLFollowUpTemplateInfo() {
		super();
	}

	/**
	 * @return the loanNo
	 */
	public String getLoanNo() {
		return loanNo;
	}

	/**
	 * @param loanNo the loanNo to set
	 */
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	/**
	 * @return the loanStatus
	 */
	public String getLoanStatus() {
		return loanStatus;
	}

	/**
	 * @param loanStatus the loanStatus to set
	 */
	public void setLoanStatus(String loanStatus) {
		this.loanStatus = loanStatus;
	}

	/**
	 * @return the phoneNo
	 */
	public String getPhoneNo() {
		return phoneNo;
	}

	/**
	 * @param phoneNo the phoneNo to set
	 */
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the collAcc
	 */
	public String getCollAcc() {
		return collectionAcc;
	}

	/**
	 * @param collAcc the collAcc to set
	 */
	public void setCollAcc(String collAcc) {
		this.collectionAcc = collAcc;
	}

	/**
	 * @return the bankRefNo
	 */
	public String getBankRefNo() {
		return bankRefNo;
	}

	/**
	 * @param bankRefNo the bankRefNo to set
	 */
	public void setBankRefNo(String bankRefNo) {
		this.bankRefNo = bankRefNo;
	}

	/**
	 * @return the bankNarr
	 */
	public String getBankNarr() {
		return bankNar;
	}

	/**
	 * @param bankNarr the bankNarr to set
	 */
	public void setBankNarr(String bankNarr) {
		this.bankNar = bankNarr;
	}

	/**
	 * @return the paymentAmount
	 */
	public String getPaymentAmount() {
		return paymentAmount;
	}

	/**
	 * @param paymentAmount the paymentAmount to set
	 */
	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	/**
	 * @return the emi
	 */
	public String getEmi() {
		return emi;
	}

	/**
	 * @param emi the emi to set
	 */
	public void setEmi(String emi) {
		this.emi = emi;
	}

	/**
	 * @return the txnDate
	 */
	public String getTxnDate() {
		return txnDate;
	}

	/**
	 * @param txnDate the txnDate to set
	 */
	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}

	/**
	 * @return the pos
	 */
	public String getPos() {
		return outstandingPrinciple;
	}

	/**
	 * @param pos the pos to set
	 */
	public void setPos(String pos) {
		this.outstandingPrinciple = pos;
	}

	/**
	 * @return the excessAmount
	 */
	public String getExcessAmount() {
		return excessAmount;
	}

	/**
	 * @param excessAmount the excessAmount to set
	 */
	public void setExcessAmount(String excessAmount) {
		this.excessAmount = excessAmount;
	}

	/**
	 * @return the etFee
	 */
	public String getEtFee() {
		return etFees;
	}

	/**
	 * @param etFee the etFee to set
	 */
	public void setEtFee(String etFee) {
		this.etFees = etFee;
	}

	/**
	 * @return the partner
	 */
	public String getPartner() {
		return partner;
	}

	/**
	 * @param partner the partner to set
	 */
	public void setPartner(String partner) {
		this.partner = partner;
	}

	/**
	 * @return the maturityDate
	 */
	public String getMaturityDate() {
		return maturityDate;
	}

	/**
	 * @param maturityDate the maturityDate to set
	 */
	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

}
