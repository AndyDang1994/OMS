package com.shinhan.migrate.service;

import java.util.Map;

public interface CreditShieldRetreiveApiService {

	public boolean retreiveAndInsertLMSDataCreditShield(Map<String, Object> inputParams) throws Exception;

}
