package com.shinhan.migrate.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.migrate.common.AbstractBasicCommonClass;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.model.CreditShieldTemplateInfo;
import com.shinhan.migrate.core.util.CommonUtil;
import com.shinhan.migrate.core.util.DTOConvert;
import com.shinhan.migrate.core.util.DateUtils;
import com.shinhan.migrate.core.util.WriteToCSV;
import com.shinhan.migrate.repository.entity.TOmsCreditShieldLmsMas;
import com.shinhan.migrate.service.CreditShieldRetreiveApiService;

@Service("creditRetreiveApiService")
public class CreditShieldRetreiveApiServiceImpl extends AbstractBasicCommonClass implements CreditShieldRetreiveApiService {

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED)
	@Override
	public boolean retreiveAndInsertLMSDataCreditShield(Map<String, Object> inputParams) throws Exception {
		List<CreditShieldTemplateInfo> lstInfo = (List<CreditShieldTemplateInfo>) CommonUtil.toListPojo(inputParams.get(APIConstant.DOCUMENT).toString(), CreditShieldTemplateInfo.class);
		boolean flag = false;
		if(CollectionUtils.isEmpty(lstInfo)) {
			return false;
		}
		
		try {
			WriteToCSV.WriteToFile(env.getProperty(APIConstant.PATH_LMS_TEMP_FOLDER) 
								+ "/" + APIConstant._LMS_TRX_TYPE_CREDIT_+ "_" 
								+ DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss) 
								+ ".dat", inputParams.get(APIConstant.DOCUMENT).toString());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		List<String> lstLoanNo = new ArrayList<>();
		for (CreditShieldTemplateInfo item : lstInfo) {
			lstLoanNo.add(item.getLoanNo());
		}
		
		// get data exist in database to update
		List<TOmsCreditShieldLmsMas> lstDataInDB = getRepositoryManagerService().gettOmsCreditShieldLmsMasRepositoryService().getListOmsCreditShieldLmsMas(lstLoanNo);

		
		// populate data for insert new trx and ignore data exist in database
		List<TOmsCreditShieldLmsMas> lstData = DTOConvert.getLmsCreditFromInfo(lstInfo, lstDataInDB);
		
		// Insert into DB
		if (CollectionUtils.isNotEmpty(lstData)) {
			flag = getRepositoryManagerService().gettOmsCreditShieldLmsMasRepositoryService().createAll(lstData);
		}
		return flag;
	}

}
