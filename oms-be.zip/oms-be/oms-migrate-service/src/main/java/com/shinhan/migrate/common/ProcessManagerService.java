/**
 * 
 */
package com.shinhan.migrate.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.shinhan.migrate.service.AutoDebitRetreiveApiService;
import com.shinhan.migrate.service.CreditShieldRetreiveApiService;
import com.shinhan.migrate.service.FCLApiService;
import com.shinhan.migrate.service.ReconcileRetreiveApiService;
import com.shinhan.migrate.service.ReconcileRetreiveLmsDataService;

/**
 * @author shds01
 *
 */
@Service("processManagerService")
public class ProcessManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private ReconcileRetreiveLmsDataService reconcileRetreiveLmsDataService;

	@Autowired
	private ReconcileRetreiveApiService reconcileRetreiveApiService;
	
	@Autowired
	private AutoDebitRetreiveApiService autoDebitRetreiveApiService;
		
	@Autowired
	private FCLApiService fclApiService;
	
	
	@Autowired
	private CreditShieldRetreiveApiService creditShieldRetreiveApiService;
	
	
	public ReconcileRetreiveLmsDataService getReconcileRetreiveLmsDataService() {
		return reconcileRetreiveLmsDataService;
	}

	public void setReconcileRetreiveLmsDataService(
			@Qualifier("reconcileRetreiveLmsDataService") ReconcileRetreiveLmsDataService reconcileRetreiveLmsDataService) {
		this.reconcileRetreiveLmsDataService = reconcileRetreiveLmsDataService;
	}

	public ReconcileRetreiveApiService getReconcileRetreiveApiService() {
		return reconcileRetreiveApiService;
	}

	public void setReconcileRetreiveApiService(
			@Qualifier("reconcileRetreiveApiService") ReconcileRetreiveApiService reconcileRetreiveApiService) {
		this.reconcileRetreiveApiService = reconcileRetreiveApiService;
	}

	public AutoDebitRetreiveApiService getAutoDebitRetreiveApiService() {
		return autoDebitRetreiveApiService;
	}

	public void setAutoDebitRetreiveApiService(@Qualifier("autodebitRetreiveApiService") AutoDebitRetreiveApiService autoDebitRetreiveApiService) {
		this.autoDebitRetreiveApiService = autoDebitRetreiveApiService;
	}

	/**
	 * @return the fclApiService
	 */
	public FCLApiService getFclApiService() {
		return fclApiService;
	}

	/**
	 * @param fclApiService the fclApiService to set
	 */
	public void setFclApiService(@Qualifier("fclApiService") FCLApiService fclApiService) {
		this.fclApiService = fclApiService;
	}

	public CreditShieldRetreiveApiService getCreditShieldRetreiveApiService() {
		return creditShieldRetreiveApiService;
	}

	public void setCreditShieldRetreiveApiService(CreditShieldRetreiveApiService creditShieldRetreiveApiService) {
		this.creditShieldRetreiveApiService = creditShieldRetreiveApiService;
	}
	
	
}
