package com.shinhan.migrate.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shinhan.migrate.repository.entity.TOmsProjPmtInf;

public interface TOmsProjPmtInfDAO extends JpaRepository<TOmsProjPmtInf, Long>{

}
