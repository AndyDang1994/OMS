package com.shinhan.migrate.service;

import java.util.Map;

import com.shinhan.migrate.core.exception.BaseException;

public interface FCLApiService {

	public boolean saveDataFollowEMITrx(Map<String, Object> inputParams) throws BaseException;

	public boolean saveDataMaturityTrx(Map<String, Object> inputParams) throws BaseException;
	
	public boolean saveDataFormPayment(Map<String, Object> inputParams) throws BaseException;
	
}
