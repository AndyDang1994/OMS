package com.shinhan.migrate.repository.service.impl;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.migrate.common.AbstractServiceClass;
import com.shinhan.migrate.core.exception.ServiceRuntimeException;
import com.shinhan.migrate.repository.dao.TOmsFclMaturityMasDAO;
import com.shinhan.migrate.repository.entity.TOmsFCLMaturityMas;
import com.shinhan.migrate.repository.service.TOmsFclMaturityMasRepositoryService;

@Service("tomsFclMaturityMasRepositoryService")
public class TOmsFclMaturityMasRepositoryServiceImpl extends AbstractServiceClass
		implements TOmsFclMaturityMasRepositoryService {

	@Autowired
	private TOmsFclMaturityMasDAO objectDao;

	@Override
	public void deleteData() throws ServiceRuntimeException {
		try {
			objectDao.deleteAll();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean createData(List<TOmsFCLMaturityMas> lstData) throws ServiceRuntimeException {
		try {
			if (CollectionUtils.isNotEmpty(lstData)) {
				objectDao.saveAll(lstData);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

}
