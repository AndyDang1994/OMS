package com.shinhan.migrate.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.migrate.common.AbstractServiceClass;
import com.shinhan.migrate.core.exception.BaseException;
import com.shinhan.migrate.core.exception.ServiceRuntimeException;
import com.shinhan.migrate.core.model.LMStemplateInfor;
import com.shinhan.migrate.core.model.TemplateInfor;
import com.shinhan.migrate.repository.entity.TOmsProjPmtInf;
import com.shinhan.migrate.repository.entity.TOmsReconLmsInf;
import com.shinhan.migrate.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.migrate.service.ReconcileRetreiveLmsDataService;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.util.CommonUtil;
import com.shinhan.migrate.core.util.DTOConvert;
import com.shinhan.migrate.core.util.DateUtils;

@Service("reconcileRetreiveLmsDataService")
@Transactional(readOnly = false, propagation =  Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
public class ReconcileRetreiveLmsDataServiceImpl extends AbstractServiceClass implements ReconcileRetreiveLmsDataService {

	@Override
	public void retreiveDataLms()throws ServiceRuntimeException , BaseException {
		List<TOmsReconLmsInf> lmsList = new ArrayList<>();
		List<TOmsReconSuspenseInf> suspList = new ArrayList<>();
		Map<String, Object> inputParams = new HashedMap<>();
		inputParams.put(APIConstant.TRX_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		inputParams.put(APIConstant._SERVICE_NM, APIConstant._SERVICE_NM_RECON);
		List<TOmsProjPmtInf> rs = getRepositoryManagerService().gettOmsReconRetreiveLmsDataRepositoryService().getListByTrxDt(inputParams);
		for (TOmsProjPmtInf tOmsProjPmtInf : rs) {
			List<TemplateInfor> dupTemplateInfors = new ArrayList<>();
			List<TemplateInfor> templateInfors = CommonUtil.toListPojo(tOmsProjPmtInf.getValue(), TemplateInfor.class);
			for (int i = 0; i < templateInfors.size(); i++) {
				boolean skip = false;
				if(dupTemplateInfors.contains(templateInfors.get(i))) {
					skip = true;
				}
				if(!skip) {
					for(int j = i+1; j < templateInfors.size(); j++) {
						if( templateInfors.get(i).getBankCode().equals(templateInfors.get(j).getBankCode()) && 
						    templateInfors.get(i).getLoanNo().equals(templateInfors.get(j).getLoanNo()) &&
							templateInfors.get(i).getRefNo().equals(templateInfors.get(j).getRefNo()) &&
							(templateInfors.get(i).getReceiptAmt() == null ? "":templateInfors.get(i).getReceiptAmt()).equals((templateInfors.get(j).getReceiptAmt() == null ?"":templateInfors.get(j).getReceiptAmt())) &&
							(templateInfors.get(i).getCreditAmt() == null ? "":templateInfors.get(i).getCreditAmt()).equals((templateInfors.get(j).getCreditAmt() == null ?"":templateInfors.get(j).getCreditAmt())) &&
							(templateInfors.get(i).getDebitAmt() == null ?"":templateInfors.get(i).getDebitAmt()).equals((templateInfors.get(j).getDebitAmt()) == null ? "": templateInfors.get(j).getDebitAmt())) {
							dupTemplateInfors.add(templateInfors.get(j));
						}
					}
				}
				
			}
			templateInfors.removeAll(dupTemplateInfors);
			List<LMStemplateInfor> items = DTOConvert.getLMStempFromInfo(templateInfors,tOmsProjPmtInf.getCD());
			List<LMStemplateInfor> dupItems = new ArrayList<>();
			List<TOmsReconLmsInf> dupList = new ArrayList<>();
			List<String> loanList = new ArrayList<>();
			List<String> refList = new ArrayList<>();
			List<String> bankList = new ArrayList<>();
			List<BigDecimal> amtList = new ArrayList<>();
			for (LMStemplateInfor item : items) {
				loanList.add(item.getLoanNo());
				refList.add(item.getRefNo());
				bankList.add(item.getBankCode());
				amtList.add(item.getReceiptAmt());
			}
			Map<String, Object> lmsInput = new HashedMap<>();
			lmsInput.put(APIConstant._BANK_CODE_KEY, bankList);
			lmsInput.put(APIConstant._DR_AMT_KEY, amtList);
			lmsInput.put(APIConstant._CR_AMT_KEY, amtList);
			lmsInput.put(APIConstant._REF_NO_KEY, refList);
			lmsInput.put(APIConstant.LOAN_NO_KEY, loanList);
			
			if( tOmsProjPmtInf.getCD().equals(APIConstant._LMS_TRX_TYPE_REP_) ) {
				dupList = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getListLMSMatchedListRepTrx(lmsInput);
			}else if(tOmsProjPmtInf.getCD().equals(APIConstant._LMS_TRX_TYPE_DISB_) || tOmsProjPmtInf.getCD().equals(APIConstant._LMS_TRX_TYPE_REV_)) {
				dupList = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getListLMSMatchedListRevTrx(lmsInput);
				
			}
			
			for (LMStemplateInfor item : items) {
				for(TOmsReconLmsInf e : dupList) {
					if( e.getBankCode().equals(item.getBankCode()) && e.getLoanNo().equals(item.getLoanNo()) && e.getRefNo().equals(item.getRefNo()) &&
						( e.getCrAmt().compareTo(item.getReceiptAmt()) == 0 || e.getDrAmt().compareTo(item.getReceiptAmt()) == 0 )	) {
						dupItems.add(item);
						break;
					}
				}
				
			}
			items.removeAll(dupItems);
			dupItems.addAll(DTOConvert.getLMStempFromInfo(dupTemplateInfors,tOmsProjPmtInf.getCD()));
			for (LMStemplateInfor item : items) {
				lmsList.add(DTOConvert.getLMSFromInf(item, tOmsProjPmtInf.getCD()));
				if( tOmsProjPmtInf.getCD().equals(APIConstant._LMS_TRX_TYPE_REV_) ) {
					suspList.add(DTOConvert.getSuspRevertFromInf(item, tOmsProjPmtInf.getCD()));
				}
			}
			for (LMStemplateInfor item : dupItems) {
				lmsList.add(DTOConvert.getLMSDuplicateFromInf(item, tOmsProjPmtInf.getCD()));
			}
			//lmsList.addAll(DTOConvert.getLMSListFromInf(CommonUtil.toListPojo(tOmsProjPmtInf.getValue(), LMStemplateInfor.class), tOmsProjPmtInf.getCD()));
			tOmsProjPmtInf.setStatus(APIConstant._PROCESS_STATUS_DONE);
			tOmsProjPmtInf.setValue(" ");
		}
		if( inputParams.containsKey(APIConstant.DOCUMENT) ) {
			inputParams.remove(APIConstant.DOCUMENT);
		}
		inputParams.put(APIConstant.DOCUMENT, rs);
		getRepositoryManagerService().gettOmsReconRetreiveLmsDataRepositoryService().updateAll(inputParams);
		if( inputParams.containsKey(APIConstant.DOCUMENT) ) {
			inputParams.remove(APIConstant.DOCUMENT);
		}
		inputParams.put(APIConstant.DOCUMENT, lmsList);
		getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().createAll(inputParams);
		if( inputParams.containsKey(APIConstant.DOCUMENT) ) {
			inputParams.remove(APIConstant.DOCUMENT);
		}
		inputParams.put(APIConstant.DOCUMENT, suspList);
		getRepositoryManagerService().gettOmsReconSuspInfManagerRepositoryService().createAll(inputParams);
	}

}
