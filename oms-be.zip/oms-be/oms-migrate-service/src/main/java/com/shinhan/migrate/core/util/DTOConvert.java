/**
 * 
 */
package com.shinhan.migrate.core.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.exception.ServiceRuntimeException;
import com.shinhan.migrate.core.model.AutoDebitTemplateInfo;
import com.shinhan.migrate.core.model.CreditShieldTemplateInfo;
import com.shinhan.migrate.core.model.FCLFollowUpTemplateInfo;
import com.shinhan.migrate.core.model.FCLFormPaymentTemplateInfo;
import com.shinhan.migrate.core.model.FCLMaturityTemplateInfo;
import com.shinhan.migrate.core.model.LMStemplateInfor;
import com.shinhan.migrate.core.model.TemplateInfor;
import com.shinhan.migrate.repository.entity.TOmsAutoDebitLmsMas;
import com.shinhan.migrate.repository.entity.TOmsCreditShieldLmsMas;
import com.shinhan.migrate.repository.entity.TOmsFCLFollowEmiMas;
import com.shinhan.migrate.repository.entity.TOmsFCLFormPaymentMas;
import com.shinhan.migrate.repository.entity.TOmsFCLMaturityMas;
import com.shinhan.migrate.repository.entity.TOmsProjPmtInf;
import com.shinhan.migrate.repository.entity.TOmsReconLmsInf;
import com.shinhan.migrate.repository.entity.TOmsReconSuspenseInf;

/**
 * @author shds01
 *
 */
public class DTOConvert {

	public static List<?> convertSettoList(Set<?> sets) throws ServiceRuntimeException {
		List<?> list = new ArrayList<>(sets);
		return list;
	}

	public static void setUtilityTOmsProjInf(TOmsProjPmtInf item, String CD, String value, String serviceName) throws Exception {
		item.setCD(CD);
		Gson gson = new GsonBuilder().create();
		JsonElement el = JsonParser.parseString(value);
		item.setValue(gson.toJson(el));
		item.setRegisDate(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
		item.setHashValue(CommonUtil.hashMD5(value));
		item.setServiceName(serviceName);
		item.setStatus(APIConstant._PROCESS_STATUS_PENDING);
	}
	
	public static List<TOmsReconLmsInf> getLMSListFromInf(List<LMStemplateInfor> items, String CD){
		
		List<TOmsReconLmsInf> rs = new ArrayList<>();
		
		for (LMStemplateInfor item : items) {
			
			TOmsReconLmsInf tOmsReconLmsInf = new TOmsReconLmsInf();
			
			if(CD.equals(APIConstant._LMS_TRX_TYPE_DISB_)) {
				tOmsReconLmsInf.setTransactionType(APIConstant._BANK_TYPE_DISB);
			}else {
				tOmsReconLmsInf.setTransactionType(APIConstant._BANK_TYPE_REP);
			}
			
			if( CD.equals(APIConstant._LMS_TRX_TYPE_DISB_) || CD.equals(APIConstant._LMS_TRX_TYPE_REV_) ) {
				tOmsReconLmsInf.setCrAmt(item.getReceiptAmt());
				tOmsReconLmsInf.setDrAmt(APIConstant.DEC_ZERO);
			}else if(CD.equals(APIConstant._LMS_TRX_TYPE_REP_)) {
				tOmsReconLmsInf.setDrAmt(item.getReceiptAmt());
				tOmsReconLmsInf.setCrAmt(APIConstant.DEC_ZERO);
			}
			
			tOmsReconLmsInf.setBankCode(item.getBankCode());
			tOmsReconLmsInf.setCif(item.getCustNo());
			tOmsReconLmsInf.setLoanNo(item.getLoanNo());
			tOmsReconLmsInf.setPaymode(item.getPaymentMode());
			tOmsReconLmsInf.setRefNo(item.getRefNo());
			tOmsReconLmsInf.setRemark(item.getRefNo());
			tOmsReconLmsInf.setTrxDt(item.getTrxDt());
			tOmsReconLmsInf.setValueDt(item.getValDt());
			tOmsReconLmsInf.setStatusCode(APIConstant._STATUS_PENDING);
			tOmsReconLmsInf.setCreatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
			tOmsReconLmsInf.setUpdatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
			tOmsReconLmsInf.setCreatedUser(APIConstant._OMS_RECONBATCH_);
			tOmsReconLmsInf.setUpdatedUser(APIConstant._OMS_RECONBATCH_);
			rs.add(tOmsReconLmsInf);
		}
		return rs;
		
	}
	public static TOmsReconLmsInf getLMSFromInf(LMStemplateInfor item, String CD){
		
		TOmsReconLmsInf tOmsReconLmsInf = new TOmsReconLmsInf();
			
		if(CD.equals(APIConstant._LMS_TRX_TYPE_DISB_)) {
			tOmsReconLmsInf.setTransactionType(APIConstant._BANK_TYPE_DISB);
		}else {
			tOmsReconLmsInf.setTransactionType(APIConstant._BANK_TYPE_REP);
		}
		
		if( CD.equals(APIConstant._LMS_TRX_TYPE_DISB_) || CD.equals(APIConstant._LMS_TRX_TYPE_REV_) ) {
			tOmsReconLmsInf.setCrAmt(item.getReceiptAmt());
			tOmsReconLmsInf.setDrAmt(APIConstant.DEC_ZERO);
		}else if(CD.equals(APIConstant._LMS_TRX_TYPE_REP_)) {
			tOmsReconLmsInf.setDrAmt(item.getReceiptAmt());
			tOmsReconLmsInf.setCrAmt(APIConstant.DEC_ZERO);
		}
		
		tOmsReconLmsInf.setBankCode(item.getBankCode());
		tOmsReconLmsInf.setCif(item.getCustNo());
		tOmsReconLmsInf.setLoanNo(item.getLoanNo());
		tOmsReconLmsInf.setPaymode(item.getPaymentMode());
		tOmsReconLmsInf.setRefNo(item.getRefNo());
		tOmsReconLmsInf.setRemark(item.getRemark());
		tOmsReconLmsInf.setTrxDt(item.getTrxDt());
		tOmsReconLmsInf.setValueDt(item.getValDt());
		tOmsReconLmsInf.setStatusCode(APIConstant._STATUS_PENDING);
		tOmsReconLmsInf.setCreatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
		tOmsReconLmsInf.setUpdatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
		tOmsReconLmsInf.setCreatedUser(APIConstant._OMS_RECONBATCH_);
		tOmsReconLmsInf.setUpdatedUser(APIConstant._OMS_RECONBATCH_);
		return tOmsReconLmsInf;
		
	}
	public static TOmsReconLmsInf getLMSDuplicateFromInf(LMStemplateInfor item, String CD){
		
		TOmsReconLmsInf tOmsReconLmsInf = new TOmsReconLmsInf();
		
		if(CD.equals(APIConstant._LMS_TRX_TYPE_DISB_)) {
			tOmsReconLmsInf.setTransactionType(APIConstant._BANK_TYPE_DISB);
		}else {
			tOmsReconLmsInf.setTransactionType(APIConstant._BANK_TYPE_REP);
		}
		
		if( CD.equals(APIConstant._LMS_TRX_TYPE_DISB_) || CD.equals(APIConstant._LMS_TRX_TYPE_REV_) ) {
			tOmsReconLmsInf.setCrAmt(item.getReceiptAmt());
			tOmsReconLmsInf.setDrAmt(APIConstant.DEC_ZERO);
		}else if(CD.equals(APIConstant._LMS_TRX_TYPE_REP_)) {
			tOmsReconLmsInf.setDrAmt(item.getReceiptAmt());
			tOmsReconLmsInf.setCrAmt(APIConstant.DEC_ZERO);
		}
		
		tOmsReconLmsInf.setBankCode(item.getBankCode());
		tOmsReconLmsInf.setCif(item.getCustNo());
		tOmsReconLmsInf.setLoanNo(item.getLoanNo());
		tOmsReconLmsInf.setPaymode(item.getPaymentMode());
		tOmsReconLmsInf.setRefNo(item.getRefNo());
		tOmsReconLmsInf.setRemark(item.getRemark());
		tOmsReconLmsInf.setTrxDt(item.getTrxDt());
		tOmsReconLmsInf.setValueDt(item.getValDt());
		tOmsReconLmsInf.setStatusCode(APIConstant._STATUS_DUPLICATE);
		tOmsReconLmsInf.setRemarkNote(APIConstant._DUPLICATE_NOTE);
		tOmsReconLmsInf.setCreatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
		tOmsReconLmsInf.setUpdatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
		tOmsReconLmsInf.setCreatedUser(APIConstant._OMS_RECONBATCH_);
		tOmsReconLmsInf.setUpdatedUser(APIConstant._OMS_RECONBATCH_);
		return tOmsReconLmsInf;
		
	}
	public static TOmsReconSuspenseInf getSuspRevertFromInf(LMStemplateInfor item, String CD){
		
		TOmsReconSuspenseInf tOmsReconLmsInf = new TOmsReconSuspenseInf();
		
		tOmsReconLmsInf.setBankCode(item.getBankCode());
		tOmsReconLmsInf.setLoanNo(item.getLoanNo());
		tOmsReconLmsInf.setRefNo(item.getRefNo());
		tOmsReconLmsInf.setRemark(item.getRefNo());
		tOmsReconLmsInf.setTrxDt(item.getTrxDt());
		tOmsReconLmsInf.setConfirmYn(APIConstant.NO_KEY);
		tOmsReconLmsInf.setCrAmt(APIConstant.DEC_ZERO);
		tOmsReconLmsInf.setDrAmt(item.getReceiptAmt());
		tOmsReconLmsInf.setLedgerType(APIConstant._LMS_TRX_TYPE_REV_);
		tOmsReconLmsInf.setStatusCode(APIConstant._STATUS_PENDING);
		tOmsReconLmsInf.setPayMode(item.getPaymentMode());
		tOmsReconLmsInf.setRefIdFileMas( (long) 1 );
		tOmsReconLmsInf.setCreatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
		tOmsReconLmsInf.setUpdatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
		tOmsReconLmsInf.setCreateUser(APIConstant._OMS_RECONBATCH_);
		tOmsReconLmsInf.setUpdatedUser(APIConstant._OMS_RECONBATCH_);
		return tOmsReconLmsInf;
		
	}
	
	public static List<LMStemplateInfor> getLMStempFromInfo(List<TemplateInfor> items, String CD){
		
		List<LMStemplateInfor> rs = new ArrayList<>();
		for (TemplateInfor item : items) {
			
			LMStemplateInfor lms = new LMStemplateInfor();
			lms.setBankCode(item.getBankCode());
			lms.setBankName(item.getBankName());
			lms.setCustNo(item.getCustNo());
			lms.setLoanNo(item.getLoanNo());
			lms.setPaymentMode(item.getPaymentMode());
			lms.setRefNo(item.getRefNo());
			lms.setRemark(item.getRemark());
			lms.setReceiptAmt(( StringUtils.isBlank(item.getReceiptAmt()) ? APIConstant.DEC_ZERO : new BigDecimal(item.getReceiptAmt())));
//			if(  CD.equals(APIConstant._LMS_TRX_TYPE_REV_) ) {
//				lms.setReceiptAmt(( StringUtils.isBlank(item.getCreditAmt()) ? APIConstant.DEC_ZERO : new BigDecimal(item.getCreditAmt())));
//				
//			}else 
			if(CD.equals(APIConstant._LMS_TRX_TYPE_REP_) || CD.equals(APIConstant._LMS_TRX_TYPE_REV_) ) {
				lms.setReceiptAmt(( StringUtils.isBlank(item.getReceiptAmt()) ? APIConstant.DEC_ZERO : new BigDecimal(item.getReceiptAmt())));
			}else if(CD.equals(APIConstant._LMS_TRX_TYPE_DISB_)) {
				lms.setReceiptAmt(( StringUtils.isBlank(item.getCreditAmt()) ? APIConstant.DEC_ZERO : new BigDecimal(item.getCreditAmt())));
				lms.setRefNo(item.getRemark());
			}
			if(DateUtils.isValidate(item.getTrxDt())) {
				lms.setTrxDt(DateUtils.convertDate(item.getTrxDt(), DateUtils.getValidFormat(item.getTrxDt()), DateUtils.DATEFORMAT,false));
				
			}else {
				lms.setRemark( APIConstant.THE_DATA_INCORRECT_FORMAT_ERROR );
				lms.setTrxDt(new Date());
			}
			if(DateUtils.isValidate(item.getValDt())) {
				lms.setValDt(DateUtils.convertDate(item.getValDt(), DateUtils.getValidFormat(item.getValDt()), DateUtils.DATEFORMAT,false));
				
			}else {
				lms.setRemark( APIConstant.THE_DATA_INCORRECT_FORMAT_ERROR );
				lms.setValDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
			}
			
			rs.add(lms);
		}
		
		return rs;
		
	}

	public static void setAutoDebitFromInfo(TOmsAutoDebitLmsMas item, AutoDebitTemplateInfo itemInfo) {
		item.setDoc36(itemInfo.getDoc36());
		item.setLoanStatus(itemInfo.getLoanStatus());
		item.setLoanACH(itemInfo.getLoanACH());
		item.setBankName(itemInfo.getBank());
		item.setCustomerBankAccount(itemInfo.getCustomerBankAccount());
		item.setLchgInfoUser(APIConstant.MIGRATE_USER);
		item.setLchgInfoDt(DateUtils.getCurrentDate());
	}

	public static TOmsCreditShieldLmsMas setCreditShieldFromInfo(TOmsCreditShieldLmsMas item, CreditShieldTemplateInfo itemInfo) {


		item.setLoanNo(item.getLoanNo());
		item.setCif(item.getCif());
		item.setDisbursalDate(item.getDisbursalDate());
		item.setLoanAmount(item.getLoanAmount());
		item.setCreditShieldAmount(item.getCreditShieldAmount());
		item.setCfiDate(item.getCfiDate());
		item.setBenName(item.getBenName());
		item.setBenBank(item.getBenBank());
		item.setBenAccountNo(item.getBenAccountNo());
		item.setClosureDate(item.getClosureDate());
		item.setPhoneNo(item.getPhoneNo());
		item.setBeneficiaryBankBranchName(item.getBeneficiaryBankBranchName());

		return item;
	}

	public static List<TOmsAutoDebitLmsMas> getLMSAutoDebittempFromInfo(List<AutoDebitTemplateInfo> items, List<TOmsAutoDebitLmsMas> lstDataInDB) {
		List<TOmsAutoDebitLmsMas> rs = new ArrayList<>();
		for (AutoDebitTemplateInfo item : items) {
			boolean isFound = false;
			
			if(CollectionUtils.isEmpty(lstDataInDB) == false) {
				for(TOmsAutoDebitLmsMas itemData : lstDataInDB) {
					if(itemData.getLoanNo().equals(item.getLoanNo())) {
						isFound = true;
						break;
					}
				}
			}
			
			if(isFound) {
				continue;
			}
			
			TOmsAutoDebitLmsMas lms = new TOmsAutoDebitLmsMas();
			
			lms.setLoanNo(item.getLoanNo());
			lms.setLoanStatus(item.getLoanStatus());
			lms.setLoanACH(item.getLoanACH());
			lms.setCustomerName(item.getCustomerName());
			lms.setCustomerPhone(item.getCustomerPhone());
			lms.setCustomerIdNo(item.getIdNo());
			
			if (DateUtils.isValidate(item.getIdIssuedDt().toString())) {
				lms.setCustomerIssuedDt(DateUtils.convertDate(item.getIdIssuedDt().toString(),
						DateUtils.getValidFormat(item.getIdIssuedDt().toString()), DateUtils.DATEFORMAT, false));
			}
			
			lms.setCustomerBankAccount(item.getCustomerBankAccount());
			
			if (DateUtils.isValidate(item.getAuthorizeDt().toString())) {
				lms.setAuthorizeDt(DateUtils.convertDate(item.getAuthorizeDt().toString(),
						DateUtils.getValidFormat(item.getAuthorizeDt().toString()), DateUtils.DATEFORMAT, false));
			}
			if (DateUtils.isValidate(item.getFirstDueDt().toString())) {
				lms.setFirstDt(DateUtils.convertDate(item.getFirstDueDt().toString(),
						DateUtils.getValidFormat(item.getFirstDueDt().toString()), DateUtils.DATEFORMAT, false));
			}
			
			lms.setBranch(item.getBranch());
			lms.setBankName(item.getBank());
			lms.setAdType(item.getAdType());
			lms.setAutosalDay(item.getAutosalDay());
			lms.setDoc36(item.getDoc36());
			lms.setRoUser(item.getRoUser());
			
			lms.setRegisInfoUser(APIConstant.MIGRATE_USER);
			lms.setRegisInfoDt(DateUtils.getCurrentDate());
			lms.setLchgInfoUser(APIConstant.MIGRATE_USER);
			lms.setLchgInfoDt(DateUtils.getCurrentDate());

			rs.add(lms);

		}
		return rs;

	}

	public static List<TOmsCreditShieldLmsMas> getLmsCreditFromInfo(List<CreditShieldTemplateInfo> itemInfo, List<TOmsCreditShieldLmsMas> lstDataInDB) {
		List<TOmsCreditShieldLmsMas> rs = new ArrayList<>();
		for (CreditShieldTemplateInfo item : itemInfo) {
			boolean isFound = false;
			
			if(CollectionUtils.isEmpty(lstDataInDB) == false) {
				for(TOmsCreditShieldLmsMas itemData : lstDataInDB) {
					if(itemData.getLoanNo().equals(item.getLoanNo())) {
						isFound = true;
						break;
					}
				}
			}
			
			if(isFound) {
				continue;
			}

			TOmsCreditShieldLmsMas lms = new TOmsCreditShieldLmsMas();
			lms.setLoanNo(item.getLoanNo());
			lms.setCif(item.getCif());

			if (DateUtils.isValidate(item.getDisbursalDate())) {
				lms.setDisbursalDate(DateUtils.convertDate(item.getDisbursalDate(),
						DateUtils.getValidFormat(item.getDisbursalDate()), DateUtils.DATEFORMAT, false));
			}

			lms.setLoanAmount(new BigDecimal(item.getLoanAmount()));
			lms.setCreditShieldAmount(new BigDecimal(item.getCreditShieldAmount()));

			lms.setBenName(item.getBenName());
			lms.setBenBank(item.getBenBank());
			lms.setBenAccountNo(item.getBenAccountNo());

			if (DateUtils.isValidate(item.getClosureDate())) {
				lms.setClosureDate(DateUtils.convertDate(item.getClosureDate(),
						DateUtils.getValidFormat(item.getClosureDate()), DateUtils.DATEFORMAT, false));
			}

			lms.setPhoneNo(item.getPhoneNo());
			lms.setBeneficiaryBankBranchName(item.getBeneficiaryBankBranchName());
			
			lms.setRegisInfoUser(APIConstant.MIGRATE_USER);
			lms.setRegisInfoDt(DateUtils.getCurrentDate());
			lms.setLchgInfoUser(APIConstant.MIGRATE_USER);
			lms.setLchgInfoDt(DateUtils.getCurrentDate());

			
			rs.add(lms);

		}
		return rs;
	}
	
	public static List<TOmsFCLFollowEmiMas> parsingToFollowUpMas(List<FCLFollowUpTemplateInfo> items) {
		List<TOmsFCLFollowEmiMas> rs = new ArrayList<>();
		for (FCLFollowUpTemplateInfo item : items) {
			TOmsFCLFollowEmiMas lms = new TOmsFCLFollowEmiMas();
			
			if (StringUtils.isBlank(item.getLoanNo())) {
				continue;
			}
			
			lms.setLoan_no(item.getLoanNo());
			lms.setCustomer_phone_no(item.getPhoneNo());
			
			lms.setCustomer_name(item.getCustomerName());
			lms.setCollection_account(item.getCollAcc());
			lms.setLast_payment_bank_ref(item.getBankRefNo());
			lms.setBank_narration(item.getBankNarr());
			
			lms.setBank_credit_amount(CommonUtil.parseStrToBigDecimal(item.getPaymentAmount()));
			lms.setEmi_amount(CommonUtil.parseStrToBigDecimal(item.getEmi()));
			
			if(StringUtils.isNotEmpty(item.getTxnDate())) {
				if (DateUtils.isValidate(item.getTxnDate())) {
					lms.setTransaction_date(DateUtils.convertDate(item.getTxnDate(),
							DateUtils.getValidFormat(item.getTxnDate()), DateUtils.DATEFORMAT, false));
				}
			}
			
			lms.setOutstanding_principle(CommonUtil.parseStrToBigDecimal(item.getPos()));
			lms.setExcess_amount(CommonUtil.parseStrToBigDecimal(item.getExcessAmount()));
			lms.setPenalty_fees(CommonUtil.parseStrToBigDecimal(item.getEtFee()));
			
			lms.setPartner_bank(item.getPartner());
			
			if(StringUtils.isNotEmpty(item.getMaturityDate())) {
				if (DateUtils.isValidate(item.getMaturityDate())) {
					lms.setLast_due_date(DateUtils.convertDate(item.getMaturityDate(),
							DateUtils.getValidFormat(item.getMaturityDate()), DateUtils.DATEFORMAT, false));
				}
			}
			
			
			lms.setLoan_status(item.getLoanStatus());
			
			lms.setCreatedUser(APIConstant.MIGRATE_USER);
			lms.setCreatedDt(DateUtils.getCurrentDate());
			lms.setUpdatedUser(APIConstant.MIGRATE_USER);
			lms.setUpdatedDt(DateUtils.getCurrentDate());
			
			rs.add(lms);
			
		}
		return rs;

	}
	
	public static List<TOmsFCLMaturityMas> parsingToMaturityMas(List<FCLMaturityTemplateInfo> items) {
		List<TOmsFCLMaturityMas> rs = new ArrayList<>();
		for (FCLMaturityTemplateInfo item : items) {
			TOmsFCLMaturityMas lms = new TOmsFCLMaturityMas();
			
			if (StringUtils.isBlank(item.getLoanNo())) {
				continue;
			}
			
			lms.setLoan_no(item.getLoanNo());
			lms.setLoan_status(item.getLoanStatus());
			
			lms.setCif(item.getCif());
			lms.setCustomer_name(item.getCustomerName());
			lms.setDelq_status(item.getDelqStatus());
			
			if(StringUtils.isNotEmpty(item.getLastDueDate())) {
				if (DateUtils.isValidate(item.getLastDueDate())) {
					lms.setLast_due_date(DateUtils.convertDate(item.getLastDueDate(),
							DateUtils.getValidFormat(item.getLastDueDate()), DateUtils.DATEFORMAT, false));
				}
			}
			
			
			lms.setPrincipal_bal(CommonUtil.parseStrToBigDecimal(item.getPrincipalAmount()));
			lms.setInterest_amount(CommonUtil.parseStrToBigDecimal(item.getInterestAmount()));
			lms.setLast_change_amount(CommonUtil.parseStrToBigDecimal(item.getLastChangeAmount()));
			lms.setOverdue_fee(CommonUtil.parseStrToBigDecimal(item.getOverdueFee()));
			lms.setExcess_amount(CommonUtil.parseStrToBigDecimal(item.getRpaAmount())); //rpa amount
			
			if(StringUtils.isNotEmpty(item.getLastPmtDate())) {
				if (DateUtils.isValidate(item.getLastPmtDate())) {
					lms.setLast_payment_date(DateUtils.convertDate(item.getLastPmtDate(),
							DateUtils.getValidFormat(item.getLastPmtDate()), DateUtils.DATEFORMAT, false));
				}
			}
			
			
			lms.setFcl_category(item.getCategory());
			
			lms.setRepayment_amount(CommonUtil.parseStrToBigDecimal(item.getRepaymentAmount()));
			lms.setPenalty_fees(CommonUtil.parseStrToBigDecimal(item.getPlEarlySettle()));
			
			if(StringUtils.isNotEmpty(item.getCloseDate())) {
				if (DateUtils.isValidate(item.getCloseDate())) {
					lms.setClose_date(DateUtils.convertDate(item.getCloseDate(),
							DateUtils.getValidFormat(item.getCloseDate()), DateUtils.DATEFORMAT, false));
				}
			}
			
			
			lms.setCreatedUser(APIConstant.MIGRATE_USER);
			lms.setCreatedDt(DateUtils.getCurrentDate());
			lms.setUpdatedUser(APIConstant.MIGRATE_USER);
			lms.setUpdatedDt(DateUtils.getCurrentDate());
			
			rs.add(lms);
			
		}
		return rs;

	}
	
	public static List<TOmsFCLFormPaymentMas> parsingToFormPaymentMas(List<FCLFormPaymentTemplateInfo> items) {
		List<TOmsFCLFormPaymentMas> rs = new ArrayList<>();
		for (FCLFormPaymentTemplateInfo item : items) {
			TOmsFCLFormPaymentMas lms = new TOmsFCLFormPaymentMas();
			
			if (StringUtils.isBlank(item.getLoanNo())) {
				continue;
			}
			
			lms.setLoan_no(item.getLoanNo());
			lms.setLoan_status(item.getLoanStatus());
			
			lms.setCif(item.getCif());
			lms.setCustomer_name(item.getCustomerName());
			
			lms.setExcess_amount(CommonUtil.parseStrToBigDecimal(item.getRpaAmount())); //rpa amount
			lms.setEt_amount(CommonUtil.parseStrToBigDecimal(item.getEtAmount()));
			lms.setLast_payment_amount(CommonUtil.parseStrToBigDecimal(item.getLastPmtAmount()));
			
			if(StringUtils.isNotEmpty(item.getLastPmtDate())) {
				if (DateUtils.isValidate(item.getLastPmtDate())) {
					lms.setLast_payment_date(DateUtils.convertDate(item.getLastPmtDate(),
							DateUtils.getValidFormat(item.getLastPmtDate()), DateUtils.DATEFORMAT, false));
				}
			}
			
			
			if(StringUtils.isNotEmpty(item.getEtfScanDate())) {
				if (DateUtils.isValidate(item.getEtfScanDate())) {
					lms.setEt_form_scan_date(DateUtils.convertDate(item.getEtfScanDate(),
							DateUtils.getValidFormat(item.getEtfScanDate()), DateUtils.DATEFORMAT, false));
				}
			}
			
			
			if(StringUtils.isNotEmpty(item.getSimulatedEtDate())) {
				if (DateUtils.isValidate(item.getSimulatedEtDate())) {
					lms.setSimulated_et_date(DateUtils.convertDate(item.getSimulatedEtDate(),
							DateUtils.getValidFormat(item.getSimulatedEtDate()), DateUtils.DATEFORMAT, false));
				}
			}
			
			
			
			lms.setLast_payment_bank_ref(item.getLastPmtBankRef());
			lms.setBank_narration(item.getLastPmtBankNarration());
			
			lms.setRepayment_amount(CommonUtil.parseStrToBigDecimal(item.getRepaymentAmount()));
			lms.setPenalty_fees(CommonUtil.parseStrToBigDecimal(item.getPlEarlySettle()));
			
			lms.setInterest_amount(CommonUtil.parseStrToBigDecimal(item.getInterestAmount()));
			lms.setLast_change_amount(CommonUtil.parseStrToBigDecimal(item.getLastChangeAmount()));
			lms.setOverdue_fee(CommonUtil.parseStrToBigDecimal(item.getOverdueFee()));
			
			lms.setFcl_category(item.getCategory());
			
			lms.setRepayment_amount(CommonUtil.parseStrToBigDecimal(item.getRepaymentAmount()));
			lms.setPenalty_fees(CommonUtil.parseStrToBigDecimal(item.getPlEarlySettle()));
			
			lms.setCreatedUser(APIConstant.MIGRATE_USER);
			lms.setCreatedDt(DateUtils.getCurrentDate());
			lms.setUpdatedUser(APIConstant.MIGRATE_USER);
			lms.setUpdatedDt(DateUtils.getCurrentDate());
			
			rs.add(lms);
			
		}
		return rs;

	}

}
