package com.shinhan.migrate.repository.service;

import java.util.List;

import com.shinhan.migrate.core.exception.BaseException;
import com.shinhan.migrate.repository.entity.TOmsAutoDebitLmsMas;

public interface TOmsAutoDebitLmsMasRepositoryService {


	public boolean createAll(List<TOmsAutoDebitLmsMas> lstData) throws BaseException;
	
	public List<TOmsAutoDebitLmsMas> getListOmsAutoDebitLmsMas(List<String> lstLoanNo) throws BaseException;
	
	public boolean updateAll(List<TOmsAutoDebitLmsMas> lstData) throws BaseException;
	
}
