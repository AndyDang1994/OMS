package com.shinhan.migrate.core.model;

public class FCLFormPaymentTemplateInfo {

	private String loanNo;
	private String loanStatus;
	private String cif;
	private String customerName;
	private String rpaAmount;
	private String etAmount;
	private String lastPmtAmount;
	private String lastPmtDate;
	private String etfScanDate;
	private String simulatedEtDate;
	private String lastPmtBankRef;

	private String category;
	private String lastPmtBankNarration;

	private String repaymentAmount;
	private String plEarlySettle;

	private String interestAmount;
	private String lastChangeAmount;
	private String overdueFee;

	/**
	 * 
	 */
	public FCLFormPaymentTemplateInfo() {
		super();
	}

	/**
	 * @return the loanNo
	 */
	public String getLoanNo() {
		return loanNo;
	}

	/**
	 * @param loanNo the loanNo to set
	 */
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	/**
	 * @return the loanStatus
	 */
	public String getLoanStatus() {
		return loanStatus;
	}

	/**
	 * @param loanStatus the loanStatus to set
	 */
	public void setLoanStatus(String loanStatus) {
		this.loanStatus = loanStatus;
	}

	/**
	 * @return the cif
	 */
	public String getCif() {
		return cif;
	}

	/**
	 * @param cif the cif to set
	 */
	public void setCif(String cif) {
		this.cif = cif;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the rpaAmount
	 */
	public String getRpaAmount() {
		return rpaAmount;
	}

	/**
	 * @param rpaAmount the rpaAmount to set
	 */
	public void setRpaAmount(String rpaAmount) {
		this.rpaAmount = rpaAmount;
	}

	/**
	 * @return the etAmount
	 */
	public String getEtAmount() {
		return etAmount;
	}

	/**
	 * @param etAmount the etAmount to set
	 */
	public void setEtAmount(String etAmount) {
		this.etAmount = etAmount;
	}

	/**
	 * @return the lastPmtAmount
	 */
	public String getLastPmtAmount() {
		return lastPmtAmount;
	}

	/**
	 * @param lastPmtAmount the lastPmtAmount to set
	 */
	public void setLastPmtAmount(String lastPmtAmount) {
		this.lastPmtAmount = lastPmtAmount;
	}

	/**
	 * @return the lastPmtDate
	 */
	public String getLastPmtDate() {
		return lastPmtDate;
	}

	/**
	 * @param lastPmtDate the lastPmtDate to set
	 */
	public void setLastPmtDate(String lastPmtDate) {
		this.lastPmtDate = lastPmtDate;
	}

	/**
	 * @return the etfScanDate
	 */
	public String getEtfScanDate() {
		return etfScanDate;
	}

	/**
	 * @param etfScanDate the etfScanDate to set
	 */
	public void setEtfScanDate(String etfScanDate) {
		this.etfScanDate = etfScanDate;
	}

	/**
	 * @return the simulatedEtDate
	 */
	public String getSimulatedEtDate() {
		return simulatedEtDate;
	}

	/**
	 * @param simulatedEtDate the simulatedEtDate to set
	 */
	public void setSimulatedEtDate(String simulatedEtDate) {
		this.simulatedEtDate = simulatedEtDate;
	}

	/**
	 * @return the lastPmtBankRef
	 */
	public String getLastPmtBankRef() {
		return lastPmtBankRef;
	}

	/**
	 * @param lastPmtBankRef the lastPmtBankRef to set
	 */
	public void setLastPmtBankRef(String lastPmtBankRef) {
		this.lastPmtBankRef = lastPmtBankRef;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * @return the lastPmtBankNarration
	 */
	public String getLastPmtBankNarration() {
		return lastPmtBankNarration;
	}

	/**
	 * @param lastPmtBankNarration the lastPmtBankNarration to set
	 */
	public void setLastPmtBankNarration(String lastPmtBankNarration) {
		this.lastPmtBankNarration = lastPmtBankNarration;
	}

	/**
	 * @return the repaymentAmount
	 */
	public String getRepaymentAmount() {
		return repaymentAmount;
	}

	/**
	 * @param repaymentAmount the repaymentAmount to set
	 */
	public void setRepaymentAmount(String repaymentAmount) {
		this.repaymentAmount = repaymentAmount;
	}

	/**
	 * @return the plEarlySettle
	 */
	public String getPlEarlySettle() {
		return plEarlySettle;
	}

	/**
	 * @param plEarlySettle the plEarlySettle to set
	 */
	public void setPlEarlySettle(String plEarlySettle) {
		this.plEarlySettle = plEarlySettle;
	}

	/**
	 * @return the interestAmount
	 */
	public String getInterestAmount() {
		return interestAmount;
	}

	/**
	 * @param interestAmount the interestAmount to set
	 */
	public void setInterestAmount(String interestAmount) {
		this.interestAmount = interestAmount;
	}

	/**
	 * @return the lastChangeAmount
	 */
	public String getLastChangeAmount() {
		return lastChangeAmount;
	}

	/**
	 * @param lastChangeAmount the lastChangeAmount to set
	 */
	public void setLastChangeAmount(String lastChangeAmount) {
		this.lastChangeAmount = lastChangeAmount;
	}

	/**
	 * @return the overdueFee
	 */
	public String getOverdueFee() {
		return overdueFee;
	}

	/**
	 * @param overdueFee the overdueFee to set
	 */
	public void setOverdueFee(String overdueFee) {
		this.overdueFee = overdueFee;
	}

}
