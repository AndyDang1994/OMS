package com.shinhan.migrate.repository.service;

import java.util.List;

import com.shinhan.migrate.core.exception.ServiceRuntimeException;
import com.shinhan.migrate.repository.entity.TOmsFCLMaturityMas;

public interface TOmsFclMaturityMasRepositoryService {
	
	public void deleteData() throws ServiceRuntimeException;

	public boolean createData(List<TOmsFCLMaturityMas> lstData) throws ServiceRuntimeException;
}
