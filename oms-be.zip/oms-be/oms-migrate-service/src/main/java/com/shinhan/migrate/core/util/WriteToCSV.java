package com.shinhan.migrate.core.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class WriteToCSV {

	public WriteToCSV() {
		super();
	}

	private static void setDataToCellHander( FileWriter fileWriter, Object data ) throws IOException  {
		fileWriter.append(data.toString());
	}
	
	private static void setDataToRowHandle(FileWriter fileWriter, Object[] datas) throws IOException {
		
		for (Object object : datas) {
			setDataToCellHander(fileWriter,object);
		}
	
	}
	
	public static void WriteToFile(String filePath, List<Object[]> datas) throws IOException {
		FileWriter csvWriter = new FileWriter(filePath);
		for (Object[] objects : datas) {
			setDataToRowHandle(csvWriter, objects);
			setDataToCellHander(csvWriter, "\n"); 
		}
		csvWriter.flush();
		csvWriter.close();
	}
	public static void WriteToFile(String filePath, String datas) throws IOException {
		File file = new File(filePath);
		file.getParentFile().mkdirs();
		FileWriter csvWriter = new FileWriter(file);
		csvWriter.append(datas);
		csvWriter.flush();
		csvWriter.close();
	}
	
	public static File WriteToFileJson(String filePath, String datas) throws IOException {
		File file = new File(filePath);
		file.getParentFile().mkdirs();
		FileWriter csvWriter = new FileWriter(file);
		csvWriter.append(datas);
		csvWriter.flush();
		csvWriter.close();
		return file;
	}
}
