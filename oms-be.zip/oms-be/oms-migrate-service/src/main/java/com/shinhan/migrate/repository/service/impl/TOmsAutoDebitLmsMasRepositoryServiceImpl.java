package com.shinhan.migrate.repository.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.shinhan.migrate.common.AbstractServiceClass;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.exception.BaseException;
import com.shinhan.migrate.core.exception.ServiceRuntimeException;
import com.shinhan.migrate.repository.dao.TOmsAutoDebitLmsMasDAO;
import com.shinhan.migrate.repository.entity.TOmsAutoDebitLmsMas;
import com.shinhan.migrate.repository.service.TOmsAutoDebitLmsMasRepositoryService;

@Service("tomsAutoDebitLmsMasRepositoryService")
public class TOmsAutoDebitLmsMasRepositoryServiceImpl extends AbstractServiceClass
		implements TOmsAutoDebitLmsMasRepositoryService {
	
	private TOmsAutoDebitLmsMasDAO objectDao;

	@Autowired
	public TOmsAutoDebitLmsMasRepositoryServiceImpl(TOmsAutoDebitLmsMasDAO objectDao) {
		super();
		this.objectDao = objectDao;
	}

	@Override
	public List<TOmsAutoDebitLmsMas> getListOmsAutoDebitLmsMas(List<String> loanNoLst) throws BaseException {
		
		int limit = Integer.valueOf(env.getProperty(APIConstant.DATA_LIMIT_CONDTION_SEARCHING_IN));
		int sizes = loanNoLst.size();
		if(sizes >= limit) {
			int times = sizes / limit;
			int start = 0;
			int end = limit;
			List<TOmsAutoDebitLmsMas> rs = new ArrayList<TOmsAutoDebitLmsMas>();
			for(int i = 0; i <= times; i++) {
				List<String> loanNoList = loanNoLst.subList(start, end);
				
				rs.addAll(objectDao.findAll(new Specification<TOmsAutoDebitLmsMas>() {
					private static final long serialVersionUID = 4026019747432813696L;

					@Override
					public Predicate toPredicate(Root<TOmsAutoDebitLmsMas> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
						List<Predicate> predicates = new ArrayList<>();
						if (CollectionUtils.isNotEmpty(loanNoList)) {
							predicates.add(root.get("loanNo").in(loanNoList));
						}
						
						return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
					}
				}));
				
				start += limit;
				end += limit;
				if(end > sizes) {
					end = sizes;
				}
			}
			return rs;
			
		} else {
			return objectDao.findAll(new Specification<TOmsAutoDebitLmsMas>() {
				/**
				 * 
				 */
				private static final long serialVersionUID = 4026019747432813696L;

				@Override
				public Predicate toPredicate(Root<TOmsAutoDebitLmsMas> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
					List<Predicate> predicates = new ArrayList<>();
					if (CollectionUtils.isNotEmpty(loanNoLst)) {
						predicates.add(root.get("loanNo").in(loanNoLst));
					}
					
					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}
			});
		}
	}


	@Override
	public boolean updateAll(List<TOmsAutoDebitLmsMas> lstData) throws BaseException {
		try {
			//insert or update record to database
			if (CollectionUtils.isNotEmpty(lstData)) {
				objectDao.saveAll(lstData);
				return true;
			}
			
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean createAll(List<TOmsAutoDebitLmsMas> lstData) throws BaseException {
		try {
			if (CollectionUtils.isNotEmpty(lstData)) {
				objectDao.saveAll(lstData);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

}
