package com.shinhan.migrate.repository.service.impl;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.migrate.common.AbstractServiceClass;
import com.shinhan.migrate.core.exception.ServiceRuntimeException;
import com.shinhan.migrate.repository.dao.TOmsFclFollowEmiMasDAO;
import com.shinhan.migrate.repository.entity.TOmsFCLFollowEmiMas;
import com.shinhan.migrate.repository.service.TOmsFclFollowEmiMasRepositoryService;

@Service("tomsFclFollowEmiMasRepositoryService")
public class TOmsFclFollowEmiMasRepositoryServiceImpl extends AbstractServiceClass
		implements TOmsFclFollowEmiMasRepositoryService {

	@Autowired
	private TOmsFclFollowEmiMasDAO objectDao;

	@Override
	public void deleteDataFollowEmi() throws ServiceRuntimeException {
		try {
			objectDao.deleteAll();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean createDataFollowEmiAll(List<TOmsFCLFollowEmiMas> lstData) throws ServiceRuntimeException {
		try {
			if (CollectionUtils.isNotEmpty(lstData)) {
				objectDao.saveAll(lstData);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

}
