/**
 * 
 */
package com.shinhan.migrate.repository.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author shds01
 *
 */
@Entity
@Table(name = "OMS_FCL_MATURITY_MAS")
public class TOmsFCLMaturityMas implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4844757815682197418L;
	
	private String loan_no;
	private String loan_status;
	private String cif;
	private String customer_name;
	private String delq_status;
	private Date last_due_date;
	private BigDecimal principal_bal;
	private BigDecimal interest_amount;
	private BigDecimal last_change_amount;
	private BigDecimal overdue_fee;
	private BigDecimal excess_amount; //rpa amount
	private Date last_payment_date;
	private String fcl_category;
	private BigDecimal repayment_amount;
	private BigDecimal penalty_fees;
	private Date close_date;
	
	private String createdUser;
	private Date createdDt;
	private String updatedUser;
	private Date updatedDt;
	
	/**
	 * 
	 */
	public TOmsFCLMaturityMas() {
		super();
	}

	/**
	 * @return the loan_no
	 */
	@Id
	@Column(name = "LOAN_NO")
	public String getLoan_no() {
		return loan_no;
	}

	/**
	 * @param loan_no the loan_no to set
	 */
	public void setLoan_no(String loan_no) {
		this.loan_no = loan_no;
	}

	/**
	 * @return the loan_status
	 */
	@Column(name = "LOAN_STATUS")
	public String getLoan_status() {
		return loan_status;
	}

	/**
	 * @param loan_status the loan_status to set
	 */
	public void setLoan_status(String loan_status) {
		this.loan_status = loan_status;
	}

	/**
	 * @return the cif
	 */
	@Column(name = "CIF")
	public String getCif() {
		return cif;
	}

	/**
	 * @param cif the cif to set
	 */
	public void setCif(String cif) {
		this.cif = cif;
	}

	/**
	 * @return the customer_name
	 */
	@Column(name = "CUSTOMER_NAME")
	public String getCustomer_name() {
		return customer_name;
	}

	/**
	 * @param customer_name the customer_name to set
	 */
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	/**
	 * @return the delq_status
	 */
	@Column(name = "DELQ_STATUS")
	public String getDelq_status() {
		return delq_status;
	}

	/**
	 * @param delq_status the delq_status to set
	 */
	public void setDelq_status(String delq_status) {
		this.delq_status = delq_status;
	}

	/**
	 * @return the last_due_date
	 */
	@Column(name = "LAST_DUE_DATE")
	public Date getLast_due_date() {
		return last_due_date;
	}

	/**
	 * @param last_due_date the last_due_date to set
	 */
	public void setLast_due_date(Date last_due_date) {
		this.last_due_date = last_due_date;
	}

	/**
	 * @return the principal_bal
	 */
	@Column(name = "PRINCIPAL_BAL")
	public BigDecimal getPrincipal_bal() {
		return principal_bal;
	}

	/**
	 * @param principal_bal the principal_bal to set
	 */
	public void setPrincipal_bal(BigDecimal principal_bal) {
		this.principal_bal = principal_bal;
	}

	/**
	 * @return the interest_amount
	 */
	@Column(name = "INTEREST_AMOUNT")
	public BigDecimal getInterest_amount() {
		return interest_amount;
	}

	/**
	 * @param interest_amount the interest_amount to set
	 */
	public void setInterest_amount(BigDecimal interest_amount) {
		this.interest_amount = interest_amount;
	}

	/**
	 * @return the last_change_amount
	 */
	@Column(name = "LAST_CHANGE_AMOUNT")
	public BigDecimal getLast_change_amount() {
		return last_change_amount;
	}

	/**
	 * @param last_change_amount the last_change_amount to set
	 */
	public void setLast_change_amount(BigDecimal last_change_amount) {
		this.last_change_amount = last_change_amount;
	}

	/**
	 * @return the overdue_fee
	 */
	@Column(name = "OVERDUE_FEE")
	public BigDecimal getOverdue_fee() {
		return overdue_fee;
	}

	/**
	 * @param overdue_fee the overdue_fee to set
	 */
	public void setOverdue_fee(BigDecimal overdue_fee) {
		this.overdue_fee = overdue_fee;
	}

	/**
	 * @return the excess_amount
	 */
	@Column(name = "EXCESS_AMOUNT")
	public BigDecimal getExcess_amount() {
		return excess_amount;
	}

	/**
	 * @param excess_amount the excess_amount to set
	 */
	public void setExcess_amount(BigDecimal excess_amount) {
		this.excess_amount = excess_amount;
	}

	/**
	 * @return the last_payment_date
	 */
	@Column(name = "LAST_PAYMENT_DATE")
	public Date getLast_payment_date() {
		return last_payment_date;
	}

	/**
	 * @param last_payment_date the last_payment_date to set
	 */
	public void setLast_payment_date(Date last_payment_date) {
		this.last_payment_date = last_payment_date;
	}

	/**
	 * @return the fcl_category
	 */
	@Column(name = "FCL_CATEGORY")
	public String getFcl_category() {
		return fcl_category;
	}

	/**
	 * @param fcl_category the fcl_category to set
	 */
	public void setFcl_category(String fcl_category) {
		this.fcl_category = fcl_category;
	}

	/**
	 * @return the repayment_amount
	 */
	@Column(name = "REPAYMENT_AMOUNT")
	public BigDecimal getRepayment_amount() {
		return repayment_amount;
	}

	/**
	 * @param repayment_amount the repayment_amount to set
	 */
	public void setRepayment_amount(BigDecimal repayment_amount) {
		this.repayment_amount = repayment_amount;
	}

	/**
	 * @return the penalty_fees
	 */
	@Column(name = "PENALTY_FEES")
	public BigDecimal getPenalty_fees() {
		return penalty_fees;
	}

	/**
	 * @param penalty_fees the penalty_fees to set
	 */
	public void setPenalty_fees(BigDecimal penalty_fees) {
		this.penalty_fees = penalty_fees;
	}

	/**
	 * @return the close_date
	 */
	@Column(name = "CLOSE_DATE")
	public Date getClose_date() {
		return close_date;
	}

	/**
	 * @param close_date the close_date to set
	 */
	public void setClose_date(Date close_date) {
		this.close_date = close_date;
	}

	/**
	 * @return the createdUser
	 */
	@Column(name = "REGIS_INF_USER")
	public String getCreatedUser() {
		return createdUser;
	}

	/**
	 * @param createdUser the createdUser to set
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	/**
	 * @return the createdDt
	 */
	@Column(name = "REGIS_INF_DT")
	public Date getCreatedDt() {
		return createdDt;
	}

	/**
	 * @param createdDt the createdDt to set
	 */
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	/**
	 * @return the updatedUser
	 */
	@Column(name = "LCHG_INF_USER")
	public String getUpdatedUser() {
		return updatedUser;
	}

	/**
	 * @param updatedUser the updatedUser to set
	 */
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}

	/**
	 * @return the updatedDt
	 */
	@Column(name = "LCHG_INF_DT")
	public Date getUpdatedDt() {
		return updatedDt;
	}

	/**
	 * @param updatedDt the updatedDt to set
	 */
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TOmsFCLMaturityMas [loan_no=" + loan_no + ", loan_status=" + loan_status + ", delq_status="
				+ delq_status + "]";
	}
	
	
}
