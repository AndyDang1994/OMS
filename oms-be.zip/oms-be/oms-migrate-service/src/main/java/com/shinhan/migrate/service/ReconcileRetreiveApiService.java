/**
 * 
 */
package com.shinhan.migrate.service;

import java.util.Map;

/**
 * @author shds01
 *
 */
public interface ReconcileRetreiveApiService {

	public boolean retreiveLMSDataRep(Map<String, Object> inputParams) throws Exception;

	public boolean retreiveLMSDataRevert(Map<String, Object> inputParams) throws Exception;
	
	public boolean retreiveLMSDataDisb(Map<String, Object> inputParams) throws Exception;

	public boolean retreiveLMSData(Map<String, Object> inputParams) throws Exception;
	
}
