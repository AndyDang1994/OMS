/**
 * 
 */
package com.shinhan.migrate.repository.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author shds01
 *
 */
@Entity
@Table(name = "OMS_FCL_FOLLOWEMI_MAS")
public class TOmsFCLFollowEmiMas implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4844757815682197418L;

	private Long id;
	private String loan_no;
	private String loan_status;

	private String customer_name;
	private String customer_phone_no;
	private String collection_account;

	private String last_payment_bank_ref;
	private String bank_narration;
	private BigDecimal bank_credit_amount;
	private BigDecimal emi_amount;
	private Date transaction_date;
	private BigDecimal outstanding_principle;
	private BigDecimal excess_amount; // rpa amount
	private BigDecimal penalty_fees;
	private String partner_bank;
	private Date last_due_date;

	private String createdUser;
	private Date createdDt;
	private String updatedUser;
	private Date updatedDt;

	public TOmsFCLFollowEmiMas() {
		super();
	}

	
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "OMS_FCL_FOLLOWEMI_MAS_SEQ_GEN")
	@SequenceGenerator(name = "OMS_FCL_FOLLOWEMI_MAS_SEQ_GEN", sequenceName = "OMS_FCL_FOLLOWEMI_MAS_SEQ", allocationSize = 1)
	@Column(name = "ID")
	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the loan_no
	 */
	@Column(name = "LOAN_NO")
	public String getLoan_no() {
		return loan_no;
	}

	/**
	 * @param loan_no the loan_no to set
	 */
	public void setLoan_no(String loan_no) {
		this.loan_no = loan_no;
	}

	/**
	 * @return the loan_status
	 */
	@Column(name = "LOAN_STATUS")
	public String getLoan_status() {
		return loan_status;
	}

	/**
	 * @param loan_status the loan_status to set
	 */
	public void setLoan_status(String loan_status) {
		this.loan_status = loan_status;
	}

	/**
	 * @return the customer_name
	 */
	@Column(name = "CUSTOMER_NAME")
	public String getCustomer_name() {
		return customer_name;
	}

	/**
	 * @param customer_name the customer_name to set
	 */
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	/**
	 * @return the customer_phone_no
	 */
	@Column(name = "CUSTOMER_PHONE_NO")
	public String getCustomer_phone_no() {
		return customer_phone_no;
	}

	/**
	 * @param customer_phone_no the customer_phone_no to set
	 */
	public void setCustomer_phone_no(String customer_phone_no) {
		this.customer_phone_no = customer_phone_no;
	}

	/**
	 * @return the collection_account
	 */
	@Column(name = "COLLECTION_ACCOUNT")
	public String getCollection_account() {
		return collection_account;
	}

	/**
	 * @param collection_account the collection_account to set
	 */
	public void setCollection_account(String collection_account) {
		this.collection_account = collection_account;
	}

	/**
	 * @return the last_payment_bank_ref
	 */
	@Column(name = "LAST_PAYMENT_BANK_REF")
	public String getLast_payment_bank_ref() {
		return last_payment_bank_ref;
	}

	/**
	 * @param last_payment_bank_ref the last_payment_bank_ref to set
	 */
	public void setLast_payment_bank_ref(String last_payment_bank_ref) {
		this.last_payment_bank_ref = last_payment_bank_ref;
	}

	/**
	 * @return the bank_narration
	 */
	@Column(name = "BANK_NARRATION")
	public String getBank_narration() {
		return bank_narration;
	}

	/**
	 * @param bank_narration the bank_narration to set
	 */
	public void setBank_narration(String bank_narration) {
		this.bank_narration = bank_narration;
	}

	/**
	 * @return the bank_credit_amount
	 */
	@Column(name = "BANK_CREDIT_AMOUNT")
	public BigDecimal getBank_credit_amount() {
		return bank_credit_amount;
	}

	/**
	 * @param bank_credit_amount the bank_credit_amount to set
	 */
	public void setBank_credit_amount(BigDecimal bank_credit_amount) {
		this.bank_credit_amount = bank_credit_amount;
	}

	/**
	 * @return the emi_amount
	 */
	@Column(name = "EMI_AMOUNT")
	public BigDecimal getEmi_amount() {
		return emi_amount;
	}

	/**
	 * @param emi_amount the emi_amount to set
	 */
	public void setEmi_amount(BigDecimal emi_amount) {
		this.emi_amount = emi_amount;
	}

	/**
	 * @return the transaction_date
	 */
	@Column(name = "TRANSACTION_DATE")
	public Date getTransaction_date() {
		return transaction_date;
	}

	/**
	 * @param transaction_date the transaction_date to set
	 */
	public void setTransaction_date(Date transaction_date) {
		this.transaction_date = transaction_date;
	}

	/**
	 * @return the outstanding_principle
	 */
	@Column(name = "OUTSTANDING_PRINCIPLE")
	public BigDecimal getOutstanding_principle() {
		return outstanding_principle;
	}

	/**
	 * @param outstanding_principle the outstanding_principle to set
	 */
	public void setOutstanding_principle(BigDecimal outstanding_principle) {
		this.outstanding_principle = outstanding_principle;
	}

	/**
	 * @return the excess_amount
	 */
	@Column(name = "EXCESS_AMOUNT")
	public BigDecimal getExcess_amount() {
		return excess_amount;
	}

	/**
	 * @param excess_amount the excess_amount to set
	 */
	public void setExcess_amount(BigDecimal excess_amount) {
		this.excess_amount = excess_amount;
	}

	/**
	 * @return the penalty_fees
	 */
	@Column(name = "PENALTY_FEES")
	public BigDecimal getPenalty_fees() {
		return penalty_fees;
	}

	/**
	 * @param penalty_fees the penalty_fees to set
	 */
	public void setPenalty_fees(BigDecimal penalty_fees) {
		this.penalty_fees = penalty_fees;
	}

	/**
	 * @return the partner_bank
	 */
	@Column(name = "PARTNER_BANK")
	public String getPartner_bank() {
		return partner_bank;
	}

	/**
	 * @param partner_bank the partner_bank to set
	 */
	public void setPartner_bank(String partner_bank) {
		this.partner_bank = partner_bank;
	}

	/**
	 * @return the last_due_date
	 */
	@Column(name = "LAST_DUE_DATE")
	public Date getLast_due_date() {
		return last_due_date;
	}

	/**
	 * @param last_due_date the last_due_date to set
	 */
	public void setLast_due_date(Date last_due_date) {
		this.last_due_date = last_due_date;
	}

	/**
	 * @return the createdUser
	 */
	@Column(name = "REGIS_INF_USER")
	public String getCreatedUser() {
		return createdUser;
	}

	/**
	 * @param createdUser the createdUser to set
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	/**
	 * @return the createdDt
	 */
	@Column(name = "REGIS_INF_DT")
	public Date getCreatedDt() {
		return createdDt;
	}

	/**
	 * @param createdDt the createdDt to set
	 */
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	/**
	 * @return the updatedUser
	 */
	@Column(name = "LCHG_INF_USER")
	public String getUpdatedUser() {
		return updatedUser;
	}

	/**
	 * @param updatedUser the updatedUser to set
	 */
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}

	/**
	 * @return the updatedDt
	 */
	@Column(name = "LCHG_INF_DT")
	public Date getUpdatedDt() {
		return updatedDt;
	}

	/**
	 * @param updatedDt the updatedDt to set
	 */
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

}
