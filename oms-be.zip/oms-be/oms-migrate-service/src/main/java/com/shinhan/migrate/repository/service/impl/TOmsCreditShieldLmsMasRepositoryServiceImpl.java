package com.shinhan.migrate.repository.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.shinhan.migrate.common.AbstractServiceClass;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.exception.BaseException;
import com.shinhan.migrate.core.exception.ServiceRuntimeException;
import com.shinhan.migrate.repository.dao.TOmsCreditShieldLmsMasDAO;
import com.shinhan.migrate.repository.entity.TOmsCreditShieldLmsMas;
import com.shinhan.migrate.repository.service.TOmsCreditShieldLmsMasRepositoryService;

@Service("tomsCreditShieldLmsMasRepositoryService")
public class TOmsCreditShieldLmsMasRepositoryServiceImpl extends AbstractServiceClass implements TOmsCreditShieldLmsMasRepositoryService{

	@Autowired
	private TOmsCreditShieldLmsMasDAO objectDao;
	
	@Override
	public boolean createAll(List<TOmsCreditShieldLmsMas> lstData) throws BaseException {
		try {
			if (CollectionUtils.isNotEmpty(lstData)) {
				objectDao.saveAll(lstData);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public List<TOmsCreditShieldLmsMas> getListOmsCreditShieldLmsMas(List<String> lstLoanNo) throws BaseException {
		int limit = Integer.valueOf(env.getProperty(APIConstant.DATA_LIMIT_CONDTION_SEARCHING_IN));
		int sizes = lstLoanNo.size();
		if(sizes >= limit) {
			int times = sizes / limit;
			int start = 0;
			int end = limit;
			List<TOmsCreditShieldLmsMas> rs = new ArrayList<TOmsCreditShieldLmsMas>();
			for(int i = 0; i <= times; i++) {
				List<String> loanNoList = lstLoanNo.subList(start, end);
				
				rs.addAll(objectDao.findAll(new Specification<TOmsCreditShieldLmsMas>() {
					private static final long serialVersionUID = 4026019747432813696L;

					@Override
					public Predicate toPredicate(Root<TOmsCreditShieldLmsMas> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
						List<Predicate> predicates = new ArrayList<>();
						if (CollectionUtils.isNotEmpty(loanNoList)) {
							predicates.add(root.get("loanNo").in(loanNoList));
						}
						
						return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
					}

					
				}));
				
				start += limit;
				end += limit;
				if(end > sizes) {
					end = sizes;
				}
			}
			return rs;
			
		} else {
			return objectDao.findAll(new Specification<TOmsCreditShieldLmsMas>() {
				/**
				 * 
				 */
				private static final long serialVersionUID = 4026019747432813696L;

				@Override
				public Predicate toPredicate(Root<TOmsCreditShieldLmsMas> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
					List<Predicate> predicates = new ArrayList<>();
					if (CollectionUtils.isNotEmpty(lstLoanNo)) {
						predicates.add(root.get("loanNo").in(lstLoanNo));
					}
					
					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}
			});
		}
	}

}
