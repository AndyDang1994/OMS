package com.shinhan.migrate.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.migrate.common.AbstractBasicCommonClass;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.model.AutoDebitTemplateInfo;
import com.shinhan.migrate.core.util.CommonUtil;
import com.shinhan.migrate.core.util.DTOConvert;
import com.shinhan.migrate.core.util.DateUtils;
import com.shinhan.migrate.core.util.WriteToCSV;
import com.shinhan.migrate.repository.entity.TOmsAutoDebitLmsMas;
import com.shinhan.migrate.service.AutoDebitRetreiveApiService;

@Service("autodebitRetreiveApiService")
public class AutoDebitRetreiveApiServiceImpl extends AbstractBasicCommonClass implements AutoDebitRetreiveApiService {

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED)
	@Override
	public boolean retreiveAndInsertLMSDataAutoDebit(Map<String, Object> inputParams) throws Exception {
		List<AutoDebitTemplateInfo> lstInfo = (List<AutoDebitTemplateInfo>) CommonUtil.toListPojo(inputParams.get(APIConstant.DOCUMENT).toString(), AutoDebitTemplateInfo.class);
		boolean flag = false;
		if (CollectionUtils.isEmpty(lstInfo)) {
			return false;
		}
		try {
			WriteToCSV.WriteToFile(env.getProperty(APIConstant.PATH_LMS_TEMP_FOLDER) 
								+ "/" + APIConstant._LMS_TRX_TYPE_AUTO_DEBIT_+ "_" 
								+ DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss) 
								+ ".dat", inputParams.get(APIConstant.DOCUMENT).toString());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		List<String> lstLoanNo = new ArrayList<>();
		for (AutoDebitTemplateInfo item : lstInfo) {
			lstLoanNo.add(item.getLoanNo());
		}

		// get data exist in database to update
		List<TOmsAutoDebitLmsMas> lstDataInDB = getRepositoryManagerService().gettOmsAutoDebitLmsMasRepositoryService().getListOmsAutoDebitLmsMas(lstLoanNo);
		
		// set data change
		for (TOmsAutoDebitLmsMas itemInDB : lstDataInDB) {
			for(AutoDebitTemplateInfo itemInfo : lstInfo) {
				if (itemInDB.getLoanNo().equals(itemInfo.getLoanNo())) {
					DTOConvert.setAutoDebitFromInfo(itemInDB, itemInfo);
				}
			}
		}
		
		//populate data for insert new trx
		List<TOmsAutoDebitLmsMas> lstData = DTOConvert.getLMSAutoDebittempFromInfo(lstInfo, lstDataInDB);
		
		//Insert into DB
		if(CollectionUtils.isNotEmpty(lstData)) {
			flag = getRepositoryManagerService().gettOmsAutoDebitLmsMasRepositoryService().createAll(lstData);
		}
		
		//Update into DB
		if(CollectionUtils.isNotEmpty(lstDataInDB)) {
			flag =  getRepositoryManagerService().gettOmsAutoDebitLmsMasRepositoryService().updateAll(lstDataInDB);
		}
		return flag;
		
	}

}
