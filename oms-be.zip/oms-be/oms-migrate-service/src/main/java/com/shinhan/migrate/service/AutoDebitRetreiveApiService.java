package com.shinhan.migrate.service;

import java.util.Map;

public interface AutoDebitRetreiveApiService {
	
	public boolean retreiveAndInsertLMSDataAutoDebit(Map<String, Object> inputParams) throws Exception;

}
