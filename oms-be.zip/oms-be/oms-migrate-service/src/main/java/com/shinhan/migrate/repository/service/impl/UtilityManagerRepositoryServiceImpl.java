/**
 * 
 */
package com.shinhan.migrate.repository.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.springframework.stereotype.Service;

import com.shinhan.migrate.common.AbstractServiceClass;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.exception.BaseException;
import com.shinhan.migrate.core.util.DateUtils;
import com.shinhan.migrate.repository.entity.TBankCommon;
import com.shinhan.migrate.repository.entity.TMetadata;
import com.shinhan.migrate.repository.service.UtilityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("utilityManagerRepositoryService")
public class UtilityManagerRepositoryServiceImpl extends AbstractServiceClass
		implements UtilityManagerRepositoryService {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.shinhan.recon.repository.service.UtilityManagerRepositoryService#
	 * getAllMetadata(java.util.Map)
	 */
	@Override
	public List<TMetadata> getAllMetadata(Map<String, Object> inputParams) throws BaseException {
		String sql = oracleOMSNamedQueries.get("getAllMetadata");
		Query query = entityManager.createNativeQuery(sql, TMetadata.class);

		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();

		return list;
	}
	
	@Override
	public List<TMetadata> getMetadataByLookupCode(String lookupCode) throws BaseException {
		String sql = oracleOMSNamedQueries.get("getMetadataByLookupCode");
		Query query = entityManager.createNativeQuery(sql, TMetadata.class);
		query.setParameter("LOOKUPCODE", lookupCode);
		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();

		return list;
	}

}
