package com.shinhan.migrate.core.model;

public class FCLMaturityTemplateInfo {

	private String loanNo;
	private String loanStatus;
	private String cif;
	private String customerName;
	private String delqStatus;
	private String lastDueDate;
	private String principalAmount;
	private String interestAmount;
	private String lastChangeAmount;
	private String overdueFee;
	private String rpaAmount;
	private String lastPmtDate;
	private String category;

	private String repaymentAmount;
	private String plEarlySettle;

	private String closedDate;

	/**
	 * 
	 */
	public FCLMaturityTemplateInfo() {
		super();
	}

	/**
	 * @return the loanNo
	 */
	public String getLoanNo() {
		return loanNo;
	}

	/**
	 * @param loanNo the loanNo to set
	 */
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	/**
	 * @return the loanStatus
	 */
	public String getLoanStatus() {
		return loanStatus;
	}

	/**
	 * @param loanStatus the loanStatus to set
	 */
	public void setLoanStatus(String loanStatus) {
		this.loanStatus = loanStatus;
	}

	/**
	 * @return the cif
	 */
	public String getCif() {
		return cif;
	}

	/**
	 * @param cif the cif to set
	 */
	public void setCif(String cif) {
		this.cif = cif;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the delqStatus
	 */
	public String getDelqStatus() {
		return delqStatus;
	}

	/**
	 * @param delqStatus the delqStatus to set
	 */
	public void setDelqStatus(String delqStatus) {
		this.delqStatus = delqStatus;
	}

	/**
	 * @return the lastDueDate
	 */
	public String getLastDueDate() {
		return lastDueDate;
	}

	/**
	 * @param lastDueDate the lastDueDate to set
	 */
	public void setLastDueDate(String lastDueDate) {
		this.lastDueDate = lastDueDate;
	}

	/**
	 * @return the principalAmount
	 */
	public String getPrincipalAmount() {
		return principalAmount;
	}

	/**
	 * @param principalAmount the principalAmount to set
	 */
	public void setPrincipalAmount(String principalAmount) {
		this.principalAmount = principalAmount;
	}

	/**
	 * @return the interestAmount
	 */
	public String getInterestAmount() {
		return interestAmount;
	}

	/**
	 * @param interestAmount the interestAmount to set
	 */
	public void setInterestAmount(String interestAmount) {
		this.interestAmount = interestAmount;
	}

	/**
	 * @return the lastChangeAmount
	 */
	public String getLastChangeAmount() {
		return lastChangeAmount;
	}

	/**
	 * @param lastChangeAmount the lastChangeAmount to set
	 */
	public void setLastChangeAmount(String lastChangeAmount) {
		this.lastChangeAmount = lastChangeAmount;
	}

	/**
	 * @return the overdueFee
	 */
	public String getOverdueFee() {
		return overdueFee;
	}

	/**
	 * @param overdueFee the overdueFee to set
	 */
	public void setOverdueFee(String overdueFee) {
		this.overdueFee = overdueFee;
	}

	/**
	 * @return the rpaAmount
	 */
	public String getRpaAmount() {
		return rpaAmount;
	}

	/**
	 * @param rpaAmount the rpaAmount to set
	 */
	public void setRpaAmount(String rpaAmount) {
		this.rpaAmount = rpaAmount;
	}

	/**
	 * @return the lastPmtDate
	 */
	public String getLastPmtDate() {
		return lastPmtDate;
	}

	/**
	 * @param lastPmtDate the lastPmtDate to set
	 */
	public void setLastPmtDate(String lastPmtDate) {
		this.lastPmtDate = lastPmtDate;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * @return the repaymentAmount
	 */
	public String getRepaymentAmount() {
		return repaymentAmount;
	}

	/**
	 * @param repaymentAmount the repaymentAmount to set
	 */
	public void setRepaymentAmount(String repaymentAmount) {
		this.repaymentAmount = repaymentAmount;
	}

	/**
	 * @return the plEarlySettle
	 */
	public String getPlEarlySettle() {
		return plEarlySettle;
	}

	/**
	 * @param plEarlySettle the plEarlySettle to set
	 */
	public void setPlEarlySettle(String plEarlySettle) {
		this.plEarlySettle = plEarlySettle;
	}

	/**
	 * @return the closeDate
	 */
	public String getCloseDate() {
		return closedDate;
	}

	/**
	 * @param closeDate the closeDate to set
	 */
	public void setCloseDate(String closeDate) {
		this.closedDate = closeDate;
	}

}
