/**
 * 
 */
package com.shinhan.recon.service.impl;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.UnaryOperator;

import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.BankStatementACBTemplate;
import com.shinhan.recon.core.model.BankStatementCommonTemplate;
import com.shinhan.recon.core.model.BankStatementVietcombankTemplate;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.ReadFromExcel;
import com.shinhan.recon.service.ReconcileApiService;

/**
 * @author shds01
 *
 */
@Service("reconcileApiService")
public class ReconcileApiServiceImpl extends AbstractServiceClass implements ReconcileApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileProcessService#getFileFromFTPServer()
	 */
	@Override
	public boolean getFileFromFTPServer() throws ServiceRuntimeException {
		// TODO Auto-generated method stub
		return true;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileProcessService#getStatementFileFromFolderToRecon(java.lang.String)
	 */
	@Override
	public Collection<File> getStatementFileFromFolderToRecon(String path) throws ServiceRuntimeException {
		return CommonUtil.getBankStatementFileInFolder(path);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileProcessService#processReconcileBankStatement()
	 */
	@Override
	public void processReconcileBankStatement() throws ServiceRuntimeException {
		logger.info("***** Start Scan Bank Statement *****");
		Collection<File> files = getStatementFileFromFolderToRecon(env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_NEW));
		for (File file : files) {
			String fileName = file.getName();
			if(fileName.startsWith(APIConstant.BANK_STATEMENT_VIETCOMBANK)){
				logger.info("***** Start Scan Bank Statement For VietComBank *****");
				//processReconcileBankStatementVietcombank(file);
				logger.info("***** End Scan Bank Statement For VietComBank *****");
			} else if(fileName.startsWith(APIConstant.BANK_STATEMENT_ACB)){
				logger.info("***** Start Scan Bank Statement For ACB *****");
				processReconcileBankStatementACB(file);
				logger.info("***** End Scan Bank Statement For ACB *****");
			}
		}
		logger.info("***** End Scan Bank Statement *****");
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileProcessService#processReconcileBankStatementVietcombank(java.io.File)
	 */
	@Override
	public void processReconcileBankStatementVietcombank(File file) throws ServiceRuntimeException {
		/** Step 1: read raw data from excel */
		ReadFromExcel rw = new ReadFromExcel(file.getAbsolutePath());
		int sheetIndex = 0;
		int fromRow = 11;
		int headerRow = 10;
		ArrayList<Map> lsArrMapObject = (ArrayList<Map>) rw.readDataFromExcel(sheetIndex, fromRow, headerRow);
		
		/** Step 2: import raw excel data to java class and validation */
		JsonArray jsonArrayDocument = (JsonArray) CommonUtil.toPojo(lsArrMapObject, JsonArray.class);
		/*excel Row defined*/
		List<String> excelColumn = Arrays.asList(APIConstant.BANK_STATEMENT_VIETCOMBANK_COLUMN.split(","));
		
		/*all property map exactly with the index of excel row (stt is the first column, lastName is the second column.....) */
		Field[] bankStatementProperty = new BankStatementVietcombankTemplate().getClass().getDeclaredFields();
		
		Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping = buildBankStatementMapping(excelColumn, bankStatementProperty);
		List<BankStatementCommonTemplate> bankStatements = super.mapListExcelDataToListBankStatement(jsonArrayDocument, bankStatementMapping, BankStatementCommonTemplate::new);
		
		/** Step 3: process reconcile between LMS and BankStatement */
		//TODO
		HashMap<String, Object> rs = new HashMap<>();
		
		/** Step 4: import data into DB */
		//TODO 
		/** Step 5: move file to Done folder */
		
		//TODO
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileProcessService#processReconcileBankStatementACB(java.io.File)
	 */
	@Override
	public void processReconcileBankStatementACB(File file) throws ServiceRuntimeException {
		/** Step 1: read raw data from excel */
		ReadFromExcel rw = new ReadFromExcel(file.getAbsolutePath());
		int sheetIndex = 0;
		int fromRow = 9;
		int headerRow = 7;
		ArrayList<Map> lsArrMapObject = (ArrayList<Map>) rw.readDataFromExcel(sheetIndex, fromRow, headerRow);
		
		/** Step 2: import raw excel data to java class and validation */
		JsonArray jsonArrayDocument = (JsonArray) CommonUtil.toPojo(lsArrMapObject, JsonArray.class);
		/*excel Row defined*/
		List<String> excelColumn = Arrays.asList(APIConstant.BANK_STATEMENT_ACB_COLUMN.split(","));
		
		/*all property map exactly with the index of excel row (stt is the first column, lastName is the second column.....) */
		Field[] bankStatementProperty = new BankStatementACBTemplate().getClass().getDeclaredFields();
		
		Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping = buildBankStatementMapping(excelColumn, bankStatementProperty);
		List<BankStatementCommonTemplate> bankStatements = super.mapListExcelDataToListBankStatement(jsonArrayDocument, bankStatementMapping, BankStatementCommonTemplate::new);
		
		/** Step 3: process reconcile between LMS and BankStatement */
		//TODO
		HashMap<String, Object> rs = new HashMap<>();
		
		/** Step 4: import data into DB */
		//TODO 
		/** Step 5: move file to Done folder */
		
		//TODO
		
	}


}














