/**
 * 
 */
package com.shinhan.recon.service;

import java.io.File;
import java.util.Collection;

import com.shinhan.recon.core.exception.ServiceRuntimeException;

/**
 * @author shds01
 *
 */
public interface ReconcileProcessService {

	public boolean getFileFromFTPServer() throws ServiceRuntimeException;
	
	public Collection<File> getStatementFileFromFolderToRecon(String path) throws ServiceRuntimeException;
	
	public void processReconcileBankStatement() throws ServiceRuntimeException;
	
	public void processReconcileBankStatementVietcombank(File file) throws ServiceRuntimeException;
	
	public void processReconcileBankStatementACB(File file) throws ServiceRuntimeException;
}
