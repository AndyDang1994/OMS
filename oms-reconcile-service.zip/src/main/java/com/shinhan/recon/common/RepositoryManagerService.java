/**
 * 
 */
package com.shinhan.recon.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * @author Kraken
 *
 */
@Service("repositoryManagerService")
public class RepositoryManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

}
