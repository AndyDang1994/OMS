/**
 * 
 */
package com.shinhan.recon.common;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.AbstractMap.SimpleEntry;
import java.util.Map.Entry;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.shinhan.recon.core.model.BankStatementCommonTemplate;
import com.shinhan.recon.core.model.BankStatementVietcombankTemplate;
import com.shinhan.recon.core.util.CommonUtil;

/**
 * @author Kraken
 *
 */
public abstract class AbstractServiceClass {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	public Environment env;
	
	@Autowired
	private RepositoryManagerService repositoryManagerService;

	@Autowired
	private ProcessManagerService processManagerService;

	/**
	 * @return the repositoryManagerService
	 */
	public RepositoryManagerService getRepositoryManagerService() {
		return repositoryManagerService;
	}

	/**
	 * @param repositoryManagerService the repositoryManagerService to set
	 */
	public void setRepositoryManagerService(@Qualifier("repositoryManagerService") RepositoryManagerService repositoryManagerService) {
		this.repositoryManagerService = repositoryManagerService;
	}

	/**
	 * @return the processManagerService
	 */
	public ProcessManagerService getProcessManagerService() {
		return processManagerService;
	}

	/**
	 * @param processManagerService the processManagerService to set
	 */
	public void setProcessManagerService(@Qualifier("processManagerService") ProcessManagerService processManagerService) {
		this.processManagerService = processManagerService;
	}
	

	protected Map<String, Entry<String, UnaryOperator<String>>> buildBankStatementMapping(List<String> excelColumn, Field[] bankStatementProperty){
		/**bankStatementMapping : {excel column name} {[property in Statement],[function to parse value on excel to value in property]}**/
		Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping = new HashMap<>();
		
		/*all parser to map value from excel, must map exactly with the index of excel column*/
		Map<Integer, UnaryOperator<String>> parser = new HashMap<>();
		
		/*excelColumn, clientCoporateProperty MUST have same size*/
		for (int columnIndex = 0; columnIndex < excelColumn.size(); columnIndex++) {
			String key = excelColumn.get(columnIndex).trim();
			UnaryOperator<String> parserToConsume = Optional.ofNullable(parser.get(columnIndex)).orElse(UnaryOperator.identity());
			bankStatementMapping.put(key, new SimpleEntry<String, UnaryOperator<String>>(bankStatementProperty[columnIndex].getName(), parserToConsume));
		}
		
		return bankStatementMapping;
	}

	public <T extends BankStatementCommonTemplate> List<T> mapListExcelDataToListBankStatement
					(JsonArray jsonArrayDocument, Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping, Supplier<T> supplier){
		List<T> statements = new ArrayList<>();
		for(JsonElement element: jsonArrayDocument) {
			boolean isContinue = mapOneExcelDataToOneBankStatement(statements, element, bankStatementMapping, supplier);
			//stop scanning excel file if one item don't add into List
			if(!isContinue) {
				break;
			}
		}
		return statements;
	}
	
	private <T extends BankStatementCommonTemplate> Boolean mapOneExcelDataToOneBankStatement
				(List<T> statements, JsonElement element, Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping, Supplier<T> supplier) {
		T statement = supplier.get();
		for(Map.Entry<String, JsonElement> entry : element.getAsJsonObject().entrySet()){
			String excelColumnName = entry.getKey();
			String excelColumnValue = entry.getValue().getAsString();
			
			if(!bankStatementMapping.containsKey(excelColumnName)) {
				continue;
			}
			
			Entry<String, UnaryOperator<String>> mapper = bankStatementMapping.get(excelColumnName);
			//get value to add into property, and call parser to parse that value
			String valueToAdd = mapper.getValue().apply(excelColumnValue);
			
			//get property of BankStatement
			String field = mapper.getKey();
			if(valueToAdd != null && !CommonUtil.setPropertyIntoObject(statement, valueToAdd, field)) {
				//statement.setError("Configuration error"); TODO
			}
		}
		if(StringUtils.isNotBlank(statement.getRef())) {
			statements.add(statement);
			return true;
		}
		return false;
	}
	
}
