/**
 * 
 */
package com.shinhan.recon.api.controller;

import java.util.Locale;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;

/**
 * @author shds01
 *
 */
@RestController
public class UtilityController extends BaseController{

	@RequestMapping(value = "shinhan/service/connection", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public String testGet() throws ServiceRuntimeException, InterruptedException {
		Thread.sleep(2000);
		return "connect server successfully";
	}

	@RequestMapping(value = "shinhan/service/exception", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	@ResponseBody
	public String testException(Locale locale) throws BaseException {
		testException();
		return "Success";
	}
}
