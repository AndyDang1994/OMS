/**
 * 
 */
package com.shinhan.recon.api.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * @author shds01
 *
 */
@RestController
public class ReconcileController extends BaseController{

	
}
