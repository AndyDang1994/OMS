/**
 * 
 */
package com.shinhan.recon.api.controller;

import com.shinhan.recon.common.AbstractBasicCommonClass;

/**
 * @author shds01
 *
 */
public class BaseController extends AbstractBasicCommonClass{

}
