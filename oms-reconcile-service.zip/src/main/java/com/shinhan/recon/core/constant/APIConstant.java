/**
 * 
 */
package com.shinhan.recon.core.constant;

/**
 * @author shds01
 *
 */

public class APIConstant {

	/** Common Constant */
	public static final String PROJECT_NAME = "GENOVA";
	public static final String ALL = "all";
	public static final String DOCUMENT = "document";
	public static final String DOCTYPE = "docType";

	public static final String USERNAME_KEY = "userName";
	public static final String EXPIRY_DATE = "expiryDate";
	public static final String TRACKING_LOG_INSTANCE = "trackingLogInstance";

	public static final String FILE = "file";
	public static final String FILE_UPLOAD = "fileUpload";
	
	public static final String SUBMISSION_MODE_KEY = "SubmissionMode";
	public static final String SUBMISSION_LAS_KEY = "SubmissionLAS";
	
	public static final String GVLSUPERGEN_KEY = "super_user";
	/** Common Document Constant */
	// Sharing resource file url
	public static final String URL_DIR_FILERESOURCE_SHARING = "url_dir_fileResource_sharing";

	public static final String FILE_TYPE_IMAGE_JPG = ".jpg";
	public static final String FILE_TYPE_IMAGE_PNG = ".png";
	public static final String FILE_TYPE_PDF = ".pdf";
	public static final String FILE_TYPE_JASPER = ".jasper";
	public static final String FILE_TYPE_TXT = ".txt";
	
	public static final String FILE_TYPE_JSON = ".json";
	public static final String FILE_TYPE_XML = ".xml";
	
	/** UPLOAD Constant **/
	public static final String PATH_SCAN_BANK_STATEMENT_SCAN= "PATH_SCAN_BANK_STATEMENT_SCAN";
	public static final String PATH_SCAN_BANK_STATEMENT_NEW= "PATH_SCAN_BANK_STATEMENT_NEW";
	public static final String PATH_SCAN_BANK_STATEMENT_OLD= "PATH_SCAN_BANK_STATEMENT_OLD";
	
	public static final String BANK_STATEMENT_VIETCOMBANK= "VCB";
	public static final String BANK_STATEMENT_VIETCOMBANK_COLUMN="Ngày giao dịch, Số tham chiếu, Số tiền ghi nợ, Số tiền ghi có, Mô tả";
	
	public static final String BANK_STATEMENT_ACB= "ACB";
	public static final String BANK_STATEMENT_ACB_COLUMN="Ngày hiệu lực, Ngày GD, Số giao dịch, Diễn giải, Ghi nợ, Ghi có, Số dư";
	/** HTTP Description **/
	public static final String HTTP_REQUEST_BODY_STR = "HttpRequestBody";
	public static final String METHOD_NOT_ALLOWED = "Method is not allowed";
	public static final String UNSUPPORTED_MEDIA_TYPE = "Media type is unsupported";
	public static final String NOT_ACCEPTABLE = "Not Acceptable";

	public static final String GET_METHOD_STR = "GET";
	public static final String POST_METHOD_STR = "POST";
	public static final String PATCH_METHOD_STR = "PATCH";
	public static final String DELETE_METHOD_STR = "DELETE";
	public static final String OPTIONS_METHOD_STR = "OPTIONS";
	public static final String ANONYMOUS_USER = "Anonymous";

	public static final String TEXT_HTML_CHARSET_UTF8_CHARSET_TYPE = "text/html;charset=UTF-8";
	public static final String UTF_8_CHARSET_TYPE = "UTF-8";
	public static final String CONTENT_TYPE_REQUEST_HEADER = "Content-Type";

	public static final String CONTENT_TYPE_IMAGE_PNG = "image/png";
	public static final String CONTENT_TYPE_IMAGE_JPG = "image/jpeg";

	public static final String CONTENT_TYPE_JSON = "application/json";
	public static final String CONTENT_TYPE_XML = "application/xml";
	public static final String CONTEXT_FILTER_PATH = "gvl/service/";
	
	public static final String REQUEST_URI_STR = "requestURI";


	/** Exception Constant **/
	public static final String SERVICE_RUNTIME_EXCEPTION_ERROR = "Some error is happened";
	public static final String THE_TOKEN_IS_INVALID_ERROR = "The Token is invalid";
	public static final String THE_TOKEN_IS_INCORRECT_FORMAT_ERROR = "The Token is incorrect format";
	public static final String THE_TOKEN_IS_BLANK_ERROR = "The Token is blank";
	public static final String THE_TOKEN_UNPERMISSION_ERROR = "The Token can not execute this operation";
	public static final String NO_RECORD_FOUND_KEY = "No record found";
	public static final String THE_TOKEN_IS_EXPIRED_ERROR = "The Token is expired";

	/** SECURE Constant **/
	public static final String SYSADMIN_STR = "SYSADMIN";
	public static final String ACCESS_TOKEN_KEY = "access-token";
	public static final String PUBLIC_KEY = "public_key";
	public static final String AES_KEY = "AES_key";
	public static final String EXECUTION_TIME_KEY = "executionTime";
	public static final String TOKEN_EXPIRY_MINUTES = "Token_expiry_minutes";

	public static final String OMNI_AES_KEY = "OMNI_AES_key";
	/** Other Constant **/
	
	public static final String YES_KEY = "Y";
	public static final String NO_KEY = "N";
	public static final String NULL_KEY = "NULL";
	public static final String EMPTY_KEY = "EMPTY";
	public static final String SUCCESS_KEY = "SUCCESS";
	public static final String SUCCESS_RESPONSE_KEY = "200";
	public static final String ERROR_100_RESPONSE_KEY = "100";
	public static final String ERROR_KEY = "ERROR";
	public static final String COMMA = ",";
	/** Metadata Constant */
	public static final String _LOOKUP_CODE_KEY = "lookupCode";

	/** Metadata Value Constant */
	
	
}
