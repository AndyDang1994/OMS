/**
 * 
 */
package com.shinhan.recon.job;

import java.time.LocalDateTime;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.shinhan.recon.common.AbstractBasicCommonClass;
import com.shinhan.recon.core.exception.BaseException;

/**
 * @author shds01
 *
 */
@Component
public class ReconcileBatchJobBankStatement extends AbstractBasicCommonClass {

	@Scheduled(fixedDelayString = "${spring.job.application.fixedDelay.scanBankStatement}") // 1 minutes
	public void scanBankStatementFile() throws BaseException {
		logger.info("***** Start Scanning File Bank Statement Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		boolean isFile = getProcessManagerService().getReconcileProcessService().getFileFromFTPServer();
		if (!isFile) {
			logger.info("***** No File Bank Statement To Scan *****");
		} else {
			getProcessManagerService().getReconcileProcessService().processReconcileBankStatement();
		}
		logger.info("***** End Scanning File Bank Statement Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
}
