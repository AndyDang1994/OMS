/**
 * 
 */
package com.shinhan.recon.common;

import java.io.File;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.core.model.statement.BankStatementCommonTemplate;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.core.util.WriteToExcelTemplate;
import com.shinhan.recon.report.model.RepaymentForHeaderReport;
import com.shinhan.recon.report.model.bank.RepaymentForBankFooterReport;
import com.shinhan.recon.report.model.bank.RepaymentForBankHeaderReport;
import com.shinhan.recon.report.model.bank.RepaymentForBankMatchingDataReport;
import com.shinhan.recon.report.model.bank.RepaymentForBankReport;
import com.shinhan.recon.report.model.bank.RepaymentForBankUnMatchingDataReport;
import com.shinhan.recon.report.model.nonbank.RepaymentForNonBankFooterReport;
import com.shinhan.recon.report.model.nonbank.RepaymentForNonBankHeaderReport;
import com.shinhan.recon.report.model.nonbank.RepaymentForNonBankMatchingDataReport;
import com.shinhan.recon.report.model.nonbank.RepaymentForNonBankReport;
import com.shinhan.recon.report.model.nonbank.RepaymentForNonBankUnMatchingDataReport;

/**
 * @author shds01
 *
 */
public abstract class AbstractServiceClass extends AbstractRepositoryClass{

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	public Environment env;
	
	@Autowired
	private ProcessManagerService processManagerService;

	@Autowired
	private ValidationManagerService validationManagerService;
	
	/**
	 * @return the processManagerService
	 */
	public ProcessManagerService getProcessManagerService() {
		return processManagerService;
	}

	/**
	 * @param processManagerService the processManagerService to set
	 */
	public void setProcessManagerService(@Qualifier("processManagerService") ProcessManagerService processManagerService) {
		this.processManagerService = processManagerService;
	}
	
	/**
	 * @return the validationManagerService
	 */
	public ValidationManagerService getValidationManagerService() {
		return validationManagerService;
	}

	/**
	 * @param validationManagerService the validationManagerService to set
	 */
	public void setValidationManagerService(@Qualifier("validationManagerService")
		ValidationManagerService validationManagerService) {
		this.validationManagerService = validationManagerService;
	}

	protected Map<String, Entry<String, UnaryOperator<String>>> buildBankStatementMapping(List<String> excelColumn, Field[] bankStatementProperty){
		/**bankStatementMapping : {excel column name} {[property in Statement],[function to parse value on excel to value in property]}**/
		Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping = new HashMap<>();
		
		/*all parser to map value from excel, must map exactly with the index of excel column*/
		Map<Integer, UnaryOperator<String>> parser = new HashMap<>();
		
		/*excelColumn, clientCoporateProperty MUST have same size*/
		for (int columnIndex = 0; columnIndex < excelColumn.size(); columnIndex++) {
			String key = excelColumn.get(columnIndex).trim();
			UnaryOperator<String> parserToConsume = Optional.ofNullable(parser.get(columnIndex)).orElse(UnaryOperator.identity());
			bankStatementMapping.put(key, new SimpleEntry<String, UnaryOperator<String>>(bankStatementProperty[columnIndex].getName(), parserToConsume));
		}
		
		return bankStatementMapping;
	}

	public <T extends BankStatementCommonTemplate> List<T> mapListExcelDataToListBankStatement
					(JsonArray jsonArrayDocument, Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping, Supplier<T> supplier){
		List<T> statements = new ArrayList<>();
		for(JsonElement element: jsonArrayDocument) {
			boolean isContinue = mapOneExcelDataToOneBankStatement(statements, element, bankStatementMapping, supplier);
			//stop scanning excel file if one item don't add into List
			if(!isContinue) {
				break;
			}
		}
		return statements;
	}
	
	private <T extends BankStatementCommonTemplate> Boolean mapOneExcelDataToOneBankStatement
				(List<T> statements, JsonElement element, Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping, Supplier<T> supplier) {
		T statement = supplier.get();
		for(Map.Entry<String, JsonElement> entry : element.getAsJsonObject().entrySet()){
			String excelColumnName = entry.getKey().trim();
			String excelColumnValue = entry.getValue().getAsString();
			if(!bankStatementMapping.containsKey(excelColumnName)) {
				continue;
			}
			
			Entry<String, UnaryOperator<String>> mapper = bankStatementMapping.get(excelColumnName);
			//get value to add into property, and call parser to parse that value
			String valueToAdd = mapper.getValue().apply(excelColumnValue);
			
			//get property of BankStatement
			String field = mapper.getKey();
			if(valueToAdd != null && !CommonUtil.setPropertyIntoObject(statement, valueToAdd, field)) {
				//statement.setError("Configuration error"); TODO
			}
		}
		
		if(StringUtils.isNotBlank(statement.getRef())) {
			statements.add(statement);
			return true;
		}
		return false;
	}
	
	private Workbook loadTemplateAndFillDataReport(String fileSource, List<Object[]> datas, int fromRow) {
		int shiftRow = fromRow + 1;// 1 = (blank row)
		String sheetName = "Data";
		return WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, null, sheetName, fromRow, shiftRow, datas, false);
	}
	
	private Workbook fillDataForSectionReport(Workbook wb, List<Object[]> datas, int fromRow) {
		if(CollectionUtils.isEmpty(datas)) {
			return wb;
		}
		int shiftRow = fromRow + 1;// 1 = (blank row)
		String sheetName = "Data";
		return WriteToExcelTemplate.fillDataToSheetTemplate(wb, null, sheetName, fromRow, shiftRow, datas, false);
	}
	
	private void fillDataTotalRecordForMatchingReport(Workbook wb, BankStatementLmsTrxInfo item, int fromRow) {
		int startRow = fromRow + 1; // 1 = (blank row)
		String sheetName = "Data";
		WriteToExcelTemplate.fillDataToSheetTemplate(wb, sheetName, startRow, DTOConverter.transferDataTotalRecordForReport(item));
	}
	
	private void fillDataTotalRecordForUnMatchingReport(Workbook wb, BankStatementLmsTrxInfo totalUnmatch, BankStatementLmsTrxInfo grandTotal, int fromRow) {
		int startRow = fromRow + 1; // 1 = (blank row)
		String sheetName = "Data";
		
		List<Object[]> datas = DTOConverter.transferDataTotalRecordForReport(totalUnmatch);
		datas.add(DTOConverter.transferDataGrandTotalRecordForReport(grandTotal));
		
		WriteToExcelTemplate.fillDataToSheetTemplate(wb, sheetName, startRow, datas);
	}
	
	private void fillDataForHeaderReport(Workbook wb, RepaymentForHeaderReport headerReport) {
		int startRow = 1; // 1 = (blank row)
		String sheetName = "Data";
		//Fill date in second row
		List<Object[]> datas = new ArrayList<>();
		Object[] object = {"From " + headerReport.getFromDt() + " To " + headerReport.getToDt()};
		datas.add(object);
		WriteToExcelTemplate.fillDataToSheetTemplate(wb, sheetName, startRow, datas);
		
		//Fill Bank information
		startRow = 3;
		WriteToExcelTemplate.fillDataToSheetTemplate(wb, sheetName, startRow, DTOConverter.transferDataToFillHeaderForReport(headerReport));
	}
	
	/** 
	 * Build data to binding report reconcile for Bank Statement
	 * @param bankCode
	 * @param bankName
	 * @param startDt
	 * @param endDt
	 * */
	public RepaymentForBankReport buildDataForRepaymentBankReport(String bankCode, String bankName, String startDt, String endDt) throws BaseException {
		RepaymentForBankReport reportData = new RepaymentForBankReport(new RepaymentForBankHeaderReport(startDt, endDt, bankCode, bankName));
		Map<String, Object> inputParams = new HashMap<String, Object>();
		
		/** Start Process build data for matching report */
		RepaymentForBankMatchingDataReport dataMatchingReport = new RepaymentForBankMatchingDataReport();
		inputParams.put(APIConstant._START_DATE_KEY, startDt);
		inputParams.put(APIConstant._END_DATE_KEY, endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, bankCode);
		inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		List<Object[]> lstMatching = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getMatchListBankStatementTrxByDateAndBankCode(inputParams);
		if(!CollectionUtils.isEmpty(lstMatching)) {
			//Sum the debit amount and credit amount of matching trx
			dataMatchingReport.setSumRecord(getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().sumDrAndCrMatchListBankStatementTrxByDateAndBankCode(inputParams));
			dataMatchingReport.setMatchingLst(lstMatching);
		}
		
		reportData.setDataMatchingReport(dataMatchingReport);
		/** End Process build data for matching report */
		
		/** Start Process build data for unmatching report */
		RepaymentForBankUnMatchingDataReport dataUnMatchingReport = new RepaymentForBankUnMatchingDataReport();
			/** Start Process build data for unmatching LMS report */
		inputParams.put(APIConstant._STATUS_KEY, APIConstant.LMS_UPLOAD_PENDING);
		List<Object[]> lmsUploadPendingLst = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
		dataUnMatchingReport.setLmsUploadPendingLst(lmsUploadPendingLst);

		if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
			inputParams.remove(APIConstant._STATUS_KEY);
		}
		inputParams.put(APIConstant._STATUS_KEY, APIConstant.LMS_TRX_MATCHED);
		List<Object[]> lmsCancelLst = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getUnMatchListTrxByDateAndBankCodeAndNonStatus(inputParams);
		lmsCancelLst.removeAll(lmsUploadPendingLst);
		dataUnMatchingReport.setLmsCancelLst(lmsCancelLst);
			/** End Process build data for unmatching LMS report */
			
			/** Start Process build data for unmatching Bank Statement report */
		if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
			inputParams.remove(APIConstant._STATUS_KEY);
		}
		inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_FINANCE_STATUS);
		List<Object[]> bankFinanceLst = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
		dataUnMatchingReport.setBankFinanceLst(bankFinanceLst);
		
		if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
			inputParams.remove(APIConstant._STATUS_KEY);
		}
		inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_REFUND_STATUS);
		List<Object[]> bankRefundLst = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
		dataUnMatchingReport.setBankRefundLst(bankRefundLst);
		
		if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
			inputParams.remove(APIConstant._STATUS_KEY);
		}
		inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_REVERT_STATUS);
		List<Object[]> bankRevertLst = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
		dataUnMatchingReport.setBankRevertLst(bankRevertLst);
		
		if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
			inputParams.remove(APIConstant._STATUS_KEY);
		}
		inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_PENDING_STATUS);
		List<Object[]> bankPendingLst = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
		dataUnMatchingReport.setBankPendingLst(bankPendingLst);
		
			/** End Process build data for unmatching Bank Statement report */
		
		//Sum the debit amount and credit amount of un-matching trx bank statement
		BankStatementLmsTrxInfo sumRecordBank = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().sumDrAndCrUnMatchListBankStatementTrxByDateAndBankCode(inputParams);
		//Sum the debit amount and credit amount of un-matching trx LMS
		BankStatementLmsTrxInfo sumRecordLMS = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().sumDrAndCrUnMatchListLMSTrxByDateAndBankCode(inputParams);
		
		dataUnMatchingReport.setSumRecord(new BankStatementLmsTrxInfo(sumRecordBank.getBankStatemenTrxInfo().getDrAmt(), sumRecordBank.getBankStatemenTrxInfo().getCrAmt()
				, sumRecordLMS.getLmsTrxInfo().getDrAmt(), sumRecordLMS.getLmsTrxInfo().getCrAmt()));
		
		
		reportData.setDataUnMatchingReport(dataUnMatchingReport);
		
		/** End Process build data for unmatching report */
		
		/** Start Process build footer data report */
		
		RepaymentForBankFooterReport footerReport = new RepaymentForBankFooterReport(
				DTOConverter.getGrandBalanceReconcileOfLMSAndBankStatement(
						dataMatchingReport.getSumRecord().getLmsTrxInfo().getDrAmt(), dataMatchingReport.getSumRecord().getLmsTrxInfo().getCrAmt(), 
						dataMatchingReport.getSumRecord().getBankStatemenTrxInfo().getDrAmt(), dataMatchingReport.getSumRecord().getBankStatemenTrxInfo().getCrAmt(), 
						dataUnMatchingReport.getSumRecord().getLmsTrxInfo().getDrAmt(), dataUnMatchingReport.getSumRecord().getLmsTrxInfo().getCrAmt(), 
						dataUnMatchingReport.getSumRecord().getBankStatemenTrxInfo().getDrAmt(), dataUnMatchingReport.getSumRecord().getBankStatemenTrxInfo().getCrAmt()));
		reportData.setFooterReport(footerReport);
		/** End Process build footer data report */
		
		/** Start Process build header data report */
		BigDecimal openBal = getRepositoryManagerService().getUtilityManagerRepositoryService().getOpenBalanceOfBankCodeByDate(inputParams);
		BigDecimal closeBal = openBal.add(
				reportData.getFooterReport().getSumRecord().getBankStatemenTrxInfo().getDrAmt()
					.subtract(reportData.getFooterReport().getSumRecord().getBankStatemenTrxInfo().getCrAmt()));
		
		reportData.getHeaderReport().setOpenBal(openBal);
		reportData.getHeaderReport().setCloseBal(closeBal);
		
		/** End Process build header data report */
		return reportData;
	}
	
	/** 
	 * process export the reconcile report for bank statement
	 * @param dataReport
	 * */
	public File exportReconcileRepaymentReportForBank(RepaymentForBankReport dataReport) throws ServiceRuntimeException {
		//Get template file
		String fileSource = env.getProperty(APIConstant.FOLDER_TEMPLATE_REPORT) + "/" + APIConstant.FILE_BANK_TEMPLATE_REPORT_IN;
		String fileDestinationExport = env.getProperty(APIConstant.FOLDER_EXPORT_REPORT) + "/" + APIConstant.FILE_BANK_TEMPLATE_REPORT_EXPORT
				+ DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss) + APIConstant.FILE_TYPE_EXCEL_NEW;
		/** Start Process fill data for matching report */
		int blankRow = 1;
		int fromRow = 10; // initial row
		int shiftRow = 0;
		int rowIndexFromMatchingToUnmatchingPendingCase = 5;
		int rowIndexFromUnmatchingPendingToCancel = 2;
		int rowIndexFromUnmatchingCancelToFinance = 2;
		int rowIndexFromUnmatchingFinanceToRefund = 2;
		int rowIndexFromUnmatchingRefundToRevert = 2;
		int rowIndexFromUnmatchingRevertToPending = 2;
		
		Workbook wb = loadTemplateAndFillDataReport(fileSource, dataReport.getDataMatchingReport().getMatchingLst(), fromRow);
		
		shiftRow = dataReport.getDataMatchingReport().getMatchingLst().size(); //array size of last data which import
		fromRow = fromRow + shiftRow; //
		fillDataTotalRecordForMatchingReport(wb, dataReport.getDataMatchingReport().getSumRecord(), fromRow);
		/** End Process fill data for matching report */
		
		/** Start Process fill data for un-matching report */
			/** Start Un-matching LMS */
			/* Pending Trx */
			fromRow = fromRow + rowIndexFromMatchingToUnmatchingPendingCase + blankRow; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, dataReport.getDataUnMatchingReport().getLmsUploadPendingLst(), fromRow);
			/* Cancel Trx */
			shiftRow = dataReport.getDataUnMatchingReport().getLmsUploadPendingLst().size(); //array size of last data which import
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingPendingToCancel; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, dataReport.getDataUnMatchingReport().getLmsCancelLst(), fromRow);
			/** End Un-matching LMS */
		
			/** Start Un-matching BankStatement */
			/* Finance Trx */
			shiftRow = dataReport.getDataUnMatchingReport().getLmsCancelLst().size(); //array size of last data which import
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingCancelToFinance; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, dataReport.getDataUnMatchingReport().getBankFinanceLst(), fromRow);
			/* Refund Trx */
			shiftRow = dataReport.getDataUnMatchingReport().getBankFinanceLst().size(); //array size of last data which import
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingFinanceToRefund; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, dataReport.getDataUnMatchingReport().getBankRefundLst(), fromRow);
			/* Revert Trx */
			shiftRow = dataReport.getDataUnMatchingReport().getBankRefundLst().size(); //array size of last data which import
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingRefundToRevert; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, dataReport.getDataUnMatchingReport().getBankRevertLst(), fromRow);
			/* Pending Trx */
			shiftRow = dataReport.getDataUnMatchingReport().getBankRevertLst().size(); //array size of last data which import
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingRevertToPending; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, dataReport.getDataUnMatchingReport().getBankPendingLst(), fromRow);
			/* Fill Total sum for record */
			shiftRow = dataReport.getDataUnMatchingReport().getBankPendingLst().size(); //array size of last data which import
			fromRow = fromRow + shiftRow; // last data row + last list . size() + (number of between record)
			fillDataTotalRecordForUnMatchingReport(wb, dataReport.getDataUnMatchingReport().getSumRecord(), dataReport.getFooterReport().getSumRecord(), fromRow);
			/** End Un-matching BankStatement */
		
		/** End Process fill data for un-matching report */
		
		/** Start Process fill data for header report */
			fillDataForHeaderReport(wb, dataReport.getHeaderReport());
		/** End Process fill data for header report */
			
		WriteToExcelTemplate.writeWorkbook(wb, fileDestinationExport);
		File file = new File(fileDestinationExport);
		if(!file.exists()) {
			throw new ServiceRuntimeException(env.getProperty("MSG_004"));
		}
		return file;
	}
	
	/** 
	 * Build data to binding report reconcile for Non-Bank Statement
	 * @param bankCode
	 * @param bankName
	 * @param startDt
	 * @param endDt
	 * */
	public RepaymentForNonBankReport buildDataForRepaymentNonBankReport(String bankCode, String bankName, String startDt, String endDt) throws BaseException {
		RepaymentForNonBankReport reportData = new RepaymentForNonBankReport(new RepaymentForNonBankHeaderReport(startDt, endDt, bankCode, bankName));
		Map<String, Object> inputParams = new HashMap<String, Object>();
		
		/** Start Process build data for matching report */
		RepaymentForNonBankMatchingDataReport dataMatchingReport = new RepaymentForNonBankMatchingDataReport();
		inputParams.put(APIConstant._START_DATE_KEY, startDt);
		inputParams.put(APIConstant._END_DATE_KEY, endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, bankCode);
		inputParams.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		List<Object[]> lstMatching = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getMatchListBankStatementTrxByDateAndBankCode(inputParams);
		if(!CollectionUtils.isEmpty(lstMatching)) {
			//Sum the debit amount and credit amount of matching trx
			dataMatchingReport.setSumRecord(getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().sumDrAndCrMatchListBankStatementTrxByDateAndBankCode(inputParams));
			dataMatchingReport.setMatchingLst(lstMatching);
		}
		
		reportData.setDataMatchingReport(dataMatchingReport);
		/** End Process build data for matching report */
		
		/** Start Process build data for unmatching report */
		RepaymentForNonBankUnMatchingDataReport dataUnMatchingReport = new RepaymentForNonBankUnMatchingDataReport();
			/** Start Process build data for unmatching LMS report */
		inputParams.put(APIConstant._STATUS_KEY, APIConstant.LMS_UPLOAD_PENDING);
		List<Object[]> lmsUploadPendingLst = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
		dataUnMatchingReport.setLmsUploadPendingLst(lmsUploadPendingLst);
		
		if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
			inputParams.remove(APIConstant._STATUS_KEY);
		}
		inputParams.put(APIConstant._STATUS_KEY, APIConstant.LMS_TRX_MATCHED);
		List<Object[]> lmsMoneyTransitLst = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getUnMatchListTrxByDateAndBankCodeAndNonStatus(inputParams);
		lmsMoneyTransitLst.removeAll(lmsUploadPendingLst);
		dataUnMatchingReport.setLmsMoneyTransitLst(lmsMoneyTransitLst);
		
		if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
			inputParams.remove(APIConstant._STATUS_KEY);
		}
		inputParams.put(APIConstant._STATUS_KEY, APIConstant.LMS_CANCEL_TRX);
		List<Object[]> lmsCancelLst = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
		dataUnMatchingReport.setLmsCancelLst(lmsCancelLst);
		
		if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
			inputParams.remove(APIConstant._STATUS_KEY);
		}
		inputParams.put(APIConstant._STATUS_KEY, APIConstant.LMS_CASE_HANDLED_TRX);
		List<Object[]> lmsCaseHandleLst = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
		dataUnMatchingReport.setLmsCaseHandleLst(lmsCaseHandleLst);
			/** End Process build data for unmatching LMS report */
			
			/** Start Process build data for unmatching Bank Statement report */
		
		if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
			inputParams.remove(APIConstant._STATUS_KEY);
		}
		inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_CASE_HANDLED_STATUS);
		List<Object[]> bankCaseHandleLst = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
		dataUnMatchingReport.setBankCaseHandleLst(bankCaseHandleLst);
		
		if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
			inputParams.remove(APIConstant._STATUS_KEY);
		}
		inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_FINANCE_STATUS);
		List<Object[]> bankFinanceLst = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
		dataUnMatchingReport.setBankFinanceLst(bankFinanceLst);
		
		if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
			inputParams.remove(APIConstant._STATUS_KEY);
		}
		inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_REFUND_STATUS);
		List<Object[]> bankRefundLst = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
		dataUnMatchingReport.setBankRefundLst(bankRefundLst);
		
		if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
			inputParams.remove(APIConstant._STATUS_KEY);
		}
		inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_REVERT_STATUS);
		List<Object[]> bankRevertLst = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
		dataUnMatchingReport.setBankRevertLst(bankRevertLst);
		
		if(inputParams.containsKey(APIConstant._STATUS_KEY)) {
			inputParams.remove(APIConstant._STATUS_KEY);
		}
		inputParams.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_PENDING_STATUS);
		List<Object[]> bankPendingLst = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getUnMatchListTrxByDateAndBankCodeAndStatus(inputParams);
		dataUnMatchingReport.setBankPendingLst(bankPendingLst);
		
			/** End Process build data for unmatching Bank Statement report */
		
		//Sum the debit amount and credit amount of un-matching trx bank statement
		BankStatementLmsTrxInfo sumRecordBank = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().sumDrAndCrUnMatchListBankStatementTrxByDateAndBankCode(inputParams);
		//Sum the debit amount and credit amount of un-matching trx LMS
		BankStatementLmsTrxInfo sumRecordLMS = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().sumDrAndCrUnMatchListLMSTrxByDateAndBankCode(inputParams);
		
		dataUnMatchingReport.setSumRecord(new BankStatementLmsTrxInfo(sumRecordBank.getBankStatemenTrxInfo().getDrAmt(), sumRecordBank.getBankStatemenTrxInfo().getCrAmt()
				, sumRecordLMS.getLmsTrxInfo().getDrAmt(), sumRecordLMS.getLmsTrxInfo().getCrAmt()));
		
		
		reportData.setDataUnMatchingReport(dataUnMatchingReport);
		
		/** End Process build data for unmatching report */
		
		/** Start Process build footer data report */
		
		RepaymentForNonBankFooterReport footerReport = new RepaymentForNonBankFooterReport(
				DTOConverter.getGrandBalanceReconcileOfLMSAndBankStatement(
						dataMatchingReport.getSumRecord().getLmsTrxInfo().getDrAmt(), dataMatchingReport.getSumRecord().getLmsTrxInfo().getCrAmt(), 
						dataMatchingReport.getSumRecord().getBankStatemenTrxInfo().getDrAmt(), dataMatchingReport.getSumRecord().getBankStatemenTrxInfo().getCrAmt(), 
						dataUnMatchingReport.getSumRecord().getLmsTrxInfo().getDrAmt(), dataUnMatchingReport.getSumRecord().getLmsTrxInfo().getCrAmt(), 
						dataUnMatchingReport.getSumRecord().getBankStatemenTrxInfo().getDrAmt(), dataUnMatchingReport.getSumRecord().getBankStatemenTrxInfo().getCrAmt()));
		reportData.setFooterReport(footerReport);
		/** End Process build footer data report */
		
		/** Start Process build header data report */
		BigDecimal openBal = getRepositoryManagerService().getUtilityManagerRepositoryService().getOpenBalanceOfBankCodeByDate(inputParams);
		BigDecimal closeBal = openBal.add(
				reportData.getFooterReport().getSumRecord().getBankStatemenTrxInfo().getDrAmt()
					.subtract(reportData.getFooterReport().getSumRecord().getBankStatemenTrxInfo().getCrAmt()));
		
		reportData.getHeaderReport().setOpenBal(openBal);
		reportData.getHeaderReport().setCloseBal(closeBal);
		
		/** End Process build header data report */
		return reportData;
	}
	
	/** 
	 * process export the reconcile report for Non-bank statement
	 * @param dataReport
	 * */
	public File exportReconcileRepaymentReportForNonBank(RepaymentForNonBankReport dataReport) throws ServiceRuntimeException {
		//Get template file
		String fileSource = env.getProperty(APIConstant.FOLDER_TEMPLATE_REPORT) + "/" + APIConstant.FILE_NONBANK_TEMPLATE_REPORT_IN;
		String fileDestinationExport = env.getProperty(APIConstant.FOLDER_EXPORT_REPORT) + "/" + APIConstant.FILE_NONBANK_TEMPLATE_REPORT_EXPORT
				+ DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss) + APIConstant.FILE_TYPE_EXCEL_NEW;
		/** Start Process fill data for matching report */
		int blankRow = 1;
		int fromRow = 10; // initial row
		int shiftRow = 0;
		int rowIndexFromMatchingToUnmatchingPendingCase = 5;
		int rowIndexFromUnmatchingPendingToMoneyTransit = 2;
		int rowIndexFromUnmatchingMoneyTransitToCancel = 2;
		int rowIndexFromUnmatchingCancelToCaseHandle = 2;
		int rowIndexFromUnmatchingCaseHandleToCaseHandle = 2; // CaseHandle of LMS to CaseHandle of Bank
		int rowIndexFromUnmatchingCaseHandleToFinance = 2;
		int rowIndexFromUnmatchingFinanceToRevert = 2;
		int rowIndexFromUnmatchingRevertToRefund = 2;
		int rowIndexFromUnmatchingRevertToPending = 2;
		
		Workbook wb = loadTemplateAndFillDataReport(fileSource, dataReport.getDataMatchingReport().getMatchingLst(), fromRow);
		
		shiftRow = dataReport.getDataMatchingReport().getMatchingLst().size(); //array size of last data which import
		fromRow = fromRow + shiftRow; //
		fillDataTotalRecordForMatchingReport(wb, dataReport.getDataMatchingReport().getSumRecord(), fromRow);
		/** End Process fill data for matching report */
		
		/** Start Process fill data for un-matching report */
			/** Start Un-matching LMS */
			/* Pending Trx */
			fromRow = fromRow + rowIndexFromMatchingToUnmatchingPendingCase + blankRow; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, dataReport.getDataUnMatchingReport().getLmsUploadPendingLst(), fromRow);
			/* Money Transit Trx */
			shiftRow = dataReport.getDataUnMatchingReport().getLmsUploadPendingLst().size(); //array size of last data which import
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingPendingToMoneyTransit; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, dataReport.getDataUnMatchingReport().getLmsMoneyTransitLst(), fromRow);
			/* Cancel Trx */
			shiftRow = dataReport.getDataUnMatchingReport().getLmsMoneyTransitLst().size(); //array size of last data which import
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingMoneyTransitToCancel; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, dataReport.getDataUnMatchingReport().getLmsCancelLst(), fromRow);
			/* Case Handle Trx */
			shiftRow = dataReport.getDataUnMatchingReport().getLmsCancelLst().size(); //array size of last data which import
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingCancelToCaseHandle; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, dataReport.getDataUnMatchingReport().getLmsCaseHandleLst(), fromRow);
			/** End Un-matching LMS */
		
			/** Start Un-matching BankStatement */
			/* Case Handle Trx */
			shiftRow = dataReport.getDataUnMatchingReport().getLmsCaseHandleLst().size(); //array size of last data which import
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingCaseHandleToCaseHandle; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, dataReport.getDataUnMatchingReport().getBankCaseHandleLst(), fromRow);
			/* Finance Trx */
			shiftRow = dataReport.getDataUnMatchingReport().getBankCaseHandleLst().size(); //array size of last data which import
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingCaseHandleToFinance; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, dataReport.getDataUnMatchingReport().getBankFinanceLst(), fromRow);
			/* Revert Trx */
			shiftRow = dataReport.getDataUnMatchingReport().getBankFinanceLst().size(); //array size of last data which import
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingFinanceToRevert; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, dataReport.getDataUnMatchingReport().getBankRevertLst(), fromRow);
			/* Refund Trx */
			shiftRow = dataReport.getDataUnMatchingReport().getBankRevertLst().size(); //array size of last data which import
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingRevertToRefund; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, dataReport.getDataUnMatchingReport().getBankRefundLst(), fromRow);
			/* Pending Trx */
			shiftRow = dataReport.getDataUnMatchingReport().getBankRefundLst().size(); //array size of last data which import
			fromRow = fromRow + shiftRow + rowIndexFromUnmatchingRevertToPending; // last data row + last list . size() + (number of between record)
			fillDataForSectionReport(wb, dataReport.getDataUnMatchingReport().getBankPendingLst(), fromRow);
			/* Fill Total sum for record */
			shiftRow = dataReport.getDataUnMatchingReport().getBankPendingLst().size(); //array size of last data which import
			fromRow = fromRow + shiftRow; // last data row + last list . size() + (number of between record)
			fillDataTotalRecordForUnMatchingReport(wb, dataReport.getDataUnMatchingReport().getSumRecord(), dataReport.getFooterReport().getSumRecord(), fromRow);
			/** End Un-matching BankStatement */
		
		/** End Process fill data for un-matching report */
		
		/** Start Process fill data for header report */
			fillDataForHeaderReport(wb, dataReport.getHeaderReport());
		/** End Process fill data for header report */
			
		WriteToExcelTemplate.writeWorkbook(wb, fileDestinationExport);
		File file = new File(fileDestinationExport);
		if(!file.exists()) {
			throw new ServiceRuntimeException(env.getProperty("MSG_004"));
		}
		return file;
	}
}







