/**
 * 
 */
package com.shinhan.recon.common;

import java.util.HashMap;
import java.util.Map;

/**
 * @author shds01
 *
 */
public class OracleOMSNamedQueries extends HashMap<String, String> {
	private static final long serialVersionUID = 1060286526025776068L;

	public OracleOMSNamedQueries(Map<String, String> namedQueries) {
		super(namedQueries);
	}

}
