/**
 * 
 */
package com.shinhan.recon.common;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.model.BankStatemenTrxInfo;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.core.model.LmsTrxInfo;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;

/**
 * @author shds01
 *
 */
@Service("validationManagerService")
public class ValidationManagerService extends AbstractRepositoryClass{

	public HashMap<String, Object> checkValidationUpdateToUnmatch(List<BankStatementLmsTrxInfo> lst, String userName) throws BaseException{
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			return rs;
		}
		Map<String, Object> inputParams;
		ArrayList<TOmsReconStmtInf> smts = new ArrayList<>();
		ArrayList<TOmsReconLmsInf> lmss = new ArrayList<>();
		for(BankStatementLmsTrxInfo item : lst) {
			
			BankStatemenTrxInfo bankStatemenTrxInfo = item.getBankStatemenTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, bankStatemenTrxInfo.getId());
			TOmsReconStmtInf stmt = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getOne(inputParams);
			
			LmsTrxInfo lmsTrxInfo = item.getLmsTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, lmsTrxInfo.getId());
			TOmsReconLmsInf lms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
			
			if(APIConstant.LMS_TRX_MATCHED == lms.getStatusCode() && APIConstant._BANK_STATEMENT_MATCH_STATUS == stmt.getStatusCode() 
					&& stmt.getRefID().equals(lms.getRefID())) {
				DTOConverter.setUtilityTOmsReconStmtInfForUnmatch(stmt, bankStatemenTrxInfo.getStatusCode(), userName, new Date(), bankStatemenTrxInfo.getRemarkNote());
				smts.add(stmt);
				DTOConverter.setUtilityTOmsReconLmsInfForUnmatch(lms, lmsTrxInfo.getStatusCode(), userName, new Date(),lmsTrxInfo.getRemarkNote());
				lmss.add(lms);
				continue;
			}else {
				rs.put(APIConstant.RESULT, false);
				return rs;
			}
		}
		rs.put(APIConstant._BANK_STATEMENT_MATCHING, smts);
		rs.put(APIConstant._BANK_LMS_MATCHING, lmss);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	
	public HashMap<String, Object> checkValidationUpdateToMatch(List<BankStatementLmsTrxInfo> lst, String userName) throws BaseException{
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			return rs;
		}
		Map<String, Object> inputParams;
		ArrayList<TOmsReconStmtInf> smts = new ArrayList<>();
		ArrayList<TOmsReconLmsInf> lmss = new ArrayList<>();
		for(BankStatementLmsTrxInfo item : lst) {
			
			BankStatemenTrxInfo bankStatemenTrxInfo = item.getBankStatemenTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, bankStatemenTrxInfo.getId());
			TOmsReconStmtInf stmt = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getOne(inputParams);
			
			LmsTrxInfo lmsTrxInfo = item.getLmsTrxInfo();
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, lmsTrxInfo.getId());
			TOmsReconLmsInf lms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
			
			DTOConverter.setUtilityTOmsReconStmtInfForMatch(stmt, stmt.getRefNo(), userName, new Date(),bankStatemenTrxInfo.getRemarkNote());
			smts.add(stmt);
			DTOConverter.setUtilityTOmsReconLmsInfForMatch(lms, stmt.getRefNo(), userName, new Date(),lmsTrxInfo.getRemarkNote());
			lmss.add(lms);
		}
		rs.put(APIConstant._BANK_STATEMENT_MATCHING, smts);
		rs.put(APIConstant._BANK_LMS_MATCHING, lmss);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	
	public HashMap<String, Object> checkValidationUpdateStatusBankStatement(List<BankStatemenTrxInfo> lst, String userName) throws BaseException {
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			return rs;
		}
		Map<String, Object> inputParams;
		ArrayList<TOmsReconStmtInf> smts = new ArrayList<>();
		for(BankStatemenTrxInfo info : lst) {
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, info.getId());
			TOmsReconStmtInf stmt = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getOne(inputParams);
			
			if(APIConstant._BANK_STATEMENT_MATCH_STATUS == stmt.getStatusCode() || APIConstant._BANK_STATEMENT_MATCH_STATUS == info.getStatusCode() 
					|| StringUtils.isNotBlank(stmt.getRefID()) ) {
				rs.put(APIConstant.RESULT, false);
				return rs;
			}
			
			DTOConverter.setUtilityTOmsReconStmtInfForChangingStatus(stmt, info, userName, new Date());
			smts.add(stmt);
		}
		rs.put(APIConstant._BANK_STATEMENT_UNMATCHING, smts);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
	
	public HashMap<String, Object> checkValidationUpdateStatusLMS(List<LmsTrxInfo> lst, String userName) throws BaseException {
		HashMap<String, Object> rs = new HashMap<String, Object>();
		if(CollectionUtils.isEmpty(lst)) {
			rs.put(APIConstant.RESULT, false);
			return rs;
		}
		Map<String, Object> inputParams;
		ArrayList<TOmsReconLmsInf> lmss = new ArrayList<>();
		for(LmsTrxInfo info : lst) {
			inputParams = new HashMap<String, Object>();
			inputParams.put(APIConstant.OMSID, info.getId());
			TOmsReconLmsInf lms = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
			
			if(APIConstant.LMS_TRX_MATCHED == lms.getStatusCode() || APIConstant.LMS_TRX_MATCHED == info.getStatusCode() 
					|| StringUtils.isNotBlank(lms.getRefID()) ) {
				rs.put(APIConstant.RESULT, false);
				return rs;
			}
			
			DTOConverter.setUtilityTOmsReconLmsInfForChangingStatus(lms, info, userName, new Date());
			lmss.add(lms);
		}
		rs.put(APIConstant._BANK_LMS_UNMATCHING, lmss);
		rs.put(APIConstant.RESULT, true);
		return rs;
	}
}
