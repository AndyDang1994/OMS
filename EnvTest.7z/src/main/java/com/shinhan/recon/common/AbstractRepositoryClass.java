/**
 * 
 */
package com.shinhan.recon.common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;


/**
 * @author shds01
 *
 */

public abstract class AbstractRepositoryClass {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	public Environment env;

	@PersistenceContext(unitName = "entityManagerOMS")
	public EntityManager entityManager;

	@Autowired
	private RepositoryManagerService repositoryManagerService;

	@Autowired
	public OracleOMSNamedQueries oracleOMSNamedQueries;

	/**
	 * @return the repositoryManagerService
	 */
	public RepositoryManagerService getRepositoryManagerService() {
		return repositoryManagerService;
	}

	/**
	 * @param repositoryManagerService the repositoryManagerService to set
	 */
	public void setRepositoryManagerService(
			@Qualifier("repositoryManagerService") RepositoryManagerService repositoryManagerService) {
		this.repositoryManagerService = repositoryManagerService;
	}

	
	public TOmsStmtFileMas createTOmsStmtFileMasToDB(TOmsStmtFileMas item, String userName) throws BaseException{
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, item);
		boolean rs = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().create(inputParams);
		if(!rs){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		
		return item;
	}
	
	public TOmsStmtFileMas updateTOmsStmtFileMasToDB(TOmsStmtFileMas item, String userName) throws BaseException{
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, item);
		boolean flag = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().update(inputParams);

		if(!flag){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		
		return item;
	}
	
	public TOmsReconLmsInf createTOmsReconLmsInfToDB(TOmsReconLmsInf item, String userName) throws BaseException{
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, item);
		boolean rs = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().create(inputParams);
		if(!rs){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		
		return item;
	}
	
	public TOmsReconLmsInf updateTOmsReconLmsInfToDB(TOmsReconLmsInf item, String userName) throws BaseException{
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, item);
		boolean flag = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().update(inputParams);
		if(!flag){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		
		return item;
	}
	
	public TOmsReconStmtInf createTOmsReconStmtInfToDB(TOmsReconStmtInf item, String userName) throws BaseException{
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, item);
		boolean rs = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().create(inputParams);
		if(!rs){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		
		return item;
	}
	
	public boolean updateTOmsStmtFileListToDB(List<TOmsStmtFileMas> items, String userName) throws BaseException{
		boolean flag = true;
		for (TOmsStmtFileMas item : items) {
			Map<String, Object> inputParams = new HashMap<>();
			inputParams.put(APIConstant.DOCUMENT, item);
			inputParams.put(APIConstant.USERNAME_KEY, userName);
			flag = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().update(inputParams);
			if(!flag){
				throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
			}
		}
		return flag;
		
	}
	
	public TOmsReconStmtInf updateTOmsReconStmtInfToDB(TOmsReconStmtInf item, String userName) throws BaseException{
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, item);
		boolean flag = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().update(inputParams);
		if(!flag){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		
		return item;
	}
	
	public boolean createListTOmsReconStmtInfToDB(Map<String, Object> items, String userName) throws BaseException{
		boolean flag = true;
		Map<String, Object> matchingMap = new HashMap<>();
		Map<String, Object> unMatchingMap = new HashMap<>();
		Map<String, Object> reversalMap = new HashMap<>();
		Map<String, Object> financeMap = new HashMap<>();
		Map<String, Object> financePendingMap = new HashMap<>();
		matchingMap.put(APIConstant.DOCUMENT, items.get(APIConstant._BANK_STATEMENT_MATCHING));
		unMatchingMap.put(APIConstant.DOCUMENT, items.get(APIConstant._BANK_STATEMENT_UNMATCHING));
		reversalMap.put(APIConstant.DOCUMENT, items.get(APIConstant._BANK_STATEMENT_REVERSAL));
		financeMap.put(APIConstant.DOCUMENT, items.get(APIConstant._BANK_STATEMENT_FINANCE));
		financePendingMap.put(APIConstant.DOCUMENT, items.get(APIConstant._BANK_STATEMENT_FINANCE_PENDING));
		flag = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().createAll(matchingMap);
		flag = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().createAll(unMatchingMap);
		flag = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().createAll(financeMap);
		flag = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().createAll(reversalMap);
		flag = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().createAll(financePendingMap);
		return flag;
	}
	public boolean createListTOmsReconDisbursToDB(Map<String, Object> items, String userName) throws BaseException{
		boolean flag = true;
		Map<String, Object> matchingMap = new HashMap<>();
		Map<String, Object> unMatchingMap = new HashMap<>();
		Map<String, Object> reversalMap = new HashMap<>();
		Map<String, Object> financeMap = new HashMap<>();
		Map<String, Object> crShieldMap = new HashMap<>();
		matchingMap.put(APIConstant.DOCUMENT, items.get(APIConstant._BANK_DISBURS_MATCHED));
		unMatchingMap.put(APIConstant.DOCUMENT, items.get(APIConstant._BANK_DISBURS_UNMATCH));
		reversalMap.put(APIConstant.DOCUMENT, items.get(APIConstant._BANK_DISBURS_REVERT));
		financeMap.put(APIConstant.DOCUMENT, items.get(APIConstant._BANK_DISBURS_FINANCE));
		crShieldMap.put(APIConstant.DOCUMENT, items.get(APIConstant._BANK_DISBURS_CRSHIELD));
		flag = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().createAll(matchingMap);
		flag = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().createAll(unMatchingMap);
		flag = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().createAll(financeMap);
		flag = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().createAll(reversalMap);
		flag = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().createAll(crShieldMap);
		return flag;
	}
	
	public boolean updateListTOmsReconLmsInfToDB(Map<String, Object> items, String userName) throws BaseException{
		boolean flag = true;
		Map<String, Object> matchingMap = new HashMap<>();
		Map<String, Object> unMatchingMap = new HashMap<>();
		matchingMap.put(APIConstant.DOCUMENT, items.get(APIConstant._BANK_LMS_MATCHING));
		unMatchingMap.put(APIConstant.DOCUMENT, items.get(APIConstant._BANK_LMS_UNMATCHING));
		
		flag = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().updateALL(matchingMap);
		flag = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().updateALL(unMatchingMap);
		return flag;
	}
	public boolean updateListTReconLmsInfToDB(List<TOmsReconLmsInf> items, String userName) throws BaseException{
		boolean flag = true;
		Map<String, Object> matchingMap = new HashMap<>();
		matchingMap.put(APIConstant.DOCUMENT, items);
		
		flag = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().updateALL(matchingMap);
		return flag;
	}
	
	public boolean createListTOmsReconSuspInfToDB(Map<String, Object> items, String userName) throws BaseException{
		boolean flag = true;
		Map<String, Object> matchingMap = new HashMap<>();
		matchingMap.put(APIConstant.DOCUMENT, items.get(APIConstant._BANK_SUSPEND_LIST));
		flag = getRepositoryManagerService().gettOmsReconSuspInfManagerRepositoryService().createAll(matchingMap);
		return flag;
	}
	
	public boolean updateListTOmsReconSuspInfToDB(List<TOmsReconSuspenseInf> items, String userName) throws BaseException{
		boolean flag = true;
		Map<String, Object> matchingMap = new HashMap<>();
		matchingMap.put(APIConstant.DOCUMENT, items);
		flag = getRepositoryManagerService().gettOmsReconSuspInfManagerRepositoryService().updateAll(matchingMap);
		return flag;
	}
	public boolean updateListTOmsStatementInfToDB(List<TOmsReconStmtInf> items, String userName) throws BaseException{
		boolean flag = true;
		Map<String, Object> matchingMap = new HashMap<>();
		matchingMap.put(APIConstant.DOCUMENT, items);
		flag = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().createAll(matchingMap);
		return flag;
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void updateToReconcileTrx(Map<String, Object> rs) throws BaseException {
		Map<String, Object> items;
		items = new HashMap<>();
		items.put(APIConstant.DOCUMENT, rs.get(APIConstant._BANK_STATEMENT_MATCHING));
		getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().updateAll(items);
		
		items = new HashMap<>();
		items.put(APIConstant.DOCUMENT, rs.get(APIConstant._BANK_LMS_MATCHING));
		getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().updateALL(items);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void updateStatusUnmatchListLMS(Map<String, Object> rs) throws BaseException {
		Map<String, Object> items;
		items = new HashMap<>();
		items.put(APIConstant.DOCUMENT, rs.get(APIConstant._BANK_LMS_UNMATCHING));
		getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().updateALL(rs);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void updateStatusUnmatchListBankStatement(Map<String, Object> rs) throws BaseException {
		Map<String, Object> items;
		items = new HashMap<>();
		items.put(APIConstant.DOCUMENT, rs.get(APIConstant._BANK_STATEMENT_UNMATCHING));
		getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().updateAll(rs);
	}
}
