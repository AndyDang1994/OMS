/**
 * 
 */
package com.shinhan.recon.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.shinhan.recon.disburs.service.ReconcileDisbursProcessService;
import com.shinhan.recon.disburs.service.ReconcileDisbursalProcessTechcombankService;
import com.shinhan.recon.disburs.service.ReconcileDisbursalProcessVietcombankService;
import com.shinhan.recon.report.ReconcileExportReportService;
import com.shinhan.recon.service.ReconcileApiService;
import com.shinhan.recon.service.ReconcileBankStatementACBService;
import com.shinhan.recon.service.ReconcileBankStatementAgribankService;
import com.shinhan.recon.service.ReconcileBankStatementAirpayService;
import com.shinhan.recon.service.ReconcileBankStatementMomoService;
import com.shinhan.recon.service.ReconcileBankStatementNapasService;
import com.shinhan.recon.service.ReconcileBankStatementOCBService;
import com.shinhan.recon.service.ReconcileBankStatementPayooService;
import com.shinhan.recon.service.ReconcileBankStatementSacombankService;
import com.shinhan.recon.service.ReconcileBankStatementShinhanFinanceService;
import com.shinhan.recon.service.ReconcileBankStatementTechcombankHSCService;
import com.shinhan.recon.service.ReconcileBankStatementTechcombankSGDService;
import com.shinhan.recon.service.ReconcileBankStatementVietcombankService;
import com.shinhan.recon.service.ReconcileBankStatementViettelService;
import com.shinhan.recon.service.ReconcileBankStatementViettinService;
import com.shinhan.recon.service.ReconcileBankStatementVnpostService;
import com.shinhan.recon.service.ReconcileProcessService;
import com.shinhan.recon.service.ReconcileRetryService;
import com.shinhan.recon.service.ReconcileScanFileProcessService;

/**
 * @author shds01
 *
 */
@Service("processManagerService")
public class ProcessManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private ReconcileProcessService reconcileProcessService;
	
	@Autowired
	private ReconcileDisbursProcessService reconcileDisbursProcessService;
	
	@Autowired 
	private ReconcileBankStatementVietcombankService reconcileBankStatementVietcombank;
	
	@Autowired
	private ReconcileBankStatementACBService reconcileBankStatementACB;
	
	@Autowired
	private ReconcileBankStatementAgribankService reconcileBankStatementAgribankService;
	
	@Autowired
	private ReconcileBankStatementOCBService reconcileBankStatementOCBService;
	
	@Autowired
	private ReconcileBankStatementSacombankService reconcileBankStatementSacombankService;
	
	@Autowired
	private ReconcileBankStatementTechcombankHSCService reconcileBankStatementTechcombankHSCService;
	
	@Autowired 
	private ReconcileBankStatementTechcombankSGDService reconcileBankStatementTechcombankSGDService;
	
	@Autowired
	private ReconcileBankStatementViettinService reconcileBankStatementViettinService;
	
	@Autowired
	private ReconcileBankStatementViettelService reconcileBankStatementViettelService;
	
	@Autowired
	private ReconcileBankStatementVnpostService reconcileBankStatementVnpostService;
	
	@Autowired
	private ReconcileBankStatementPayooService reconcileBankStatementPayooService;
	
	@Autowired
	private ReconcileBankStatementMomoService reconcileBankStatementMomoService;
	
	@Autowired
	private ReconcileBankStatementAirpayService reconcileBankStatementAirpayService;
	
	@Autowired
	private ReconcileBankStatementNapasService reconcileBankStatementNapasService;
	
	@Autowired
	private ReconcileBankStatementShinhanFinanceService reconcileBankStatementShinhanFinanceService;
	
	@Autowired
	private ReconcileDisbursalProcessVietcombankService reconcileDisbursalProcessVietcombankService;
	
	@Autowired
	private ReconcileDisbursalProcessTechcombankService reconcileDisbursalProcessTechcombankService;
	
	@Autowired
	private ReconcileScanFileProcessService reconcileScanFileProcessService;

	@Autowired
	private ReconcileRetryService reconcileRetryService;
	
	@Autowired
	private ReconcileApiService reconcileApiService;
	
	@Autowired
	private ReconcileExportReportService reconcileExportReportService;

	/**
	 * @return the reconcileProcessService
	 */
	public ReconcileProcessService getReconcileProcessService() {
		return reconcileProcessService;
	}

	/**
	 * @param reconcileProcessService the reconcileProcessService to set
	 */
	public void setReconcileProcessService(
			@Qualifier("reconcileProcessService") ReconcileProcessService reconcileProcessService) {
		this.reconcileProcessService = reconcileProcessService;
	}

	/**
	 * @return the reconcileApiService
	 */
	public ReconcileApiService getReconcileApiService() {
		return reconcileApiService;
	}

	/**
	 * @param reconcileApiService the reconcileApiService to set
	 */
	public void setReconcileApiService(@Qualifier("reconcileApiService") ReconcileApiService reconcileApiService) {
		this.reconcileApiService = reconcileApiService;
	}

	public ReconcileScanFileProcessService getReconcileScanFileProcessService() {
		return reconcileScanFileProcessService;
	}

	public void setReconcileScanFileProcessService(
			@Qualifier("reconcileScanFileProcessService") ReconcileScanFileProcessService reconcileScanFileProcessService) {
		this.reconcileScanFileProcessService = reconcileScanFileProcessService;
	}

	/**
	 * @return the reconcileExportReportService
	 */
	public ReconcileExportReportService getReconcileExportReportService() {
		return reconcileExportReportService;
	}

	/**
	 * @param reconcileExportReportService the reconcileExportReportService to set
	 */
	public void setReconcileExportReportService(
			@Qualifier("reconcileExportReportService") ReconcileExportReportService reconcileExportReportService) {
		this.reconcileExportReportService = reconcileExportReportService;
	}

	public ReconcileBankStatementVietcombankService getReconcileBankStatementVietcombank() {
		return reconcileBankStatementVietcombank;
	}

	public void setReconcileBankStatementVietcombank(
			@Qualifier("reconcileBankStatementVietcombankService") ReconcileBankStatementVietcombankService reconcileBankStatementVietcombank) {
		this.reconcileBankStatementVietcombank = reconcileBankStatementVietcombank;
	}

	public ReconcileBankStatementACBService getReconcileBankStatementACB() {
		return reconcileBankStatementACB;
	}

	public void setReconcileBankStatementACB(
			@Qualifier("reconcileBankStatementACBService") ReconcileBankStatementACBService reconcileBankStatementACB) {
		this.reconcileBankStatementACB = reconcileBankStatementACB;
	}

	public ReconcileBankStatementAgribankService getReconcileBankStatementAgribankService() {
		return reconcileBankStatementAgribankService;
	}

	public void setReconcileBankStatementAgribankService(
			@Qualifier("reconcileBankStatementAgribankService")	ReconcileBankStatementAgribankService reconcileBankStatementAgribankService) {
		this.reconcileBankStatementAgribankService = reconcileBankStatementAgribankService;
	}

	public ReconcileBankStatementOCBService getReconcileBankStatementOCBService() {
		return reconcileBankStatementOCBService;
	}

	public void setReconcileBankStatementOCBService(
			@Qualifier("reconcileBankStatementOCBService")	ReconcileBankStatementOCBService reconcileBankStatementOCBService) {
		this.reconcileBankStatementOCBService = reconcileBankStatementOCBService;
	}

	public ReconcileBankStatementSacombankService getReconcileBankStatementSacombankService() {
		return reconcileBankStatementSacombankService;
	}

	public void setReconcileBankStatementSacombankService(
			@Qualifier("reconcileBankStatementSacombankService")	ReconcileBankStatementSacombankService reconcileBankStatementSacombankService) {
		this.reconcileBankStatementSacombankService = reconcileBankStatementSacombankService;
	}

	public ReconcileBankStatementTechcombankHSCService getReconcileBankStatementTechcombankHSCService() {
		return reconcileBankStatementTechcombankHSCService;
	}

	public void setReconcileBankStatementTechcombankHSCService(
			@Qualifier("reconcileBankStatementTechcombankHSCService")	ReconcileBankStatementTechcombankHSCService reconcileBankStatementTechcombankHSCService) {
		this.reconcileBankStatementTechcombankHSCService = reconcileBankStatementTechcombankHSCService;
	}

	public ReconcileBankStatementTechcombankSGDService getReconcileBankStatementTechcombankSGDService() {
		return reconcileBankStatementTechcombankSGDService;
	}

	public void setReconcileBankStatementTechcombankSGDService(
			@Qualifier("reconcileBankStatementTechcombankSGDService")	ReconcileBankStatementTechcombankSGDService reconcileBankStatementTechcombankSGDService) {
		this.reconcileBankStatementTechcombankSGDService = reconcileBankStatementTechcombankSGDService;
	}

	public ReconcileBankStatementViettinService getReconcileBankStatementViettinService() {
		return reconcileBankStatementViettinService;
	}

	public void setReconcileBankStatementViettinService(
			@Qualifier("reconcileBankStatementViettinService")	ReconcileBankStatementViettinService reconcileBankStatementViettinService) {
		this.reconcileBankStatementViettinService = reconcileBankStatementViettinService;
	}

	public ReconcileBankStatementViettelService getReconcileBankStatementViettelService() {
		return reconcileBankStatementViettelService;
	}

	public void setReconcileBankStatementViettelService(
			@Qualifier("reconcileBankStatementViettelService")	ReconcileBankStatementViettelService reconcileBankStatementViettelService) {
		this.reconcileBankStatementViettelService = reconcileBankStatementViettelService;
	}

	public ReconcileBankStatementVnpostService getReconcileBankStatementVnpostService() {
		return reconcileBankStatementVnpostService;
	}

	public void setReconcileBankStatementVnpostService(
			@Qualifier("reconcileBankStatementVnpostService")	ReconcileBankStatementVnpostService reconcileBankStatementVnpostService) {
		this.reconcileBankStatementVnpostService = reconcileBankStatementVnpostService;
	}

	public ReconcileBankStatementPayooService getReconcileBankStatementPayooService() {
		return reconcileBankStatementPayooService;
	}

	public void setReconcileBankStatementPayooService(
			@Qualifier("reconcileBankStatementPayooService")	ReconcileBankStatementPayooService reconcileBankStatementPayooService) {
		this.reconcileBankStatementPayooService = reconcileBankStatementPayooService;
	}

	public ReconcileBankStatementMomoService getReconcileBankStatementMomoService() {
		return reconcileBankStatementMomoService;
	}

	public void setReconcileBankStatementMomoService(
			@Qualifier("reconcileBankStatementMomoService")	ReconcileBankStatementMomoService reconcileBankStatementMomoService) {
		this.reconcileBankStatementMomoService = reconcileBankStatementMomoService;
	}

	public ReconcileBankStatementAirpayService getReconcileBankStatementAirpayService() {
		return reconcileBankStatementAirpayService;
	}

	public void setReconcileBankStatementAirpayService(
			@Qualifier("reconcileBankStatementAirpayService")	ReconcileBankStatementAirpayService reconcileBankStatementAirpayService) {
		this.reconcileBankStatementAirpayService = reconcileBankStatementAirpayService;
	}

	public ReconcileBankStatementNapasService getReconcileBankStatementNapasService() {
		return reconcileBankStatementNapasService;
	}

	public void setReconcileBankStatementNapasService(
			@Qualifier("reconcileBankStatementNapasService")	ReconcileBankStatementNapasService reconcileBankStatementNapasService) {
		this.reconcileBankStatementNapasService = reconcileBankStatementNapasService;
	}

	public ReconcileRetryService getReconcileRetryService() {
		return reconcileRetryService;
	}

	public void setReconcileRetryService(
			@Qualifier("reconcileRetryService")	ReconcileRetryService reconcileRetryService) {
		this.reconcileRetryService = reconcileRetryService;
	}

	public ReconcileBankStatementShinhanFinanceService getReconcileBankStatementShinhanFinanceService() {
		return reconcileBankStatementShinhanFinanceService;
	}

	public void setReconcileBankStatementShinhanFinanceService(
			@Qualifier("reconcileBankStatementShinhanFinanceService")	ReconcileBankStatementShinhanFinanceService reconcileBankStatementShinhanFinanceService) {
		this.reconcileBankStatementShinhanFinanceService = reconcileBankStatementShinhanFinanceService;
	}

	public ReconcileDisbursProcessService getReconcileDisbursProcessService() {
		return reconcileDisbursProcessService;
	}

	public void setReconcileDisbursProcessService(
			@Qualifier("reconcileDisbursProcessService")	ReconcileDisbursProcessService reconcileDisbursProcessService) {
		this.reconcileDisbursProcessService = reconcileDisbursProcessService;
	}

	public ReconcileDisbursalProcessVietcombankService getReconcileDisbursalProcessVietcombankService() {
		return reconcileDisbursalProcessVietcombankService;
	}

	public void setReconcileDisbursalProcessVietcombankService(
			@Qualifier("reconcileDisbursalProcessVietcombankService")	ReconcileDisbursalProcessVietcombankService reconcileDisbursalProcessVietcombankService) {
		this.reconcileDisbursalProcessVietcombankService = reconcileDisbursalProcessVietcombankService;
	}

	public ReconcileDisbursalProcessTechcombankService getReconcileDisbursalProcessTechcombankService() {
		return reconcileDisbursalProcessTechcombankService;
	}

	public void setReconcileDisbursalProcessTechcombankService(
			@Qualifier("reconcileDisbursalProcessTechcombankService")	ReconcileDisbursalProcessTechcombankService reconcileDisbursalProcessTechcombankService) {
		this.reconcileDisbursalProcessTechcombankService = reconcileDisbursalProcessTechcombankService;
	}
	
	
}
