/**
 * 
 */
package com.shinhan.recon.report.model.bank;

import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;

/**
 * @author shds01
 *
 */
public class RepaymentForBankFooterReport {

	private BankStatementLmsTrxInfo sumGrandRecord;

	/**
	 * 
	 */
	public RepaymentForBankFooterReport() {
		super();
	}

	/**
	 * @param sumGrandRecord
	 */
	public RepaymentForBankFooterReport(BankStatementLmsTrxInfo sumGrandRecord) {
		super();
		this.sumGrandRecord = sumGrandRecord;
	}
	
	/**
	 * @return the sumRecord
	 */
	public BankStatementLmsTrxInfo getSumRecord() {
		return sumGrandRecord;
	}

	/**
	 * @param sumGrandRecord the sumGrandRecord to set
	 */
	public void setSumRecord(BankStatementLmsTrxInfo sumGrandRecord) {
		this.sumGrandRecord = sumGrandRecord;
	}

	
}
