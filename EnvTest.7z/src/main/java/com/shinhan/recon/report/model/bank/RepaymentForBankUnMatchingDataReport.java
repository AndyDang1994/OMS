/**
 * 
 */
package com.shinhan.recon.report.model.bank;

import java.util.ArrayList;
import java.util.List;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;

/**
 * @author shds01
 *
 */
public class RepaymentForBankUnMatchingDataReport {

	private List<Object[]> lmsUploadPendingLst;
	private List<Object[]> lmsCancelLst;
	private List<Object[]> bankFinanceLst;
	private List<Object[]> bankRefundLst;
	private List<Object[]> bankRevertLst;
	private List<Object[]> bankPendingLst;
	private BankStatementLmsTrxInfo sumRecord;

	/**
	 * 
	 */
	public RepaymentForBankUnMatchingDataReport() {
		super();
		this.lmsUploadPendingLst = new ArrayList<>();
		this.lmsCancelLst = new ArrayList<>();
		this.bankFinanceLst = new ArrayList<>();
		this.bankRefundLst = new ArrayList<>();
		this.bankRevertLst = new ArrayList<>();
		this.bankPendingLst = new ArrayList<>();
		this.sumRecord = new BankStatementLmsTrxInfo(APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
	}

	/**
	 * @return the lmsUploadPendingLst
	 */
	public List<Object[]> getLmsUploadPendingLst() {
		return lmsUploadPendingLst;
	}

	/**
	 * @param lmsUploadPendingLst the lmsUploadPendingLst to set
	 */
	public void setLmsUploadPendingLst(List<Object[]> lmsUploadPendingLst) {
		this.lmsUploadPendingLst = lmsUploadPendingLst;
	}

	/**
	 * @return the lmsCancelLst
	 */
	public List<Object[]> getLmsCancelLst() {
		return lmsCancelLst;
	}

	/**
	 * @param lmsCancelLst the lmsCancelLst to set
	 */
	public void setLmsCancelLst(List<Object[]> lmsCancelLst) {
		this.lmsCancelLst = lmsCancelLst;
	}

	/**
	 * @return the bankFinanceLst
	 */
	public List<Object[]> getBankFinanceLst() {
		return bankFinanceLst;
	}

	/**
	 * @param bankFinanceLst the bankFinanceLst to set
	 */
	public void setBankFinanceLst(List<Object[]> bankFinanceLst) {
		this.bankFinanceLst = bankFinanceLst;
	}

	/**
	 * @return the bankRefundLst
	 */
	public List<Object[]> getBankRefundLst() {
		return bankRefundLst;
	}

	/**
	 * @param bankRefundLst the bankRefundLst to set
	 */
	public void setBankRefundLst(List<Object[]> bankRefundLst) {
		this.bankRefundLst = bankRefundLst;
	}

	/**
	 * @return the bankRevertLst
	 */
	public List<Object[]> getBankRevertLst() {
		return bankRevertLst;
	}

	/**
	 * @param bankRevertLst the bankRevertLst to set
	 */
	public void setBankRevertLst(List<Object[]> bankRevertLst) {
		this.bankRevertLst = bankRevertLst;
	}

	/**
	 * @return the bankPendingLst
	 */
	public List<Object[]> getBankPendingLst() {
		return bankPendingLst;
	}

	/**
	 * @param bankPendingLst the bankPendingLst to set
	 */
	public void setBankPendingLst(List<Object[]> bankPendingLst) {
		this.bankPendingLst = bankPendingLst;
	}

	/**
	 * @return the sumRecord
	 */
	public BankStatementLmsTrxInfo getSumRecord() {
		return sumRecord;
	}

	/**
	 * @param sumRecord the sumRecord to set
	 */
	public void setSumRecord(BankStatementLmsTrxInfo sumRecord) {
		this.sumRecord = sumRecord;
	}

}
