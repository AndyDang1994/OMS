/**
 * 
 */
package com.shinhan.recon.report.model.nonbank;

import com.shinhan.recon.report.model.RepaymentForHeaderReport;

/**
 * @author shds01
 *
 */
public class RepaymentForNonBankHeaderReport extends RepaymentForHeaderReport {

	/**
	 * 
	 */
	public RepaymentForNonBankHeaderReport() {
		super();
	}

	/**
	 * @param fromDt
	 * @param toDt
	 * @param bankAccount
	 * @param bankName
	 */
	public RepaymentForNonBankHeaderReport(String fromDt, String toDt, String bankAccount, String bankName) {
		super();
		this.setFromDt(fromDt);
		this.setToDt(fromDt);
		this.setBankAccount(bankAccount);
		this.setBankName(bankName);
	}

}
