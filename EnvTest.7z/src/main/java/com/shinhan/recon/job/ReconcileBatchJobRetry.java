/**
 * 
 */
package com.shinhan.recon.job;

import java.time.LocalDateTime;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.shinhan.recon.common.AbstractBasicCommonClass;
import com.shinhan.recon.core.exception.BaseException;

/**
 * @author shds04
 *
 */
@Component
public class ReconcileBatchJobRetry extends AbstractBasicCommonClass {

	@Scheduled(fixedDelayString = "${spring.job.application.fixedDelay.retryBankStatement}") // 1 minutes
	public void scanBankStatementFile() throws BaseException {
		logger.info("***** Start Retry Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		getProcessManagerService().getReconcileRetryService().retryProcess();
		
		logger.info("***** End Retry Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
	
}
