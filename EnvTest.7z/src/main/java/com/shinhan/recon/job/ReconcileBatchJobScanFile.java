package com.shinhan.recon.job;

import java.time.LocalDateTime;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.shinhan.recon.common.AbstractBasicCommonClass;
import com.shinhan.recon.core.exception.BaseException;

@Component
public class ReconcileBatchJobScanFile extends AbstractBasicCommonClass {
	
	@Scheduled(fixedDelayString = "${spring.job.application.fixedDelay.scanBankStatement}") // 1 minutes
	public void scanBankStatementFile() throws Exception {
		logger.info("***** Start Scan Re-payment File To Process Reconcile Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		getProcessManagerService().getReconcileScanFileProcessService().scanBankStatementFile();
		
		logger.info("***** End Scan Re-payment File To Process Reconcile Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		logger.info("***** Start Scan Disbursal File To Process Reconcile  Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		getProcessManagerService().getReconcileScanFileProcessService().scanBankDisbursalFile();
		
		logger.info("***** End Scan Disbursal File To Process Reconcile Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}

}
