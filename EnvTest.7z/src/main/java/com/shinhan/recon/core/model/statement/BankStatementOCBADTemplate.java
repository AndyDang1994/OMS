package com.shinhan.recon.core.model.statement;

public class BankStatementOCBADTemplate {
	
	private String cusCode;
	private String cusName;
	private String loanNo;
	private String credit;
	private String ref;
	private String trxDt;
	private String exntRef;
	
	public BankStatementOCBADTemplate() {
		
	}

	public BankStatementOCBADTemplate(String cusCode, String cusName, String loanNo, String credit, String ref,
			String trxDate, String exntRef) {
		super();
		this.cusCode = cusCode;
		this.cusName = cusName;
		this.loanNo = loanNo;
		this.credit = credit;
		this.ref = ref;
		this.trxDt = trxDate;
		this.exntRef = exntRef;
	}

	public String getCusCode() {
		return cusCode;
	}

	public void setCusCode(String cusCode) {
		this.cusCode = cusCode;
	}

	public String getCusName() {
		return cusName;
	}

	public void setCusName(String cusName) {
		this.cusName = cusName;
	}

	public String getDebitAccount() {
		return loanNo;
	}

	public void setDebitAccount(String loanNo) {
		this.loanNo = loanNo;
	}

	public String getCredit() {
		return credit;
	}

	public void setCredit(String credit) {
		this.credit = credit;
	}

	public String getRef() {
		return ref;
	}

	public void setRef(String ref) {
		this.ref = ref;
	}

	public String getTrxDate() {
		return trxDt;
	}

	public void setTrxDate(String trxDate) {
		this.trxDt = trxDate;
	}

	public String getExntRef() {
		return exntRef;
	}

	public void setExntRef(String exntRef) {
		this.exntRef = exntRef;
	}
	
}
