package com.shinhan.recon.core.model.statement;

public class BankStatementTechcombankTemplate {
	private String trxDt;
	private String remitter;
	private String remitterBank;
	private String description;
	private String ref;
	private String debit;
	private String credit;
	private String fee;
	private String tax;
	private String balance;
	public BankStatementTechcombankTemplate() {
		
	}
	public BankStatementTechcombankTemplate(String trxDt, String remitter, String remitterBank, String description,
			String ref, String debit, String credit, String fee, String tax, String balance) {
		super();
		this.trxDt = trxDt;
		this.remitter = remitter;
		this.remitterBank = remitterBank;
		this.description = description;
		this.ref = ref;
		this.debit = debit;
		this.credit = credit;
		this.fee = fee;
		this.tax = tax;
		this.balance = balance;
	}

	public String getTrxDt() {
		return trxDt;
	}

	public void setTrxDt(String trxDt) {
		this.trxDt = trxDt;
	}

	public String getRemitter() {
		return remitter;
	}

	public void setRemitter(String remitter) {
		this.remitter = remitter;
	}

	public String getRemitterBank() {
		return remitterBank;
	}

	public void setRemitterBank(String remitterBank) {
		this.remitterBank = remitterBank;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRef() {
		return ref;
	}

	public void setRef(String ref) {
		this.ref = ref;
	}

	public String getDebit() {
		return debit;
	}

	public void setDebit(String debit) {
		this.debit = debit;
	}

	public String getCredit() {
		return credit;
	}

	public void setCredit(String credit) {
		this.credit = credit;
	}

	public String getFee() {
		return fee;
	}

	public void setFee(String fee) {
		this.fee = fee;
	}

	public String getTax() {
		return tax;
	}

	public void setTax(String tax) {
		this.tax = tax;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}
	
}
