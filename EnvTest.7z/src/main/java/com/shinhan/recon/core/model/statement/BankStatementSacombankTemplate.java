package com.shinhan.recon.core.model.statement;

public class BankStatementSacombankTemplate {
	private String accountId;
	private String ref;
	private String debit;
	private String credit;
	private String trxDt;
	private String valueDt;
	private String description;
	private String loanNo;
	private String benCustomer;
	private String benPayDetails;
	private String transRefNumber;
	private String channelId;
	
	public BankStatementSacombankTemplate() {
		
	}

	public BankStatementSacombankTemplate(String accountId, String ref, String debit, String credit, String valueDt,
			String trxDt, String description, String loanNo, String benCustomer, String benPayDetails,
			String transRefNumber, String channelId) {
		super();
		this.accountId = accountId;
		this.ref = ref;
		this.debit = debit;
		this.credit = credit;
		this.valueDt = valueDt;
		this.trxDt = trxDt;
		this.description = description;
		this.loanNo = loanNo;
		this.benCustomer = benCustomer;
		this.benPayDetails = benPayDetails;
		this.transRefNumber = transRefNumber;
		this.channelId = channelId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getRef() {
		return ref;
	}

	public void setRef(String ref) {
		this.ref = ref;
	}

	public String getDebit() {
		return debit;
	}

	public void setDebit(String debit) {
		this.debit = debit;
	}

	public String getCredit() {
		return credit;
	}

	public void setCredit(String credit) {
		this.credit = credit;
	}

	public String getValueDt() {
		return valueDt;
	}

	public void setValueDt(String valueDt) {
		this.valueDt = valueDt;
	}

	public String getTrxDt() {
		return trxDt;
	}

	public void setTrxDt(String trxDt) {
		this.trxDt = trxDt;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLoanNo() {
		return loanNo;
	}

	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	public String getBenCustomer() {
		return benCustomer;
	}

	public void setBenCustomer(String benCustomer) {
		this.benCustomer = benCustomer;
	}

	public String getBenPayDetails() {
		return benPayDetails;
	}

	public void setBenPayDetails(String benPayDetails) {
		this.benPayDetails = benPayDetails;
	}

	public String getTransRefNumber() {
		return transRefNumber;
	}

	public void setTransRefNumber(String transRefNumber) {
		this.transRefNumber = transRefNumber;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
}
