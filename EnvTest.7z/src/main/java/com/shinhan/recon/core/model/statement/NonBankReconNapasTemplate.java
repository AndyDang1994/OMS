package com.shinhan.recon.core.model.statement;

public class NonBankReconNapasTemplate {

	private String loanNo;
	private String ref;
	private String credit;
	private String trxDt;
	private String description;
	
	public NonBankReconNapasTemplate() {
		super();
		// TODO Auto-generated constructor stub
	}
	public NonBankReconNapasTemplate(String loanNo, String ref, String credit, String trxDt, String description) {
		super();
		this.loanNo = loanNo;
		this.ref = ref;
		this.credit = credit;
		this.trxDt = trxDt;
		this.description = description;
	}
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	public String getRef() {
		return ref;
	}
	public void setRef(String ref) {
		this.ref = ref;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	public String getTrxDt() {
		return trxDt;
	}
	public void setTrxDt(String trxDt) {
		this.trxDt = trxDt;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
