/**
 * 
 */
package com.shinhan.recon.core.model.statement;

/**
 * @author shds04
 *
 */
public class NonBankStatementNapasTemplate {

	private String trxDt;
	private String ref;
	private String debit;
	private String credit;
	private String description;

	/**
	 * 
	 */
	public NonBankStatementNapasTemplate() {
		super();
	}

	/**
	 * @param trxDt
	 * @param ref
	 * @param credit
	 * @param debit
	 * @param description
	 */
	public NonBankStatementNapasTemplate(String trxDt, String ref, String credit, String debit, String description) {
		super();
		this.trxDt = trxDt;
		this.ref = ref;
		this.credit = credit;
		this.debit = debit;
		this.description = description;
	}

	/**
	 * @return the trxDt
	 */
	public String getTrxDt() {
		return trxDt;
	}

	/**
	 * @param trxDt the trxDt to set
	 */
	public void setTrxDt(String trxDt) {
		this.trxDt = trxDt;
	}

	/**
	 * @return the ref
	 */
	public String getRef() {
		return ref;
	}

	/**
	 * @param ref the ref to set
	 */
	public void setRef(String ref) {
		this.ref = ref;
	}

	/**
	 * @return the credit
	 */
	public String getCredit() {
		return credit;
	}

	/**
	 * @param credit the credit to set
	 */
	public void setCredit(String credit) {
		this.credit = credit;
	}

	/**
	 * @return the debit
	 */
	public String getDebit() {
		return debit;
	}

	/**
	 * @param debit the debit to set
	 */
	public void setDebit(String debit) {
		this.debit = debit;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
}
