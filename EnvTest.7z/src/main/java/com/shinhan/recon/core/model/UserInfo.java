/**
 * 
 */
package com.shinhan.recon.core.model;

/**
 * @author shds01
 *
 */
public class UserInfo {

	private String userName;
	private String password;
	private String token;

	/**
	 * 
	 */
	public UserInfo() {
		super();
	}

	/**
	 * @param userName
	 * @param password
	 */
	public UserInfo(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}

	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param token
	 */
	public UserInfo(String token) {
		super();
		this.token = token;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

}
