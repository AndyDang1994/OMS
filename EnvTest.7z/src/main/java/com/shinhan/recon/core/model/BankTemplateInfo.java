/**
 * 
 */
package com.shinhan.recon.core.model;

/**
 * @author shds04
 *
 */
public class BankTemplateInfo {

	private int sheetIndex;
	private int fromRow;
	private int headerRow;
	private int fileCnt;
	private int glOpenBlcRow;
	private int glOpenBlcCol;
	private int glCloseBlcRow;
	private int glCloseBlcCol;
	private String templateColName;
	public BankTemplateInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BankTemplateInfo(int sheetIndex, int fromRow, int headerRow, int fileCnt, int glOpenBlcRow, int glOpenBlcCol,
			int glCloseBlcRow, int glCloseBlcCol, String templateColName) {
		super();
		this.sheetIndex = sheetIndex;
		this.fromRow = fromRow;
		this.headerRow = headerRow;
		this.fileCnt = fileCnt;
		this.glOpenBlcRow = glOpenBlcRow;
		this.glOpenBlcCol = glOpenBlcCol;
		this.glCloseBlcRow = glCloseBlcRow;
		this.glCloseBlcCol = glCloseBlcCol;
		this.templateColName = templateColName;
	}
	public int getSheetIndex() {
		return sheetIndex;
	}
	public void setSheetIndex(int sheetIndex) {
		this.sheetIndex = sheetIndex;
	}
	public int getFromRow() {
		return fromRow;
	}
	public void setFromRow(int fromRow) {
		this.fromRow = fromRow;
	}
	public int getHeaderRow() {
		return headerRow;
	}
	public void setHeaderRow(int headerRow) {
		this.headerRow = headerRow;
	}
	public int getFileCnt() {
		return fileCnt;
	}
	public void setFileCnt(int fileCnt) {
		this.fileCnt = fileCnt;
	}
	public int getGlOpenBlcRow() {
		return glOpenBlcRow;
	}
	public void setGlOpenBlcRow(int glOpenBlcRow) {
		this.glOpenBlcRow = glOpenBlcRow;
	}
	public int getGlOpenBlcCol() {
		return glOpenBlcCol;
	}
	public void setGlOpenBlcCol(int glOpenBlcCol) {
		this.glOpenBlcCol = glOpenBlcCol;
	}
	public int getGlCloseBlcRow() {
		return glCloseBlcRow;
	}
	public void setGlCloseBlcRow(int glCloseBlcRow) {
		this.glCloseBlcRow = glCloseBlcRow;
	}
	public int getGlCloseBlcCol() {
		return glCloseBlcCol;
	}
	public void setGlCloseBlcCol(int glCloseBlcCol) {
		this.glCloseBlcCol = glCloseBlcCol;
	}
	public String getTemplateColName() {
		return templateColName;
	}
	public void setTemplateColName(String templateColName) {
		this.templateColName = templateColName;
	}
	
}
