/**
 * 
 */
package com.shinhan.recon.core.model.statement;

/**
 * @author shds04
 *
 */
public class NonBankStatementVNPostTemplate {

	private String valuedt;
	private String trxDt;
	private String ref;
	private String description;
	private String debit;
	private String credit;
	public NonBankStatementVNPostTemplate() {
		super();
		// TODO Auto-generated constructor stub
	}
	public NonBankStatementVNPostTemplate(String valuedt, String trxDt, String ref, String description, String debit,
			String credit) {
		super();
		this.valuedt = valuedt;
		this.trxDt = trxDt;
		this.ref = ref;
		this.description = description;
		this.debit = debit;
		this.credit = credit;
	}
	public String getValuedt() {
		return valuedt;
	}
	public void setValuedt(String valuedt) {
		this.valuedt = valuedt;
	}
	public String getTrxDt() {
		return trxDt;
	}
	public void setTrxDt(String trxDt) {
		this.trxDt = trxDt;
	}
	public String getRef() {
		return ref;
	}
	public void setRef(String ref) {
		this.ref = ref;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDebit() {
		return debit;
	}
	public void setDebit(String debit) {
		this.debit = debit;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	
}
