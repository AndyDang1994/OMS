/**
 * 
 */
package com.shinhan.recon.core.model;

/**
 * @author shds01
 *
 */
public class ReconcileCommonStatementInfo {

	private BankStatementFile headerData;
	private BankStatementLmsTrxInfo totalRecordMatching;
	private BankStatementLmsTrxInfo totalRecordUnMatching;
	private BankStatementLmsTrxInfo totalRecordGrandData;

	/**
	 * 
	 */
	public ReconcileCommonStatementInfo() {
		super();
	}

	/**
	 * @param headerData
	 */
	public ReconcileCommonStatementInfo(BankStatementFile headerData) {
		super();
		this.headerData = headerData;
	}

	/**
	 * @param headerData
	 * @param totalRecordMatching
	 * @param totalRecordUnMatching
	 * @param totalRecordGrandData
	 */
	public ReconcileCommonStatementInfo(BankStatementFile headerData, BankStatementLmsTrxInfo totalRecordMatching,
			BankStatementLmsTrxInfo totalRecordUnMatching, BankStatementLmsTrxInfo totalRecordGrandData) {
		super();
		this.headerData = headerData;
		this.totalRecordMatching = totalRecordMatching;
		this.totalRecordUnMatching = totalRecordUnMatching;
		this.totalRecordGrandData = totalRecordGrandData;
	}

	/**
	 * @return the headerData
	 */
	public BankStatementFile getHeaderData() {
		return headerData;
	}

	/**
	 * @param headerData the headerData to set
	 */
	public void setHeaderData(BankStatementFile headerData) {
		this.headerData = headerData;
	}

	/**
	 * @return the totalRecordMatching
	 */
	public BankStatementLmsTrxInfo getTotalRecordMatching() {
		return totalRecordMatching;
	}

	/**
	 * @param totalRecordMatching the totalRecordMatching to set
	 */
	public void setTotalRecordMatching(BankStatementLmsTrxInfo totalRecordMatching) {
		this.totalRecordMatching = totalRecordMatching;
	}

	/**
	 * @return the totalRecordUnMatching
	 */
	public BankStatementLmsTrxInfo getTotalRecordUnMatching() {
		return totalRecordUnMatching;
	}

	/**
	 * @param totalRecordUnMatching the totalRecordUnMatching to set
	 */
	public void setTotalRecordUnMatching(BankStatementLmsTrxInfo totalRecordUnMatching) {
		this.totalRecordUnMatching = totalRecordUnMatching;
	}

	/**
	 * @return the totalRecordGrandData
	 */
	public BankStatementLmsTrxInfo getTotalRecordGrandData() {
		return totalRecordGrandData;
	}

	/**
	 * @param totalRecordGrandData the totalRecordGrandData to set
	 */
	public void setTotalRecordGrandData(BankStatementLmsTrxInfo totalRecordGrandData) {
		this.totalRecordGrandData = totalRecordGrandData;
	}

}
