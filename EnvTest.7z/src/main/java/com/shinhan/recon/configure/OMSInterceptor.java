/**
 * 
 */
package com.shinhan.recon.configure;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.UnauthorizedException;
import com.shinhan.recon.core.util.CommonUtil;

/**
 * @author shds01
 *
 */
@Component
public class OMSInterceptor implements HandlerInterceptor {
	
	@Autowired
	public Environment env;

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.web.servlet.HandlerInterceptor#afterCompletion(javax.
	 * servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * java.lang.Object, java.lang.Exception)
	 */
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		if(request.getAttribute(com.shinhan.recon.core.constant.APIConstant.HTTP_REQUEST_BODY_STR) != null && HttpStatus.OK.value() != response.getStatus()){
			//logger.info("Body : " + request.getAttribute(APIConstant.HTTP_REQUEST_BODY_STR));
			saveTrackingLogRequestToDB(request, response.getStatus());
		}
		
		logger.info("***** After completion handle *****");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.web.servlet.HandlerInterceptor#postHandle(javax.
	 * servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * java.lang.Object, org.springframework.web.servlet.ModelAndView)
	 */
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		int statusCode = response.getStatus();
		saveTrackingLogRequestToDB(request, statusCode);
		logger.info("***** Post completion handle *****");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.web.servlet.HandlerInterceptor#preHandle(javax.
	 * servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * java.lang.Object)
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		logger.info("***** Begin Pre Interceptor *****");
		String userName = APIConstant.ANONYMOUS_USER;
		String URI = request.getRequestURI();
		boolean flag = URI.contains(APIConstant.CONTEXT_FILTER_PATH);
		logger.info(request.getHeader("Content-Type"));
		logger.info(request.getHeader("content-type"));
		
		if (flag) {
			
			String token = request.getHeader(APIConstant.ACCESS_TOKEN_KEY);
			if (StringUtils.isBlank(token)) {
				throw new UnauthorizedException(APIConstant.THE_TOKEN_IS_BLANK_ERROR);
			}
			// Parse the token.
			JsonObject jsonToken = (JsonObject) CommonUtil.toPojo(CommonUtil.checkSecureTheToken(env, token), JsonObject.class);
			
			// Parse the token to get userName;
			userName = jsonToken.get(APIConstant.USERNAME_KEY) != null ? jsonToken.get(APIConstant.USERNAME_KEY).getAsString() : "";
			if (StringUtils.isBlank(userName)) {
				throw new UnauthorizedException(APIConstant.THE_TOKEN_IS_BLANK_ERROR);
			}
		}
		request.setAttribute(APIConstant.USERNAME_KEY, userName);
		request.setAttribute(APIConstant.REQUEST_URI_STR, request.getRequestURI());

		logger.info("======= Begin Transaction =======");
		logger.info(" ***** URL : " + request.getRequestURI() + " ***** ");
		logger.info(" ***** method : " + request.getMethod() + " ***** ");
		logger.info(" ***** userName : " + userName + " ***** ");
		logger.info("At : " + new Date());
		
		writeLogHttpSerlvetRequest(request);
		
		long startTime = System.currentTimeMillis();
		request.setAttribute(APIConstant.EXECUTION_TIME_KEY, startTime);

		return true;
	}
	
	private void saveTrackingLogRequestToDB(HttpServletRequest request, int statusCode){
		long starttime = (long) request.getAttribute(APIConstant.EXECUTION_TIME_KEY);
		long endTime = System.currentTimeMillis();
		long spentTime = (endTime - starttime);
		if(request.getMethod().equals(HttpMethod.POST.toString()) || request.getMethod().equals(HttpMethod.PATCH.toString())){
			if(request.getAttribute(APIConstant.HTTP_REQUEST_BODY_STR) != null){
				ObjectMapper objectMapper = new ObjectMapper();
				String json = request.getAttribute(APIConstant.HTTP_REQUEST_BODY_STR).toString();
				try{
					JsonNode jsonNode = objectMapper.readValue(json, JsonNode.class);
					logger.info("Body : " + jsonNode.toString());
				}catch(Exception e){
					logger.info("Body : " + json);
				}
			}
		}
		logger.info("Time Execution : " + spentTime);
		logger.info("At : " + new Date());
		logger.info("======= End Transaction =======");
	}
	
	public void writeLogHttpSerlvetRequest(HttpServletRequest httpServletRequest) throws UnsupportedEncodingException {
		Map<?, ?> params = httpServletRequest.getParameterMap();
		Iterator<?> i = params.keySet().iterator();
		while (i.hasNext()) {
			String key = (String) i.next();
			if(params.containsKey(key)){
				String[] strs = (String[]) params.get(key);
				if(strs != null && strs.length > 0){
					for(String str : strs){
						logger.info("Key : " + key);
						logger.info("Value : " + str);
						logger.info("Value Decode UTF-8 : " + URLDecoder.decode(str, APIConstant.UTF_8_CHARSET_TYPE));
						logger.info("Value Encode UTF-8 : " + URLEncoder.encode(str, APIConstant.UTF_8_CHARSET_TYPE));
					}
				}
			}
			//String value = params.get(key) != null ? ((String[]) params.get(key))[0] : "";
			
		}
	}
}
