/**
 * 
 */
package com.shinhan.recon.repository.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.repository.dao.TOmsReconDisbursalInfDAO;
import com.shinhan.recon.repository.dao.TOmsReconLmsInfDAO;
import com.shinhan.recon.repository.entity.TOmsReconDisburInf;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.service.TOmsReconDisbursalInfManagerRepositoryService;

/**
 * @author shds04
 *
 */

@Service("tOmsReconDisbursalInfManagerRepositoryService")
public class TOmsReconDisbursalInfManagerRepositoryServiceImpl  extends AbstractServiceClass
implements TOmsReconDisbursalInfManagerRepositoryService{
	
	private TOmsReconDisbursalInfDAO objectDao;

	@Autowired
	public TOmsReconDisbursalInfManagerRepositoryServiceImpl(TOmsReconDisbursalInfDAO objectDao) {
		this.objectDao = objectDao;
	}
	
	@Override
	public List<TOmsReconDisburInf> getSpecInfs(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconDisburInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getSpecDisbByLoanAndAmt");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String loanNo = inputParams.get(APIConstant.LOAN_NO_KEY).toString();
		String drAmtString = inputParams.get(APIConstant._DR_AMT_KEY).toString();
		BigDecimal drAmt = new BigDecimal( StringUtils.isBlank(drAmtString) ? "0" :drAmtString );
		Query query = entityManager.createNativeQuery(sql,TOmsReconDisburInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant.LOAN_NO_KEY,loanNo);
		query.setParameter(APIConstant._DR_AMT_KEY,drAmt);
		list = query.getResultList();
		return list;
	}
	@Override
	public List<TOmsReconDisburInf> getDisbursByBankCodeAndStatus(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconDisburInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getDisbursByBankCodeAndStatus");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String loanNo = inputParams.get(APIConstant.LOAN_NO_KEY).toString();
		String status = inputParams.get(APIConstant._STATUS_KEY).toString();
		Query query = entityManager.createNativeQuery(sql,TOmsReconDisburInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant.LOAN_NO_KEY,loanNo);
		query.setParameter(APIConstant._STATUS_KEY,status);
		list = query.getResultList();
		return list;
	}

	@Override
	public boolean create(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconDisburInf item = (TOmsReconDisburInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean createAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconDisburInf> items = (List<TOmsReconDisburInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public TOmsReconLmsInf getOne(Map<String, Object> inputParams) throws BaseException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconDisburInf item = (TOmsReconDisburInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean updateALL(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconDisburInf> items = (List<TOmsReconDisburInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

}
