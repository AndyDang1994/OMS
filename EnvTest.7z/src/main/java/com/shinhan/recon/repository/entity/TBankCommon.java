/**
 * 
 */
package com.shinhan.recon.repository.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

/**
 * @author shds04
 *
 */
@Entity
@Table(name = "OMS_BANK_COMMON")
public class TBankCommon implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	private String bankCode;
	private String bankName;
	private String bankAccNuber;
	private String isBankYn;
	private String isRepaymentYn;
	private String addInf;
	private String bizValue;

	/**
	 * 
	 */
	public TBankCommon() {
		super();
	}

	/**
	 * @param id
	 * @param bankCode
	 * @param bankName
	 * @param bankNum
	 * @param isBank
	 * @param isRepayment
	 * @param addInf
	 */
	public TBankCommon(Long id, String bankCode, String bankName, String bankAccNuber, String isBankYn, String isRepayment,String addInf,String bizValue) {
		super();
		this.id = id;
		this.bankCode = bankCode;
		this.bankName = bankName;
		this.bankAccNuber = bankAccNuber;
		this.isBankYn = isBankYn;
		this.isRepaymentYn = isRepayment;
		this.addInf = addInf;
		this.bizValue = bizValue;
	}

	/**
	 * @return the id
	 */
	@Id
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the bankCode
	 */
	@Column(name = "BANK_CODE")
	public String getBankCode() {
		return bankCode;
	}

	/**
	 * @param bankCode the bankCode to set
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	/**
	 * @return the bankName
	 */
	@Column(name = "BANK_NAME")
	public String getBankName() {
		return bankName;
	}

	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * @return the bankNum
	 */
	@Column(name = "BANK_ACC_NUM")
	public String getBankAccNuber() {
		return bankAccNuber;
	}

	/**
	 * @param bankNum the bankNum to set
	 */
	public void setBankAccNuber(String bankAccNuber) {
		this.bankAccNuber = bankAccNuber;
	}

	/**
	 * @return the isBankYn
	 */
	@Column(name = "IS_BANK_YN")
	public String getIsBankYn() {
		return isBankYn;
	}

	/**
	 * @param isBankYn the isBank to set
	 */
	public void setIsBankYn(String isBank) {
		this.isBankYn = isBank;
	}

	/**
	 * @return the isRepayment
	 */
	@Column(name = "IS_REPAYMENT_YN")
	public String getIsRepaymentYn() {
		return isRepaymentYn;
	}

	/**
	 * @param isRepayment the isRepayment to set
	 */
	public void setIsRepaymentYn(String isRepayment) {
		this.isRepaymentYn = isRepayment;
	}

	@Lob
	@Column(name = "ADD_INF")
	public String getAddInf() {
		return addInf;
	}

	public void setAddInf(String addInf) {
		this.addInf = addInf;
	}

	@Column(name = "BIZ_VALUE")
	public String getBizValue() {
		return bizValue;
	}
	public void setBizValue(String bizValue) {
		this.bizValue = bizValue;
	}
	
}
