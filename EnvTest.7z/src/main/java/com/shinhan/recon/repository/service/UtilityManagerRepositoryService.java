/**
 * 
 */
package com.shinhan.recon.repository.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TMetadata;

/**
 * @author shds01
 *
 */
public interface UtilityManagerRepositoryService {

	public List<TMetadata> getAllMetadata(Map<String, Object> inputParams) throws BaseException;
	
	public List<TMetadata> getMetadataByLookupCode(String lookupCode) throws BaseException;
	
	public List<TBankCommon> getBankCommonByBankName(String bankName) throws BaseException;

	public TBankCommon getBankCommonByBankAccNum(String bankName) throws BaseException;
	
	public List<TBankCommon> getBankCommonByBizValue(String bizValue) throws BaseException;
	
	public BigDecimal getOpenBalanceOfBankCodeByDate(Map<String, Object> inputParams) throws BaseException;
}
