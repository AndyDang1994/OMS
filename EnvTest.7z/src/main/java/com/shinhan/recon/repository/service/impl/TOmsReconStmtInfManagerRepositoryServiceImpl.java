/**
 * 
 */
package com.shinhan.recon.repository.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.BankStatemenTrxInfo;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.dao.TOmsReconStmtInfDAO;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("tomsReconStmtInfManagerRepositoryService")
public class TOmsReconStmtInfManagerRepositoryServiceImpl extends AbstractServiceClass
		implements TOmsReconStmtInfManagerRepositoryService {

	private TOmsReconStmtInfDAO objectDao;

	@Autowired
	public TOmsReconStmtInfManagerRepositoryServiceImpl(TOmsReconStmtInfDAO objectDao) {
		this.objectDao = objectDao;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#
	 * getListTrxByDate(java.util.Map)
	 */
	@Override
	public List<TOmsReconStmtInf> getListTrxByDate(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconStmtInf> list = new ArrayList<>();
		String startDt = inputParams.get(APIConstant._START_DATE_KEY).toString();
		String endDt = inputParams.get(APIConstant._END_DATE_KEY).toString();
		String status = inputParams.get(APIConstant._STATUS_KEY).toString();
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String sql = oracleOMSNamedQueries.get("getOmsDataByDate");
		
		Query query = entityManager.createNativeQuery(sql,TOmsReconStmtInf.class);
		query.setParameter(APIConstant._START_DATE_KEY,DateUtils.converToDate(startDt));
		query.setParameter(APIConstant._END_DATE_KEY,  DateUtils.converToDate(endDt));
		query.setParameter(APIConstant._STATUS_KEY,status);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		
		list = query.getResultList();
		return list;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#
	 * create(java.util.Map)
	 */
	@Override
	public boolean create(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconStmtInf item = (TOmsReconStmtInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#
	 * createAll(java.util.Map)
	 */
	@Override
	public boolean createAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconStmtInf> items = (List<TOmsReconStmtInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#
	 * getOne(java.util.Map)
	 */
	@Override
	public TOmsReconStmtInf getOne(Map<String, Object> inputParams) throws BaseException {
		String omsId = inputParams.get(APIConstant.OMSID).toString();
		if (StringUtils.isBlank(omsId)) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_003"));
		}
		try {
			TOmsReconStmtInf item = objectDao.findById(Long.valueOf(omsId)).get();
			return item;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + omsId + "");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#
	 * update(java.util.Map)
	 */
	@Override
	public boolean update(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconStmtInf item = (TOmsReconStmtInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#updateAll(java.util.Map)
	 */
	@Override
	public boolean updateAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconStmtInf> items = (List<TOmsReconStmtInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#countTotalBankStatementTrxByDate(java.util.Map)
	 */
	@Override
	public BigDecimal countTotalBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT count( distinct lms.ID) "
					+ "FROM OMS_RECON_LMS_INF lms, OMS_RECON_STMT_INF bank "
					+ "WHERE lms.TRX_DT = bank.TRX_DT and bank.BANK_CODE = lms.BANK_CODE and lms.STATUS = bank.STATUS and lms.REF_ID = bank.REF_ID "
					+ "and lms.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS =:statusCode "
					+ "and (:ref is NULL or lms.REF_NO =:ref) "
					+ "and (:loanNo is NULL or lms.LOAN_NO =:loanNo) ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", APIConstant._BANK_STATEMENT_MATCH_STATUS);
			
			query.setParameter("ref", inputParams.get(APIConstant.REF_KEY).toString());
			query.setParameter("loanNo", inputParams.get(APIConstant.LOAN_NO_KEY).toString());
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#getListBankStatementTrxByDate(java.util.Map)
	 */
	@Override
	public List<BankStatementLmsTrxInfo> getListBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT new com.shinhan.recon.core.model.BankStatementLmsTrxInfo("
					+ "bank.id as id, bank.refNo as refNo, bank.trxDt as trxDt, bank.bankCode as bankCode, "
					+ "bank.drAmt as drAmt, bank.crAmt as crAmt, bank.loanNo as loanNo, "
					+ "bank.statusCode as statusCode, bank.subStatusCode as subStatusCode, bank.remark as remark, bank.remarkNote as remarkNote, "
					+ "lms.id as idLMS, lms.refNo as refNoLMS, lms.bankCode as bankCodeLMS, lms.trxDt as trxDtLMS, "
					+ "lms.valueDt as valueDtLMS, lms.cif as cifLMS, lms.paymode as paymodeLMS, "
					+ "lms.drAmt as drAmtLMS, lms.crAmt as crAmtLMS, lms.loanNo as loanNoLMS, "
					+ "lms.statusCode as statusCodeLMS, lms.subStatusCode as subStatusCodeLMS, lms.remark as remarkLMS, lms.remarkNote as remarkNoteLMS"
					+ ") "
					+ "FROM TOmsReconLmsInf lms, TOmsReconStmtInf bank "
					+ "WHERE lms.trxDt = bank.trxDt and bank.bankCode = lms.bankCode and lms.statusCode = bank.statusCode "
					+ "and lms.refID = bank.refID "
					+ "and lms.trxDt BETWEEN :fromDt and :endDt "
					+ "and lms.bankCode =:bankCode and lms.statusCode =:statusCode "
					+ "and (:ref is NULL or lms.refNo =:ref) "
					+ "and (:loanNo is NULL or lms.loanNo =:loanNo) ";
			
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			Query query = entityManager.createQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant._BANK_STATEMENT_MATCH_STATUS));
			
			query.setParameter("ref", inputParams.get(APIConstant.REF_KEY).toString());
			query.setParameter("loanNo", inputParams.get(APIConstant.LOAN_NO_KEY).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			List<BankStatementLmsTrxInfo> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#countTotalUnmatchBankStatementTrxByDate(java.util.Map)
	 */
	@Override
	public BigDecimal countTotalUnmatchBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT count( distinct bank.ID) "
					+ "FROM OMS_RECON_STMT_INF bank "
					+ "WHERE "
					+ "bank.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and bank.BANK_CODE =:bankCode and bank.STATUS <> :statusCode and bank.REF_ID is NULL "
					+ "and (:ref is NULL or bank.REF_NO =:ref) "
					+ "and (:loanNo is NULL or bank.LOAN_NO =:loanNo) ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", APIConstant._BANK_STATEMENT_MATCH_STATUS);
			
			query.setParameter("ref", inputParams.get(APIConstant.REF_KEY).toString());
			query.setParameter("loanNo", inputParams.get(APIConstant.LOAN_NO_KEY).toString());
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	@Override
	public List<BankStatemenTrxInfo> getUnmatchListBankStatementTrxByDate(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT new com.shinhan.recon.core.model.BankStatemenTrxInfo("
					+ "bank.id as id, bank.refNo as refNo, bank.trxDt as trxDt, bank.bankCode as bankCode, "
					+ "bank.drAmt as drAmt, bank.crAmt as crAmt, bank.loanNo as loanNo, "
					+ "bank.statusCode as statusCode, bank.subStatusCode as subStatusCode, bank.remark as remark, bank.remarkNote as remarkNote"
					+ ") "
					+ "FROM TOmsReconStmtInf bank "
					+ "where bank.trxDt BETWEEN :fromDt and :endDt "
					+ "and bank.bankCode =:bankCode "
					+ "and bank.statusCode <> :statusCode "
					+ "and bank.refID is NULL "
					+ "and (:ref is NULL or bank.refNo =:ref) "
					+ "and (:loanNo is NULL or bank.loanNo =:loanNo) ";
			
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			Query query = entityManager.createQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode",APIConstant._BANK_STATEMENT_MATCH_STATUS);
			
			query.setParameter("ref", inputParams.get(APIConstant.REF_KEY).toString());
			query.setParameter("loanNo", inputParams.get(APIConstant.LOAN_NO_KEY).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			List<BankStatemenTrxInfo> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	@Override
	public List<TOmsReconStmtInf> getStatementByRef(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconStmtInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getStatementByRef");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String refNo = inputParams.get(APIConstant._REF_NO_KEY).toString();
		String crAmtString = inputParams.get(APIConstant._CR_AMT_KEY).toString();
		BigDecimal crAmt = new BigDecimal( StringUtils.isBlank(crAmtString) ? "0" :crAmtString );
		Query query = entityManager.createNativeQuery(sql,TOmsReconStmtInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant._REF_NO_KEY,refNo);
		query.setParameter(APIConstant._CR_AMT_KEY,crAmt);
		list = query.getResultList();
		return list;
	}
	@Override
	public List<TOmsReconStmtInf> getStatementByRevertRef(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconStmtInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getStatementByRevertRef");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String refNo = inputParams.get(APIConstant._REF_NO_KEY).toString();
		String drAmtString = inputParams.get(APIConstant._CR_AMT_KEY).toString();
		BigDecimal drAmt = new BigDecimal( StringUtils.isBlank(drAmtString) ? "0" :drAmtString );
		Query query = entityManager.createNativeQuery(sql,TOmsReconStmtInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant._REF_NO_KEY,refNo);
		query.setParameter(APIConstant._DR_AMT_KEY,drAmt);
		list = query.getResultList();
		return list;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#getMatchListBankStatementTrxByDateAndBankCode(java.util.Map)
	 */
	@Override
	public List<Object[]> getMatchListBankStatementTrxByDateAndBankCode(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT "
					+ "bank.TRX_DT as trxDt, bank.REF_NO as refNo, bank.REMARK as remark, "
					+ "bank.DR_AMT as drAmt, bank.CR_AMT as crAmt, bank.LOAN_NO as loanNo, "
					+ "lms.TRX_DT as trxDtLMS, lms.REF_NO as refNoLMS, lms.LOAN_NO as loanNoLMS, "
					+ "lms.CIF as cif, lms.PAYMODE as paymode, "
					+ "lms.DR_AMT as drAmtLMS, lms.CR_AMT as crAmtLMS, '' as remarkLMS "
					+ "FROM OMS_RECON_LMS_INF lms, OMS_RECON_STMT_INF bank "
					+ "WHERE lms.TRX_DT = bank.TRX_DT and bank.BANK_CODE = lms.BANK_CODE and lms.STATUS = bank.STATUS "
					+ "and lms.REF_ID = bank.REF_ID "
					+ "and lms.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS =:statusCode ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant._BANK_STATEMENT_MATCH_STATUS));
			
			return query.getResultList();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#sumDrAndCrMatchListBankStatementTrxByDateAndBankCode(java.util.Map)
	 */
	@Override
	public BankStatementLmsTrxInfo sumDrAndCrMatchListBankStatementTrxByDateAndBankCode(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT "
					+ "SUM(bank.DR_AMT) as drAmt, SUM(bank.CR_AMT) as crAmt, "
					+ "SUM(lms.DR_AMT) as drAmtLMS, SUM(lms.CR_AMT) as crAmtLMS "
					+ "FROM OMS_RECON_LMS_INF lms, OMS_RECON_STMT_INF bank "
					+ "WHERE lms.TRX_DT = bank.TRX_DT and bank.BANK_CODE = lms.BANK_CODE and lms.STATUS = bank.STATUS "
					+ "and lms.REF_ID = bank.REF_ID "
					+ "and lms.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS =:statusCode ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant._BANK_STATEMENT_MATCH_STATUS));
			
			List<Object[]> lst = query.getResultList();
			
			for(Object[] item : lst){
				if(item[0] == null) {
					return new BankStatementLmsTrxInfo(APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
				}
				return new BankStatementLmsTrxInfo(new BigDecimal(item[0] + ""), new BigDecimal(item[1] + "")
						, new BigDecimal(item[2] + ""), new BigDecimal(item[3] + ""));
			}
			return new BankStatementLmsTrxInfo();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#getUnMatchListTrxByDateAndBankCodeAndStatus(java.util.Map)
	 */
	@Override
	public List<Object[]> getUnMatchListTrxByDateAndBankCodeAndStatus(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT "
					+ "bank.TRX_DT as trxDt, bank.REF_NO as refNo, bank.REMARK as remark, "
					+ "bank.DR_AMT as drAmt, bank.CR_AMT as crAmt, bank.LOAN_NO as loanNo, "
					+ "'' as trxDtLMS, '' as refNoLMS, '' as loanNoLMS, "
					+ "'' as cif, '' as paymode, "
					+ "'' as drAmtLMS, '' as crAmtLMS, bank.REMARK_NOTE as remarkLMS "
					+ "FROM OMS_RECON_STMT_INF bank "
					+ "WHERE bank.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and bank.BANK_CODE =:bankCode and bank.STATUS = :statusCode ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			
			query.setParameter("statusCode", Long.valueOf(inputParams.get(APIConstant._STATUS_KEY).toString()));
			
			return query.getResultList();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconStmtInfManagerRepositoryService#sumDrAndCrUnMatchListBankStatementTrxByDateAndBankCode(java.util.Map)
	 */
	@Override
	public BankStatementLmsTrxInfo sumDrAndCrUnMatchListBankStatementTrxByDateAndBankCode(
			Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT "
					+ "SUM(bank.DR_AMT) as drAmt, SUM(bank.CR_AMT) as crAmt "
					+ "FROM OMS_RECON_STMT_INF bank "
					+ "WHERE "
					+ "bank.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and bank.BANK_CODE =:bankCode and bank.STATUS <> :statusCode ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant._BANK_STATEMENT_MATCH_STATUS));
			
			List<Object[]> lst = query.getResultList();
			
			for(Object[] item : lst){
				if(item[0] == null) {
					return new BankStatementLmsTrxInfo(APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
				}
				return new BankStatementLmsTrxInfo(new BigDecimal(item[0] + ""), new BigDecimal(item[1] + ""), APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
			}
			return new BankStatementLmsTrxInfo();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	@Override
	public List<TOmsReconStmtInf> getListTrxByBankcodeAndDate(Map<String, Object> inputParams) throws BaseException {
		List< TOmsReconStmtInf> rs = new ArrayList<>();
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String trxDt = inputParams.get(APIConstant.TRX_DATE_KEY).toString();
		String sql = oracleOMSNamedQueries.get("getOmsDataByBankCodeAndDate");
		Query query = entityManager.createNativeQuery(sql, TOmsReconStmtInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY, bankCode);
		query.setParameter(APIConstant.TRX_DATE_KEY, DateUtils.convertDate(trxDt, DateUtils.DATEFORMAT));
		rs = query.getResultList();
		return rs;
	}
	
}
