/**
 * 
 */
package com.shinhan.recon.repository.service;

import java.util.List;
import java.util.Map;

import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.model.BankStatementFile;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;

/**
 * @author shds01
 *
 */
public interface TOmsStmtFileMasManagerRepositoryService {

	public List<TOmsStmtFileMas> getListUploadByDateAndStatus(Map<String, Object> inputParams) throws BaseException;

	public List<TOmsStmtFileMas> getDeleteListUploadByBankcode(Map<String, Object> inputParams) throws BaseException;
	
	public List<TOmsStmtFileMas> getListUploadByDate(Map<String, Object> inputParams) throws BaseException;
	
	public List<TOmsStmtFileMas> getListUploadByDateAndBankCode(Map<String, Object> inputParams) throws BaseException;
	
	public boolean create(Map<String, Object> inputParams) throws BaseException;
	
	public boolean createAll(Map<String, Object> inputParams) throws BaseException;
	
	public TOmsStmtFileMas getOne(Map<String, Object> inputParams) throws BaseException;
	
	public boolean update(Map<String, Object> inputParams) throws BaseException;
	
	public List<BankStatementFile> getListStmtFileMasByDate(Map<String, Object> inputParams) throws BaseException;
	
}
