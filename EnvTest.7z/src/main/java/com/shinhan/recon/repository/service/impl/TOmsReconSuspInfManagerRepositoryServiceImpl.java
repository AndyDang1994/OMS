/**
 * 
 */
package com.shinhan.recon.repository.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.dao.TOmsReconSuspInfDAO;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.recon.repository.service.TOmsReconSuspInfManagerRepositoryService;

/**
 * @author shds04
 *
 */
@Service("tOmsReconSuspInfManagerRepositoryService")
public class TOmsReconSuspInfManagerRepositoryServiceImpl extends AbstractServiceClass implements TOmsReconSuspInfManagerRepositoryService {

	private TOmsReconSuspInfDAO objectDao;

	@Autowired
	public TOmsReconSuspInfManagerRepositoryServiceImpl(TOmsReconSuspInfDAO objectDao) {
		this.objectDao = objectDao;
	}
	
	@Override
	public List<TOmsReconSuspenseInf> getSuspenseByRef(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconSuspenseInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getSuspByRef");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String refNo = inputParams.get(APIConstant._REF_NO_KEY).toString();
		String crAmtString = inputParams.get(APIConstant._CR_AMT_KEY).toString();
		BigDecimal crAmt = new BigDecimal( StringUtils.isBlank(crAmtString) ? "0" :crAmtString );
		Query query = entityManager.createNativeQuery(sql,TOmsReconSuspenseInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant._REF_NO_KEY,refNo);
		query.setParameter(APIConstant._CR_AMT_KEY,crAmt);
		list = query.getResultList();
		return list;
	}

	@Override
	public boolean create(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconSuspenseInf item = (TOmsReconSuspenseInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean createAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconSuspenseInf> items = (List<TOmsReconSuspenseInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean update(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconSuspenseInf item = (TOmsReconSuspenseInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean updateAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconSuspenseInf> items = (List<TOmsReconSuspenseInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public List<TOmsReconSuspenseInf> getListTrxByBankcodeAndDate(Map<String, Object> inputParams)
			throws BaseException {
		List< TOmsReconSuspenseInf> rs = new ArrayList<>();
		String bankCode = inputParams.get(APIConstant.UPLOAD_BANKCODE_KEY).toString();
		String trxDt = inputParams.get(APIConstant.TRX_DATE_KEY).toString();
		String sql = oracleOMSNamedQueries.get("getSuspDataByBankCodeAndDate");
		Query query = entityManager.createNativeQuery(sql, TOmsReconSuspenseInf.class);
		query.setParameter(APIConstant.UPLOAD_BANKCODE_KEY, bankCode);
		query.setParameter(APIConstant.TRX_DATE_KEY, DateUtils.convertDate(trxDt, DateUtils.DATEFORMAT));
		rs = query.getResultList();
		return rs;
	}
}
