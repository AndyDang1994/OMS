/**
 * 
 */
package com.shinhan.recon.repository.service;

import java.util.List;
import java.util.Map;

import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;

/**
 * @author shds04
 *
 */
public interface TOmsReconSuspInfManagerRepositoryService {
	
	public List<TOmsReconSuspenseInf> getListTrxByBankcodeAndDate(Map<String, Object> inputParams) throws BaseException;
	
	public List<TOmsReconSuspenseInf> getSuspenseByRef(Map<String, Object> inputParams) throws BaseException;
	
	public boolean create(Map<String, Object> inputParams) throws BaseException;
	
	public boolean createAll(Map<String, Object> inputParams) throws BaseException;
	
	public boolean update(Map<String, Object> inputParams) throws BaseException;

	public boolean updateAll(Map<String, Object> inputParams) throws BaseException;
	
}
