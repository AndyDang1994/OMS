/**
 * 
 */
package com.shinhan.recon.api.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.UserInfo;
import com.shinhan.recon.repository.entity.TMetadata;

/**
 * @author shds01
 *
 */
@RestController
public class UtilityController extends BaseController{

	
	@RequestMapping(value = "shinhan/common/connection", method = RequestMethod.GET)
	public ResponseEntity<Object> testGet() throws ServiceRuntimeException, InterruptedException {
		return triggerSuccessOutPut(null, JsonObject.class, "connect server successfully");
	}

	@RequestMapping(value = "shinhan/common/exception", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	@ResponseBody
	public String testException(Locale locale) throws BaseException {
		testException();
		return "Success";
	}
	
	@RequestMapping(value = "shinhan/common/metadata", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getAllMetadata(@RequestParam(required = false, defaultValue = "") String _lookupCode, Locale locale) throws BaseException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._LOOKUP_CODE_KEY, StringUtils.isEmpty(_lookupCode) ? APIConstant.ALL : _lookupCode);
		
		List<TMetadata> listTMetadata = getProcessManagerService()
				.getReconcileApiService().getAllMetadata(inputParams, inputParams.get(APIConstant._LOOKUP_CODE_KEY).toString());
		return triggerSuccessOutPut(listTMetadata, listTMetadata.size());
	}
	
	@RequestMapping(value = "shinhan/common/authentication", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> generateTokenUser(@RequestBody String document, Locale locale) throws BaseException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		
		String token = getProcessManagerService().getReconcileApiService().generateUserToken(inputParams);
		UserInfo user = new UserInfo(token);
		return triggerSuccessOutPut(user, JsonObject.class, null);
	}
}
