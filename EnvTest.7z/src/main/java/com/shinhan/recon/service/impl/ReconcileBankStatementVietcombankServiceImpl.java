/**
 * 
 */
package com.shinhan.recon.service.impl;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.recon.core.model.statement.BankStatementCommonTemplate;
import com.shinhan.recon.core.model.statement.BankStatementVietcombankTemplate;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;
import com.shinhan.recon.service.ReconcileBankStatementVietcombankService;

/**
 * @author shds04
 *
 */
@Service("reconcileBankStatementVietcombankService")
@Transactional(readOnly = false, propagation =  Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
public class ReconcileBankStatementVietcombankServiceImpl extends ReconcileBankStatement implements ReconcileBankStatementVietcombankService {

	@Override
	public void processReconcileBankStatementVietcombank(File file, List<TBankCommon> tBankCommons) throws Exception {
		
		/** Step 1: read raw data from excel */
		Map<String, String> glBalance = new HashMap<>();
		TBankCommon bankFileVal = CommonUtil.getBankCommonValByBankCode(file.getName(), tBankCommons);
		
		List<TOmsReconStmtInf> stmtMatchingList = new ArrayList<>(); 
		List<TOmsReconStmtInf> stmtDebitList = new ArrayList<>(); 
		List<TOmsReconStmtInf> stmtUnMatchingList = new ArrayList<>(); 
		List<TOmsReconLmsInf> lmsMatchingList = new ArrayList<>();
		List<TOmsReconLmsInf> lmsUnMatchingList = new ArrayList<>();
		List<TOmsReconSuspenseInf> suspanseList = new ArrayList<>();
		List<TOmsStmtFileMas> tOmsStmtFileMasList = new ArrayList<>();
		List<TOmsReconStmtInf> bankStatementsFinance = new ArrayList<>();
		List<TOmsReconStmtInf> bankStatementsReversal = new ArrayList<>();
		
		List<BankStatementCommonTemplate> bankStatements = getBankStatement(file, bankFileVal, new BankStatementVietcombankTemplate(),glBalance ); 
		
		processLoadReconcileInfo(file, bankFileVal,bankStatements,tOmsStmtFileMasList,stmtMatchingList,stmtUnMatchingList,
								lmsMatchingList,lmsUnMatchingList,suspanseList,bankStatementsFinance,bankStatementsReversal,stmtDebitList);
		
		/** Step 3: process reconcile between LMS and BankStatement */
		TOmsStmtFileMas tOmsStmtFileMas = CommonUtil.getFileMasByFileName(file.getName(), tOmsStmtFileMasList);
		
		processReconcileForSuspense(stmtMatchingList,stmtMatchingList, suspanseList);
		processReconcileForReversal(bankStatementsReversal, stmtMatchingList, lmsMatchingList);
		if(CommonUtil.isNumber(glBalance.get(APIConstant.GL_OPEN_BALANCE)) && CommonUtil.isNumber(glBalance.get(APIConstant.GL_CLOSE_BALANCE))) {
			tOmsStmtFileMas.setOpenBalance(new BigDecimal( StringUtils.isBlank(glBalance.get(APIConstant.GL_OPEN_BALANCE)) ? "0":glBalance.get(APIConstant.GL_OPEN_BALANCE)));
			tOmsStmtFileMas.setCloseBalance(new BigDecimal( StringUtils.isBlank(glBalance.get(APIConstant.GL_CLOSE_BALANCE)) ? "0":glBalance.get(APIConstant.GL_CLOSE_BALANCE)));
		}
		tOmsStmtFileMas.setProcessStatus(APIConstant._RECONCILE_DONE_STATUS);
		/** Step 4: import data into DB */
		processReconcileDataBase(stmtMatchingList, stmtDebitList, stmtUnMatchingList, lmsMatchingList,
									lmsUnMatchingList, suspanseList, bankStatementsFinance, bankStatementsReversal, tOmsStmtFileMas);
		
		/** Step 5: move file to Done folder */
		File destFile = new File(env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_DONE_FOLDER));
		moveFileToDirectory(file, destFile);
		//CommonUtil.moveFileToDirectory(file, destFile, file.getName() + "_" + DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss));

	}

}
