/**
 * 
 */
package com.shinhan.recon.service;

/**
 * @author shds04
 *
 */
public interface ReconcileScanFileProcessService {
	
	public void scanBankStatementFile() throws Exception;

	public void scanBankDisbursalFile() throws Exception;
	
}
