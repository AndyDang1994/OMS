/**
 * 
 */
package com.shinhan.recon.service.impl;

import java.io.File;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.BankTemplateInfo;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;
import com.shinhan.recon.service.ReconcileProcessService;

/**
 * @author shds01
 *
 */
@Service("reconcileProcessService")
@Transactional(readOnly = false, propagation =  Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
public class ReconcileProcessServiceImpl extends AbstractServiceClass implements ReconcileProcessService {

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileProcessService#getFileFromFTPServer()
	 */
	@Override
	public boolean getFileFromFTPServer() throws ServiceRuntimeException {
		Collection<File> files = getStatementFileFromFolderToRecon(env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_PROCESS_FOLDER));
		if(files.size() > 0) {
			return true;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileProcessService#getStatementFileFromFolderToRecon(java.lang.String)
	 */
	@Override
	public Collection<File> getStatementFileFromFolderToRecon(String path) throws ServiceRuntimeException {
		return CommonUtil.getBankStatementFileInFolder(path);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileProcessService#processReconcileBankStatement()
	 */
	@Override
	public void processReconcileBankStatement() throws Exception {
		logger.info("***** Start Reconcile Bank Statement *****");
		Collection<File> bankFileList = null;
		Map<String, Object> statementFileMasMap = new HashMap<String, Object>();
		statementFileMasMap.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_BANKSTATUS_KEY, APIConstant._UPLOAD_FILE_DELETE_STATUS);
		statementFileMasMap.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		Collection<File> files = getStatementFileFromFolderToRecon(env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_PROCESS_FOLDER));
		List<TOmsStmtFileMas> tOmsStmtFileMasList= getRepositoryManagerService()
				.getTomsStmtFileMasManagerRepositoryService().getListUploadByDate(statementFileMasMap);
		List<TBankCommon> listBankCommonVal = getRepositoryManagerService().getUtilityManagerRepositoryService()
				.getBankCommonByBizValue(APIConstant._BANK_COMMON_BIZ_TEMPLATE_VALUE_);

		for (File file : files) {
			TBankCommon bankFileVal = CommonUtil.getBankCommonValByBankCode(file.getName(), listBankCommonVal);
			BankTemplateInfo templateInfo = DTOConverter.getBankTemplateInfo(bankFileVal);
			List<TOmsStmtFileMas> fileMasList  = CommonUtil.getListByBankCode(bankFileVal.getBankAccNuber(),tOmsStmtFileMasList );
			if( ( fileMasList.size() != templateInfo.getFileCnt() && 
				  CommonUtil.getBankUploadedFileCount(files, listBankCommonVal) != templateInfo.getFileCnt()
				) || templateInfo.getFileCnt() == 0	) {
				logger.info("***** " + bankFileVal.getBankName() + " is not enough quantity to process " + "*****");
				continue;
			}
			switch (bankFileVal.getBankCode()) {
				case APIConstant.BANK_STATEMENT_VIETCOMBANK:
					logger.info("***** Start Scan Bank Statement For VietComBank *****");
					
					try {
						getProcessManagerService().getReconcileBankStatementVietcombank().processReconcileBankStatementVietcombank(file, listBankCommonVal);
						logger.info("***** End Scan Bank Statement For VietComBank *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Scan Bank Statement For VietComBank *****");
					}
					
					break;
				case APIConstant.BANK_STATEMENT_ACB:
					logger.info("***** Start Scan Bank Statement For ACB *****");
					try {
						getProcessManagerService().getReconcileBankStatementACB().processReconcileBankStatementACB(file, listBankCommonVal);
						logger.info("***** End Scan Bank Statement For ACB *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Scan Bank Statement For ACB *****");
					}
					break;
				case APIConstant.BANK_STATEMENT_TECHCOMBANK_HSC:
					logger.info("***** Start Scan Bank Statement For TECHCOMBANK_028 *****");
					try {
						getProcessManagerService().getReconcileBankStatementTechcombankHSCService().processReconcileBankStatementTechcombank_028(file, listBankCommonVal);
						logger.info("***** End Scan Bank Statement For TECHCOMBANK_028 *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Scan Bank Statement For TECHCOMBANK_028 *****");
					}
					break;
				case APIConstant.BANK_STATEMENT_TECHCOMBANK_SGD:
					logger.info("***** Start Scan Bank Statement For TECHCOMBANK_022 *****");
					try {
						getProcessManagerService().getReconcileBankStatementTechcombankSGDService().processReconcileBankStatementTechcombank_022(file, listBankCommonVal);
						logger.info("***** End Scan Bank Statement For TECHCOMBANK_022 *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Scan Bank Statement For TECHCOMBANK_022 *****");
					}
					break;
				case APIConstant.BANK_STATEMENT_SACOMBANK:
					logger.info("***** Start Scan Bank Statement For SACOMBANK *****");
					try {
						getProcessManagerService().getReconcileBankStatementSacombankService().processReconcileBankStatementSacombank(file, listBankCommonVal);
						logger.info("***** End Scan Bank Statement For SACOMBANK *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Scan Bank Statement For SACOMBANK *****");
					}
					break;
				case APIConstant.BANK_STATEMENT_AGRIBANK:
					logger.info("***** Start Scan Bank Statement For AGRIBANK *****");
					try {
						getProcessManagerService().getReconcileBankStatementAgribankService().processReconcileBankStatementAgribank(file, listBankCommonVal);
						logger.info("***** End Scan Bank Statement For AGRIBANK *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Scan Bank Statement For AGRIBANK *****");
					}
					break;
				case APIConstant.BANK_STATEMENT_OCB_AD:
					logger.info("***** Start Scan Bank Statement For OCB *****");
					bankFileList = CommonUtil.getListFileOfBank(files,listBankCommonVal,bankFileVal.getBankAccNuber());
					
					try {
						getProcessManagerService().getReconcileBankStatementOCBService().processReconcileBankStatementOCB(bankFileList, listBankCommonVal);
						logger.info("***** End Scan Bank Statement For OCB *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Scan Bank Statement For OCB *****");
					}
					break;
				case APIConstant.BANK_STATEMENT_VIETTINBANK_STMT:
					logger.info("***** Start Scan Bank Statement For VietinBank *****");
					bankFileList = CommonUtil.getListFileOfBank(files,listBankCommonVal,bankFileVal.getBankAccNuber());
					
					try {
						getProcessManagerService().getReconcileBankStatementViettinService().processReconcileBankStatementViettinbank(bankFileList, listBankCommonVal);;
						logger.info("***** End Scan Bank Statement For VietinBank *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Scan Bank Statement For VietinBank *****");
					}
					break;
				case APIConstant.NON_BANK_STATEMENT_VIETTEL:
					logger.info("***** Start Scan Bank Statement For Viettel *****");
					bankFileList = CommonUtil.getListFileOfBank(files,listBankCommonVal,bankFileVal.getBankAccNuber());
					
					try {
						getProcessManagerService().getReconcileBankStatementViettelService().processReconcileBankStatementViettel(bankFileList, listBankCommonVal);;
						logger.info("***** End Scan Bank Statement For Viettel *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Scan Bank Statement For Viettel *****");
					}
					break;
				case APIConstant.NON_BANK_STATEMENT_VNPOST:
					logger.info("***** Start Scan Bank Statement For VNPost *****");
					bankFileList = CommonUtil.getListFileOfBank(files,listBankCommonVal,bankFileVal.getBankAccNuber());
					
					try {
						getProcessManagerService().getReconcileBankStatementVnpostService().processReconcileBankStatementVnpost(bankFileList, listBankCommonVal);;
						logger.info("***** End Scan Bank Statement For VNPost *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Scan Bank Statement For VNPost *****");
					}
					break;
				case APIConstant.NON_BANK_STATEMENT_PAYOO:
					logger.info("***** Start Scan Bank Statement For Payoo *****");
					bankFileList = CommonUtil.getListFileOfBank(files,listBankCommonVal,bankFileVal.getBankAccNuber());
					
					try {
						getProcessManagerService().getReconcileBankStatementPayooService().processReconcileBankStatementPayoo(bankFileList, listBankCommonVal);;
						logger.info("***** End Scan Bank Statement For Payoo *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Scan Bank Statement For Payoo *****");
					}
					break;
				case APIConstant.NON_BANK_STATEMENT_MOMO:
					logger.info("***** Start Scan Bank Statement For Momo *****");
					bankFileList = CommonUtil.getListFileOfBank(files,listBankCommonVal,bankFileVal.getBankAccNuber());
					
					try {
						getProcessManagerService().getReconcileBankStatementMomoService().processReconcileBankStatementMomo(bankFileList, listBankCommonVal);;
						logger.info("***** End Scan Bank Statement For Momo *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Scan Bank Statement For Momo *****");
					}
					break;
				case APIConstant.NON_BANK_STATEMENT_AIRPAY:
					logger.info("***** Start Scan Bank Statement For Airpay *****");
					bankFileList = CommonUtil.getListFileOfBank(files,listBankCommonVal,bankFileVal.getBankAccNuber());
					
					try {
						getProcessManagerService().getReconcileBankStatementAirpayService().processReconcileBankStatementMomoAirpay(bankFileList, listBankCommonVal);;
						logger.info("***** End Scan Bank Statement For Airpay *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Scan Bank Statement For Airpay *****");
					}
					break;
				case APIConstant.NON_BANK_STATEMENT_NAPAS:
					logger.info("***** Start Scan Bank Statement For Napas *****");
					bankFileList = CommonUtil.getListFileOfBank(files,listBankCommonVal,bankFileVal.getBankAccNuber());
					
					try {
						getProcessManagerService().getReconcileBankStatementNapasService().processReconcileBankStatementNapas(bankFileList, listBankCommonVal);;
						logger.info("***** End Scan Bank Statement For Napas *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Scan Bank Statement For Napas *****");
					}
					break;
				default :
					logger.info("***** Start Scan Bank Statement For Shinhan Finance *****");
					try {
						getProcessManagerService().getReconcileBankStatementShinhanFinanceService().processReconcileBankStatementShinhanFinance(file, listBankCommonVal);
						logger.info("***** End Scan Bank Statement For Shinhan Finance *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Scan Bank Statement For Shinhan Finance *****");
					}
					break;
			}

		}
		logger.info("***** End Reconcile Bank Statement *****");
	}

}














