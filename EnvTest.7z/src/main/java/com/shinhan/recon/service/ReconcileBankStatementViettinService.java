/**
 * 
 */
package com.shinhan.recon.service;

import java.io.File;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.repository.entity.TBankCommon;

/**
 * @author shds04
 *
 */
public interface ReconcileBankStatementViettinService {
	public void getMapRefToAudit(Collection<File> files, List<TBankCommon> tBankCommons,List<Map<String, String>> glBaMap) throws Exception;
	
	public void processReconcileBankStatementViettinbank(Collection<File> files, List<TBankCommon> tBankCommons) throws Exception;
	
	public void ReconcileBankStatementViettinbank(File files, List<TBankCommon> tBankCommons,List<Map<String, String>> mapRefToAudit ) throws Exception;

	public void ReconcileBankReconViettinbank(File files, List<TBankCommon> tBankCommons,List<Map<String, String>> mapRefToAudit) throws Exception;

}
