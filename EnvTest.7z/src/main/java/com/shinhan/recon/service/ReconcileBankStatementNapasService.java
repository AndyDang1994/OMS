/**
 * 
 */
package com.shinhan.recon.service;

import java.io.File;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.shinhan.recon.repository.entity.TBankCommon;

/**
 * @author shds04
 *
 */
public interface ReconcileBankStatementNapasService {
	
	public void processReconcileBankStatementNapas(Collection<File> files, List<TBankCommon> tBankCommons) throws Exception;
	
	public void ReconcileBankStatementNapas(File files, List<TBankCommon> tBankCommons,List<Map<String, String>> mapRefToAudit ) throws Exception;

	public void ReconcileBankReconNapas(File files, List<TBankCommon> tBankCommons,List<Map<String, String>> mapRefToAudit) throws Exception;

}
