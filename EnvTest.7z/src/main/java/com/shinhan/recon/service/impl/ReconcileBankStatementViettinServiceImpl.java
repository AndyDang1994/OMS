/**
 * 
 */
package com.shinhan.recon.service.impl;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.BankTemplateInfo;
import com.shinhan.recon.core.model.statement.BankStatementCommonTemplate;
import com.shinhan.recon.core.model.statement.BankStatementViettinBankReconTemplate;
import com.shinhan.recon.core.model.statement.BankStatementViettinBankStatementTemplate;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.core.util.ReadFromExcel;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;
import com.shinhan.recon.service.ReconcileBankStatementViettinService;

/**
 * @author shds04
 *
 */
@Service("reconcileBankStatementViettinService")
@Transactional(readOnly = false, propagation =  Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
public class ReconcileBankStatementViettinServiceImpl extends ReconcileBankStatement implements ReconcileBankStatementViettinService {

	@Override
	public void getMapRefToAudit(Collection<File> files, List<TBankCommon> tBankCommons,List<Map<String, String>> mapRefToAudit) throws Exception {
		ArrayList<Map> lsArrMapObjectStmt = new ArrayList();
		ArrayList<Map> lsArrMapObjectRecon = new ArrayList();
		for (File file : files) { 
			ReadFromExcel rw = new ReadFromExcel(file.getAbsolutePath());
			TBankCommon bankFileVal = CommonUtil.getBankCommonValByBankCode(file.getName(), tBankCommons);
			BankTemplateInfo tmBankTemplateInfo = DTOConverter.getBankTemplateInfo(bankFileVal);
			switch (bankFileVal.getBankCode()) {
				case APIConstant.BANK_STATEMENT_VIETTINBANK_STMT:
					lsArrMapObjectStmt = (ArrayList<Map>) rw.readDataFromExcel(tmBankTemplateInfo.getSheetIndex(), tmBankTemplateInfo.getFromRow(), tmBankTemplateInfo.getHeaderRow());
					break;
				case APIConstant.BANK_STATEMENT_VIETTINBANK_RECON:
					lsArrMapObjectRecon = (ArrayList<Map>) rw.readDataFromExcel(tmBankTemplateInfo.getSheetIndex(), tmBankTemplateInfo.getFromRow(), tmBankTemplateInfo.getHeaderRow());
					break;
			}
		}
		for (Map recon : lsArrMapObjectRecon) {
			for (Map stmt : lsArrMapObjectStmt) {
				if( String.valueOf(stmt.get("Số giao dịch/ Transaction number")).equals(String.valueOf(recon.get("Số giao dịch/ Transaction number"))) ) {
					Map<String, String> map = new HashMap<>();
					map.put(String.valueOf(stmt.get("Số giao dịch/ Transaction number")), String.valueOf(recon.get("Audit_No")));
					mapRefToAudit.add(map);
				}
			}
		}
	}

	@Override
	public void processReconcileBankStatementViettinbank(Collection<File> files, List<TBankCommon> listBankCommonVal) throws Exception {
		List<Map<String, String>> mapRefToAudit =  new ArrayList<>();
		getMapRefToAudit(files, listBankCommonVal, mapRefToAudit);
		for (File file : files) {
			TBankCommon bankFileVal = CommonUtil.getBankCommonValByBankCode(file.getName(), listBankCommonVal);
		
			switch (bankFileVal.getBankCode()) {
				case APIConstant.BANK_STATEMENT_VIETTINBANK_STMT:
					logger.info("***** Start Scan Bank Statement For Vietin Statement *****");
					ReconcileBankStatementViettinbank(file, listBankCommonVal,mapRefToAudit);
					logger.info("***** End Scan Bank Statement For Vietin Statement *****");
					break;
				case APIConstant.BANK_STATEMENT_VIETTINBANK_RECON:
					logger.info("***** Start Scan Bank Statement For Vietin Recon *****");
					ReconcileBankReconViettinbank(file, listBankCommonVal,mapRefToAudit);
					logger.info("***** End Scan Bank Statement For Vietin Recon *****");
					break;
				
			}
			
		}
		for (File file : files) {
			File destFile = new File(env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_DONE_FOLDER));
			moveFileToDirectory(file, destFile);
			//CommonUtil.moveFileToDirectory(file, destFile, file.getName() + "_" + DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss));
		}
	}

	@Override
	public void ReconcileBankStatementViettinbank(File file, List<TBankCommon> tBankCommons, List<Map<String, String>> mapRefToAudit) throws Exception {
		/** Step 1: read raw data from excel */
		Map<String, String> glBalance = new HashMap<>();
		TBankCommon bankFileVal = CommonUtil.getBankCommonValByBankCode(file.getName(), tBankCommons);
		
		List<TOmsReconStmtInf> stmtMatchingList = new ArrayList<>(); 
		List<TOmsReconStmtInf> stmtDebitList = new ArrayList<>(); 
		List<TOmsReconStmtInf> stmtUnMatchingList = new ArrayList<>(); 
		List<TOmsReconLmsInf> lmsMatchingList = new ArrayList<>();
		List<TOmsReconLmsInf> lmsUnMatchingList = new ArrayList<>();
		List<TOmsReconSuspenseInf> suspanseList = new ArrayList<>();
		List<TOmsStmtFileMas> tOmsStmtFileMasList = new ArrayList<>();
		List<TOmsReconStmtInf> bankStatementsFinance = new ArrayList<>();
		List<TOmsReconStmtInf> bankStatementsReversal = new ArrayList<>();
		
		List<BankStatementCommonTemplate> bankStatements = getBankStatement(file, bankFileVal, new BankStatementViettinBankStatementTemplate(),glBalance ); 
		mapRefToAudit.stream().forEach(d->{
			bankStatements.stream().forEach(e->{
				if(d.containsKey(e.getRef())) {
					e.setRef(d.get(e.getRef()));
				}
			});
		});
		
		processLoadReconcileInfo(file, bankFileVal,bankStatements,tOmsStmtFileMasList,stmtMatchingList,stmtUnMatchingList,
								lmsMatchingList,lmsUnMatchingList,suspanseList,bankStatementsFinance,bankStatementsReversal,stmtDebitList);
		
		/** Step 3: process reconcile between LMS and BankStatement */
		TOmsStmtFileMas tOmsStmtFileMas = CommonUtil.getFileMasByFileName(file.getName(), tOmsStmtFileMasList);
		
		processReconcileForSuspense(stmtMatchingList,stmtMatchingList, suspanseList);
		processReconcileForReversal(bankStatementsReversal, stmtMatchingList, lmsMatchingList);
		if(CommonUtil.isNumber(glBalance.get(APIConstant.GL_OPEN_BALANCE)) && CommonUtil.isNumber(glBalance.get(APIConstant.GL_CLOSE_BALANCE))) {
			tOmsStmtFileMas.setOpenBalance(new BigDecimal( StringUtils.isBlank(glBalance.get(APIConstant.GL_OPEN_BALANCE)) ? "0":glBalance.get(APIConstant.GL_OPEN_BALANCE)));
			tOmsStmtFileMas.setCloseBalance(new BigDecimal( StringUtils.isBlank(glBalance.get(APIConstant.GL_CLOSE_BALANCE)) ? "0":glBalance.get(APIConstant.GL_CLOSE_BALANCE)));
		}
		tOmsStmtFileMas.setProcessStatus(APIConstant._RECONCILE_DONE_STATUS);
		/** Step 4: import data into DB */
		processReconcileDataBase(stmtMatchingList, stmtDebitList, stmtUnMatchingList, lmsMatchingList,
				lmsUnMatchingList, suspanseList, bankStatementsFinance, bankStatementsReversal, tOmsStmtFileMas);
	}

	@Override
	public void ReconcileBankReconViettinbank(File file, List<TBankCommon> tBankCommons,List<Map<String, String>> mapRefToAudit) throws Exception {
		/** Step 1: read raw data from excel */
		Map<String, String> glBalance = new HashMap<>();
		TBankCommon bankFileVal = CommonUtil.getBankCommonValByBankCode(file.getName(), tBankCommons);
		
		List<TOmsReconStmtInf> stmtMatchingList = new ArrayList<>(); 
		List<TOmsReconStmtInf> stmtDebitList = new ArrayList<>(); 
		List<TOmsReconStmtInf> stmtUnMatchingList = new ArrayList<>(); 
		List<TOmsReconLmsInf> lmsMatchingList = new ArrayList<>();
		List<TOmsReconLmsInf> lmsUnMatchingList = new ArrayList<>();
		List<TOmsReconSuspenseInf> suspanseList = new ArrayList<>();
		List<TOmsStmtFileMas> tOmsStmtFileMasList = new ArrayList<>();
		List<TOmsReconStmtInf> bankStatementsFinance = new ArrayList<>();
		List<TOmsReconStmtInf> bankStatementsReversal = new ArrayList<>();
		
		List<BankStatementCommonTemplate> bankStatements = getBankStatement(file, bankFileVal, new BankStatementViettinBankReconTemplate(),glBalance ); 
		List<BankStatementCommonTemplate> removedbankStatements = new ArrayList<>();
		mapRefToAudit.stream().forEach(d->{
			bankStatements.stream().forEach(e->{
				if(d.containsValue(e.getRef())) {
					removedbankStatements.add(e);
				}
			});
		});
		bankStatements.removeAll(removedbankStatements);
		processLoadReconcileInfo(file, bankFileVal,bankStatements,tOmsStmtFileMasList,stmtMatchingList,stmtUnMatchingList,
								lmsMatchingList,lmsUnMatchingList,suspanseList,bankStatementsFinance,bankStatementsReversal,stmtDebitList);
		
		/** Step 3: process reconcile between LMS and BankStatement */
		TOmsStmtFileMas tOmsStmtFileMas = CommonUtil.getFileMasByFileName(file.getName(), tOmsStmtFileMasList);
		
		processReconcileForSuspense(stmtMatchingList,stmtMatchingList, suspanseList);
		processReconcileForReversal(bankStatementsReversal, stmtMatchingList, lmsMatchingList);
		if(CommonUtil.isNumber(glBalance.get(APIConstant.GL_OPEN_BALANCE)) && CommonUtil.isNumber(glBalance.get(APIConstant.GL_CLOSE_BALANCE))) {
			tOmsStmtFileMas.setOpenBalance(new BigDecimal( StringUtils.isBlank(glBalance.get(APIConstant.GL_OPEN_BALANCE)) ? "0":glBalance.get(APIConstant.GL_OPEN_BALANCE)));
			tOmsStmtFileMas.setCloseBalance(new BigDecimal( StringUtils.isBlank(glBalance.get(APIConstant.GL_CLOSE_BALANCE)) ? "0":glBalance.get(APIConstant.GL_CLOSE_BALANCE)));
		}
		tOmsStmtFileMas.setProcessStatus(APIConstant._RECONCILE_DONE_STATUS);
		/** Step 4: import data into DB */
		processReconcileDataBase(stmtMatchingList, stmtDebitList, stmtUnMatchingList, lmsMatchingList,
				lmsUnMatchingList, suspanseList, bankStatementsFinance, bankStatementsReversal, tOmsStmtFileMas);
	}
	
}
