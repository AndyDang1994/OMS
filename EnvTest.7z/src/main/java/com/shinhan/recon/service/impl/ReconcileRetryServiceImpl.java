/**
 * 
 */
package com.shinhan.recon.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;
import com.shinhan.recon.service.ReconcileRetryService;

/**
 * @author shds04
 *
 */
@Service("reconcileRetryService")
@Transactional(readOnly = false, propagation =  Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
public class ReconcileRetryServiceImpl extends AbstractServiceClass implements ReconcileRetryService {

	@Override
	public void retryProcess() throws BaseException {
		Map<String, Object> statementFileMasMap = new HashedMap<String, Object>();
		statementFileMasMap.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_BANKSTATUS_KEY, APIConstant._UPLOAD_FILE_PENDING_DELETE_STATUS);
		statementFileMasMap.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		List<TOmsStmtFileMas> tOmsStmtFileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getListUploadByDateAndStatus(statementFileMasMap);
		if(tOmsStmtFileMas.size() <1 ) {
			logger.info("**** No record to retry ****");
		}else {
			for (TOmsStmtFileMas fileMas : tOmsStmtFileMas) {
				
				Map<String, Object > inputParams =  new HashMap<>();
				inputParams.put(APIConstant.TRX_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
				inputParams.put(APIConstant._BANK_CODE_KEY, fileMas.getBankCode());
				String userName =  fileMas.getUploadUser();
				List<TOmsReconLmsInf> tOmsReconLmsInfs = new ArrayList<>();
				List<TOmsReconStmtInf> tOmsReconStmtInfs = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getListTrxByBankcodeAndDate(inputParams);
				List<TOmsReconSuspenseInf> tOmsReconSuspenseInfs = getRepositoryManagerService().gettOmsReconSuspInfManagerRepositoryService().getListTrxByBankcodeAndDate(inputParams);
				for (TOmsReconStmtInf tOmsReconStmtInf : tOmsReconStmtInfs) {
					Map<String, Object> map = new HashMap<>();
					map.put(APIConstant._BANK_CODE_KEY,tOmsReconStmtInf.getBankCode());
					map.put(APIConstant._REF_NO_KEY,tOmsReconStmtInf.getRefNo());
					map.put(APIConstant._DR_AMT_KEY,tOmsReconStmtInf.getDrAmt());
					map.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
					List<TOmsReconLmsInf> lmsInfs = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getListLmsTrxMatchWithStmtRef(map);
					tOmsReconLmsInfs.addAll(lmsInfs);
					tOmsReconStmtInf.setStatusCode(APIConstant._BANK_STATEMENT_DELETED_STATUS);
					DTOConverter.setUtilityTOmsReconStmtInf(tOmsReconStmtInf, null, null, userName,
							DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
				}
				for (TOmsReconSuspenseInf tOmsReconSuspenseInf : tOmsReconSuspenseInfs) {
					tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_DELETE_STATUS);
					DTOConverter.setUtilityTOmsReconSuspenseInf(tOmsReconSuspenseInf, null, null,userName, 
							DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
				}
				for (TOmsReconLmsInf tOmsReconLmsInf : tOmsReconLmsInfs) {
					tOmsReconLmsInf.setStatusCode(APIConstant.LMS_UPLOAD_PENDING);
					tOmsReconLmsInf.setRefID("");
				}
				fileMas.setFileStatus(APIConstant._UPLOAD_FILE_DELETE_STATUS);
				
				logger.info("***** Start delete OMS bank statement *****");
				updateListTOmsStatementInfToDB(tOmsReconStmtInfs, userName);
				logger.info("***** End delete OMS bank statement *****");
				logger.info("***** Start delete Suspense bank statement *****");
				updateListTOmsReconSuspInfToDB(tOmsReconSuspenseInfs, userName);
				logger.info("***** End delete Suspense bank statement *****");
				logger.info("***** Start delete LMS bank statement *****");
				updateListTReconLmsInfToDB(tOmsReconLmsInfs, userName);
				logger.info("***** End delete LMS bank statement *****");
			}
			logger.info("***** Start delete Uploaded File Mas *****");
			updateTOmsStmtFileListToDB(tOmsStmtFileMas, APIConstant._USERNAME_BATCHJOB);
			logger.info("***** End delete Uploaded File Mas *****");
		}
			
	}

}
