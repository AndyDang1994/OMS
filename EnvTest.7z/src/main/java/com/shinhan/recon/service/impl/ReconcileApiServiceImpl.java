/**
 * 
 */
package com.shinhan.recon.service.impl;

import java.io.File;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.recon.common.AbstractBasicCommonClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.recon.core.exception.UnauthorizedException;
import com.shinhan.recon.core.model.BankStatemenTrxInfo;
import com.shinhan.recon.core.model.BankStatementFile;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.core.model.LmsTrxInfo;
import com.shinhan.recon.core.model.ReconcileCommonStatementInfo;
import com.shinhan.recon.core.model.UserInfo;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TMetadata;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;
import com.shinhan.recon.service.ReconcileApiService;

/**
 * @author shds01
 *
 */
@Service("reconcileApiService")
@Transactional(readOnly = false, propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
public class ReconcileApiServiceImpl extends AbstractBasicCommonClass implements ReconcileApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#generateUserToken(java.util.Map)
	 */
	@Override
	public String generateUserToken(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		UserInfo userInfo = (UserInfo) CommonUtil.toPojo(document, UserInfo.class);
		
		if(StringUtils.isBlank(userInfo.getUserName()) || StringUtils.isBlank(userInfo.getPassword())){
			throw new UnauthorizedException(env.getProperty("MSG_121"));
		} else if ( (env.getProperty(APIConstant.SHINHAN_USERNAME_KEY).equals(userInfo.getUserName()) == false 
				|| env.getProperty(APIConstant.SHINHAN_PASSWORD_KEY).equals(userInfo.getPassword()) == false ) &&
				(userInfo.getUserName().equals("DRNHS11") || env.getProperty(APIConstant.SHINHAN_PASSWORD_KEY).equals(userInfo.getPassword()) == false ) &&
				(userInfo.getUserName().equals("DRNHS1") || env.getProperty(APIConstant.SHINHAN_PASSWORD_KEY).equals(userInfo.getPassword()) == false) &&
				(userInfo.getUserName().equals("DRCTV1") || env.getProperty(APIConstant.SHINHAN_PASSWORD_KEY).equals(userInfo.getPassword()) == false)){
			throw new UnauthorizedException(env.getProperty("MSG_121"));
		}
		
		//Generate token
		String token = CommonUtil.getCryptUser(env, userInfo.getUserName().toUpperCase());
		return token;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getAllMetadata(java.util.Map, java.lang.String)
	 */
	@Override
	public List<TMetadata> getAllMetadata(Map<String, Object> inputParams, String lookupCode) throws BaseException {
		List<TMetadata> list = getRepositoryManagerService().getUtilityManagerRepositoryService().getAllMetadata(inputParams);
		return list;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getListStmtFileMasByDate(java.util.Map)
	 */
	@Override
	public List<BankStatementFile> getListStmtFileMasByDate(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getListStmtFileMasByDate(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#createStmtFileMas(java.util.Map)
	 */
	@Override
	public TOmsStmtFileMas createStmtFileMas(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		TOmsStmtFileMas mas = (TOmsStmtFileMas) CommonUtil.toPojo(document, TOmsStmtFileMas.class);
		
		//Check validation and set Utility
		DTOConverter.setUtilityTOmsStmtFileMas(mas, userName, new Date(), userName, new Date());
		
		return createTOmsStmtFileMasToDB(mas, userName);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getOneStmtFileMas(java.util.Map)
	 */
	@Override
	public TOmsStmtFileMas getOneStmtFileMas(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getOne(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#updateStmtFileMas(java.util.Map)
	 */
	@Override
	public TOmsStmtFileMas updateStmtFileMas(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		TOmsStmtFileMas mas = (TOmsStmtFileMas) CommonUtil.toPojo(document, TOmsStmtFileMas.class);
		
		//Check validation and set Utility
		DTOConverter.setUtilityTOmsStmtFileMas(mas, userName, new Date(), userName, new Date());
		return updateTOmsStmtFileMasToDB(mas, userName);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getListTOmsReconLmsInfByDate(java.util.Map)
	 */
	@Override
	public List<TOmsReconLmsInf> getListTOmsReconLmsInfByDate(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getListLmsTrxByDate(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#createTOmsReconLmsInf(java.util.Map)
	 */
	@Override
	public TOmsReconLmsInf createTOmsReconLmsInf(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		TOmsReconLmsInf inf = (TOmsReconLmsInf) CommonUtil.toPojo(document, TOmsReconLmsInf.class);
		
		//Check validation and set Utility
		DTOConverter.setUtilityTOmsReconLmsInf(inf, userName, new Date(), userName, new Date());
		
		return createTOmsReconLmsInfToDB(inf, userName);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getOneTOmsReconLmsInf(java.util.Map)
	 */
	@Override
	public TOmsReconLmsInf getOneTOmsReconLmsInf(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getOne(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#updateTOmsReconLmsInf(java.util.Map)
	 */
	@Override
	public TOmsReconLmsInf updateTOmsReconLmsInf(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		TOmsReconLmsInf inf = (TOmsReconLmsInf) CommonUtil.toPojo(document, TOmsReconLmsInf.class);
		
		//Check validation and set Utility
		DTOConverter.setUtilityTOmsReconLmsInf(inf, userName, new Date(), userName, new Date());
		return updateTOmsReconLmsInfToDB(inf, userName);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getListTOmsReconStmtInfByDate(java.util.Map)
	 */
	@Override
	public List<TOmsReconStmtInf> getListTOmsReconStmtInfByDate(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getListTrxByDate(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#createTOmsReconStmtInf(java.util.Map)
	 */
	@Override
	public TOmsReconStmtInf createTOmsReconStmtInf(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		TOmsReconStmtInf inf = (TOmsReconStmtInf) CommonUtil.toPojo(document, TOmsReconStmtInf.class);
		
		//Check validation and set Utility
		DTOConverter.setUtilityTOmsReconStmtInf(inf, userName, new Date(), userName, new Date());
		
		return createTOmsReconStmtInfToDB(inf, userName);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getOneTOmsReconStmtInf(java.util.Map)
	 */
	@Override
	public TOmsReconStmtInf getOneTOmsReconStmtInf(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getOne(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#updateTOmsReconStmtInf(java.util.Map)
	 */
	@Override
	public TOmsReconStmtInf updateTOmsReconStmtInf(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		TOmsReconStmtInf inf = (TOmsReconStmtInf) CommonUtil.toPojo(document, TOmsReconStmtInf.class);
		
		//Check validation and set Utility
		DTOConverter.setUtilityTOmsReconStmtInf(inf, userName, new Date(), userName, new Date());
		return updateTOmsReconStmtInfToDB(inf, userName);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#countTotalBankStatementTrxByDate(java.util.Map)
	 */
	@Override
	public BigDecimal countTotalBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().countTotalBankStatementTrxByDate(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getListBankStatementTrxByDate(java.util.Map)
	 */
	@Override
	public List<BankStatementLmsTrxInfo> getListBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getListBankStatementTrxByDate(inputParams);
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#updateListBankStatementTrxByDate(java.util.Map)
	 */
	@Override
	public List<BankStatementLmsTrxInfo> updateListBankStatementTrxByDate(Map<String, Object> inputParams)
			throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		boolean _isUnmatch = (boolean) inputParams.get(APIConstant.FLAG);
		HashMap<String, Object> rs = new HashMap<String, Object>();
		List<BankStatementLmsTrxInfo> lst = CommonUtil.toListPojo(document, BankStatementLmsTrxInfo.class);
		//Check validation
		
		if(_isUnmatch) {
			//For Unmatch
			rs = getValidationManagerService().checkValidationUpdateToUnmatch(lst, userName);
		}else {
			//For Match
			rs = getValidationManagerService().checkValidationUpdateToMatch(lst, userName);
		}
		boolean flag = (boolean) rs.get(APIConstant.RESULT);
		
		if(!flag) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_005"));
		}
		updateToReconcileTrx(rs);
		
		return lst;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#countTotalUnMatchLMSTrxByDate(java.util.Map)
	 */
	@Override
	public BigDecimal countTotalUnMatchLMSTrxByDate(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().countTotalUnMatchLMSTrxByDate(inputParams);
	}
	
	@Override
	public List<LmsTrxInfo> getUnmatchListLMSTrxByDate(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getUnmatchListLMSTrxByDate(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#setStatusUnmatchListLMS(java.util.Map)
	 */
	@Override
	public List<LmsTrxInfo> setStatusUnmatchListLMS(Map<String, Object> inputParams) throws BaseException {

		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		List<LmsTrxInfo> lst = CommonUtil.toListPojo(document, LmsTrxInfo.class);
		//Check validation
		HashMap<String, Object> rs = getValidationManagerService().checkValidationUpdateStatusLMS(lst, userName);
		boolean flag = (boolean) rs.get(APIConstant.RESULT);
		if(!flag) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_005"));
		}
		updateStatusUnmatchListLMS(rs);
		
		return lst;
	
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#countTotalUnMatchBankStatementTrxByDate(java.util.Map)
	 */
	@Override
	public BigDecimal countTotalUnMatchBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException {
		return getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().countTotalUnmatchBankStatementTrxByDate(inputParams);
	}
	
	@Override
	public List<BankStatemenTrxInfo> getUnmatchListBankStatementTrxByDate(Map<String, Object> inputParams)
			throws BaseException {
		return getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getUnmatchListBankStatementTrxByDate(inputParams);
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#setStatusUnmatchListBankStatement(java.util.Map)
	 */
	@Override
	public List<BankStatemenTrxInfo> setStatusUnmatchListBankStatement(Map<String, Object> inputParams)
			throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String userName = inputParams.get(APIConstant.USERNAME_KEY).toString();
		
		List<BankStatemenTrxInfo> lst = CommonUtil.toListPojo(document, BankStatemenTrxInfo.class);
		//Check validation
		HashMap<String, Object> rs = getValidationManagerService().checkValidationUpdateStatusBankStatement(lst, userName);
		boolean flag = (boolean) rs.get(APIConstant.RESULT);
		if(!flag) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_005"));
		}
		updateStatusUnmatchListBankStatement(rs);
		
		return lst;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#getBankStatementCommonInforByDate(java.util.Map)
	 */
	@Override
	public ReconcileCommonStatementInfo getBankStatementCommonInforByDate(Map<String, Object> inputParams) throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		ReconcileCommonStatementInfo commonInfo = new ReconcileCommonStatementInfo();
		
		/**Matching Data*/
		//Sum total balance trx which matching
		commonInfo.setTotalRecordMatching(getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().sumDrAndCrMatchListBankStatementTrxByDateAndBankCode(inputParams));
		
		/**UnMatching Data*/
		//Sum total balance trx which un-matching
		BankStatementLmsTrxInfo sumRecordBank = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().sumDrAndCrUnMatchListBankStatementTrxByDateAndBankCode(inputParams);
		
		//Sum the debit amount and credit amount of un-matching trx LMS
		BankStatementLmsTrxInfo sumRecordLMS = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().sumDrAndCrUnMatchListLMSTrxByDateAndBankCode(inputParams);
		
		commonInfo.setTotalRecordUnMatching(new BankStatementLmsTrxInfo(sumRecordBank.getBankStatemenTrxInfo().getDrAmt(), sumRecordBank.getBankStatemenTrxInfo().getCrAmt()
				, sumRecordLMS.getLmsTrxInfo().getDrAmt(), sumRecordLMS.getLmsTrxInfo().getCrAmt()));
		/**Grand Data*/
		commonInfo.setTotalRecordGrandData(DTOConverter.getGrandBalanceReconcileOfLMSAndBankStatement
				(commonInfo.getTotalRecordMatching().getLmsTrxInfo().getDrAmt(), commonInfo.getTotalRecordMatching().getLmsTrxInfo().getCrAmt(),
					commonInfo.getTotalRecordMatching().getBankStatemenTrxInfo().getDrAmt(), commonInfo.getTotalRecordMatching().getBankStatemenTrxInfo().getCrAmt(),
					sumRecordLMS.getLmsTrxInfo().getDrAmt(), sumRecordLMS.getLmsTrxInfo().getCrAmt(), 
					sumRecordBank.getBankStatemenTrxInfo().getDrAmt(), sumRecordBank.getBankStatemenTrxInfo().getCrAmt()));
		
		/**Header Data*/
		BankStatementFile headerData = DTOConverter.transferDataTBankCommonToBankStatementFile(bankCommon);
		BigDecimal openBal = getRepositoryManagerService().getUtilityManagerRepositoryService().getOpenBalanceOfBankCodeByDate(inputParams);
		BigDecimal closeBal = openBal.add(
				commonInfo.getTotalRecordGrandData().getBankStatemenTrxInfo().getDrAmt()
					.subtract(commonInfo.getTotalRecordGrandData().getBankStatemenTrxInfo().getCrAmt()));
		
		headerData.setOpenBalance(openBal);
		headerData.setCloseBalance(closeBal);
		commonInfo.setHeaderData(headerData);
		
		return commonInfo;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.service.ReconcileApiService#exportReconcileReport(java.util.Map)
	 */
	@Override
	public File exportReconcileReport(Map<String, Object> inputParams) throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		if (bankCommon == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		} else {
			inputParams.put(APIConstant._BANK_NAME_KEY, bankCommon.getBankName());
		}
		
		if(APIConstant.YES_KEY.equalsIgnoreCase(bankCommon.getIsRepaymentYn())) {
			// For Re-payment report reconcile
			if(APIConstant.YES_KEY.equalsIgnoreCase(bankCommon.getIsBankYn())) {
				return getProcessManagerService().getReconcileExportReportService().exportReconcileRepaymentReportForBank(inputParams);
			}
			return getProcessManagerService().getReconcileExportReportService().exportReconcileRepaymentReportForNonBank(inputParams);
		} else {
			// For Disbursal report reconcile
			return getProcessManagerService().getReconcileExportReportService().exportReconcileDisbursalReport(inputParams);
		}
	}

	@Override
	public boolean retryReconcileByBankcode(Map<String, Object> inputParams) throws BaseException {
		String userName =  inputParams.get(APIConstant.USERNAME_KEY).toString();
		String bankCode = inputParams.get(APIConstant.UPLOAD_BANKCODE_KEY).toString();
		inputParams.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		TBankCommon bankCommon = getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankAccNum(bankCode);
		if (bankCommon == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_003"), bankCode));
		}
		List<TOmsStmtFileMas> fileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getListUploadByDateAndBankCode(inputParams);
		
		for (TOmsStmtFileMas tOmsStmtFileMas : fileMas) {
			tOmsStmtFileMas.setFileStatus(APIConstant._UPLOAD_FILE_PENDING_DELETE_STATUS);
			tOmsStmtFileMas.setUploadUser(userName);
		}
		return updateTOmsStmtFileListToDB(fileMas, userName);
	}

}
