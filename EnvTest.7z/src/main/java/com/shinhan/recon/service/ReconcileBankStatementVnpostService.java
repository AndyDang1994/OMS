/**
 * 
 */
package com.shinhan.recon.service;

import java.io.File;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.shinhan.recon.repository.entity.TBankCommon;

/**
 * @author shds04
 *
 */
public interface ReconcileBankStatementVnpostService {

	public void processReconcileBankStatementVnpost(Collection<File> files, List<TBankCommon> tBankCommons) throws Exception;
	
	public void ReconcileBankStatementVnpost(File files, List<TBankCommon> tBankCommons,List<Map<String, String>> mapRefToAudit ) throws Exception;

	public void ReconcileBankReconVnpost(File files, List<TBankCommon> tBankCommons,List<Map<String, String>> mapRefToAudit) throws Exception;

}
