/**
 * 
 */
package com.shinhan.recon.service;

import java.io.File;
import java.util.List;

import com.shinhan.recon.repository.entity.TBankCommon;

/**
 * @author shds04
 *
 */
public interface ReconcileBankStatementShinhanFinanceService {

	public void processReconcileBankStatementShinhanFinance(File file, List<TBankCommon> tBankCommons) throws Exception;
	
}
