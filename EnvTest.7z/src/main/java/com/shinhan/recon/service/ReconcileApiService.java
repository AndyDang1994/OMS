/**
 * 
 */
package com.shinhan.recon.service;

import java.io.File;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.model.BankStatemenTrxInfo;
import com.shinhan.recon.core.model.BankStatementFile;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.core.model.LmsTrxInfo;
import com.shinhan.recon.core.model.ReconcileCommonStatementInfo;
import com.shinhan.recon.repository.entity.TMetadata;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;

/**
 * @author shds01
 *
 */
public interface ReconcileApiService {

	public String generateUserToken(Map<String, Object> inputParams) throws BaseException;
	
	public List<TMetadata> getAllMetadata(Map<String, Object> inputParams, String lookupCode) throws BaseException;
	
	
	public List<BankStatementFile> getListStmtFileMasByDate(Map<String, Object> inputParams) throws BaseException;

	public TOmsStmtFileMas createStmtFileMas(Map<String, Object> inputParams) throws BaseException;
	
	public TOmsStmtFileMas getOneStmtFileMas(Map<String, Object> inputParams) throws BaseException;
	
	public TOmsStmtFileMas updateStmtFileMas(Map<String, Object> inputParams) throws BaseException;
	
	public List<TOmsReconLmsInf> getListTOmsReconLmsInfByDate(Map<String, Object> inputParams) throws BaseException;
	
	public TOmsReconLmsInf createTOmsReconLmsInf(Map<String, Object> inputParams) throws BaseException;
	
	public TOmsReconLmsInf getOneTOmsReconLmsInf(Map<String, Object> inputParams) throws BaseException;
	
	public TOmsReconLmsInf updateTOmsReconLmsInf(Map<String, Object> inputParams) throws BaseException;
	
	public List<TOmsReconStmtInf> getListTOmsReconStmtInfByDate(Map<String, Object> inputParams) throws BaseException;
	
	public TOmsReconStmtInf createTOmsReconStmtInf(Map<String, Object> inputParams) throws BaseException;
	
	public TOmsReconStmtInf getOneTOmsReconStmtInf(Map<String, Object> inputParams) throws BaseException;
	
	public TOmsReconStmtInf updateTOmsReconStmtInf(Map<String, Object> inputParams) throws BaseException;
	
	public BigDecimal countTotalBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException;

	public List<BankStatementLmsTrxInfo> getListBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException;
	
	public List<BankStatementLmsTrxInfo> updateListBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException;
	
	public BigDecimal countTotalUnMatchBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException;
	
	public List<BankStatemenTrxInfo> getUnmatchListBankStatementTrxByDate(Map<String, Object> inputParams) throws BaseException;
	
	public List<BankStatemenTrxInfo> setStatusUnmatchListBankStatement(Map<String, Object> inputParams) throws BaseException;
	
	public BigDecimal countTotalUnMatchLMSTrxByDate(Map<String, Object> inputParams) throws BaseException;
	
	public List<LmsTrxInfo> getUnmatchListLMSTrxByDate(Map<String, Object> inputParams) throws BaseException;
	
	public List<LmsTrxInfo> setStatusUnmatchListLMS(Map<String, Object> inputParams) throws BaseException;
	
	public ReconcileCommonStatementInfo getBankStatementCommonInforByDate(Map<String, Object> inputParams) throws BaseException;
	
	public File exportReconcileReport (Map<String, Object> inputParams) throws BaseException;
	
	public boolean retryReconcileByBankcode(Map<String, Object> inputParams) throws BaseException;

}
