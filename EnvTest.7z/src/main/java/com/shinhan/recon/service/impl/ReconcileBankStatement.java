/**
 * 
 */
package com.shinhan.recon.service.impl;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.UnaryOperator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;

import com.google.gson.JsonArray;
import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.BankTemplateInfo;
import com.shinhan.recon.core.model.statement.BankStatementCommonTemplate;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.CompareBankStatementProcess;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.core.util.ReadFromCSV;
import com.shinhan.recon.core.util.ReadFromExcel;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsReconDisburInf;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;

/**
 * @author shds04
 *
 */
public abstract class ReconcileBankStatement extends AbstractServiceClass {
	
	protected void processLoadReconcileInfo(File file, TBankCommon bankFileVal,List<BankStatementCommonTemplate> bankStatements,List<TOmsStmtFileMas> tOmsStmtFileMasList,List<TOmsReconStmtInf> stmtMatchingList,List<TOmsReconStmtInf> stmtUnMatchingList,
			List<TOmsReconLmsInf> lmsMatchingList,List<TOmsReconLmsInf> lmsUnMatchingList,List<TOmsReconSuspenseInf> suspanseList,List<TOmsReconStmtInf> bankStatementsFinance,List<TOmsReconStmtInf> bankStatementsReversal,List<TOmsReconStmtInf> stmtDebitList)
			throws ServiceRuntimeException, BaseException {
		Map<String, Object> unMatchinglistMap = new HashMap<>();
		Map<String, Object> statementFileMasMap = new HashedMap<String, Object>();
		Map<String, Object> lmsParaMap = new HashMap<>();
		
		unMatchinglistMap.put(APIConstant._BANK_CODE_KEY, bankFileVal.getBankAccNuber());
		unMatchinglistMap.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_PENDING_STATUS);
		unMatchinglistMap.put(APIConstant._START_DATE_KEY, DateUtils.getFirstDayOfLastMonth(DateUtils.DATEFORMAT));
		unMatchinglistMap.put(APIConstant._END_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_BANKCODE_KEY, bankFileVal.getBankAccNuber());
		statementFileMasMap.put(APIConstant.UPLOAD_TRXTYPE_KEY,  APIConstant.LMS_TRX_TYPE_REPAYMENT);
		lmsParaMap.put(APIConstant.UPLOAD_BANKCODE_KEY, bankFileVal.getBankAccNuber());
		lmsParaMap.put(APIConstant.UPLOAD_BANKSTATUS_KEY, APIConstant.LMS_MONEY_IN_TRANSIT);
		lmsParaMap.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		
		List<TOmsReconStmtInf> reconStmtInfs = DTOConverter
				.setCommonTemplateToOmsReconStmtInf(bankStatements, bankFileVal.getBankAccNuber(), 
														APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
																DateUtils.DATEFORMAT), APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT), 1) ;
		getLoanNoFromDescription(reconStmtInfs, oracleOMSNamedQueries.get(APIConstant._REGEX_GET_LOAN_NO).replaceAll("\\s+",""));
		List<TOmsReconStmtInf> unmatchPrevious =  getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService()
				.getListTrxByDate(unMatchinglistMap);
		List<TOmsReconLmsInf>  lmsStatementList = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService()
				.getListLmsTrxByBankCode(lmsParaMap);
		reconStmtInfs.addAll( unmatchPrevious );
		
		tOmsStmtFileMasList.addAll(getRepositoryManagerService()
				.getTomsStmtFileMasManagerRepositoryService().getListUploadByDateAndBankCode(statementFileMasMap)); 
		
		stmtDebitList.addAll(CompareBankStatementProcess.getFinanceList(reconStmtInfs));
		reconStmtInfs.removeAll(stmtDebitList);
		CompareBankStatementProcess.getMatchingList(reconStmtInfs, lmsStatementList,stmtMatchingList,lmsMatchingList);
		String regexFinance =  oracleOMSNamedQueries.get(APIConstant._BANK_REGEX_FINANCE).toLowerCase().replaceAll("\\s+","");
		bankStatementsFinance.addAll(CompareBankStatementProcess.getMatchingListByPattern(stmtDebitList, regexFinance));
		String regexReversal =  oracleOMSNamedQueries.get(APIConstant._BANK_REGEX_REVERSAL).toLowerCase().replaceAll("\\s+","");
		bankStatementsReversal.addAll( CompareBankStatementProcess.getMatchingListByPattern(stmtDebitList, regexReversal));
		
		stmtDebitList.removeAll(bankStatementsFinance);
		stmtDebitList.removeAll(bankStatementsReversal);
		
		stmtUnMatchingList.addAll( CommonUtil.getDiffStmtList(reconStmtInfs, stmtMatchingList));
		lmsUnMatchingList.addAll(CommonUtil.getDiffStmtList(lmsStatementList, lmsMatchingList));
		suspanseList.addAll( DTOConverter.getSuspenseListFromStatement(stmtUnMatchingList));
		
		TOmsStmtFileMas tOmsStmtFileMas = CommonUtil.getFileMasByFileName(file.getName(), tOmsStmtFileMasList);
		lmsMatchingList.stream().forEach(e->{  
			if(DateUtils.isPreviousMonth(e.getTrxDt())) {
				e.setStatusCode(APIConstant.LMS_UPLOAD_PENDING);
			}else {
				e.setStatusCode(APIConstant._BANK_STATEMENT_MATCH_STATUS);
			}
		});
		stmtMatchingList.stream().forEach(e->{
			if(!DateUtils.isPreviousMonth(e.getTrxDt())) {
				e.setStatusCode(APIConstant._BANK_STATEMENT_MATCH_STATUS);
				
			}else {
				e.setStatusCode(APIConstant._BANK_STATEMENT_PENDING_STATUS);
			}
			e.setRefIdFileMas(tOmsStmtFileMas.getId());
		});
		bankStatementsFinance.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_FINANCE_STATUS);
			e.setRefIdFileMas(tOmsStmtFileMas.getId());
		});
	
		stmtUnMatchingList.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_PENDING_STATUS);
			e.setRefIdFileMas(tOmsStmtFileMas.getId());
		});
		lmsUnMatchingList.stream().forEach(e->{
			e.setStatusCode(APIConstant.LMS_MONEY_IN_TRANSIT);
		});
		suspanseList.stream().forEach(e->{
			e.setStatusCode(APIConstant._SUSPENSE_PENDING_STATUS);
		});
		stmtDebitList.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_PENDING_STATUS);
			e.setRefIdFileMas(tOmsStmtFileMas.getId());
		});
	}
	
	protected void processReconcileDataBase(List<TOmsReconStmtInf> stmtMatchingList, List<TOmsReconStmtInf> stmtDebitList,
			List<TOmsReconStmtInf> stmtUnMatchingList, List<TOmsReconLmsInf> lmsMatchingList,
			List<TOmsReconLmsInf> lmsUnMatchingList, List<TOmsReconSuspenseInf> suspanseList,
			List<TOmsReconStmtInf> bankStatementsFinance, List<TOmsReconStmtInf> bankStatementsReversal,
			TOmsStmtFileMas tOmsStmtFileMas) throws Exception {
		HashMap<String, Object> rs = new HashMap<>();
		rs.put(APIConstant._BANK_STATEMENT_UNMATCHING, stmtUnMatchingList);
		rs.put(APIConstant._BANK_LMS_UNMATCHING, lmsUnMatchingList);
		rs.put(APIConstant._BANK_STATEMENT_MATCHING, stmtMatchingList);
		rs.put(APIConstant._BANK_STATEMENT_FINANCE, bankStatementsFinance);
		rs.put(APIConstant._BANK_STATEMENT_REVERSAL, bankStatementsReversal);
		rs.put(APIConstant._BANK_STATEMENT_FINANCE_PENDING, stmtDebitList);
		rs.put(APIConstant._BANK_LMS_MATCHING, lmsMatchingList);
		rs.put(APIConstant._BANK_LMS_UNMATCHING, lmsUnMatchingList);
		rs.put(APIConstant._BANK_SUSPEND_LIST, suspanseList);
		
		if( StringUtils.isBlank(tOmsStmtFileMas.getBankCode())) {
			throw new ServiceRuntimeException("File_Mas is null " + env.getProperty("MSG_004"));
		}
		
		logger.info("***** Start Insert Bank Statement *****");
		createListTOmsReconStmtInfToDB(rs, APIConstant._OMS_RECONBATCH_);
		logger.info("***** End Insert Bank Statement *****");
		logger.info("***** Start Update LMS *****");
		updateListTOmsReconLmsInfToDB(rs, APIConstant._OMS_RECONBATCH_);
		logger.info("***** End Update LMS *****");
		logger.info("***** Start Update Suspense table *****");
		createListTOmsReconSuspInfToDB(rs, APIConstant._OMS_RECONBATCH_);
		logger.info("***** End Update Suspense table *****");
		logger.info("***** Start Update File Mas *****");
		updateTOmsStmtFileMasToDB(tOmsStmtFileMas, APIConstant._OMS_RECONBATCH_);
		logger.info("***** End Update File Mas *****");
	}
	
	protected void processReconcileForReversal(List<TOmsReconStmtInf> reversalInfList, List<TOmsReconStmtInf> stmtList,
			List<TOmsReconLmsInf> lmsList) throws Exception {
		
		for (TOmsReconStmtInf reversalInf : reversalInfList) {
			Map<String, Object> stmtMap = new HashedMap<>();
			stmtMap.put(APIConstant._BANK_CODE_KEY, reversalInf.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, reversalInf.getRefNo());
			stmtMap.put(APIConstant._CR_AMT_KEY, reversalInf.getDrAmt());
			stmtMap.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
			
			List<TOmsReconStmtInf> stmtLInfs  = getRepositoryManagerService()
					.getTomsReconStmtInfManagerRepositoryService().getStatementByRevertRef(stmtMap);
			List<TOmsReconLmsInf> lmsInfs  = getRepositoryManagerService()
					.getTomsReconLmsInfManagerRepositoryService().getListLmsTrxMatchWithRevertRef(stmtMap);
			for (TOmsReconStmtInf tOmsReconStmtInf : stmtLInfs) {
				if(DateUtils.isPreviousMonth(tOmsReconStmtInf.getTrxDt())) {
					tOmsReconStmtInf.setStatusCode(APIConstant._BANK_STATEMENT_REFUND_STATUS);
					reversalInf.setStatusCode(APIConstant._BANK_STATEMENT_REFUND_STATUS);
				}else {
					tOmsReconStmtInf.setStatusCode(APIConstant._BANK_STATEMENT_REVERT_STATUS);
					reversalInf.setStatusCode(APIConstant._BANK_STATEMENT_REVERT_STATUS);
				}
				stmtList.add(tOmsReconStmtInf);
			}
			for (TOmsReconLmsInf tOmsReconLmsInf : lmsInfs) {
				tOmsReconLmsInf.setStatusCode(APIConstant.LMS_CANCEL_TRX);
				lmsList.add(tOmsReconLmsInf);
			}
			
		}
	}
	protected void processReconcileForSuspense(List<TOmsReconStmtInf> reversalInfList,List<TOmsReconStmtInf> matchingList, List<TOmsReconSuspenseInf> stmtList)
			throws ServiceRuntimeException, BaseException {
		for (TOmsReconStmtInf reversalInf : reversalInfList) {
			Map<String, Object> stmtMap = new HashedMap<>();
			stmtMap.put(APIConstant._BANK_CODE_KEY, reversalInf.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, reversalInf.getRefNo());
			stmtMap.put(APIConstant._CR_AMT_KEY, reversalInf.getCrAmt());
			
			List<TOmsReconSuspenseInf> lmsInfs  = getRepositoryManagerService()
					.gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRef(stmtMap);
			for (TOmsReconSuspenseInf tOmsReconSuspenseInf : lmsInfs) {
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_DONE_STATUS);
				stmtList.add(tOmsReconSuspenseInf);
			}
		}
		for (TOmsReconStmtInf matchings : matchingList) {
			Map<String, Object> stmtMap = new HashedMap<>();
			stmtMap.put(APIConstant._BANK_CODE_KEY, matchings.getBankCode());
			stmtMap.put(APIConstant._REF_NO_KEY, matchings.getRefNo());
			stmtMap.put(APIConstant._CR_AMT_KEY, matchings.getCrAmt());
			
			List<TOmsReconSuspenseInf> lmsInfs  = getRepositoryManagerService()
					.gettOmsReconSuspInfManagerRepositoryService().getSuspenseByRef(stmtMap);
			for (TOmsReconSuspenseInf tOmsReconSuspenseInf : lmsInfs) {
				tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_DONE_STATUS);
				stmtList.add(tOmsReconSuspenseInf);
			}
		}
	}
	
	protected List<BankStatementCommonTemplate> getBankStatement(File file, TBankCommon bankVal, Object bankTemplate, Map<String, String> glBaMap) throws Exception {
		ReadFromExcel rw = new ReadFromExcel(file.getAbsolutePath());
		BankTemplateInfo templateInfo = DTOConverter.getBankTemplateInfo(bankVal);
		ArrayList<Map> lsArrMapObject = (ArrayList<Map>) rw.readDataFromExcel(templateInfo.getSheetIndex(), templateInfo.getFromRow(), templateInfo.getHeaderRow());
		if(bankVal.getBankCode().equals(APIConstant.BANK_STATEMENT_AGRIBANK)) {
			//Pattern p = Pattern.compile("[\\d]+[|][\\d]+");
			Pattern p = Pattern.compile(oracleOMSNamedQueries.get(APIConstant._REGEX_GET_REF_AGRIBANK).replaceAll("\\s+", ""));
			for (Map map : lsArrMapObject) {
				map.put("crAmt", "0");
				map.put("drAmt", "0");
				if(String.valueOf(map.get("+/-")).equals("+")) {
					map.put("crAmt", map.get("So Tien Giao dich"));
				}else {
					map.put("drAmt", map.get("So Tien Giao dich"));
				}
				String loanRefNoFromDesc =String.valueOf(map.get("Dien Giai")).toLowerCase().replaceAll(" ", "");
				Matcher matcher = p.matcher(loanRefNoFromDesc);
				String regexString = "";
				if(matcher.find()) {
					regexString = matcher.group(0);
				}
				String[] loanRefNoFromDescArr = regexString.split("\\|");
				System.out.println(loanRefNoFromDescArr);
				if(loanRefNoFromDescArr.length == 2) {
					map.put("refNo", loanRefNoFromDescArr[0]);
					map.put("loanNo", loanRefNoFromDescArr[1]);
				}else {
					map.put("refNo", "ARD" + DateUtils.getSystemDateStr(DateUtils.ddMMyyyyhhmmss));
					map.put("loanNo", " ");
				}
				
			}
		}else if(bankVal.getBankCode().equals(APIConstant.BANK_STATEMENT_OCB_061) || bankVal.getBankCode().equals(APIConstant.NON_BANK_STATEMENT_VIETTEL)) {
			//Pattern p = Pattern.compile("(?<=Ref:).[0-9]+");
			
			Pattern p = Pattern.compile(oracleOMSNamedQueries.get(APIConstant._REGEX_GET_REF_OCB061).toLowerCase().replaceAll("\\s+", ""));
			//Pattern pDes = Pattern.compile(".*thu ho.*");
			Pattern pDes = Pattern.compile(oracleOMSNamedQueries.get(APIConstant._REGEX_EXCPT_OCB061).toLowerCase().replaceAll("\\s+", ""));
			List<Map<String, Object>> deleteList = new ArrayList<>();
			for (Map map : lsArrMapObject) {
				String loanRefNoFromDesc =String.valueOf(map.get("Debit/Credit Ref")).toLowerCase().replaceAll("\\s+", "");
				String desLower = String.valueOf(map.get("Detail Description")).toLowerCase().replaceAll("\\s+", "");
				Matcher matcher = p.matcher(loanRefNoFromDesc);
				String regexString = "";
				
				if(matcher.find()) {
					regexString = matcher.group(0);
				}
				if(!StringUtils.isBlank(regexString)) {
					map.put("refNo", regexString);
				}else {
					map.put("refNo", "SFVC" + DateUtils.getSystemDateStr(DateUtils.ddMMyyyyhhmmss));
				}
				matcher = pDes.matcher(desLower);
				if(matcher.find()) {
					deleteList.add(map);
				}
			}
			if(bankVal.getBankCode().equals(APIConstant.BANK_STATEMENT_OCB_061)){
				lsArrMapObject.removeAll(deleteList);
			}
			
		}
		/** Step 2: import raw excel data to java class and validation */
		JsonArray jsonArrayDocument = (JsonArray) CommonUtil.toPojo(lsArrMapObject, JsonArray.class);
		
		List<String> excelColumn = Arrays.asList(templateInfo.getTemplateColName().split(","));
		Field[] bankStatementProperty = bankTemplate.getClass().getDeclaredFields();
		
		Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping = buildBankStatementMapping(excelColumn, bankStatementProperty);
		List<BankStatementCommonTemplate> bankStatements = super.mapListExcelDataToListBankStatement(jsonArrayDocument, bankStatementMapping, BankStatementCommonTemplate::new);
		if(bankStatements.isEmpty()) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_006"));
		}
		glBaMap.put(APIConstant.GL_OPEN_BALANCE, rw.readFromSpecCell(templateInfo.getSheetIndex(), templateInfo.getGlOpenBlcRow(), templateInfo.getGlOpenBlcCol()));
		glBaMap.put(APIConstant.GL_CLOSE_BALANCE,rw.readFromSpecCell(templateInfo.getSheetIndex(), templateInfo.getGlCloseBlcRow(), templateInfo.getGlCloseBlcCol()));
		return bankStatements;
	}
	protected void processLoadReconcileInfoForNonBank(File file, TBankCommon bankFileVal,List<BankStatementCommonTemplate> bankStatements,List<TOmsStmtFileMas> tOmsStmtFileMasList,List<TOmsReconStmtInf> bankStatementsFinance,List<TOmsReconStmtInf> stmtDebitList)
			throws ServiceRuntimeException, BaseException {
		Map<String, Object> unMatchinglistMap = new HashMap<>();
		Map<String, Object> statementFileMasMap = new HashedMap<String, Object>();
		Map<String, Object> lmsParaMap = new HashMap<>();
		
		unMatchinglistMap.put(APIConstant._BANK_CODE_KEY, bankFileVal.getBankAccNuber());
		unMatchinglistMap.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_PENDING_STATUS);
		unMatchinglistMap.put(APIConstant._START_DATE_KEY, DateUtils.getFirstDayOfLastMonth(DateUtils.DATEFORMAT));
		unMatchinglistMap.put(APIConstant._END_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_BANKCODE_KEY, bankFileVal.getBankAccNuber());
		statementFileMasMap.put(APIConstant.UPLOAD_TRXTYPE_KEY,  APIConstant.LMS_TRX_TYPE_DISBURSAL);
		lmsParaMap.put(APIConstant.UPLOAD_BANKCODE_KEY, bankFileVal.getBankAccNuber());
		lmsParaMap.put(APIConstant.UPLOAD_BANKSTATUS_KEY, APIConstant.LMS_MONEY_IN_TRANSIT);
		
		List<TOmsReconStmtInf> reconStmtInfs = DTOConverter
				.setCommonTemplateToOmsReconStmtInf(bankStatements, bankFileVal.getBankAccNuber(), 
														APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
																DateUtils.DATEFORMAT), APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT), 1) ;
		getLoanNoFromDescription(reconStmtInfs, oracleOMSNamedQueries.get(APIConstant._REGEX_GET_LOAN_NO).replaceAll("\\s+",""));
		tOmsStmtFileMasList.addAll(getRepositoryManagerService()
				.getTomsStmtFileMasManagerRepositoryService().getListUploadByDateAndBankCode(statementFileMasMap)); 
		stmtDebitList.addAll(reconStmtInfs);
		String regexFinance =  oracleOMSNamedQueries.get(APIConstant._BANK_REGEX_FINANCE).toLowerCase().replaceAll("\\s+","");
		bankStatementsFinance.addAll(CompareBankStatementProcess.getMatchingListByPattern(stmtDebitList, regexFinance));
		
		stmtDebitList.removeAll(bankStatementsFinance);
		
		TOmsStmtFileMas tOmsStmtFileMas = CommonUtil.getFileMasByFileName(file.getName(), tOmsStmtFileMasList);
		
		bankStatementsFinance.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_FINANCE_STATUS);
			e.setRefIdFileMas(tOmsStmtFileMas.getId());
		});
		
		stmtDebitList.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_PENDING_STATUS);
			e.setRefIdFileMas(tOmsStmtFileMas.getId());
		});
	}
	
	protected List<BankStatementCommonTemplate> getBankStatementForCSV(File file, TBankCommon bankVal, Object bankTemplate) throws Exception {
		BankTemplateInfo templateInfo = DTOConverter.getBankTemplateInfo(bankVal);
		ReadFromCSV readFromCSV = new ReadFromCSV(file.getAbsolutePath());
		ArrayList<Map> lsArrMapObject = (ArrayList<Map>) readFromCSV.readDataFromCsv(templateInfo.getTemplateColName());
		JsonArray jsonArrayDocument = (JsonArray) CommonUtil.toPojo(lsArrMapObject, JsonArray.class);
		List<String> excelColumn = Arrays.asList(templateInfo.getTemplateColName().split(","));
		Field[] bankStatementProperty = bankTemplate.getClass().getDeclaredFields();
		
		Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping = buildBankStatementMapping(excelColumn, bankStatementProperty);
		List<BankStatementCommonTemplate> bankStatements = super.mapListExcelDataToListBankStatement(jsonArrayDocument, bankStatementMapping, BankStatementCommonTemplate::new);

		return bankStatements;
	}
	
	protected void getLoanNoFromDescription(List<TOmsReconStmtInf> stmtInfs, String regex) {
		
		Pattern p = Pattern.compile(regex);
		
		for (TOmsReconStmtInf tOmsReconStmtInf : stmtInfs) {
			Matcher matcher = p.matcher(tOmsReconStmtInf.getRemark());
			String regexString = "";
			
			if(matcher.find()) {
				regexString = matcher.group(0);
			}
			tOmsReconStmtInf.setLoanNo(regexString);
		}
		
	}
	
	protected void moveFileToDirectory(File srcFile, File desFile) {
		String[] fileName = srcFile.getName().split("\\.");
		String newFileName = "";
		if(fileName.length == 2) {
			newFileName = fileName[0] + "_" + DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss) + "." + fileName[1];
		}else {
			newFileName = srcFile.getName() + "_" + DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss);
		}
		
		CommonUtil.moveFileToDirectory(srcFile, desFile, newFileName);
	}
}
