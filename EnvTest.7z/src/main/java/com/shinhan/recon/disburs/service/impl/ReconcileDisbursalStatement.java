/**
 * 
 */
package com.shinhan.recon.disburs.service.impl;

import java.io.File;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;

import com.google.gson.JsonArray;
import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.BankDisbursInfo;
import com.shinhan.recon.core.model.BankTemplateInfo;
import com.shinhan.recon.core.model.statement.BankStatementCommonTemplate;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.CompareBankStatementProcess;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.core.util.ReadFromExcel;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsReconDisburInf;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;

/**
 * @author shds04
 *
 */
public abstract class ReconcileDisbursalStatement extends AbstractServiceClass {
	
	protected List<TOmsReconDisburInf> getBankStatement(File file, TBankCommon bankVal, Object bankTemplate, Map<String, String> glBaMap) throws Exception {
		ReadFromExcel rw = new ReadFromExcel(file.getAbsolutePath());
		BankTemplateInfo templateInfo = DTOConverter.getBankTemplateInfo(bankVal);
		ArrayList<Map> lsArrMapObject = (ArrayList<Map>) rw.readDataFromExcel(templateInfo.getSheetIndex(), templateInfo.getFromRow(), templateInfo.getHeaderRow());
		/** Step 2: import raw excel data to java class and validation */
		JsonArray jsonArrayDocument = (JsonArray) CommonUtil.toPojo(lsArrMapObject, JsonArray.class);
		
		List<String> excelColumn = Arrays.asList(templateInfo.getTemplateColName().split(","));
		Field[] bankStatementProperty = bankTemplate.getClass().getDeclaredFields();
		
		Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping = buildBankStatementMapping(excelColumn, bankStatementProperty);
		List<BankStatementCommonTemplate> bankStatements = super.mapListExcelDataToListBankStatement(jsonArrayDocument, bankStatementMapping, BankStatementCommonTemplate::new);
		if(bankStatements.isEmpty()) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_006"));
		}
		glBaMap.put(APIConstant.GL_OPEN_BALANCE, rw.readFromSpecCell(templateInfo.getSheetIndex(), templateInfo.getGlOpenBlcRow(), templateInfo.getGlOpenBlcCol()));
		glBaMap.put(APIConstant.GL_CLOSE_BALANCE,rw.readFromSpecCell(templateInfo.getSheetIndex(), templateInfo.getGlCloseBlcRow(), templateInfo.getGlCloseBlcCol()));
		List<TOmsReconDisburInf> reconStmtInfs = DTOConverter
				.setCommonTemplateToOmsReconDisbursalInf(bankStatements, bankVal.getBankAccNuber(), 
														APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), 
																DateUtils.DATEFORMAT), APIConstant._OMS_RECONBATCH_, DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT), 1) ;
		return reconStmtInfs;
	}
	
	protected void processLoadReconcileInfo(File file, TBankCommon bankFileVal,List<TOmsReconDisburInf> reconStmtInfs,List<TOmsStmtFileMas> tOmsStmtFileMasList,List<TOmsReconDisburInf> crShieldList,List<TOmsReconDisburInf> financeList,
			List<TOmsReconDisburInf> revertList,List<TOmsReconDisburInf> MatchingList,List<TOmsReconDisburInf> unMatchingList,List<TOmsReconLmsInf> lmsMatchingList,List<TOmsReconLmsInf> lmsUnMatchingList)
			throws Exception {
		
		Map<String, Object> inputParam = new HashMap<>();
		Map<String, Object> statementFileMasMap = new HashedMap<String, Object>();
		Map<String, Object> lmsParaMap = new HashMap<>();
		
		statementFileMasMap.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_BANKCODE_KEY, bankFileVal.getBankAccNuber());
		statementFileMasMap.put(APIConstant.UPLOAD_TRXTYPE_KEY,  APIConstant.LMS_TRX_TYPE_DISBURSAL);
		lmsParaMap.put(APIConstant.UPLOAD_BANKCODE_KEY, bankFileVal.getBankAccNuber());
		lmsParaMap.put(APIConstant.UPLOAD_BANKSTATUS_KEY, APIConstant.LMS_MONEY_IN_TRANSIT);
		lmsParaMap.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
		List<TOmsReconLmsInf>  lmsStatementList = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService()
				.getListLmsTrxByBankCode(lmsParaMap);
		BankDisbursInfo bankDisbursInfo = (BankDisbursInfo)CommonUtil.toPojo(bankFileVal.getAddInf(), BankDisbursInfo.class);
		CompareBankStatementProcess.getMatchingList(reconStmtInfs, lmsStatementList, MatchingList, lmsMatchingList, bankDisbursInfo.getInnerFee(),bankDisbursInfo.getOuterFee());
		reconStmtInfs.removeAll(MatchingList);
		lmsStatementList.removeAll(lmsMatchingList);
		unMatchingList.addAll(reconStmtInfs);
		lmsUnMatchingList.addAll(lmsStatementList);
		
		tOmsStmtFileMasList.addAll(getRepositoryManagerService()
				.getTomsStmtFileMasManagerRepositoryService().getListUploadByDateAndBankCode(statementFileMasMap)); 
		
		TOmsStmtFileMas tOmsStmtFileMas = CommonUtil.getFileMasByFileName(file.getName(), tOmsStmtFileMasList);
		
		MatchingList.stream().forEach(e->{  
			e.setStatusCode(APIConstant._BANK_STATEMENT_MATCH_STATUS);
			e.setRefIdFileMas(tOmsStmtFileMas.getId());
		});
		lmsMatchingList.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_STATEMENT_MATCH_STATUS);
		});
		lmsUnMatchingList.stream().forEach(e->{
			if(e.getSubStatusCode() == APIConstant._LMS_LOAN_STATUS_ACTIVE) {
				e.setStatusCode(APIConstant.LMS_MONEY_IN_TRANSIT);
			}else if(e.getSubStatusCode() == APIConstant._LMS_LOAN_STATUS_UNACTIVE) {
				e.setStatusCode(APIConstant._BANK_DISBURSAL_STATUS_EXCESS);
			}
			
		});
		for (TOmsReconDisburInf tOmsReconDisburInf : unMatchingList) {
			inputParam.put(APIConstant.UPLOAD_BANKCODE_KEY, tOmsReconDisburInf.getBankCode());
			inputParam.put(APIConstant.LOAN_NO_KEY, tOmsReconDisburInf.getLoanNo());
			inputParam.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_REVERT_STATUS);
			List<TOmsReconDisburInf> disburPreviousRevertInfs = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getDisbursByBankCodeAndStatus(inputParam);
			inputParam.put(APIConstant._STATUS_KEY, APIConstant._BANK_STATEMENT_MATCH_STATUS);
			List<TOmsReconDisburInf> disburPreviousMatchingInfs = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getDisbursByBankCodeAndStatus(inputParam);
			if(disburPreviousRevertInfs.size() > 0 && disburPreviousMatchingInfs.size()>0) {
				for (TOmsReconDisburInf disburInf : disburPreviousRevertInfs) {
					disburInf.setStatusCode(APIConstant._BANK_DISBURSAL_STATUS_RE_DISB);
					unMatchingList.add(disburInf);
				}
				tOmsReconDisburInf.setStatusCode(APIConstant._BANK_DISBURSAL_STATUS_RE_DISB);
				tOmsReconDisburInf.setRefIdFileMas(tOmsStmtFileMas.getId());
			}else {
				tOmsReconDisburInf.setStatusCode(APIConstant._BANK_DISBURSAL_STATUS_PENDING);
				tOmsReconDisburInf.setRefIdFileMas(tOmsStmtFileMas.getId());
			}
			
		}
		
		revertList.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_DISBURSAL_STATUS_REVERTED);
			e.setRefIdFileMas(tOmsStmtFileMas.getId());
		});
		
		crShieldList.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_DISBURSAL_STATUS_CRSHIELD);
			e.setRefIdFileMas(tOmsStmtFileMas.getId());
		});
		financeList.stream().forEach(e->{
			e.setStatusCode(APIConstant._BANK_DISBURSAL_STATUS_FINANCE);
			e.setRefIdFileMas(tOmsStmtFileMas.getId());
		});
	}
	
	protected void getLoanNoFromDescription(List<TOmsReconDisburInf> disburInfs, String regex) {
		
		Pattern p = Pattern.compile(regex);
		
		for (TOmsReconDisburInf tOmsReconDisburInf : disburInfs) {
			Matcher matcher = p.matcher(tOmsReconDisburInf.getRemark());
			String regexString = "";
			
			if(matcher.find()) {
				regexString = matcher.group(0);
			}
			tOmsReconDisburInf.setLoanNo(regexString);
		}
		
	}
	
	protected List<TOmsReconDisburInf> getListMatchPattern(List<TOmsReconDisburInf> disburInfs, String regex){
		Pattern pattern = Pattern.compile(regex.toLowerCase().replaceAll("\\s+", ""));
		Predicate<TOmsReconDisburInf> predicate = e->(pattern.matcher( e.getRemark().toLowerCase().replaceAll("\\s+", "")).find());
		return CompareBankStatementProcess.getMatchingListByPredict(disburInfs, predicate);
	}
	protected void processReconcileDataBase(TOmsStmtFileMas tOmsStmtFileMas,List<TOmsReconDisburInf> crShieldList,List<TOmsReconDisburInf> financeList,
			List<TOmsReconDisburInf> revertList,List<TOmsReconDisburInf> MatchingList,List<TOmsReconDisburInf> unMatchingList,List<TOmsReconLmsInf> lmsMatchingList,List<TOmsReconLmsInf> lmsUnMatchingList) throws Exception {
		HashMap<String, Object> rs = new HashMap<>();
		
		rs.put(APIConstant._BANK_LMS_MATCHING, lmsMatchingList);
		rs.put(APIConstant._BANK_LMS_UNMATCHING, lmsUnMatchingList);
		rs.put(APIConstant._BANK_DISBURS_FINANCE, financeList);
		rs.put(APIConstant._BANK_DISBURS_CRSHIELD, crShieldList);
		rs.put(APIConstant._BANK_DISBURS_REVERT, revertList);
		rs.put(APIConstant._BANK_DISBURS_MATCHED, MatchingList);
		rs.put(APIConstant._BANK_DISBURS_UNMATCH, unMatchingList);
		
		if( StringUtils.isBlank(tOmsStmtFileMas.getBankCode())) {
			throw new ServiceRuntimeException("File_Mas is null " + env.getProperty("MSG_004"));
		}
		
		logger.info("***** Start Insert Bank Disbursed Inf *****");
		createListTOmsReconDisbursToDB(rs, APIConstant._OMS_RECONBATCH_);
		logger.info("***** End Insert Bank Disbursed Inf *****");
		logger.info("***** Start Update LMS *****");
		updateListTOmsReconLmsInfToDB(rs, APIConstant._OMS_RECONBATCH_);
		logger.info("***** End Update LMS *****");
		logger.info("***** Start Update File Mas *****");
		updateTOmsStmtFileMasToDB(tOmsStmtFileMas, APIConstant._OMS_RECONBATCH_);
		logger.info("***** End Update File Mas *****");
	}
	protected void moveFileToDirectory(File srcFile, File desFile) {
		String[] fileName = srcFile.getName().split("\\.");
		String newFileName = "";
		if(fileName.length == 2) {
			newFileName = fileName[0] + "_" + DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss) + "." + fileName[1];
		}else {
			newFileName = srcFile.getName() + "_" + DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss);
		}
		
		CommonUtil.moveFileToDirectory(srcFile, desFile, newFileName);
	}
}
